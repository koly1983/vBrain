vBrain

#Build

At repo rootdir:
> cd ant
> ant clean all

#Install

1) MySQL DB
- install MySQL 5.7.

- add/update MySQL global 'sql_mode' to as belo, in one of the MySQL config files (under /etc/mysql/, mysqld.cnf, or mysql.cnf).

sql_mode=STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION
 
- create database 'vbrain':

  mysql> CREATE DATABASE `vbrain`;

- create DB user 'vbrain' with password 'vbrain':

  mysql> CREATE USER 'vbrain'@'localhost' IDENTIFIED BY 'vbrain';

- grant 'vbrain' user with all privileges on 'vbrain' database:

  mysql> GRANT ALL PRILVILEGES ON vbrain.* TO 'vbrain'@'localhost';

- load one of DB dumps, in <vbrain repo> root/dbdumps to the database

2) Tomcat:
- install JRE 1.8 or JDK 1.8.
- install Tomcat 7.0+, on the same host as MySQL server (default configuration).
- copy <repo root>/dist/vBrain.war to webapps
- restart tomcat (to make sure the .war was deployed)
