(function () {
  'use strict';
  
  var urlName = window.location.origin + "/vBrain";
  
  //var locationPath = "resources/";
  var locationPath = "vBrain/resources/";
 
  var roleList = [];
  
  angular.module('vBrainApp')
    .directive('demoFileModel', function ($parse) {
        return {
            restrict: 'A', //the directive can be used as an attribute only
 
            /*
             link is a function that defines functionality of directive
             scope: scope associated with the element
             element: element on which this directive used
             attrs: key value pair of element attributes
             */
            link: function (scope, element, attrs) {
                var model = $parse(attrs.demoFileModel),
                    modelSetter = model.assign; //define a setter for demoFileModel
 
                //Bind change event on the element
                element.bind('change', function () {
                    //Call apply on scope, it checks for value changes and reflect them on UI
                    scope.$apply(function () {
                        //set the model value
                        modelSetter(scope, element[0].files[0]);
                    });
                });
            }
        };
    })    
    .controller('UserCtrl', ['$scope','$http', '$window', function ($scope, $http, $window) { 
    	
    	if(! $window.sessionStorage.getItem('loginId') || $window.sessionStorage.getItem('loginId') == null){
  			alert("Invalid access! Please login...");
  			
  			window.location.pathname = locationPath + 'index.html';
  		}
    	
    	$scope.ViewProcess =  parseInt($window.sessionStorage.getItem('ViewWorkers'));
    	$scope.ViewUser =  parseInt($window.sessionStorage.getItem('ViewUser'));
    	$scope.ViewPrivilege =  parseInt($window.sessionStorage.getItem('ViewPrivilege'));
    	$scope.DisableUser =  parseInt($window.sessionStorage.getItem('DisableUser'));
    	$scope.CreateUser =  parseInt($window.sessionStorage.getItem('CreateUser'));
    	$scope.processSla = true;
    	
    	$scope.userForm = false;
     
        $scope.uploadFile = function () {
    		 
    		document.getElementById("uploadErrors").innerHTML = "";
            var file = $scope.myFile;
            if($scope.myFile){
		    	$http({
		    		method: 'POST',
		    		url: urlName + "/vbrain/vBrainService/uploadUsers",
		    		headers: { 'Content-Type': undefined },
		    		transformRequest: function(data) {
			    		var formData = new FormData();
			    		
			    		formData.append('file', file);
			    		
			    		return formData;
		    		},
		    		data: {}
		    	}).then(
			   				function(response){
			   					
			   					//alert(response.data.responseData.message);
			   					
			   					
			   					if( response.data.responseData.message == "success"){
	 		   						alert("Users uploaded successfully");
	 		   					}
	 		   					else {
	 		   						alert("Error in upload! Please find the error details under 'Upload Errors' section");
	 		   						
	 		   						document.getElementById("uploadErrors").innerHTML = "<u><b>Upload Errors:</b></u> </br> "+ response.data.responseData.errorReason;
	 		   						
	 		   					}
			   					
			   					
			   					$scope.getUsers();
			   					console.log('User updated for this row');
			   				},
			   				function(e){alert("error: "+e);}
			   			);
	    	 }
	         else{
	             alert("Please select a file to upload!");
	        	 return false;
	         }
    	};
    	
    	 $scope.gridUsers = {};
    	 $scope.gridUsers.enableCellEditOnFocus = true;
    	 
    	// $scope.gridUsers.columnDefs[0].editDropdownOptionsArray = ;
         $scope.gridUsers.columnDefs = [
             { name:'userId', enableCellEditOnFocus:false, enableCellEdit: false, width:150 },
             { name:'firstName', displayName: 'First Name', width:285},
             { name:'lastName', displayName: 'Last Name', width:200 },
             { name:'role', displayName: 'Role',editableCellTemplate: 'ui-grid/dropdownEditor',
            	 width: 280,
                 editDropdownValueLabel: 'name', editDropdownKeyLabel: 'id'
             },
             { name:'delete', width:100, displayName: 'Delete',enableCellEdit: true, enableSorting: false, cellTemplate:'<a class="btn btn-danger btn-xs text-center" style="margin-left: 20px; margin-top:5px;" ng-show="'+$scope.DisableUser+'" ng-click="grid.appScope.removeUser(row.entity.id)"><span class="glyphicon glyphicon-remove"></span></a>' }
         ];
         
         
         
 	    // attache event to save on edit
	   	 	$scope.gridUsers.onRegisterApi =  function (gridApi) {
	   	 		console.log('saving row..')
	          $scope.gridApi = gridApi;
	          //gridApi.rowEdit.on.saveRow($scope, $scope.saveRow);
	          
	          gridApi.edit.on.afterCellEdit($scope, function(rowEntity, colDef, newValue, oldValue) {
	        	    //Do your REST call here via $http.get or $http.post
	        	    //Alert to show what info about the edit is available
	        	  //  alert('Column: ' + colDef.name + ' ID: ' + rowEntity.id + ' hostName: ' + rowEntity.hostName + ' avgEfforts: ' + rowEntity.avgEfforts);
	        	  
	        	  var roleID = rowEntity.role;
	        	  var roleIdSel = "";
	        	  
	        	  //alert("id : "+rowEntity.role);
	        	  
	        		for(var i=0; i<$scope.roles.length; i++){
	         	    	  
	         	    	if(roleID == $scope.roles[i].name){
	         	    		roleIdSel = $scope.roles[i].id;
	         	    	}
	         	    }
	        	  
	        		if(roleIdSel.length > 0){
	        			roleID = roleIdSel;
	        		}
	        		
	        	  
	        	    let endPoint = "editUser";
	        	    $http({
	  		       	  method: 'POST',
	  		       	  url: urlName + "/vbrain/vBrainService/"+endPoint,
	  		       	  data:{
	  			     		 requestParameter: {
	  			     			 user:{
	  			     				id:rowEntity.id,
			     				 	userId:rowEntity.userId,
				     				firstName:rowEntity.firstName,
				     				lastName:rowEntity.lastName,
				     				roleId:roleID
	  			     			 }
	  				      			
	  				      	  }
	  				        },
	  		       	  headers: {
	  		       		   'Content-Type': 'application/json'
	  		       	  }
	  		       	}).then(
	  		   				function(response){
	  		   					
	  		   					//alert(response.data.responseData.message);
	  		   					
	  		   					$scope.getUsers();
	  		   					console.log('User updated for this row');
	  		   				},
	  		   				function(e){alert("error: "+e);}
	  		   			);
	          
	          
	          });
	          
	  		}
	   	 	
         
         
       	
	 	$scope.clearUserFields = function (){
	 		$scope.Id = "";
	 		$scope.userId = "";
	    	$scope.firstName = "";
	    	$scope.surName = "";
	    	$scope.lastName = "";
			$scope.userRole = "";
			    
	 	}
	 	
	 	
	   	 
	   
	 	$scope.getUserRoles = function () {
			 $http({
		       	  method: 'POST',
		       	  url: urlName + "/vbrain/vBrainService/getUserRoles",
		       	  data:{},
		       	  headers: {
		       		   'Content-Type': 'application/json'
		       	  }
		       	}).then(
		   				function(response){
		   					
		   					console.log(response.data.responseData.dataList[0].roles);
		   					$scope.roles = response.data.responseData.dataList[0].roles;
		   					$scope.gridUsers.columnDefs[3].editDropdownOptionsArray = $scope.roles;
		   					
		   					//roleList = $scope.roles;
		   					
		   					//alert("roleList.length : "+roleList.length);
		   				},
		   				function(e){alert("error: "+e);}
		   			);
	   	}
	   	 
	   	$scope.getUsers = function () {
			 $http({
		       	  method: 'POST',
		       	  url: urlName + "/vbrain/vBrainService/getUsers",
		       	  data:{},
		       	  headers: {
		       		   'Content-Type': 'application/json'
		       	  }
		       	}).then(
		   				function(response){
		   					
		   					console.log(response.data.responseData.dataList[0].users);
		   					$scope.users = response.data.responseData.dataList[0].users;
		   					$scope.gridUsers.data = $scope.users;
		   				},
		   				function(e){alert("error: "+e);}
		   			);
	   	}
	   	
	    $scope.addUser = function () {
	    	
	    	 if(!$scope.userId){
	        	  alert("Please enter the User Id");
	        	  return false;
	        	  
	          }
	    	  else if(!$scope.firstName){
	        	  alert("Please enter First Name");
	        	  return false;
	        	  
	          }
	          else if(!$scope.lastName ){
	        	  alert("Please enter Last Name");
	        	  return false;
	          }
	          else if(!$scope.userRole ){
	        	  alert("Please select User Role");
	        	  return false;
	          }
	          
	   	     
	    	var endPoint = "addUser";
	    	
		   	 $http({
		       	  method: 'POST',
		       	  url: urlName + "/vbrain/vBrainService/"+endPoint,
		       	  data:{
			     		 requestParameter: {
			     			 user:{
			     				userId:$scope.userId,
			     				firstName:$scope.firstName,
			     				lastName:$scope.lastName,
			     				roleId:$scope.userRole
			     				
			     			 }
				      			
				      	  }
				        },
		       	  headers: {
		       		   'Content-Type': 'application/json'
		       	  }
		       	}).then(
		   				function(response){
		   					//alert("assignUser ::::: ");
		   					alert(response.data.responseData.message);
		   					
		   				    $scope.clearUserFields();
			   		    	
		   					$scope.getUsers();
		   				},
		   				function(e){alert("error: "+e);}
		   			);
		    };
		    
		    $scope.editUserMode = 0;
		    $scope.id = "";
		   		    
		    $scope.dispUser = function (user) {
		   	     
		    	console.log("disp user function called");
		    	
			 	$scope.userId = user.userId;
		    	$scope.firstName = user.firstName;
		    	$scope.surName = user.surName;
		    	$scope.lastName = user.lastName;
 				$scope.userRoles = user.userRoles;
 				
		    	$scope.editUserMode = 1;
		    	$scope.id = user.id;
		    	
		    	
		    };
		    
		    $scope.editUser = function (userId) {
		   	     
		    	 console.log("edit User function called");
		    	 
			   	 $http({
			       	  method: 'POST',
			       	  url: urlName + "/vbrain/vBrainService/editUser",
			       	  data:{
				     		 requestParameter: {
				     			 user:{	
				     				 	id:userId,
				     				 	userId:$scope.userId,
					     				firstName:$scope.firstName,
					     				surName:$scope.surName,
					     				lastName:$scope.lastName,
					     				roleId:$scope.userRoles
					     				 
					     			 }
					      		}
					        },
			       	  headers: {
			       		   'Content-Type': 'application/json'
			       	  }
			       	}).then(
			   				function(response){
			   					//alert("assignUser ::::: ");
			   					alert(response.data.responseData.message);
			   				},
			   				function(e){alert("error: "+e);}
			   			);
			    };
		    
			    $scope.removeUser = function (userId) {
			   	     
			    	 console.log("remove function called id is " + userId);
			    	 //alert("userId :"+userId);
			    	 
			    	 var r = confirm("Are you sure you want to remove?");
				 		if (r == true) {
			    	 
				   	 $http({
				       	  method: 'POST',
				       	  url: urlName + "/vbrain/vBrainService/disableUser",
				       	  data:{
					     		 requestParameter: {
						      			user:{
						      				id:userId
						      			}
						      		}
						        },
				       	  headers: {
				       		   'Content-Type': 'application/json'
				       	  }
				       	}).then(
				   				function(response){
				   					//alert("assignUser ::::: ");
				   					alert(response.data.responseData.message);
				   					
				   					$scope.getUsers();
				   					
				   				},
				   				function(e){alert("error: "+e);}
				   			);
				 		}
				 		else {
				 			return false;
				 		}
				    };
				    
				    
					$scope.getUsers();
					$scope.getUserRoles();

         }])        
         .filter('mapGender', function() {
        	  
			  	
        	  var genderHash = {
					    1: 'Administrator',
					    2: 'Operation Manager',
					    3: 'Operation Supervisor'
					  };
		 		
        	  	//var genderHash = {};
        	  	
        	  	alert("roleList : "+roleList.length); 
        	  	
        	    //for(var i=0; i<roleList.length; i++){
        	    	 //alert("RoleId : "+roleList[i].id); 
        	    	//genderHash.push([roleList[i].id : roleList[i].name]);
        	    //}
        	      
        	    alert("Role : "+genderHash[1]); 
        	      
				  return function(input) {
				    if (!input){
				      return '';
				    } else {
				      return genderHash[input];
				    }
				  };
		         });

}());
