$(document).ready(function () {
    $("#main tbody").on("click", "td.hubname", function () {
        //alert($(this).text());
        var tableRef = document.getElementById('sub').getElementsByTagName('tbody')[0];
        tableRef.innerHTML = "";
        var hubName = $(this).text();
        $("td.hubname").removeAttr('style');
        $("h4").text("Node status details for selected hub : " + hubName);

        var d = new Date();
        var hour = new String(d.getHours());
        var min = new String(d.getMinutes());
        var sec = new String(d.getSeconds());

        if (hour.length < 2) {
            hour = '0' + hour;
        }
        if (min.length < 2) {
            min = '0' + min;
        }
        if (sec.length < 2) {
            sec = '0' + sec;
        }

        $("h5").text("Last checked : " + hour + ":" + min + ":" + sec);

        angular.element('#angularData').scope().readNodes(hubName);
        $(this).css("font-weight", "bold");
    });
});
(function () {
    'use strict';

    //var urlName = "http://lowcost-env.yv5sv2bh2p.ap-south-1.elasticbeanstalk.com/";
    var urlName = window.location.origin + "/vBrain/";

    //var locationPath = "resources/";
    var locationPath = "vBrain/";



    angular.module('vBrainApp', [])
            .controller('HubsCtrl', ['$scope', '$http', '$window', '$interval', function ($scope, $http, $window, $interval) {

                    //clear all the session values
                    $window.sessionStorage.clear();

                    //Reset headers to avoid OPTIONS request (aka preflight)
                    $http.defaults.headers.common = {};
                    $http.defaults.headers.post = {};
                    $http.defaults.headers.put = {};
                    $http.defaults.headers.patch = {};



                    $scope.readHubs = function () {
                        $http({
                            method: 'POST',
                            url: urlName + "vbrain/vBrainService/getHubStatus",
                            data: {},
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        }).then(function (response) {
                            console.log(response.data.responseData.dataList[0].hub);
                            $scope.hub = response.data.responseData.dataList[0].hub;

                            if ($scope.hub) {

                                $scope.dataList = response.data.responseData.dataList;

                                for (var i = 0; i < $scope.dataList.length; i++) {
                                    var hubName = $scope.dataList[i].hub.hubName;
                                    var status = $scope.dataList[i].hub.status;
                                    var serverName = $scope.dataList[i].hub.serverName;

                                    console.log("hubName :" + hubName + " | status:" + status);

                                    var tableRef = document.getElementById('main').getElementsByTagName('tbody')[0];

                                    // Insert a row in the table at the last row
                                    var newRow = tableRef.insertRow(tableRef.rows.length);

                                    // Insert a cell in the row at index 0
                                    var newCell0 = newRow.insertCell(0);

                                    // Append a text node to the cell
                                    var newText0 = document.createTextNode(serverName);
                                    newCell0.appendChild(newText0);

                                    // Insert a cell in the row at index 1
                                    var newCell1 = newRow.insertCell(1);
                                    newCell1.className = "hubname";

                                    // Append a text node to the cell
                                    var newText1 = document.createTextNode(hubName);
                                    newCell1.appendChild(newText1);

                                    // Insert a cell in the row at index 2
                                    var newCell2 = newRow.insertCell(2);
                                    if (status === 'WEAK') {
                                        newCell2.style.backgroundColor = "red";
                                    } else if (status === 'HEALTHY') {
                                        newCell2.style.backgroundColor = "green";
                                    }else if (status === 'UPGRADED') {
                                        newCell2.style.backgroundColor = "salmon";
                                    }else if (status === 'QUEUED') {
                                        newCell2.style.backgroundColor = "darkred";
                                    }
                                    // Append a text node to the cell
                                    var newText2 = document.createTextNode(status);
                                    newCell2.appendChild(newText2);

                                }


                            } else {
                                alert("Invalid request sent !");
                            }
                        },
                                function (e) {
                                    alert("error: " + e);
                                }
                        );

                    };

                    $scope.submitSync = function () {
                        alert("in");
                        $http({
                            method: 'POST',
                            url: urlName + "vbrain/vBrainService/syncNodes",
                            data: {
                                requestParameter: {
                                    hub: {
                                        serverName: '',
                                        hubName: $scope.hubname,
                                        url: $scope.url,
                                        status: 'HEALTHY'
                                    }
                                }
                            },
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        }).then(function (response) {
                            console.log(response.data.responseData.message);
                            $scope.message = response.data.responseData.message;

                            if ($scope.message) {
                                alert($scope.message);

                            } else {
                                alert("Invalid request sent !");
                            }
                        },
                                function (e) {
                                    alert("error: " + e);
                                }
                        );

                    };

                    $scope.readNodes = function (hubName) {
                        $http({
                            method: 'POST',
                            url: urlName + "vbrain/vBrainService/getNodeStatus",
                            data: {
                                requestParameter: {
                                    hubName: hubName
                                }
                            },
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        }).then(function (response) {
                            console.log(response.data.responseData.dataList[0].node);
                            $scope.node = response.data.responseData.dataList[0].node;

                            if ($scope.node) {

                                $scope.dataList = response.data.responseData.dataList;

                                for (var i = 0; i < $scope.dataList.length; i++) {
                                    var nodeName = $scope.dataList[i].node.nodeName;
                                    var status = $scope.dataList[i].node.status;

                                    console.log("nodeName :" + nodeName + " | status:" + status);

                                    var tableRef = document.getElementById('sub').getElementsByTagName('tbody')[0];

                                    // Insert a row in the table at the last row
                                    var newRow = tableRef.insertRow(tableRef.rows.length);

                                    // Insert a cell in the row at index 0
                                    var newCell1 = newRow.insertCell(0);

                                    // Append a text node to the cell
                                    var newText1 = document.createTextNode(nodeName);
                                    newCell1.appendChild(newText1);

                                    // Insert a cell in the row at index 0
                                    var newCell2 = newRow.insertCell(1);
                                    if (status === 'INACTIVE') {
                                        newCell2.style.backgroundColor = "red";
                                    } else if (status === 'ACTIVE') {
                                        newCell2.style.backgroundColor = "green";
                                    } else if (status === 'UPGRADED') {
                                        newCell2.style.backgroundColor = "pink";
                                    }
                                    // Append a text node to the cell
                                    var newText2 = document.createTextNode(status);
                                    newCell2.appendChild(newText2);
                                }


                            } else {
                                alert("Invalid request sent !");
                            }
                        },
                                function (e) {
                                    alert("error: " + e);
                                }
                        );

                    };

                    //Initiate the Timer object.
                    $scope.Timer = null;

                    //Timer start function.
                    $scope.StartTimer = function () {
                        //Set the Timer start message.
                        $scope.Message = "Timer started. ";

                        //Initialize the Timer to run every 1000 milliseconds i.e. one second.
                        $scope.Timer = $interval(function () {
                            //Display the current time.
                            var tableRef = document.getElementById('main').getElementsByTagName('tbody')[0];
                            tableRef.innerHTML = "";
                            $scope.readHubs();
                        }, 30000);
                    };

                    //Timer stop function.
                    $scope.StopTimer = function () {

                        //Set the Timer stop message.
                        $scope.Message = "Timer stopped.";

                        //Cancel the Timer.
                        if (angular.isDefined($scope.Timer)) {
                            $interval.cancel($scope.Timer);
                        }
                    };

                    angular.element(document.getElementById('main').getElementsByTagName('tbody')).ready(function () {
                        $scope.readHubs();
                        $scope.StartTimer();
                    });


                }]);
})();


