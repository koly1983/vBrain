(function () {
  'use strict';
  
  //var urlName = "http://lowcost-env.yv5sv2bh2p.ap-south-1.elasticbeanstalk.com/";
  var urlName = window.location.origin + "/vBrain/";
  
  //var locationPath = "resources/";
  var locationPath = "vBrain/resources/";

  
  
  angular.module('vBrainApp', ['ngRoute', 'ui.bootstrap'])
  	.controller('LoginCtrl', ['$scope', '$http', '$window', function ($scope, $http, $window) {
  		
  		//clear all the session values
  		$window.sessionStorage.clear();
		
	    //Reset headers to avoid OPTIONS request (aka preflight)
	    $http.defaults.headers.common = {};
	    $http.defaults.headers.post = {};
	    $http.defaults.headers.put = {};
	    $http.defaults.headers.patch = {};
  		
	    $scope.submitUser = function(){
				 $http({
			       	  method: 'POST',
			       	  url: urlName + "vbrain/vBrainService/getUserPrivilege",
			       	  data:{
			     		 requestParameter: {
			     			 user:{
			     				 	userId:$scope.username,
			     				 	password:$scope.password
			     			 }
				      	 }
				      },
			       	  headers: {
			       		   'Content-Type': 'application/json'
			       	  }
			       	}).then(function(response){
	   					console.log(response.data.responseData.dataList[0].user);
	   					$scope.user = response.data.responseData.dataList[0].user;
	   					
	   					if($scope.user){
		   					
		   					$scope.privilages = $scope.user.privilages;
							
							for(var i=0; i<$scope.privilages.length; i++){
								var functionName = $scope.privilages[i].functionName;
								var access = $scope.privilages[i].access;
								
								console.log("functionName :"+functionName+" | access:"+access);
								
							    // Setting a cookie
								$window.sessionStorage.setItem(functionName, access);
							}
							
							$window.sessionStorage.setItem("loginId", $scope.user.userId);
							$window.sessionStorage.setItem("loginRole", $scope.user.role);
							
							if($scope.user.roleId == "1"){
								window.location.pathname = locationPath + 'OrgStructure.html';
								
							}
							else if ($scope.user.roleId == "2"){
								window.location.pathname = locationPath + 'selection.html';
								
								
							}
							else if ($scope.user.roleId == "3"){
								window.location.pathname = locationPath + 'selection.html';
								
								
							}
							else {
								
								window.location.pathname = locationPath + 'selection.html';
							}
							//console.log("Get Cookies Value of Create Group : "+$window.sessionStorage.getItem('CreateGroup'));
		   					
	   					}
	   					else {
	   						alert("Invalid User Name/ Password !");
	   						$scope.password = '';
	   					}
	   				},
	   				function(e){alert("error: "+e);}
			    );
		   	}
		  
		  
		  
		  	
		  /*
		    if($scope.username == 'roger'){
		  		$scope.role = 'Administrator';
		  	    window.location.pathname = 'vBrain/resources/OrgStructure.html';
		  	}
		  	else if($scope.username == 'walter'){
		  		$scope.role = 'Operations Manager';
		  		window.location.pathname = 'vBrain/resources/vbrain.html';
		  	}
		  	else if($scope.username == 'oc'){
		  		$scope.role = 'oc';
		  		window.location.pathname = 'vBrain/resources/vbrain2.html';
		  	}
		  	*/
		  
	  
    
    }]);
})();