(function () {
  'use strict';
  angular.module('vBrainApp', ['ui.tree', 'ngRoute', 'ui.bootstrap','ui.grid','ui.grid.edit', 'ui.grid.cellNav'])

    .config(['$routeProvider', '$compileProvider', function ($routeProvider, $compileProvider) {
      $routeProvider
        .when('/', {
        	controller: 'ReportsCtrl',
            templateUrl: 'views/reportview.html'
        })
        .otherwise({
          redirectTo: '/'
        });

      // testing issue #521
      $compileProvider.debugInfoEnabled(false);
    }]);
})();
