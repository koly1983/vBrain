
(function(){
	'use strict';
	console.log('reports loaded...');
	
    var hostName = window.location.origin + "/vBrain/";
	var locationPath = "vBrain/resources/";

	angular.module('vBrainApp')
    .controller('ReportsCtrl', ['$scope','$http','$window', function ($scope,$http,$window) {
    	if(! $window.sessionStorage.getItem('loginId') || $window.sessionStorage.getItem('loginId') == null){
  			alert("Invalid access! Please login...");
  			window.location.pathname = locationPath + 'index.html';
  		}
    	
    	console.log('reports view loading...');
    	
		$scope.processMetrics = Object();
		$scope.selectedProcess = -1;
        $scope.dropdown1 = {
  			  "rpa": {
  			    "v1": "108", "v2": "19", "v3": "57", "v4": "33", "v5": "52", "v6": "0", "v7": "5", "v8": "12", "v9": "4",
  			    "v10": "4", "v11": "4", "v12": "220", "v13": "76", "v14": "9%", "v15": "25%", "v16": "2", "v17": "7", "v18": "2", "v19": "7", "v20": "28",
  			    "v21": "2", "v22": "22", "v23": "2", "v24": "7", "v25": "2", "v26": "7", "v27": "28",
  			    "v28": "2", "v29": "22", "v30": "2", "v31": "7", "v32": "2", "v33": "7", "v34": "28",
  			    "v35": "2", "v36": "1%", "v37": "22%", "v38": "2", "v39": "7", "v40": "2", "v41": "7", "v42": "28",
  			    "v43": "2", "v44": "22", "v45": "2", "v46": "7", "v47": "2", "v48": "7", "v49": "28", "v50": "22%", "v51": "9"
  			  },
  			  "chart": [17, 52, 30, 91, 9, 33, 45, 12, 34, 32, 22, 11, 33, 66, 77, 12, 1, 2]
  			}

	  	$scope.dropdown2 = {
	  	  "rpa": {
	  	    "v1": "110", "v2": "20", "v3": "58", "v4": "33", "v5": "32", "v6": "0", "v7": "20", "v8": "112", "v9": "14",
	  	    "v10": "49", "v11": "44", "v12": "20", "v13": "6", "v14": "39%", "v15": "29%", "v16": "20", "v17": "27", "v18": "12", "v19": "17", "v20": "16",
	  	    "v21": "3", "v22": "1", "v23": "5", "v24": "545", "v25": "23", "v26": "1212", "v27": "21",
	  	    "v28": "221", "v29": "21312", "v30": "24", "v31": "37", "v32": "2121", "v33": "223", "v34": "2312",
	  	    "v35": "23", "v36": "431%", "v37": "224%", "v38": "432", "v39": "337", "v40": "23", "v41": "127", "v42": "2128",
	  	    "v43": "2544", "v44": "254642", "v45": "454542", "v46": "43227", "v47": "1212", "v48": "721", "v49": "2438", "v50": "1222%", "v51": "921"
	  	  },
	  	  "chart": [22, 12, 3, 8, 9, 22, 11, 33, 23, 55, 66, 12, 12, 2, 3, 1, 23, 65, 7, 6]
	  	}

    	console.log('reports view loading done...');
    	
    	document.getElementById("loginId").innerHTML = $window.sessionStorage.getItem('loginId');
    	document.getElementById("loginRole").innerHTML = $window.sessionStorage.getItem('loginRole');
    	
    	$scope.formatDate = function (date) {
  		  const monthNames = ["January", "February", "March", "April", "May", "June",
  		    "July", "August", "September", "October", "November", "December"
  		  ];

  		  var d = new Date(date),
  		    month = '' + (monthNames[d.getMonth()]),
  		    day = '' + d.getDate(),
  		    year = d.getFullYear();

  		  if (month.length < 2) month = '0' + month;
  		  if (day.length < 2) day = '0' + day;

  		  return [year, month, day].join('-');
  		}

    	$scope.selectOption = function () {
  		  var selectedDropdown = $scope.getValue();
  		  if (selectedDropdown == undefined || selectedDropdown == null) {
  			  return;
  		  }

		  $scope.loadReport();
  		}

	  	$scope.getValue = function () {
	  		  if (document.getElementById('processQueueId') != null &&
		  				document.getElementById('processQueueId') != undefined) {
	  			  $scope.processName = document.getElementById('processQueueId').value;
	  			  return $scope.processName;
	  		  } else {
	  			  return null;
	  		  }
	  		}

    	$scope.char1Click = function (val) {
    		  $scope.reportType = "Today";
			  var date = $scope.formatDate(new Date())
			  if (document.getElementById("tabDates") != null) {
				  document.getElementById("tabDates").innerHTML = date;
			  }
			  $scope.loadReport();
			  if(window.barChart1){
				  window.barChart1.destroy();
				  window.barChart1 = null;
			  }
			  var barChart1 = new Chart(document.getElementById("bar-chart1"), {
			    type: 'bar',
			    data: {
			      labels: ["Buss Errors", "Tech Errors" , "Others"],
			      datasets: [
			        {
			          backgroundColor: ["#3cba9f", "#8e5ea2", "#3e95cd"],
			          data: [$scope.processMetrics.business_exp_txn, $scope.processMetrics.technical_exp_txn, $scope.processMetrics.other_exp_txn]
			        }
			      ]
			    },
			    options: {
			      legend: { display: false },
			      title: {
			        display: false
			      },
			      responsive: false,
			      maintainAspectRatio: true,
			      scales: {
			        xAxes: [{
			          gridLines: {
			            color: "rgba(0, 0, 0, 0)",
			            display: false
			          }

			        }],
			        yAxes: [{
			          gridLines: {
			            color: "rgba(0, 0, 0, 0)",
			          },
			          display: false
			        }]
			      }
			    }

			  });
			  window.barChart1 = barChart1;
			  if(window.barChart1Timeout){
				  clearTimeout(window.barChart1Timeout);
				  window.barChart1Timeout = null;
			  }
			  window.barChart1Timeout = setTimeout(function () {
			    barChart1.render();
			  }, 200);

			  if(window.pieChart1){
				  window.pieChart1.destroy();
				  window.pieChart1 = null;
			  }
			  
			  var pieChart1 = new Chart(document.getElementById("pie-chart1"), {
			    type: 'pie',
			    data: {
			      labels: ["Buss Errors", "Tech Errors", "Others"],
			      datasets: [{
			        label: "Population (millions)",
			        backgroundColor: ["#12a342", "#8e5ea2", "#3e95cd"],
 		          data: [$scope.processMetrics.business_exp_txn, $scope.processMetrics.technical_exp_txn, $scope.processMetrics.other_exp_txn]
			      }]
			    },
			    options: {
			      legend: {
			        position: 'right'
			      },
			      responsive: false,
			      maintainAspectRatio: true,
			      title: {
			        display: true
			      }
			    }
			  });

			  window.pieChart1 = pieChart1;

			  if(window.pieChart1Timeout){
				  clearTimeout(window.pieChart1Timeout);
				  window.pieChart1Timeout = null;
			  }
			  
			  window.pieChart1Timeout = setTimeout(function () {
			    pieChart1.update();
			  }, 200);

			}

    	$scope.char2Click = function (val) {
    		  $scope.reportType = "Previous Day";
			  var date1 = $scope.formatDate(new Date());
			  var d = new Date();
			  var yesterday = d.setDate(d.getDate() - 1);
			  var date2 = $scope.formatDate(yesterday);
			  document.getElementById("tabDates").innerHTML = date2 + '  to  ' + date1;

			  $scope.loadReport();

			  if(window.barChart2){
				  window.barChart2.destroy();
				  window.barChart2 = null;
			  }
			  
			  var barChart2 = new Chart(document.getElementById("bar-chart2"), {
			    type: 'bar',
			    data: {
			      labels: ["Buss Errors", "Tech Errors" , "Others"],
			      datasets: [
			        {
			          backgroundColor: ["#8e5ea2", "#3e95cd"],
			          data: [$scope.processMetrics.business_exp_txn, $scope.processMetrics.technical_exp_txn, $scope.processMetrics.other_exp_txn]
			        }
			      ]
			    },
			    options: {
			      legend: { display: false },
			      responsive: false,
			      maintainAspectRatio: true,
			      tooltipTemplate: "<%= value %>%",
			      title: {
			        display: false
			      },
			      scales: {
			        xAxes: [{
			          gridLines: {
			            color: "rgba(0, 0, 0, 0)",
			            display: false
			          }

			        }],
			        yAxes: [{
			          gridLines: {
			            color: "rgba(0, 0, 0, 0)",
			          },
			          display: false
			        }]
			      }
			    }

			  });
			  window.barChart2 = barChart2;

			  if(window.barChart2Timeout){
				  clearTimeout(window.barChart2Timeout);
				  window.barChart2Timeout = null;
			  }
			  
			  window.barChart2Timeout = setTimeout(function () {
			    barChart2.update();
			  }, 200);
			  
			  if(window.pieChart2){
				  window.pieChart2.destroy();
				  window.pieChart2 = null;
			  }
			  
			  var pieChart2 = new Chart(document.getElementById("pie-chart2"), {
			    type: 'pie',
			    data: {
   		          labels: ["Buss Errors", "Tech Errors" , "Others"],
			      datasets: [{
			        label: "Population (millions)",
			        backgroundColor: ["#8e5ea2", "#3e95cd"],
 		            data: [$scope.processMetrics.business_exp_txn, $scope.processMetrics.technical_exp_txn, $scope.processMetrics.other_exp_txn]
			      }]
			    },
			    options: {
			      title: {
			        display: true
			      },
			      responsive: false,
			      maintainAspectRatio: true,
			      legend: {
			        position: 'right'
			      }
			    }
			  });
			  window.pieChart2 = pieChart2;

			  if(window.pieChart2Timeout){
				  clearTimeout(window.pieChart2Timeout);
				  window.pieChart2Timeout = null;
			  }
			  
			  window.pieChart2Timeout = setTimeout(function () {
			    pieChart2.update();
			  }, 200);

			}

    	$scope.char3Click = function (val) {
  		      $scope.reportType = "MTD";
			  var date1 = $scope.formatDate(new Date());
			  var d = new Date();
			  var prevMonth = d.setMonth(d.getMonth() - 1);
			  var date2 = $scope.formatDate(prevMonth);
			  document.getElementById("tabDates").innerHTML = date2 + '  to  ' + date1;

			  $scope.loadReport();

			  if(window.barChart3){
				  window.barChart3.destroy();
				  window.barChart3 = null;
			  }
			  
			  var barChart3 = new Chart(document.getElementById("bar-chart3"), {
			    type: 'bar',
			    data: {
			      labels: ["Buss Errors", "Tech Errors", "Others"],
			      datasets: [
			        {
			          backgroundColor: ["#3cba9f", "#8e5ea2", "#3e95cd"],
			          data: [$scope.processMetrics.business_exp_txn, $scope.processMetrics.technical_exp_txn, $scope.processMetrics.other_exp_txn]
			        }
			      ]
			    },
			    options: {
			      legend: { display: false },
			      responsive: false,
			      maintainAspectRatio: true,
			      title: {
			        display: false
			      },
			      scales: {
			        xAxes: [{
			          gridLines: {
			            color: "rgba(0, 0, 0, 0)",
			            display: false
			          }
			        }],
			        yAxes: [{
			          gridLines: {
			            color: "rgba(0, 0, 0, 0)",
			          },
			          display: false
			        }]
			      }
			    }

			  });
			  window.barChart3 = barChart3;

			  if(window.barChart3Timeout){
				  clearTimeout(window.barChart3Timeout);
				  window.barChart3Timeout = null;
			  }
			  
			  window.barChart3Timeout = setTimeout(function () {
			    barChart3.render();
			  }, 200);

			  if(window.pieChart3){
				  window.pieChart3.destroy();
				  window.pieChart3 = null;
			  }
			  
			  var pieChart3 = new Chart(document.getElementById("pie-chart3"), {
			    type: 'pie',
			    data: {
			      labels: ["Buss Errors", "Tech Errors", "Errors"],
			      datasets: [{
			        label: "Population (millions)",
			        backgroundColor: ["#8eada2", "#8e5ea2", "#3e95cd"],
   		            data: [$scope.processMetrics.business_exp_txn, $scope.processMetrics.technical_exp_txn, $scope.processMetrics.other_exp_txn]
			      }]
			    },
			    options: {
			      title: {
			        display: true
			      },
			      responsive: false,
			      maintainAspectRatio: true,
			      legend: {
			        position: 'right'
			      }
			    }
			  });
			  window.pieChart3 = pieChart3;

			  if(window.pieChart3Timeout){
				  clearTimeout(window.pieChart3Timeout);
				  window.pieChart3Timeout = null;
			  }
			  
			  window.pieChart3Timeout = setTimeout(function () {
			    pieChart3.render();
			  }, 200);

			}

    	$scope.char4Click = function () {
    		  $scope.reportType = "YTD";
			  var date1 = $scope.formatDate(new Date());
			  var d = new Date();
			  var prevYear = d.setYear(d.getFullYear() - 1);
			  var date2 = $scope.formatDate(prevYear);
			  document.getElementById("tabDates").innerHTML = date2 + '  to  ' + date1;
			  
			  $scope.loadReport();

			  if(window.barChart4){
				  window.barChart4.destroy();
				  window.barChart4 = null;
			  }
			  var barChart4 = new Chart(document.getElementById("bar-chart4"), {
			    type: 'bar',
			    data: {
			      labels: ["Buss Errors", "Tech Errors", "Others"],
			      datasets: [
			        {
			          backgroundColor: ["#3cba9f", "#8e5ea2", "#3e95cd"],
			          data: [$scope.processMetrics.business_exp_txn, $scope.processMetrics.technical_exp_txn, $scope.processMetrics.other_exp_txn]
			        }
			      ]
			    },
			    options: {
			      legend: { display: false },
			      responsive: false,
			      maintainAspectRatio: true,
			      title: {
			        display: false
			      },
			      scales: {
			        xAxes: [{
			          gridLines: {
			            color: "rgba(0, 0, 0, 0)",
			            display: false
			          },
			        }],
			        yAxes: [{
			          gridLines: {
			            color: "rgba(0, 0, 0, 0)",
			          },
			          display: false
			        }]
			      }
			    }

			  });
			  window.barChart4 = barChart4;

			  if(window.barChart4Timeout){
				  clearTimeout(window.barChart4Timeout);
				  window.barChart4Timeout = null;
			  }
			  
			  window.barChart4Timeout = setTimeout(function () {
			    barChart4.render();
			  }, 200);

			  if(window.pieChart4){
				  window.pieChart4.destroy();
				  window.pieChart4 = null;
			  }
			  var pieChart4 = new Chart(document.getElementById("pie-chart4"), {
			    type: 'pie',
			    data: {
			      labels: ["Buss Errors", "Tech Error", "Others"],
			      datasets: [{
			        backgroundColor: ["#3aaacd", "#8e5ea2", "#3e95cd"],
   		            data: [$scope.processMetrics.business_exp_txn, $scope.processMetrics.technical_exp_txn, $scope.processMetrics.other_exp_txn]
			      }]
			    },
			    options: {
			      title: {
			        display: true
			      },
			      responsive: false,
			      maintainAspectRatio: true,
			      legend: {
			        position: 'right'
			      }
			    }
			  });
			  window.pieChart4 = pieChart4;

			  if(window.pieChart4Timeout){
				  clearTimeout(window.pieChart4Timeout);
				  window.pieChart4Timeout = null;
			  }
			  
			  window.pieChart4Timeout = setTimeout(function () {
			    pieChart4.render();
			  }, 200);

			}
    	
    	$scope.char5Click = function () {
    		
    	}

    	$scope.menuAction = function (val) {
		  
		  document.getElementById("t" + val).className = "tabEnable";
		  document.getElementById("tab" + val).style.display = "block";
		  for (var i = 0; i < 6; i++) {

		    if (i != val) {
		      document.getElementById("t" + i).className = "tabDisable";
		      document.getElementById("tab" + i).style.display = "none";
		    }
		  }
		  if(val==0 || val==5) {
			  $scope.hideProcessQueue = true;
		  } else {
			  $scope.hideProcessQueue = false;
		  }
		}
    	
    	$scope.getAllProcesses = function() {
    		var processRequest = {
    				method: 'POST',
    				url: hostName+'vbrain/vBrainService/getAllProcess',
    				headers: {
    			       'Content-Type': 'application/json'
    				},
    				data: {
    					 "requestParameter": {
    				    }
    				}
    			};
			$http(processRequest).then(
					function(response){
						var processes = response.data.responseData.dataList;
						console.log("processes = " + JSON.stringify($scope.processes));
						if (processes != null && processes.length > 0 && processes[0].groups != null) {
	         				$scope.processes = processes[0].groups;
	         				if ($scope.selectedProcess == -1) {
	         					$scope.selectedProcess = $scope.processes[0].name;
	         				}
						} else {
							$scope.processes = Object();
						}
					},
					function(e){
						alert("error: "+e);
						$scope.processes = Object();
					}
				);
    	}
    	
    	$scope.loadReport = function() {
    		
    		if ($scope.processName == undefined || $scope.processName == null ||
    				$scope.reportType == undefined || $scope.reportType == null) {
    			console.log("Invalid reportType or processName")
    			return;
    		}
    		var reportRequest = {
				method: 'POST',
				url: hostName+'vbrain/vBrainService/getReports',
				headers: {
			       'Content-Type': 'application/json'
				},
				data: {
					 "requestParameter": {
						 	"processName":$scope.processName,
						 	"reportType":$scope.reportType,
				    }
				}
			};
    		var processName = $scope.processName;
    		var reportType = $scope.reportType;
			$http(reportRequest).then(
				function(response){
					$scope.reports = response.data.responseData.dataList;
					console.log("reports = " + JSON.stringify($scope.reports));
					if ($scope.reports != null && $scope.reports.length > 0 && $scope.reports[0].processMetrics != null) {
         				$scope.processMetrics = $scope.reports[0].processMetrics; 
					} else {
						$scope.resetProcessMetrics();
					}
				},
				function(e){
					alert("error: "+e);
					$scope.resetProcessMetrics();
				}
			);
    	}
    	
    	$scope.resetProcessMetrics = function() {
    		$scope.processMetrics.rpa_count = "N/A";
    		$scope.processMetrics.completd_txn = "N/A";
    		$scope.processMetrics.exception_txn = "N/A";
    		$scope.processMetrics.pending_txn = "N/A";
    		$scope.processMetrics.technical_exp_txn = "N/A";
    		$scope.processMetrics.business_exp_txn = "N/A";
    		$scope.processMetrics.other_exp_txn = "N/A";
    		$scope.processMetrics.avg_bot_txn_minutes = "N/A";
    		$scope.processMetrics.avg_human_txn_minutes = "N/A";
    		$scope.processMetrics.total_bot_txn_minutes = "N/A";
    		$scope.processMetrics.total_human_txn_minutes = "N/A";
    		$scope.processMetrics.bot_efficiency = 0;
    		$scope.processMetrics.human_efficiency = 0;
    		$scope.processMetrics.bot_minutes_saved = 0;
    		$scope.processMetrics.human_minutes_saved = 0;
    	}

		setTimeout(function(){
			$scope.char1Click();
			$scope.selectOption();
		}, 200)
	
		var date = $scope.formatDate(new Date())
	    $scope.tabDates= date
	    
	    $scope.getAllProcesses();
		$scope.hideProcessQueue = true;
    }]);
}());
    	




