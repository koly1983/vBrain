(function () {
  'use strict';

  var urlName = window.location.origin + "/vBrain";

  angular.module('demoApp')
    .controller('BasicExampleCtrl', ['$scope','$http', function ($scope,$http) {
     
      $scope.removeItem = function (nodeId) {
    	//alert(nodeId); 
    	
    	 $http({
       	  method: 'POST',
       	  url: urlName + '/vbrain/vBrainService/disableGroup',
       	  data:{
	     		 requestParameter: {
	      			group:{
	      			 id:nodeId
	      			}
	      		}
	        },
	       	headers: {
	       		   'Content-Type': 'application/json'
	        }
       	}).then(
   				function(response){
   					console.log('adding node response here');
   					console.log(response.message);
   					//$scope.data = response.data.responseData.dataList[0].groups;
   					
   					alert(response.data.responseData.message);
   				},
   				function(e){alert("error: "+e);}
   			);
   	
          $scope.getGroups();
    	
    	
    	
        //scope.remove();
        
      };

      $scope.toggle = function (scope) {
        scope.toggle();
      };

      $scope.moveLastToTheBeginning = function () {
        var a = $scope.data.pop();
        $scope.data.splice(0, 0, a);
      };

      $scope.newSubItem = function (parentId, parentNodeName) {
    	  
    	  
    	  //alert(parentId)
    	  $scope.newItem(parentId);
    	  $scope.parentNodeName = parentNodeName;
    	  /*$scope.isNew = true;
    	  
    	  var nodeData = scope.$modelValue;
    	  
    	  alert("sub item : "+ nodeData);
          
          console.log(nodeData)
          nodeData.nodes.push({
	          id: nodeData.id * 10 + nodeData.nodes.length,
	          title: nodeData.title + '.' + (nodeData.nodes.length + 1),
          nodes: []
        });
          
          
          */
      };
      
      $scope.userForm = true;
      $scope.isNew = false;
      
      $scope.newItem = function (parentId, parentNodeName) {
         //$scope.data = [];
    	  $scope.parentNodeName = parentNodeName;
    	  $scope.description = '';
    	  $scope.botNodeName = '';
    	  $scope.nodeTypeValue = '';
    	  
    	  $scope.isNew = true;
          $scope.userForm = false;
          $scope.dataId = '';
          $scope.dataParantId = parentId;
          $scope.dataParantGroupId = '0'
         
      }
          
      $scope.addNode = function(){
          
    	  console.log('addNode function called');
    	  alert('addNode function called')
    	  
         // console.log($scope.dataId+$scope.dataParantId+$scope.dataParantGroupId)
          //console.log('edit data above');
          $scope.userForm = false;
          var nodeData = $scope.data;
          
          //alert($scope.isNew);
          
          if( !$scope.isNew ){

        	  
	    	  
        	  
             $scope.dataAPIUrl = urlName + '/vbrain/vBrainService/updateGroups';
             $scope.newNode = {
            		 requestParameter: {
             			group:{
             			 id:$scope.dataId,
             			 name:$scope.botNodeName,
             			 description:$scope.description,
             			 type:$scope.nodeTypeValue,
             			 parentId: $scope.dataParantId,
             			 parentGroupId: $scope.dataParantGroupId
             			}
             		}
               };
          }
          else{
	       		console.log('data parent id is '+$scope.dataParantId);
	        	//$scope.dataParantId = '0'
	        	$scope.dataParantGroupId = '0'
        		$scope.dataAPIUrl = urlName + '/vbrain/vBrainService/addGroups';
        		$scope.newNode = {requestParameter: {
        			group:{
           			
           			 name:$scope.botNodeName,
           			 description:$scope.description,
           			 type:$scope.nodeTypeValue,
           			 parentId: $scope.dataParantId,
           			 parentGroupId: $scope.dataParantGroupId
           			}
           		}
              };
            }
                    
          console.log($scope.newNode)
          console.log($scope.dataAPIUrl);
          
          //alert($scope.dataAPIUrl);
         
          /* call add node url here with form data */
          $http({
        	  method: 'POST',
        	  url: $scope.dataAPIUrl,
        	  data:$scope.newNode,
        	  headers: {
        		   'Content-Type': 'application/json'
        	  }
        	}).then(
    				function(response){
    					console.log('adding node response here');
    					console.log(response.message);
    					//$scope.data = response.data.responseData.dataList[0].groups;
    					
    					alert(response.data.responseData.message);
    				},
    				function(e){alert("error: "+e);}
    			);
    	
           $scope.getGroups();
           
       }
          
    
        
       $scope.editNode = function (refNode) {
         /*  console.log(refNode.$element[0].childNodes[5].getAttribute('data-id'))
           console.log(refNode.$element[0].childNodes[5].getAttribute('data-parentid'))
           console.log(refNode.$element[0].childNodes[5].getAttribute('data-parantgroupid'))
          */ 
           
           
           //$scope.userForm = false;
    	   $scope.isNew = false;
    	   
           $scope.fieldName = refNode.$element[0].innerText;
           $scope.botNodeName = $scope.fieldName;
           
           
           if(refNode.$element[0].childNodes[5].getAttribute('data-id') == null){
        	   var dataHtmlNode = refNode.$element[0].childNodes[3];
        	  
        	   
           }else{
        	   var dataHtmlNode = refNode.$element[0].childNodes[5];
        	   
        	   
           }
           $scope.dataId = dataHtmlNode.getAttribute('data-id');
           $scope.dataParantId = dataHtmlNode.getAttribute('data-parentid')
           $scope.dataParantGroupId = dataHtmlNode.getAttribute('data-parantgroupid')
           $scope.nodeTypeValue = dataHtmlNode.getAttribute('data-nodetype')
           $scope.description = dataHtmlNode.getAttribute('data-description')
           console.log($scope.dataId+$scope.dataParantId+$scope.dataParantGroupId+$scope.description)
           $scope.userForm = false;
           
           
           
           $scope.getGroupUsers($scope.dataId);
           $scope.getAllUsers($scope.dataId);
           
          
           
      };
        
      $scope.collapseAll = function () {
        $scope.$broadcast('angular-ui-tree:collapse-all');
      };

      $scope.expandAll = function () {
        $scope.$broadcast('angular-ui-tree:expand-all');
      };

      
      $scope.dataNodeUrl = urlName + "/vbrain/vBrainService/getGroups";
      $http({
    	  method: 'POST',
    	  url: $scope.dataNodeUrl,
    	  data:{},
    	  headers: {
    		   'Content-Type': 'application/json'
    	  }
    	}).then(
				function(response){
					
					console.log(response.data.responseData.dataList[0].groups);
					$scope.data = response.data.responseData.dataList[0].groups;
					
					
				},
				function(e){alert("error: "+e);}
			);
      
      
      $scope.getGroups = function () {
    	  
    	  //alert("getGroups");
          
    	  $http({
        	  method: 'POST',
        	  url: $scope.dataNodeUrl,
        	  data:{},
        	  headers: {
        		   'Content-Type': 'application/json'
        	  }
        	}).then(
    				function(response){
    					
    					console.log(response.data.responseData.dataList[0].groups);
    					$scope.data = response.data.responseData.dataList[0].groups;
    					
    					
    				},
    				function(e){alert("error: "+e);}
    			);
     };
     
     
     //$scope.users = {};
     
     $scope.getGroupUsers = function (groupId) {
   	     
    	 alert("groupId : "+groupId)
    	 
	   	 $http({
	       	  method: 'POST',
	       	  url: urlName + "/vbrain/vBrainService/getGroupUsers",
	       	  data:{
		     		 requestParameter: {
			      			groupId:groupId
			      		}
			        },
	       	  headers: {
	       		   'Content-Type': 'application/json'
	       	  }
	       	}).then(
	   				function(response){
	   					
	   					console.log(response.data.responseData.dataList[0].group);
	   					$scope.users = response.data.responseData.dataList[0].group.users;
	   					
	   					
	   				},
	   				function(e){alert("error: "+e);}
	   			);
	    };
	    
	    
	    $scope.getAllUsers = function (groupId) {
	   	     
	    	 //alert("getAllUsers | groupId : "+groupId)
	    	 
		   	 $http({
		       	  method: 'POST',
		       	  url: urlName + "/vbrain/vBrainService/getUsers",
		       	  data:{
			     		 requestParameter: {
				      			groupId:groupId
				      		}
				        },
		       	  headers: {
		       		   'Content-Type': 'application/json'
		       	  }
		       	}).then(
		   				function(response){
		   					
		   					console.log(response.data.responseData.dataList[0].group);
		   					$scope.allUsers = response.data.responseData.dataList[0].group.users;
		   					
		   					
		   				},
		   				function(e){alert("error: "+e);}
		   			);
		    };
		    
		    
		    
		    
		    $scope.assignUser = function () {
		   	     
		    	 //alert("$scope.dataId : "+$scope.dataId);
		    	 
			   	 $http({
			       	  method: 'POST',
			       	  url: urlName + "/vbrain/vBrainService/addGroupUsers",
			       	  data:{
				     		 requestParameter: {
					      			groupId:$scope.dataId,
					      			userId:$scope.aUsers
					      		}
					        },
			       	  headers: {
			       		   'Content-Type': 'application/json'
			       	  }
			       	}).then(
			   				function(response){
			   					//alert("assignUser ::::: ");
			   					alert(response.data.responseData.message);
			   					
			   					$scope.getGroupUsers($scope.dataId);
			   				},
			   				function(e){alert("error: "+e);}
			   			);
			    };
			    
			   
	
      
     /* 
      $scope.data = [
        {
	        'id': 1,
	        'title': 'Nodex',
	        'type': 'Bot Type',
	        'nodes': [
	          {
	            'id': 21,
	            'title': 'node1.1',
	            'type': 'Bot Type 1.1',
	            'nodes': [
	              {
	                'id': 111,
	                'title': 'Node 1.1.1',
	                'type': 'Bot Type 1.1.1',
	                'nodes': []
	              }
	            ]
	          }          
	        ]
	      },
	      {
	        'id': 1,
	        'title': 'NodeY',
	        'type': 'Bot Type',
	        'nodes': [
	          {
	            'id': 1,
	            'title': 'node1.1',
	            'type': 'Bot Type 1.1',
	            'nodes': [
	              {
	                'id': 1,
	                'title': 'Node 1.1.1',
	                'type': 'Bot Type 1.1.1',
	                'nodes': []
	              }
	            ]
	          }          
	        ]
	      }
        
      ];  */
    }]);

}());
