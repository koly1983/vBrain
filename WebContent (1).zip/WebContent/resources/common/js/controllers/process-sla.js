(function () {
	'use strict';

	var urlName = window.location.origin + "/vBrain/";

	var locationPath = "vBrain/resources/";


	angular.module('vBrainApp')
	.controller('ProcessSlaCtrl', ['$scope','$http', '$window', function ($scope,$http, $window) {

		if(! $window.sessionStorage.getItem('loginId') || $window.sessionStorage.getItem('loginId') == null){
			alert("Invalid access! Please login...");

			window.location.pathname = locationPath + 'index.html';
		}

		$scope.ViewProcess =  parseInt($window.sessionStorage.getItem('ViewWorkers'));
		$scope.ViewUser =  parseInt($window.sessionStorage.getItem('ViewUser'));
		$scope.ViewPrivilege =  parseInt($window.sessionStorage.getItem('ViewPrivilege'));
		$scope.processSla = true;

		var getAllBusinessProcesses = function() {
			var postReq = {
					method : 'POST',
					url : urlName + 'vbrain/vBrainService/getBusinessProcesses',
					headers : {
						'Content-Type' : 'application/json'
					},
					data : {}
			};
			$http(postReq)
			.then(function(response) {
				$scope.businessProcesses = response.data.responseData.dataList[0].groups;
			},
			function(e) {
				console.log("error: " + e);
			});
		}

		var getSlaConfigurations = function() {
			var postReq = {
					method : 'POST',
					url : urlName + 'vbrain/vBrainService/getSlaConfigurations',
					headers : {
						'Content-Type' : 'application/json'
					},
					data : {}
			};
			$http(postReq)
			.then(function(response) {
				var dataList = response.data.responseData.dataList;
				if(dataList && dataList.length > 0) {
					var slaConfigurationsList = dataList[0].businessProcessSlas;
					$scope.slaConfigurationsList = response.data.responseData.dataList[0].businessProcessSlas;
				}
			},
			function(e) {
				console.log("error: " + e);
			});
		}

		getAllBusinessProcesses();
		getSlaConfigurations();

		$scope.configureSla = function() {
			if(!$scope.bpId || !$scope.slaTime || !$scope.emailAddress) {
				alert("Error in configuring SLA Time. Please select all mandatory fields!!!")
				return;
			}
			var dataAPIUrl = urlName + '/vbrain/vBrainService/configureSla';
			var newNode = {
					requestParameter : {
						businessProcessSla : {
							bpId : $scope.bpId,
							bpName:"",
							slaTime : $scope.slaTime,
							emailAddress : $scope.emailAddress
						}
					}
			};
			$http({
				method : 'POST',
				url : dataAPIUrl,
				data : newNode,
				headers : {
					'Content-Type' : 'application/json'
				}
			}).then(function(response) {
				console.log(response.data);
				//getSlaConfigurations();
				alert(response.data.responseData.message);
				window.location.reload();

			}, function(e) {
				console.log("error: " + e);
			});

		};

		var setSlaEditMode = function(bpId, inEditMode) {
			for(var i = 0; i < $scope.slaConfigurationsList.length; i++) {

				if($scope.slaConfigurationsList[i].bpId == bpId) {
					$scope.slaConfigurationsList[i].inEditMode = inEditMode;

					break;
				}
			}
		}

		$scope.editSla = function (bpId) {
			setSlaEditMode(bpId, true);
		}

		$scope.deleteSlaConfiguration = function (bpId) {
			var r = confirm("Are you sure you want to delete the SLA Configuration?");
			if (r == true) {
				var postReq = {
						method : 'POST',
						url : urlName + 'vbrain/vBrainService/deleteSlaConfiguration',
						headers : {
							'Content-Type' : 'application/json'
						},
						data : {
							"requestParameter" : {
								"businessProcessId" : bpId
							}
						}
				};
				$http(postReq)
				.then(function(response) {
					alert(response.data.responseData.message);
					window.location.reload();
				},
				function(e) {
					console.log("error: " + e);
				});
			}
		};

		$scope.saveSlaConfiguration = function (sla) {
			var dataAPIUrl = urlName + '/vbrain/vBrainService/updateSlaConfiguration';
			var newNode = {
					requestParameter : {
						businessProcessSla : {
							id: sla.id,
							bpId: sla.bpId,
							bpName: sla.bpName,
							slaTime: sla.slaTime,
							emailAddress: sla.emailAddress
						}
					}
			};

			$http({
				method : 'POST',
				url : dataAPIUrl,
				data : newNode,
				headers : {
					'Content-Type' : 'application/json'
				}
			}).then(function(response) {
				console.log(response.data);
				alert(response.data.responseData.message);
				setSlaEditMode(sla.bpId, false);

			}, function(e) {
				console.log("error: " + e);
			});
		}

		$scope.cancelUpdate = function (bpId) {
			setSlaEditMode(bpId, false);
		}


	}]);

}());
