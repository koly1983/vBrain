(function() {
	'use strict';
	console.log('reports loaded...');

	var hostName = window.location.origin + "/vBrain/";
	var locationPath = "vBrain/resources/";

	angular.module('vBrainApp')
		.controller('SnapshotCtrl', ['$scope', '$http', '$window', function($scope, $http, $window) {

			var getSnapshotList = function() {
				var getReq = {
						method : 'GET',
						url : hostName + 'vbrain/vBrainService/getSnapshotList'
					};
				$http(getReq)
					.then(function(response) {
						$scope.snapshotList = response.data;
						if($scope.snapshotList.length > 0) {
							$scope.snapshotTime = $scope.snapshotList[0].snapshot_time;
						}
					},
					function(e) {
						console.log("error: " + e);
					});
			};
			
			getSnapshotList();

		} ]);
}());
