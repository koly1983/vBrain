var domain = {
	"dev_auth" : "https://oneclaimsvcdev.aig.net:13420/",
	"dev_omniture_account" : "cebwa-travelguard-dev",
	"integ_auth" : "https://oneclaimsvcinteg.aig.net:13440/",
	"qa_auth" : "https://www-272q.aig.com/",
	"model_auth" : "https://www-272m.aig.com/",
	"prod_auth" : "https://www-272.aig.com/"
};
var environment_type = 'Dev';
var s_account = domain.dev_omniture_account;
var oneClaimUrls = {
	"integ_url" : "http://gcisvcint.aig.net:13520/prweb/GCExt/kh4bAUC4zN8Uk00d_hzdJf9hGFSw-NvWj7hf3THwZGA%5B*/!STANDARD?pzAuth=guest&",
	"dev_url" : "http://10.91.82.78/prweb/GCExt/kh4bAUC4zN8Uk00d_hzdJf9hGFSw-NvWj7hf3THwZGA%5B*/!STANDARD?pzAuth=guest&"
};
var appFolderUrls = {
	'ELIAS_DIRECTORY' : 'elias/',
	'WORk_FLOW_JSON_PATH' : 'common/proxy/workFlow.json',
	'WORk_FLOW_REFRESHJSON_PATH' : 'common/proxy/workflowRefresh.json',
	'WORK_FLOW_WEEKLY' : 'common/proxy/workflowWeekly.json',
	'WORK_FLOW_MONTHLY' : 'common/proxy/workflowMonthly.json',
	'WORK_FLOW_YEARLY' : 'common/proxy/workflowYearly.json',
	'WORkFLOW_TRAN_JSON_PATH' : 'common/proxy/workflowTransaction.json',
	'WORkFLOW_TRAN_REFRESHJSON_PATH' : 'common/proxy/workflowTransactionRefresh.json',
	'WORKFLOW_CONFIG_JSON_PATH' : 'common/proxy/workFlow_diagram.json',
	'WF_CONFIG_JSON_PATH' : 'common/proxy/workflowConfig.json',
	'WORKFLOW_TYPE' : 'common/proxy/workFlowType.json',
	'WORKFLOW_NAMES' : 'common/proxy/workFlowNames.json',
	'PROCESS_CONFIG_JSON_PATH' : 'common/proxy/process_config.json',
	'TRANSACTION_CONFIG_JSON_PATH' : 'common/proxy/transactionsConfig.json',
	'HEALTH_CONFIG_JSON_PATH' : 'common/proxy/serviceHealthConfig.json',
	'GET_SERVICE_THROUGHPUT' : 'common/proxy/getServicesByThroughput.json',
	'GET_SERVICE_PERFORMANCE' : 'common/proxy/getServicesByPerformance.json',
	'GET_SERVICE_AVAILABILITY' : 'common/proxy/getServicesByAvailablity.json',
	'GET_WORKFLOW_BYSERVICEID' : 'common/proxy/getWorkFlowByServiceID.json',
	'GET_WORKFLOW_BYSERVICEIDCONFIG' : 'common/proxy/getWorkFlowByServiceIDConfig.json',
	'HEALTH_SERVICES_JSON_PATH' : 'common/proxy/serviceHealth.json',
	'PROFILE_JSON' : 'common/proxy/userProfile.json',
	'PROFILE_CONFIG_JSON_PATH' : "common/proxy/profileConfig.json",
	'PROFILE_RULE_CONFIG_JSON_PATH' : "common/proxy/profileRuleConfig.json",
	'PROFILE_USER_CONFIG_JSON_PATH' : "common/proxy/profileUserDataConfig.json",
	'FILTER_JSON_PATH' : 'common/proxy/filterData.json',
	'WORKFLOW_TYPE_FILTER' : 'common/proxy/workFlowTypeFilter.json',
	'WORKFLOW_NAME_FILTER' : 'common/proxy/workFlowNamesFilter.json',
	'WORKFLOW_BREAKDOWN' : 'common/proxy/processBreakDownData.json',
	'WORKFLOW_BREAKDOWN_FILTER' : 'common/proxy/processBreakDownDataFilter.json',
	'PROCESS_TYPE' : 'common/proxy/process_types.json',
	'PROCESS_NAME' : 'common/proxy/process_name.json',
	'PROCESS_SCREEN_DATA' : 'common/proxy/process_screen_data.json',
	'PROCESS_ID_RES' : 'common/proxy/process_id_response.json',
	'PROCESS_ID2_RES' : 'common/proxy/process_id_response2.json',
	'PROCESS_ID3_RES' : 'common/proxy/process_id_response3.json',
	'WORKFLOW_JSON_DATA' : 'common/proxy/workflowData.json',
	'TRANSACTION_END_STATE' : 'common/proxy/transactionsEndState.json',
	'TRANSACTION_END_STATE_PA' : 'common/proxy/transactionsEndStatePA.json',
	'PROCESS_LOB' : 'common/proxy/processLOBs.json',
	'PROCESS_COUNTRIES' : 'common/proxy/processCountries.json',
	'EXPORT_WORKFLOW' : 'common/proxy/exportWorkflowsConfig.json',
	'ORDER_END_STATE_GRAPH' : 'common/proxy/endstates',
	'USER_COUNTRIES_JSON' : 'common/proxy/user-countries.json',
	'USER_REGIONS_JSON' : 'common/proxy/user-regions.json',
	'USER_LOBS_JSON' : 'common/proxy/user-lobs.json',
	'USER_SUBLOBS_JSON' : 'common/proxy/user-sublobs.json',
	'HEADER_CONFIG_JSON' : 'common/proxy/header-icons-config.json',
	'WORKFLOW_HEADER_MAPPING' : 'common/proxy/workflowHeaderMapping.json'

};

var hostname = document.location.hostname;
controller_Path = window.location.origin;

/*
if (hostname === 'localhost' || hostname === '10.33.124.177') {
	// controller_Path = 'http://10.33.124.177:8082/';
	// controller_Path = 'http://iremdev.aig.net/';
	
	controller_Path = 'http://localhost:8080/';
	
	
	// controller_Path = 'http://localhost:8084/';
} else if (hostname === 'vmzldlcimw201.r1-core.r1.aig.net') {
	controller_Path = 'http://vmzldlcimw201.r1-core.r1.aig.net:21260/';
} else if (hostname === 'vmzldlcimw311.r1-core.r1.aig.net') {
	controller_Path = 'http://vmzldlcimw311.r1-core.r1.aig.net:21260/';
} else if (hostname === 'vmzlmlcimw404.r1-core.r1.aig.net') {
	controller_Path = 'http://vmzlmlcimw404.r1-core.r1.aig.net:21260/';
} else if (hostname === 'vmzlmlcimw405.r1-core.r1.aig.net') {
	controller_Path = 'http://vmzlmlcimw405.r1-core.r1.aig.net:21260/';
} else if (hostname === 'vmzlplcimw507.r1-core.r1.aig.net') {
	controller_Path = 'http://vmzlplcimw507.r1-core.r1.aig.net:21260/';
} else if (hostname === 'iremdev.aig.net') {
	controller_Path = 'http://iremdev.aig.net/';
} else if (hostname === 'http://iremqa.aig.net/') {
	controller_Path = 'http://iremqa.aig.net/';
} else if (hostname === 'http://iremmodl.aig.net/') {
	controller_Path = 'http://iremmodl.aig.net/';
} else if (hostname === 'http://iremprod.aig.net/') {
	controller_Path = 'http://iremprod.aig.net/';
} else {
	controller_Path = 'http://vmzldlcimw202.r1-core.r1.aig.net:21260/';
}
*/

var serviceUrls = {
	'API_PATH' : controller_Path + 'APIController/jsondata',
	'GET_LOOKUP_RDFS' : 'https://dpsvcdev-cl.r1-core.r1.aig.net:7250/api/claims/lookupRDFEnumerations',
	'GET_WORKFLOW_DATA' : useLocalJson ? "common/proxy/us_casuality_pa.json"
			: "",
	'GET_PROCESS_CONFIG' : 'http://10.91.82.36/prweb/PRRestService/ELIASSP/ELIASRestAPI/GetProcessConfigurationsAPI',
	'ADD_WORK_FLOW' : 'http://10.91.82.36/prweb/PRRestService/ELIASSP/ELIASRestAPI/AddWorkFlowConfiguration',
	'UPDTAE_WORK_FLOW' : 'http://10.91.82.36/prweb/PRRestService/ELIASSP/ELIASRestAPI/UpdateWorkflowConfigurations'
};
