var useLocalJson = false;
var SHAREDDATA={};
var RDFConfig = {
    'COUNTRY': 'COUNTRY'
};
var processStatusObj = {
		  processStarted : -1, 
		  inProcess : 0,
		  processCompelted : 1
};
var workFlows = {
    "workflow1": "json",
    "workflow2": "json",
    "workflow3": "json"
};

var flowChatColors = {
	 "noColor" : 'nocolor',	
    "bgColorCssClass": {
        "blue": 'virtui-bg-blue',
        "darkblue": "virtui-bg-dark-blue",
        "green": "virtui-bg-green",
        "lightgreen": "virtui-bg-light-green",
        "grey": "virtui-bg-grey",
        "pink": "virtui-bg-pink",
        "violet": "virtui-bg-violet",
        "orange": "virtui-bg-orange",
        "nocolor":"virtui-no-bg",
        "magenta":"virtui-bg-magenta"
    }
};
var pageTitles={
"home.elias":"",
    "home.elias.dashboard":{"pgTitle":"Processes","BreadCrumb":"Dashboard"},
    "home.elias.workflow":{"pgTitle":"Process","BreadCrumb":"Workflow"},
    "home.elias.workflowChart":{"pgTitle":"Process Chart","BreadCrumb":"Process Chart"},
    "home.elias.allTransactions":{"pgTitle":"All Transactions","BreadCrumb":"Transactions"},
    "home.elias.transactions":{"pgTitle":"Transactions","BreadCrumb":"Transactions"},
    "home.elias.allTransactions":{"pgTitle":"Transactions","BreadCrumb":"Transactions"},
    "home.elias.profile":{"pgTitle":"Profile","BreadCrumb":"Profile"},
    "home.elias.health":{"pgTitle":"Health","BreadCrumb":"Health"},
    "home.elias.serviceSelected":{"pgTitle":"Selected Services","BreadCrumb":"Selected Services"},
    "home.elias.fromWorkflow":{"pgTitle":"From Process","BreadCrumb":"From Workflow"},
    "home.elias.configTool":{"pgTitle":"Configuration Tool","BreadCrumb":"Configuration Tool"},
    "home.elias.addprocess":{"pgTitle":"Adding New Process","BreadCrumb":"Adding New Process"} 
};
var zoomSettings={
    max:200,
    min:50,
    step:2
};
var country_check = {
		"south_africa":"ZA"
};
var lob_check = {
	"anh":"ANH"	
};
var serviceObjParams ={
		"workflow":{
			"donut":{
				"successCount":"successWFCount",
				"businessCount":"businessExceptionCount",
				"operatioanlCount":"operationalExceptionCount"
			}
		}
};
var processFunctionTypeMap ={
		"PROCESS" :"rectangle",
		"START STATE" :"rectangle",
		"END STATE" :"oval",
		"CONDITION" :"diamond",
		"FAILURE STATE" :"oval",
        "CIRCLE":"circle"
	};
	var processFlowColorMap ={
			"PROCESS" :"blue",
			"START STATE" :"blue",
			"END STATE" :"green",
			"CONDITION" :"violet",
			"FAILURE STATE" :"orange",
            "CIRCLE":"magenta"
		
	};
	
	var startAndEndStates = {
			"START" : {"state":"START STATE" , "processId":"SP"},
			"END" : {"state":"END STATE" , "processId":"EP"}
	};
	
	var nextLevelLabels = {
			"CONFIG":"Back to Configuration Tool",
			"ALL_PROCESS":"Activate Process",
			"LOSS_INTAKE":"Loss Intake"
	};
	
	var dataCategories = {
			"PROCESS":"PROCESS",
			"PAYMENT":"PAYMENT"
	};
	
	var userActions = {	
			"CREATE":"ADD",
			"READ":"READ",
			"UPDATE":"UPDATE",
			"DELETE":"DELETE",
			"MARK_OFF":"MARK OFF",
			"RE_OPEN":"RE OPEN"
	};
	var workFlowStatus = {
			"ACTIVE":"ACTIVE",
			"IDLE":"IDLE",
			"DRAFT":"DRAFT",
			"INACTIVE":"INACTIVE"
	};
	var yesOrNo = {"Yes":"Y","No":"N"};
	var username = "CDUDDE";
	var intakeBreConfiguration = [{"ruleName": "Intake Rule","ruleDescription":"Intake Description"}];
	
	var userIds={
			"GB":"9110051",
			"ZA":"9304015",
			"US":"9302022"
	};
	var endProcess = ['Resolved Claim','Post Payment'];
	var disableEditProcessLabels = ['BOT (Robot)','BOT'];
/*******************************************
        Omniture configurations
*********************************************/

if(typeof(omniture)=='undefined'){
    omniture={};
}
omniture.s_account='cebwa461,cebwaglobal';
//on live there is a different value than local/dev
//we need to add the domain url that this site will be run on (for both dev and live)
omniture.s_scYear='2015';  //set with server's year if possible.
//Needs to be updated automatically on 1/1 @ 12:00:00a
omniture.s_scTimeZone='-6';  //-5 est, -6 cst, -7 mst, -8 pst
//needs to be set depending on which timezone the server is running in
omniture.s_prop41="dev";//Custom 1 � Environment
//on live there is a different value than local/dev
omniture.s_prop8='insurance services:americas:united states:commercial insurance:aig customer portal-us'; //MLC Level 1 - 8
omniture.s_prop28='REM'; //Site
omniture.s_prop30='north america'; //Region (north america)
omniture.s_prop31='usa'; //Country
omniture.s_prop33='english'; //Language