
var dropdown1 =  {"rpa" : { "v1" : "108", "v2" : "19", "v3" : "57", "v4" : "33", "v5" : "52", "v6" : "0", "v7":"5", "v8":"12", "v9":"4",
"v10":"4", "v11":"4", "v12":"220", "v13":"76", "v14":"9%", "v15":"25%" , "v16":"2", "v17":"7", "v18":"2", "v19":"7", "v20":"28",
"v21":"2", "v22":"22", "v23":"2", "v24":"7", "v25":"2", "v26":"7", "v27":"28",
"v28":"2", "v29":"22", "v30":"2", "v31":"7", "v32":"2", "v33":"7", "v34":"28",
"v35":"2", "v36":"1%", "v37":"22%", "v38":"2", "v39":"7", "v40":"2", "v41":"7", "v42":"28",
"v43":"2", "v44":"22", "v45":"2", "v46":"7", "v47":"2", "v48":"7", "v49":"28", "v50":"22%", "v51":"9"}, 
"chart" : [17, 52, 30, 91, 9,33,45,12,34,32,22,11,33,66,77,12,1,2]}

var dropdown2 =  {"rpa" : { "v1" : "110", "v2" : "20", "v3" : "58", "v4" : "33", "v5" : "32", "v6" : "0", "v7":"20", "v8":"112", "v9":"14",
"v10":"49", "v11":"44", "v12":"20", "v13":"6", "v14":"39%", "v15":"29%", "v16":"20", "v17":"27", "v18":"12", "v19":"17", "v20":"16",
"v21":"3", "v22":"1", "v23":"5", "v24":"545", "v25":"23", "v26":"1212", "v27":"21",
"v28":"221", "v29":"21312", "v30":"24", "v31":"37", "v32":"2121", "v33":"223", "v34":"2312",
"v35":"23", "v36":"431%", "v37":"224%", "v38":"432", "v39":"337", "v40":"23", "v41":"127", "v42":"2128",
"v43":"2544", "v44":"254642", "v45":"454542", "v46":"43227", "v47":"1212", "v48":"721", "v49":"2438", "v50":"1222%", "v51":"921"}, 
"chart" : [22, 12, 3, 8, 9, 22,11,33,23,55,66,12,12,2,3,1,23,65,7,6]}


var selectedDropdown;

function selectOption() {
	selectedDropdown = getValue();
	document.getElementById('v1').innerHTML = selectedDropdown.rpa.v1;
	document.getElementById('v2').innerHTML = selectedDropdown.rpa.v2;
	document.getElementById('v3').innerHTML = selectedDropdown.rpa.v3;
	document.getElementById('v4').innerHTML = selectedDropdown.rpa.v4;
	document.getElementById('v5').innerHTML = selectedDropdown.rpa.v5;
	document.getElementById('v6').innerHTML = selectedDropdown.rpa.v6;
	document.getElementById('v7').innerHTML = selectedDropdown.rpa.v7;
	document.getElementById('v8').innerHTML = selectedDropdown.rpa.v8;
	document.getElementById('v9').innerHTML = selectedDropdown.rpa.v9;
	document.getElementById('v10').innerHTML = selectedDropdown.rpa.v10;
	document.getElementById('v11').innerHTML = selectedDropdown.rpa.v11;
	document.getElementById('v12').innerHTML = selectedDropdown.rpa.v12;
	document.getElementById('v13').innerHTML = selectedDropdown.rpa.v13;
	document.getElementById('v14').innerHTML = selectedDropdown.rpa.v14;
	document.getElementById('v15').innerHTML = selectedDropdown.rpa.v15;
	document.getElementById('v16').innerHTML = selectedDropdown.rpa.v16;
	document.getElementById('v17').innerHTML = selectedDropdown.rpa.v17;
	document.getElementById('v18').innerHTML = selectedDropdown.rpa.v18;
	document.getElementById('v19').innerHTML = selectedDropdown.rpa.v19;
	document.getElementById('v20').innerHTML = selectedDropdown.rpa.v20;
	document.getElementById('v21').innerHTML = selectedDropdown.rpa.v21;
	document.getElementById('v22').innerHTML = selectedDropdown.rpa.v22;
	document.getElementById('v23').innerHTML = selectedDropdown.rpa.v23;
	document.getElementById('v24').innerHTML = selectedDropdown.rpa.v24;
	document.getElementById('v25').innerHTML = selectedDropdown.rpa.v25;
	document.getElementById('v26').innerHTML = selectedDropdown.rpa.v26;
	document.getElementById('v27').innerHTML = selectedDropdown.rpa.v27;
	document.getElementById('v28').innerHTML = selectedDropdown.rpa.v28;
	document.getElementById('v29').innerHTML = selectedDropdown.rpa.v29;
	document.getElementById('v30').innerHTML = selectedDropdown.rpa.v30;
	document.getElementById('v31').innerHTML = selectedDropdown.rpa.v31;
	document.getElementById('v32').innerHTML = selectedDropdown.rpa.v32;
	document.getElementById('v33').innerHTML = selectedDropdown.rpa.v33;
	document.getElementById('v34').innerHTML = selectedDropdown.rpa.v34;
	document.getElementById('v35').innerHTML = selectedDropdown.rpa.v35;
	document.getElementById('v36').innerHTML = selectedDropdown.rpa.v36;
	document.getElementById('v37').innerHTML = selectedDropdown.rpa.v37;
	document.getElementById('v38').innerHTML = selectedDropdown.rpa.v38;
	document.getElementById('v39').innerHTML = selectedDropdown.rpa.v39;
	document.getElementById('v40').innerHTML = selectedDropdown.rpa.v40;
	document.getElementById('v41').innerHTML = selectedDropdown.rpa.v41;
	document.getElementById('v42').innerHTML = selectedDropdown.rpa.v42;
	document.getElementById('v43').innerHTML = selectedDropdown.rpa.v43;
	document.getElementById('v44').innerHTML = selectedDropdown.rpa.v44;
	document.getElementById('v45').innerHTML = selectedDropdown.rpa.v45;
	document.getElementById('v46').innerHTML = selectedDropdown.rpa.v46;
	document.getElementById('v47').innerHTML = selectedDropdown.rpa.v47;
	document.getElementById('v48').innerHTML = selectedDropdown.rpa.v48;
	document.getElementById('v49').innerHTML = selectedDropdown.rpa.v49;
	document.getElementById('v50').innerHTML = selectedDropdown.rpa.v50;
	document.getElementById('v51').innerHTML = selectedDropdown.rpa.v51;
}

function getValue() {
	if(document.getElementById('processQueueId').value == 'dropdown1') {
		return dropdown1;
	} else if(document.getElementById('processQueueId').value == 'dropdown2') {
		return dropdown2;
	}
}

function formatDate(date) {
const monthNames = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

    var d = new Date(date),
        month = '' + (monthNames[d.getMonth()]),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
}

window.onload = function() {
	selectOption();
	char1Click();
	var date = formatDate(new Date())
	document.getElementById("tabDates").innerHTML = date;
}

function char1Click() {
var date = formatDate(new Date())
	document.getElementById("tabDates").innerHTML = date;
		var barChart1 = new Chart(document.getElementById("bar-chart1"), {
    type: 'bar',
    data: {
      labels: ["Others", "Technical Errors", "Errors"],
      datasets: [
        {
          backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f"],
          data: [11,25,30]
        }
      ]
    },
    options: {
      legend: { display: false },
      title: {
        display: false
      },
	  responsive: false,
    maintainAspectRatio: true,
	   scales: {
    xAxes: [{
                gridLines: {
                    color: "rgba(0, 0, 0, 0)",
					display: false
                }
				
            }],
    yAxes: [{
                gridLines: {
                    color: "rgba(0, 0, 0, 0)",
                },
				display: false
            }]
    }
    }
    
});
	setTimeout(function(){
		barChart1.render();
	}, 200);

	var pieChart1 = new Chart(document.getElementById("pie-chart1"), {
    type: 'pie',
    data: {
      labels: ["Others", "Technical Error", "Errors"],
      datasets: [{
        label: "Population (millions)",
        backgroundColor: ["#3e95cd", "#8e5ea2", "#12a342"],
        data: [20,10, 45]
      }]
    },
    options: {
	legend: {
         position: 'right'
      },
	  responsive: false,
    maintainAspectRatio: true,
      title: {
        display: true
      }
    }
});
	setTimeout(function(){
		pieChart1.update();
	}, 200);

}

function char2Click() {
var date1 = formatDate(new Date());
var d = new Date();
var yesterday = d.setDate(d.getDate() - 1);
var date2 = formatDate(yesterday);
	document.getElementById("tabDates").innerHTML = date2 + '  to  ' + date1;
	var barChart2 = new Chart(document.getElementById("bar-chart2"), {
    type: 'bar',
    data: {
      labels: ["Others", "Technical Error"],
      datasets: [
        {
          backgroundColor: ["#3e95cd", "#8e5ea2"],
          data: [11,20]
        }
      ]
    },
    options: {
      legend: { display: false },
	  responsive: false,
    maintainAspectRatio: true,
	  tooltipTemplate: "<%= value %>%",
      title: {
        display: false
      },
	   scales: {
    xAxes: [{
                gridLines: {
                    color: "rgba(0, 0, 0, 0)",
					display: false
                }
				
            }],
    yAxes: [{
                gridLines: {
                    color: "rgba(0, 0, 0, 0)",
                },
display: false				
            }]
    }
    }
    
});
	setTimeout(function(){
		barChart2.update();
	}, 200);

	var pieChart2 = new Chart(document.getElementById("pie-chart2"), {
    type: 'pie',
    data: {
      labels: ["Others", "Technical Error"],
      datasets: [{
        label: "Population (millions)",
        backgroundColor: ["#3e95cd", "#8e5ea2"],
        data: [20,10]
      }]
    },
    options: {
      title: {
        display: true
      },
	  responsive: false,
    maintainAspectRatio: true,
	  legend: {
         position: 'right'
      }
    }
});
	setTimeout(function(){
		pieChart2.update();
	}, 200);

}


function char3Click() {
var date1 = formatDate(new Date());
var d = new Date();
var prevMonth = d.setMonth(d.getMonth() - 1);
var date2 = formatDate(prevMonth);
	document.getElementById("tabDates").innerHTML = date2 + '  to  ' + date1;
	var barChart3 = new Chart(document.getElementById("bar-chart3"), {
    type: 'bar',
    data: {
      labels: ["Others", "Technical Errors", "Errors"],
      datasets: [
        {
          backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f"],
          data: [11,5,30]
        }
      ]
    },
    options: {
      legend: { display: false },
	  responsive: false,
    maintainAspectRatio: true,
      title: {
        display: false
      },
	   scales: {
    xAxes: [{
                gridLines: {
                    color: "rgba(0, 0, 0, 0)",
					display: false
                }
            }],
    yAxes: [{
                gridLines: {
                    color: "rgba(0, 0, 0, 0)",
                },
display: false				
            }]
    }
    }
    
});
	setTimeout(function(){
		barChart3.render();
	}, 200);

	var pieChart3 = new Chart(document.getElementById("pie-chart3"), {
    type: 'pie',
    data: {
      labels: ["Others", "Technical Error", "errors"],
      datasets: [{
        label: "Population (millions)",
        backgroundColor: ["#3e95cd", "#8e5ea2", "#8eada2"],
        data: [20,10,34]
      }]
    },
    options: {
      title: {
        display: true
      },
	  responsive: false,
    maintainAspectRatio: true,
	  legend: {
         position: 'right'
      }
    }
});
	setTimeout(function(){
		pieChart3.render();
	}, 200);

}

function char4Click() {
var date1 = formatDate(new Date());
var d = new Date();
var prevYear = d.setYear(d.getFullYear() - 1);
var date2 = formatDate(prevYear);
	document.getElementById("tabDates").innerHTML = date2 + '  to  ' + date1;
	var barChart4 = new Chart(document.getElementById("bar-chart4"), {
    type: 'bar',
    data: {
      labels: ["Others", "Technical Error", "errors"],
      datasets: [
        {
          backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f"],
          data: [21,40,25]
        }
      ]
    },
    options: {
      legend: { display: false },
	  responsive: false,
    maintainAspectRatio: true,
      title: {
        display: false
      },
	   scales: {
    xAxes: [{
                gridLines: {
                    color: "rgba(0, 0, 0, 0)",
					display: false
                },
            }],
    yAxes: [{
                gridLines: {
                    color: "rgba(0, 0, 0, 0)",
                },
				display: false
            }]
    }
    }
    
});
	setTimeout(function(){
		barChart4.render();
	}, 200);

	var pieChart4 = new Chart(document.getElementById("pie-chart4"), {
    type: 'pie',
    data: {
      labels: ["Others", "Technical Error", "Errors"],
      datasets: [{
        backgroundColor: ["#3e95cd", "#8e5ea2", "#3aaacd"],
        data: [25, 85, 56]
      }]
    },
    options: {
      title: {
        display: true
      },
	  responsive: false,
    maintainAspectRatio: true,
	  legend: {
         position: 'right'
      }
    }
});
	setTimeout(function(){
		pieChart4.render();
	}, 200);

}
$("div").each(function(){
     $(this).hide();
    if($(this).attr('id') == 'tab1') {
        $(this).show();
    }
});

$('a').on( "click", function(e) {
    e.preventDefault();
    var id = $(this).attr('data-related'); 
    $("div").each(function(){
        $(this).hide();
        if($(this).attr('id') == id) {
            $(this).show();
        }
    });
});



