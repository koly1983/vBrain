(function () {
  'use strict';
  
  var urlName = window.location.origin + "/vBrain/";
  
  //var locationPath = "resources/";
  var locationPath = "vBrain/resources/";

  
  angular.module('vBrainApp')
    .controller('PrivilageCtrl', ['$scope','$http', '$window', function ($scope,$http, $window) {
    	
    	if(! $window.sessionStorage.getItem('loginId') || $window.sessionStorage.getItem('loginId') == null){
  			alert("Invalid access! Please login...");
  			
  			window.location.pathname = locationPath + 'index.html';
  		}
    	
    	$scope.ViewProcess =  parseInt($window.sessionStorage.getItem('ViewWorkers'));
    	$scope.ViewUser =  parseInt($window.sessionStorage.getItem('ViewUser'));
    	$scope.ViewPrivilege =  parseInt($window.sessionStorage.getItem('ViewPrivilege'));
    	$scope.processSla = true;
    	
    	$scope.userForm = false;
     
    	  	 
	   
	 	$scope.getUserRoles = function () {
			 $http({
		       	  method: 'POST',
		       	  url: urlName + "vbrain/vBrainService/getUserRoles",
		       	  data:{},
		       	  headers: {
		       		   'Content-Type': 'application/json'
		       	  }
		       	}).then(
		   				function(response){
		   					
		   					console.log(response.data.responseData.dataList[0].roles);
		   					$scope.roles = response.data.responseData.dataList[0].roles;
		   					
		   					//alert("roles : "+$scope.roles);
		   					
		   				},
		   				function(e){alert("error: "+e);}
		   			);
	   	}
	 	
	 	$scope.changeMode = "";
	   	 
	   	$scope.getPrivilages = function () {
	   		
	   		//alert("getPrivilages...");
	   		
	   		$scope.operFlag = true;
	   		
	   		if($scope.userRole){
	   			$scope.stateFlag = false;
	   			$scope.editFlag = false;
	   			
	   			
	   			var disableFlag = "";
		   		for(var i=0; i<$scope.roles.length; i++){
		   			if($scope.roles[i].id == $scope.userRole.id){
		   				disableFlag = $scope.roles[i].isDisabled;
		   			}
		   		}
		   		
		   				   		
		   		if(disableFlag == "0"){
		   			document.getElementById("stateDiv").innerHTML="Active <img src='../resources/ui/assets/images/right_arrow.png' height='15' style=''/>";
		   			$scope.changeMode = "1";
		   			$scope.editFlag = false;
		   		}
		   		else {
		   			document.getElementById("stateDiv").innerHTML="Disabled <img src='../resources/ui/assets/images/right_arrow.png' height='15' style='cursor:pointer;'/>";
		   			$scope.changeMode = "0";
		   			$scope.editFlag = true;
		   			
		   			$scope.privilages = [];
		   			return false;
		   		}
	   			
	   		}
	   		else {
	   			//$scope.operFlag = true;
	   			$scope.stateFlag = true;
	   			$scope.editFlag = true;
	   		}
	   		
	   		  		
	   		
			 $http({
		       	  method: 'POST',
		       	  url: urlName + "vbrain/vBrainService/getPrivilages",
		       	  data:{
		       		  requestParameter: {
		       			roleId:$scope.userRole.id
		       		  }
		       	  },
		     	  headers: {
		       		   'Content-Type': 'application/json'
		       	  }
		       	}).then(
		   				function(response){
		   					//alert("privilages : "+ response.data.responseData.dataList[0].privilages);
		   					
		   					//console.log(response.data.responseData.dataList[0].privilages);
		   					$scope.privilages = response.data.responseData.dataList[0].privilages;
		   					//$scope.gridUsers.data = $scope.users;
		   				},
		   				function(e){alert("error: "+e);}
		   			);
	   	}
	   	
	    $scope.eidtPrivilage = function ($event, privilageId) {
	   	    
	    	console.log($event);
	    	var checkbox = $event.target;
	    	 
	    	var access = "0";
	    	
	    	if(checkbox.checked){
	    		access = "1";
	    	}
	    	
	    	
	    	$http({
		       	  method: 'POST',
		       	  url: urlName + "vbrain/vBrainService/editPrivilage",
		       	  data:{
			     		 requestParameter: {
			     			 privilage:{
			     				id:privilageId,
			     				access:access
			     				
			     			 }
				      			
				      	  }
				        },
		       	  headers: {
		       		   'Content-Type': 'application/json'
		       	  }
		       	}).then(
		   				function(response){
		   					//alert("assignUser ::::: ");
		   					alert(response.data.responseData.message);
		   				},
		   				function(e){alert("error: "+e);}
		   			);
		   			
		    };
		    
		    
		    $scope.mode = "";
		    $scope.stateFlag = true;
		    $scope.operFlag = true;
		    $scope.editFlag = true;
		    
		    $scope.addNew = function () {
		    	$scope.mode = "add";
		    	$scope.roleName = '';
		    	$scope.operFlag = false;
		    }
		    
		    $scope.editMode = function () {
		    	$scope.mode = "edit";
		    	$scope.roleName = $scope.userRole.name;
		    	$scope.operFlag = false;
		    }
		    
		    $scope.save = function () {
		    	
		    	if($scope.mode == "edit"){
		    		 $scope.editRole();
		    		
		    	}
		    	else if ($scope.mode == "add"){
		    		 $scope.addRole();
		    		
		    	}
		    	
		    }
		    
		   
		    
		    $scope.addRole = function () {
		   	    
		    	
		    	$http({
			       	  method: 'POST',
			       	  url: urlName + "vbrain/vBrainService/addRole",
			       	  data:{
				     		 requestParameter: {
				     			 role:{
				     				name:$scope.roleName
				     			 }
					      			
					      	  }
					        },
			       	  headers: {
			       		   'Content-Type': 'application/json'
			       	  }
			       	}).then(
			   				function(response){
			   					//alert("assignUser ::::: ");
			   					alert(response.data.responseData.message);
			   					$scope.getUserRoles();
			   				},
			   				function(e){alert("error: "+e);}
			   			);
			   			
			    };
			    
			    
			    $scope.editRole = function () {
			   	    
			    	
			    	$http({
				       	  method: 'POST',
				       	  url: urlName + "vbrain/vBrainService/editRole",
				       	  data:{
					     		 requestParameter: {
					     			 role:{
					     				id:$scope.userRole.id,
					     				name:$scope.roleName
					     			 }
						      			
						      	  }
						        },
				       	  headers: {
				       		   'Content-Type': 'application/json'
				       	  }
				       	}).then(
				   				function(response){
				   					//alert("assignUser ::::: ");
				   					alert(response.data.responseData.message);
				   					$scope.getUserRoles();
				   				},
				   				function(e){alert("error: "+e);}
				   			);
				   			
				    };
				    
				    $scope.changeRole = function () {
				    	
				    	var message = "";
				    	if($scope.changeMode == '1'){
				    		message = "Are you sure want to disable the Role";
				    	}
				    	else if ($scope.changeMode == '0'){
				    		message = "Are you sure want to enable the Role";
				    	}
				    	
				    	if(message.length == 0) return false;
				    	
				    	
				    	var r = confirm(message);
				 		if (r == true) {
				   	    
				    	
					    	$http({
						       	  method: 'POST',
						       	  url: urlName + "vbrain/vBrainService/changeRole",
						       	  data:{
							     		 requestParameter: {
							     			 role:{
							     				id:$scope.userRole.id,
							     				isDisabled:$scope.changeMode
							     			 }
								      			
								      	  }
								        },
						       	  headers: {
						       		   'Content-Type': 'application/json'
						       	  }
						       	}).then(
						   				function(response){
						   					
						   					
						   					//alert("assignUser ::::: ");
						   					alert(response.data.responseData.message);
						   					
						   					if($scope.changeMode == "0"){
						   			   			document.getElementById("stateDiv").innerHTML="Active <img src='../resources/ui/assets/images/right_arrow.png' height='15' style=''/>";
						   			   			$scope.changeMode = "1";
						   			   			$scope.editFlag = false;
						   			   			
						   			   			
						   			   			
							   			   		$http({
							   			       	  method: 'POST',
							   			       	  url: urlName + "vbrain/vBrainService/getPrivilages",
							   			       	  data:{
							   			       		  requestParameter: {
							   			       			roleId:$scope.userRole.id
							   			       		  }
							   			       	  },
							   			     	  headers: {
							   			       		   'Content-Type': 'application/json'
							   			       	  }
							   			       	}).then(
							   			   				function(response){
							   			   					//alert("privilages : "+ response.data.responseData.dataList[0].privilages);
							   			   					
							   			   					//console.log(response.data.responseData.dataList[0].privilages);
							   			   					$scope.privilages = response.data.responseData.dataList[0].privilages;
							   			   					//$scope.gridUsers.data = $scope.users;
							   			   				},
							   			   				function(e){alert("error: "+e);}
							   			   			);
						   			   			
						   			   		}
						   			   		else {
						   			   			document.getElementById("stateDiv").innerHTML="Disabled <img src='../resources/ui/assets/images/right_arrow.png' height='15' style='cursor:pointer;'/>";
						   			   			$scope.changeMode = "0";
						   			   			$scope.editFlag = true;
						   			   			$scope.privilages = [];
						   			   		}
						   					
						   					
						   					$scope.getUserRoles();
						   					
						   					
						   				},
						   				function(e){alert("error: "+e);}
						   			);
					    	
					    	
				 		}
				 		else {
				 			return false;
				 		}
				    };
		    
		   
				    
		    $scope.getUserRoles();

         }]);

}());
