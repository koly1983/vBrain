(function () {
  'use strict';
  
  var urlName = window.location.origin + "/vBrain/";
  
  //var locationPath = "resources/";
  var locationPath = "vBrain/resources/";
  
  
  angular.module('vBrainApp')
  	.directive('demoFileModel', function ($parse) {
        return {
            restrict: 'A', //the directive can be used as an attribute only
 
            /*
             link is a function that defines functionality of directive
             scope: scope associated with the element
             element: element on which this directive used
             attrs: key value pair of element attributes
             */
            link: function (scope, element, attrs) {
                var model = $parse(attrs.demoFileModel),
                    modelSetter = model.assign; //define a setter for demoFileModel
 
                //Bind change event on the element
                element.bind('change', function () {
                    //Call apply on scope, it checks for value changes and reflect them on UI
                    scope.$apply(function () {
                        //set the model value
                        modelSetter(scope, element[0].files[0]);
                    });
                });
            }
        };
    })    
    .controller('ProcessCtrl', ['$scope','$http', '$window', function ($scope, $http, $window) {
    	
    	if(! $window.sessionStorage.getItem('loginId') || $window.sessionStorage.getItem('loginId') == null){
  			alert("Invalid access! Please login...");
  			window.location.pathname = locationPath + 'index.html';
  			
  		}
    	
    	$scope.ViewProcess =  parseInt($window.sessionStorage.getItem('ViewWorkers'));
    	$scope.ViewUser =  parseInt($window.sessionStorage.getItem('ViewUser'));
    	$scope.ViewPrivilege =  parseInt($window.sessionStorage.getItem('ViewPrivilege'));
    	$scope.AssignWrokers =  parseInt($window.sessionStorage.getItem('AssignWrokers'));
    	$scope.DisableWorkers =  parseInt($window.sessionStorage.getItem('DisableWorkers'));
    	$scope.processSla = true;
    	
    	   	
    	$scope.userForm = false;
    	
    	 $scope.uploadFile = function () {
    		 
    		 if(!$scope.aProcess){
    			alert("Please select the process");
    			return false;
    			
    		 }
             var file = $scope.myFile;
             
             document.getElementById("uploadErrors").innerHTML = "";
             
             if($scope.myFile){
            	
	 	    	$http({
	 	    		method: 'POST',
	 	    		url: urlName + "vbrain/vBrainService/uploadHumanWorkers",
	 	    		headers: { 'Content-Type': undefined },
	 	    		transformRequest: function(data) {
	 		    		var formData = new FormData();
	 		    		formData.append('processId', $scope.aProcess);
	 		    		formData.append('file', file);
	 		    		
	 		    		return formData;
	 	    		},
	 	    		data: {}
	 	    	}).then(
	 		   				function(response){
	 		   					
	 		   					if( response.data.responseData.message == "success"){
	 		   						alert("BPM (Human Workers) uploaded successfully");
	 		   						//$scope.uploadErrors = true;
	 		   					}
	 		   					else {
	 		   						alert("Error in upload! Please find the error details under 'Upload Errors' section");
	 		   						//alert(response.data.responseData.errorReason);
	 		   						//$scope.uploadErrors = false;
	 		   						//$scope.uploadErrors.innerHTML = response.data.responseData.errorReason;
	 		   						document.getElementById("uploadErrors").innerHTML = "<u><b>Upload Errors:</b></u> </br> "+ response.data.responseData.errorReason;
	 		   						
	 		   					}
	 		   					
	 		   					$scope.getHumans();
	 		   					console.log('Huamn worker uploaded !');
	 		   				},
	 		   				function(e){alert("error: "+e);}
	 		   			);
             }
             else{
	             alert("Please select a file to upload!");
	        	 return false;
             }
     	};
     	
    	 $scope.gridOptions = {};
    	 $scope.gridOptions.enableCellEditOnFocus = true;
         $scope.gridOptions.columnDefs = [
             { name:'botKey', enableCellEditOnFocus:false, enableCellEdit: false, width:80 },
             { name:'provider', width:150},
             { name:'hostName', displayName: 'Host Name', width:100 },
             { name:'description', width:200 },
             { name:'avgEfforts', displayName: 'Avg Efforts (Mins)',width:130, cellClass: 'grid-align-right' },
             { name:'avgCost', displayName: 'Avg Cost (USD)',width:120, cellClass: 'grid-align-right' },
             { name:'avgEffortsSaved', displayName: 'Avg Efforts Saved(Mins)',width:130, cellClass: 'grid-align-right' },
             { name:'cycleTime', displayName: 'Cycle Time (Mins)',width:130,  cellClass: 'grid-align-right' },
             { name:'noOftransactions', displayName: '# of Transactions/ Day',width:150,  cellClass: 'grid-align-right' },
             { name:'delete', width:90, displayName: 'Delete',enableCellEdit: false,enableSorting: false,cellTemplate:'<a class="btn btn-danger btn-xs text-center" style="margin-left: 20px; margin-top:5px;" ng-show="'+$scope.DisableWorkers+'"  ng-click="grid.appScope.removeBot(row.entity.id)"><span class="glyphicon glyphicon-remove"></span></a>' }
         ];
         
         

         
   	   	 $http({
	       	  method: 'POST',
	       	  url: urlName + "vbrain/vBrainService/getProcesses",
	       	  data:{},
	       	  headers: {
	       		   'Content-Type': 'application/json'
	       	  }
	       	}).then(
	   				function(response){
	   					
	   					console.log(response.data.responseData.dataList[0].groups);
	   					$scope.processes = response.data.responseData.dataList[0].groups;
	   					
	   				},
	   				function(e){alert("error: "+e);}
	   			);
	   	 
	   	 
   	 
   	   	 $scope.checkTest  = function (){
   	   		 alert('Hi');
   	   	 }
   	   	 
   	   	 
	 	$scope.clearBotFields = function (){
	 		  $scope.botId = "";
		        $scope.provider = '';
		    	$scope.ipName = '';
		    	$scope.description = '';
		    	$scope.bAvgEfforts ="";
				$scope.bAvgCost ="";
				$scope.bCycleTime ="";
				$scope.bTransactions ="";
			    
	 	}
	 	
	 	$scope.clearHumanFields = function (){
	 		 $scope.humanId = "";
		    $scope.workerId = "";
		    $scope.hName="";
		    $scope.hDescription="";
		    $scope.hAvgEfforts ="";
			$scope.hAvgCost ="";
			$scope.hCycleTime ="";
			$scope.hTransactions ="";
	 	}
	   	 
	   	$scope.getWorkers = function (){
	   		$scope.editBotMode = 0;
		    $scope.botId = "";
		    $scope.editHumanMode = 0;
		    $scope.humanId = "";

		    $scope.clearBotFields();
		    $scope.clearHumanFields();
		    
		   // $scope.gridOptions.data = '';
		   // $scope.gridOptions2.data = '';
		    
		   // alert("hi");
		    
		    $scope.getBots();
	   		$scope.getHumans();
	   		
	   		
	   	}
	   	 
	   	$scope.getBots = function () {
	   		//alert($scope.aProcess);
	   		
			 $http({
		       	  method: 'POST',
		       	  url: urlName + "vbrain/vBrainService/getBots",
		       	  data:{
		     		 requestParameter: {
			      			processId:$scope.aProcess
			      		}
			      },
		       	  headers: {
		       		   'Content-Type': 'application/json'
		       	  }
		       	}).then(
		   				function(response){
		   					
		   					if(response.data.responseData.dataList){
		   						$scope.bots = response.data.responseData.dataList[0].bots;
		   						$scope.gridOptions.data = $scope.bots;
		   					}
		   					else {
		   						$scope.bots = "";
		   						$scope.gridOptions.data = [];
		   					}
		   					
		   					
		   					//$scope.bots.push({botKey:'test bot2',provider:'Blue Prism',hostName:'122.305.200',description:'BP Bot for BC',
		   					//	avgEfforts:'123',avgCost:'124',cycleTime:'12',noOftransactions:'100'})
		   					//console.log('groups data above')
		   					//console.log($scope.gridOptions.data)
		   			       //console.log('groups data below')
		   					
		   				},
		   				function(e){alert("error: "+e);}
		   			);
	   	}
	   	
	    $scope.addBot = function () {
	   	     
	    	var endPoint = "registerBot";
	    	if($scope.editBotMode == 1){
	    		endPoint = "editBot";
	    	}
	    	
	    	 
	    	 if(!$scope.aProcess){
	        	  alert("Please select the Process");
	        	  return false;
	        	  
	          }
	    	  else if(!$scope.provider){
	        	  alert("Please enter the Bot Provider");
	        	  return false;
	        	  
	          }
	          else if(!$scope.ipName ){
	        	  alert("Please enter Bot IP/ Host Name");
	        	  return false;
	          }
	          else if(!$scope.description ){
	        	  alert("Please enter Bot Description");
	        	  return false;
	          }
	          else if(!$scope.bAvgEfforts ){
	        	  alert("Please enter Bot Avg Efforts");
	        	  return false;
	          }
	          else if(!$scope.bAvgCost ){
	        	  alert("Please enter Bot Avg Cost ");
	        	  return false;
	          }
	          else if(!$scope.bCycleTime ){
	        	  alert("Please enter Bot Cycle Time");
	        	  return false;
	          }
	          else if(!$scope.bTransactions ){
	        	  alert("Please enter Bot's # of Transactions/ Day");
	        	  return false;
	          }
	    	
	    	
	    	//alert(endPoint);
		   	 $http({
		       	  method: 'POST',
		       	  url: urlName + "vbrain/vBrainService/"+endPoint,
		       	  data:{
			     		 requestParameter: {
			     			 bot:{
			     				id:$scope.botId,
			     				provider:$scope.provider,
			     				hostName:$scope.ipName,
			     				description:$scope.description,
			     				processId:$scope.aProcess,
			     				avgEfforts:$scope.bAvgEfforts,
			     				avgCost:$scope.bAvgCost,
			     				cycleTime:$scope.bCycleTime,
			     				noOftransactions:$scope.bTransactions,
			     				avgEffortsSaved:$scope.bAvgEffortsSaved
			     				
			     			 }
				      			
				      	  }
				        },
		       	  headers: {
		       		   'Content-Type': 'application/json'
		       	  }
		       	}).then(
		   				function(response){
		   					//alert("assignUser ::::: ");
		   					alert(response.data.responseData.message);
		   					
		   				    $scope.clearBotFields();
			   		    	
		   					$scope.getBots();
		   				},
		   				function(e){alert("error: "+e);}
		   			);
		    };
		    
		    $scope.editBotMode = 0;
		    $scope.botId = "";
		   		    
		    $scope.dispBot = function (bot) {
		   	     
		    	console.log("disp bot function called");
		    	
			 	$scope.provider = bot.provider;
		    	$scope.ipName = bot.hostName;
		    	$scope.description = bot.description;
		    	$scope.bAvgEfforts = bot.avgEfforts;
 				$scope.bAvgCost = bot.avgCost;
 				$scope.bCycleTime = bot.cycleTime;
 				$scope.bTransactions = bot.noOftransactions;
 				$scope.bAvgEffortsSaved = bot.avgEffortsSaved;
		    	
		    	$scope.editBotMode = 1;
		    	$scope.botId = bot.id;
		    	
		    	
		    };
		    
		    
		    
		    // attache event to save on edit
   	   	 	$scope.gridOptions.onRegisterApi =  function (gridApi) {
   	   	 		console.log('saving row..')
	          $scope.gridApi = gridApi;
	          //gridApi.rowEdit.on.saveRow($scope, $scope.saveRow);
	          
	          gridApi.edit.on.afterCellEdit($scope, function(rowEntity, colDef, newValue, oldValue) {
	        	    
	        	    let endPoint = "editBot";
	        	    $http({
	  		       	  method: 'POST',
	  		       	  url: urlName + "vbrain/vBrainService/"+endPoint,
	  		       	  data:{
	  			     		 requestParameter: {
	  			     			 bot:{
	  			     				id:rowEntity.id,
	  			     				provider:rowEntity.provider,
	  			     				hostName:rowEntity.hostName,
	  			     				description:rowEntity.description,
	  			     				processId:$scope.aProcess,
	  			     				avgEfforts:rowEntity.avgEfforts,
	  			     				avgCost:rowEntity.avgCost,
	  			     				avgEffortsSaved:rowEntity.avgEffortsSaved,
	  			     				cycleTime:rowEntity.cycleTime,
	  			     				noOftransactions:rowEntity.noOftransactions
	  			     				
	  			     				
	  			     			 }
	  				      			
	  				      	  }
	  				        },
	  		       	  headers: {
	  		       		   'Content-Type': 'application/json'
	  		       	  }
	  		       	}).then(
	  		   				function(response){
	  		   					
	  		   					//alert(response.data.responseData.message);
	  		   					
	  		   					$scope.getBots();
	  		   					console.log('bot updated for this row');
	  		   				},
	  		   				function(e){alert("error: "+e);}
	  		   			);
	          
	          
	          });
	          
   	  		}
   	   	 	
         $scope.gridOptions2 = {};
       	 $scope.gridOptions2.enableCellEditOnFocus = true;
	        $scope.gridOptions2.columnDefs = [
	            { name:'workerId', enableCellEditOnFocus:false, enableCellEdit: false, width:100 },
	            { name:'name', displayName: 'Worker Name', width:200 },
	            { name:'description', displayName: 'Description', width:330 },
	            { name:'avgEfforts', displayName: 'Avg Efforts (Mins)',width:130, cellClass: 'grid-align-right' },
	            { name:'cycleTime', displayName: 'Cycle Time (Mins)', width:130, cellClass: 'grid-align-right' },
	            { name:'noOftransactions', displayName: '# of Transactions/ Day', width:160, cellClass: 'grid-align-right' },           
	            { name:'delete', width:100, displayName: 'Delete',enableCellEdit: false,enableSorting: false,cellTemplate:'<a class="btn btn-danger btn-xs text-center" style="margin-left: 20px;  margin-top:5px;" ng-show="'+$scope.DisableWorkers+'"  ng-click="grid.appScope.removeHuman(row.entity.id)"><span class="glyphicon glyphicon-remove"></span></a>' }
	       ];
            
	    
   	   	$scope.gridOptions2.onRegisterApi =  function (gridApi) {
	   	  console.log('saving row..')
          $scope.gridApi = gridApi;
          //gridApi.rowEdit.on.saveRow($scope, $scope.saveRow);
          
          gridApi.edit.on.afterCellEdit($scope, function(rowEntity, colDef, newValue, oldValue) {
        	    //Do your REST call here via $http.get or $http.post
        	    //Alert to show what info about the edit is available
        	    //alert('Column: ' + colDef.name + ' ID: ' + rowEntity.id + ' name: ' + rowEntity.name + ' avgEfforts: ' + rowEntity.avgEfforts);
        	    
        	    let endPoint = "editHuman";
        	   
        	    
        	    $http({
			       	  method: 'POST',
			       	  url: urlName + "vbrain/vBrainService/"+endPoint,
			       	  data:{
				     		 requestParameter: {
				     			 human:{
				     				id:rowEntity.id,
				     				workerId:rowEntity.workerId,
				     				name:rowEntity.name,
				     				description:rowEntity.description,
				     				processId:$scope.aProcess,	
				     				avgEfforts:rowEntity.avgEfforts,
				     				cycleTime:rowEntity.cycleTime,
				     				noOftransactions:rowEntity.noOftransactions

				     				 
				     			 }
					      			
					      	  }
					        },
			       	  headers: {
			       		   'Content-Type': 'application/json'
			       	  }
			       	}).then(
			   				function(response){
			   					//alert("assignUser ::::: ");
			   					//alert(response.data.responseData.message);
			   				
			   				   // $scope.clearHumanFields();
			   					
			   					$scope.getHumans();
			   					
			   					
			   				},
			   				function(e){alert("error: "+e);}
			   			);
        	    
          
          });
          
	  		}
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    $scope.editBot = function (botId) {
		   	     
		    	 console.log("edit bot function called");
		    	 
			   	 $http({
			       	  method: 'POST',
			       	  url: urlName + "vbrain/vBrainService/editBot",
			       	  data:{
				     		 requestParameter: {
				     			 bot:{	
				     				 	id:botId,
					     				provider:$scope.provider,
					     				hostName:$scope.ipName,
					     				description:$scope.description,
					     				processId:$scope.aProcess
					     				 
					     			 }
					      		}
					        },
			       	  headers: {
			       		   'Content-Type': 'application/json'
			       	  }
			       	}).then(
			   				function(response){
			   					//alert("assignUser ::::: ");
			   					alert(response.data.responseData.message);
			   					$scope.botId = "";
			   			        $scope.provider = '';
				   		    	$scope.ipName = '';
				   		    	$scope.description = '';
				   		    	
				   		    	$scope.bAvgEfforts ="";
			     				$scope.bAvgCost ="";
			     				$scope.bCycleTime ="";
			     				$scope.bTransactions ="";
			   					
			   				},
			   				function(e){alert("error: "+e);}
			   			);
			    };
		    
			    $scope.removeBot = function (botId) {
			   	     
			    	console.log("remove function called id is " + botId);
			    	 
			    	var r = confirm("Are you sure you want to remove?");
			 		if (r == true) {
			    	 
					   	 $http({
					       	  method: 'POST',
					       	  url: urlName + "vbrain/vBrainService/disableBot",
					       	  data:{
						     		 requestParameter: {
							      			bot:{
							      				id:botId
							      			}
							      		}
							        },
					       	  headers: {
					       		   'Content-Type': 'application/json'
					       	  }
					       	}).then(
					   				function(response){
					   					//alert("assignUser ::::: ");
					   					alert(response.data.responseData.message);
					   					
					   					$scope.clearHumanFields();
					   					$scope.getBots();
					   					
					   				},
					   				function(e){alert("error: "+e);}
					   			);
			 		}
			 		else {
			 			return false;
			 		}
			};
			    
		    
		    $scope.addHuman = function () {
		   	    
		    	 if(!$scope.aProcess){
		        	  alert("Please select the Process");
		        	  return false;
		        	  
		          }
		    	  else if(!$scope.workerId){
		        	  alert("Please enter Worker Id");
		        	  return false;
		        	  
		          }
		          else if(!$scope.hName ){
		        	  alert("Please enter Worker Name");
		        	  return false;
		          }
		          else if(!$scope.hDescription ){
		        	  alert("Please enter Worker Description");
		        	  return false;
		          }
		          else if(!$scope.hCycleTime ){
		        	  alert("Please enter Worker's Cycle Time");
		        	  return false;
		          }
		          else if(!$scope.hTransactions ){
		        	  alert("Please enter Worker's # of Transactions/ Day");
		        	  return false;
		          }
		    	
		    	var endPoint = "addHuman";
		    	if($scope.editHumanMode == 1){
		    		endPoint = "editHuman";
		    	}
		    	// alert(endPoint);
		    	
		    	
		    	 
			   	 $http({
			       	  method: 'POST',
			       	  url: urlName + "vbrain/vBrainService/"+endPoint,
			       	  data:{
				     		 requestParameter: {
				     			 human:{
				     				id:$scope.humanId,
				     				workerId:$scope.workerId,
				     				name:$scope.hName,
				     				description:$scope.hDescription,
				     				processId:$scope.aProcess,
				     				
				     				avgEfforts:$scope.hAvgEfforts,
				     				avgCost:$scope.hAvgCost,
				     				cycleTime:$scope.hCycleTime,
				     				noOftransactions:$scope.hTransactions

				     				 
				     			 }
					      			
					      	  }
					        },
			       	  headers: {
			       		   'Content-Type': 'application/json'
			       	  }
			       	}).then(
			   				function(response){
			   					//alert("assignUser ::::: ");
			   					alert(response.data.responseData.message);
			   				
			   				    $scope.clearHumanFields();
			   					
			   					$scope.getHumans();
			   					
			   					
			   				},
			   				function(e){alert("error: "+e);}
			   			);
			    };
		
			    $scope.editHumanMode = 0;
			    $scope.humanId = "";
			    
			    $scope.workerId = "";
			    $scope.name="";
			    $scope.description="";
			    
			    $scope.dispHuman = function (human) {
			   	     
			    	console.log("disp bot function called");
			    	
			    	$scope.workerId = human.workerId;
			    	$scope.hName = human.name;
			    	$scope.hDescription = human.description;
			    	$scope.hAvgEfforts = human.avgEfforts;
	 				$scope.hAvgCost = human.avgCost;
	 				$scope.hCycleTime = human.cycleTime;
	 				$scope.hTransactions = human.noOftransactions;
			    	
			    	$scope.editHumanMode = 1;
			    	$scope.humanId = human.id;
			    	
			    };
			    
			    $scope.removeHuman = function (humanId) {
			   	     
			    	 console.log("remove function called");
			    	 
			    	 var r = confirm("Are you sure you want to remove?");
				 		if (r == true) {
			    	 
					   	 $http({
					       	  method: 'POST',
					       	  url: urlName + "vbrain/vBrainService/disableHuman",
					       	  data:{
						     		 requestParameter: {
							      			human:{
							      				id:humanId
							      			}
							      		}
							        },
					       	  headers: {
					       		   'Content-Type': 'application/json'
					       	  }
					       	}).then(
					   				function(response){
					   					//alert("assignUser ::::: ");
					   					alert(response.data.responseData.message);
					   					$scope.getHumans();
					   					$scope.clearHumanFields();
					   					
					   				},
					   				function(e){alert("error: "+e);}
					   			);
				 		}
				 		else {
				 			return false;
				 		}
				   };
				    
			    
			    
			    
			    
			    
	   	
		$scope.getHumans = function () {
	   		//alert($scope.aProcess);
	   		
			 $http({
		       	  method: 'POST',
		       	  url: urlName + "vbrain/vBrainService/getHumans",
		       	  data:{
		     		 requestParameter: {
			      			processId:$scope.aProcess
			      		}
			      },
		       	  headers: {
		       		   'Content-Type': 'application/json'
		       	  }
		       	}).then(
		   				function(response){
		   					if(response.data.responseData.dataList){
		   						$scope.humans = response.data.responseData.dataList[0].humans;
		   						$scope.gridOptions2.data = $scope.humans;
		   					}
		   					else {
		   						
		   						$scope.humans = {};
		   						$scope.gridOptions2.data = [];
		   						
		   					}
		   					
		   					
		   					
		   				},
		   				function(e){alert("error: "+e);}
		   			);
	   	}
		

         }]);

}());
