(function () {
  'use strict';
  
  var urlName = window.location.origin + "/vBrain/";
  
  //var locationPath = "resources/";
  var locationPath = "vBrain/resources/";

  
  angular.module('vBrainApp')
    .controller('ResetDataCtrl', ['$scope','$http', '$window', function ($scope,$http, $window) {
    	
    	if(! $window.sessionStorage.getItem('loginId') || $window.sessionStorage.getItem('loginId') == null){
  			alert("Invalid access! Please login...");
  			
  			window.location.pathname = locationPath + 'index.html';
  		}
    	
    	$scope.ViewProcess =  parseInt($window.sessionStorage.getItem('ViewWorkers'));
    	$scope.ViewUser =  parseInt($window.sessionStorage.getItem('ViewUser'));
    	$scope.ViewPrivilege =  parseInt($window.sessionStorage.getItem('ViewPrivilege'));
    	$scope.processSla = true;
    	
    	var getLastUpdatedDate = function() {
    		var dataAPIUrl = urlName + '/vbrain/vBrainService/getLastUpdatedDate';

			$http({
				method : 'POST',
				url : dataAPIUrl,
				data : {},
				headers : {
					'Content-Type' : 'application/json'
				}
			}).then(function(response) {
				 var dataList = response.data.responseData.dataList;
				 if(dataList && dataList.length > 0) {
					 $scope.lastUpdatedDate = new Date(dataList[0].transactionDate);
				 }

			}, function(e) {
				console.log("error: " + e);
			});
    	};
    	
    	var  formatDate = function(date)
    	{
    		  var d = new Date(date);
    		  var month = d.getMonth()+1;
    		  var day = d.getDate();

    		  var output = ((month<10 ? '0' : '') + month + '/' + (day<10 ? '0' : '') + day + "/" + d.getFullYear()) ;
    		  return output;
    		};
    	
    	$scope.deleteTransactions = function (lastUpdatedDate) {
    		var r = confirm("Are you sure you want to delete the transactions after "+formatDate(lastUpdatedDate)+"?");
			if (r == true) {
				var postReq = {
					method : 'POST',
					url : urlName + 'vbrain/vBrainService/deleteTransactionsAfterDate',
					headers : {
						'Content-Type' : 'application/json'
					},
					data : {
						"requestParameter" : {
							"startDate" : formatDate(lastUpdatedDate)
						}
					}
				};
				$http(postReq)
					.then(function(response) {
						alert(response.data.responseData.message);
					},
					function(e) {
						console.log("error: " + e);
					});
			}
    	};
    	
    	getLastUpdatedDate();
    	
         }]);

}());
