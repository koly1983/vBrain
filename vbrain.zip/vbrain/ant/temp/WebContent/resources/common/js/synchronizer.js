/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function clean() {
    document.getElementById('hubname').value = '';
    document.getElementById('hubname2').value = '';
    document.getElementById('url').value = '';
}
(function () {
    'use strict';

    //var urlName = "http://lowcost-env.yv5sv2bh2p.ap-south-1.elasticbeanstalk.com/";
    var urlName = window.location.origin + "/vBrain/";

    //var locationPath = "resources/";
    var locationPath = "vBrain/";
    
    angular.module('vBrainApp', [])
            .controller('SyncCrlt', ['$scope', '$http', '$window', function ($scope, $http, $window) {

                    //clear all the session values
                    $window.sessionStorage.clear();

                    //Reset headers to avoid OPTIONS request (aka preflight)
                    $http.defaults.headers.common = {};
                    $http.defaults.headers.post = {};
                    $http.defaults.headers.put = {};
                    $http.defaults.headers.patch = {};


                    $scope.submitSync = function () {
                        $http({
                            method: 'POST',
                            url: urlName + "vbrain/vBrainService/syncNodes",
                            data: {
                                requestParameter: {
                                    hub: {
                                        serverName: '',
                                        hubName: $scope.hubname,
                                        url: $scope.url,
                                        status: 'HEALTHY'
                                    }
                                }
                            },
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        }).then(function (response) {
                            console.log(response.data.responseData.message);
                            $scope.message = response.data.responseData.message;

                            if ($scope.message) {
                                alert($scope.message);

                            } else {
                                alert("Invalid request sent !");
                            }
                        },
                                function (e) {
                                    alert("error: " + e);
                                }
                        );

                    };
                    
                    $scope.submitDeSync = function () {
                        $http({
                            method: 'POST',
                            url: urlName + "vbrain/vBrainService/deSyncNodes",
                            data: {
                                requestParameter: {
                                    hub: {
                                        serverName: '',
                                        hubName: $scope.hubname,
                                        status: 'HEALTHY'
                                    }
                                }
                            },
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        }).then(function (response) {
                            console.log(response.data.responseData.message);
                            $scope.message = response.data.responseData.message;

                            if ($scope.message) {
                                alert($scope.message);

                            } else {
                                alert("Invalid request sent !");
                            }
                        },
                                function (e) {
                                    alert("error: " + e);
                                }
                        );

                    };

                }]);

})();
