(function () {
  'use strict';
  
  var urlName = window.location.origin + "/vBrain/";

  //var locationPath = "resources/";
  var locationPath = "vBrain/resources/";
  
  angular.module('vBrainApp')
    .controller('orgStructureCtrl', ['$scope','$http', '$window', function ($scope, $http, $window) {
    	
    	if(! $window.sessionStorage.getItem('loginId') || $window.sessionStorage.getItem('loginId') == null){
  			alert("Invalid access! Please login...");
  			window.location.pathname = locationPath + 'index.html';
  			
  		}
    	
    	document.getElementById("loginId").innerHTML = $window.sessionStorage.getItem('loginId');
    	document.getElementById("loginRole").innerHTML = $window.sessionStorage.getItem('loginRole');
    	
    	$scope.CreateGroup =  parseInt($window.sessionStorage.getItem('CreateGroup'));
    	$scope.ViewProcess =  parseInt($window.sessionStorage.getItem('ViewWorkers'));
    	$scope.ViewUser =  parseInt($window.sessionStorage.getItem('ViewUser'));
    	$scope.ViewPrivilege =  parseInt($window.sessionStorage.getItem('ViewPrivilege'));
    	$scope.DisableGroup =  parseInt($window.sessionStorage.getItem('DisableGroup'));
    	$scope.processSla = true;
    	
    	//alert("$scope.ViewProcess : "+$scope.ViewProcess);
    	
       	
    	$scope.menuAction = function (val) {
			
			document.getElementById("t"+val).className = "tabEnable";
			for(var i=1; i<5; i++){
			
				if(i != val){
					document.getElementById("t"+i).className = "tabDisable";
				}
			}
		}
    	
     
      $scope.removeItem = function (nodeId, disableKey) {
    	
    	//alert(disableKey);
    	
    	var msg = "disable";
    	if(disableKey == "disabled"){
    		msg = "enable";
    	}
    	  
		var r = confirm("Are you sure you want to "+msg+"?");
		if (r == true) {
			var isDisabled = "1";
	    	if(disableKey == "disabled"){
	    		isDisabled = "0";
	    	}
	    	
	    	 $http({
	       	  method: 'POST',
	       	  url: urlName + 'vbrain/vBrainService/disableGroup',
	       	  data:{
		     		 requestParameter: {
		      			group:{
		      			 id:nodeId,
		      			 isDisabled:isDisabled
		      			}
		      		}
		        },
		       	headers: {
		       		   'Content-Type': 'application/json'
		        }
	       	}).then(
	   				function(response){
	   					console.log('adding node response here');
	   					console.log(response.message);
	   					//$scope.data = response.data.responseData.dataList[0].groups;
	   					
	   					//alert(response.data.responseData.message);
	   				},
	   				function(e){alert("error: "+e);}
	   			);
	   	
	          $scope.getGroups();
	          $scope.userForm = true;
		} 
		else {
		    return false;
		}
    	  
    	
        
      };

      $scope.toggle = function (scope) {
        scope.toggle();
      };

      $scope.moveLastToTheBeginning = function () {
        var a = $scope.data.pop();
        $scope.data.splice(0, 0, a);
      };

      $scope.newSubItem = function (parentId, parentNodeName, parentNodeType) {
    	  
    	  
    	  $scope.newItem(parentId, parentNodeName);
    	  
    	  getBPNames();
    	  getCampaignsList();
    	  
    	  
      };
      
      var getBPNames = function () {
    	  var groupId = $scope.isNew ? 0 : $scope.dataId || 0;
    	  $http({
        	  method: 'POST',
        	  url: urlName + 'vbrain/vBrainService/getBpNames_2',
        	  data:{
         		 requestParameter: {
         			groupId: groupId
         		 }
        	  },
        	  headers: {
        		   'Content-Type': 'application/json'
        	  }
        	}).then(
    				function(response){
    					$scope.bpNamesList = response.data.responseData.dataList;
    				},
    				function(e){alert("error: "+e);}
    			);
      }
      
      var getCampaignsList = function(){
    	  var groupId = $scope.isNew ? 0 : $scope.dataId || 0;
    	  $http({
        	  method: 'POST',
        	  url: urlName + 'vbrain/vBrainService/getAvailableCampaigns',
        	  data:{
         		 requestParameter: {
         			 groupId: groupId
         		 }
        	  },
        	  headers: {
        		   'Content-Type': 'application/json'
        	  }
        	}).then(
    				function(response){
    					$scope.campaignsList = response.data.responseData.dataList[0].campaigns;
    					$scope.fullCampaignsList = $scope.campaignsList;
    					if(!$scope.isNew) {
    						getCampaignMappings();
    					}
    				},
    				function(e){alert("error: "+e);}
    			);
      };
      
      var getCampaignMappings = function(){
    	  $http({
        	  method: 'POST',
        	  url: urlName + 'vbrain/vBrainService/getCampaignMappings_2',
        	  data:{
         		 requestParameter: {
         			groupId: $scope.dataId
         		 }
        	  },
        	  headers: {
        		   'Content-Type': 'application/json'
        	  }
        	}).then(
    				function(response){
    					var bpId = response.data.responseData.dataList[0].bpId;
    					var campaignId = response.data.responseData.dataList[0].campaignId;
    					var mappingId = response.data.responseData.dataList[0].mappingId;
    					
    					$scope.businessProcess = $scope.bpNamesList.find(function(bp) {
    					    return bp.processId == bpId;
    					  });
    					$scope.selectedCampaign = $scope.campaignsList.find(function(campaign) {
    					    return campaign.id == campaignId;
    					  });
    					$scope.selectCampaign();
    					$scope.campaignStep = $scope.stepsList.find(function(step) {
    					    return step.mappingId == mappingId;
  					  	});
    					$scope.selectStep();
    				},
    				function(e){alert("error: "+e);}
    			);
      };
      
      $scope.selectCampaign = function() {
    	  if($scope.selectedCampaign) {
    		  $scope.stepsList = $scope.selectedCampaign.mappings;
    		  $scope.botNodeName = $scope.businessProcess.processName;
    	  }
      };
      
      $scope.selectBP = function() {
    	  if($scope.businessProcess) {
    		  $scope.wfVersion = $scope.businessProcess.wfVersion;
    		  $scope.campaignsList = $scope.fullCampaignsList.filter(function(campaign) {
				    return campaign.wfVersion == $scope.wfVersion;
				  });
    	  }
      }
      
      $scope.selectStep = function() {
    	  if($scope.campaignStep) {
    		  $scope.description = $scope.campaignStep.stepTitle;
    	  }
      }
      
      $scope.userForm = true;
      $scope.isNew = false;
      
      $scope.newItem = function (parentId, parentNodeName) {
         //$scope.data = [];
    	  $scope.parentNodeName = parentNodeName;
    	  $scope.description = '';
    	  $scope.botNodeName = '';
    	  $scope.nodeTypeValue = '';
    	  
    	  $scope.isNew = true;
          $scope.userForm = false;
          $scope.dataId = '';
          $scope.dataParantId = parentId;
          $scope.dataParantGroupId = '0'
        	  
          $scope.btnEdit = true;
          $scope.btnCancel = true;
        	  
          //$scope.hideUserSection = true;
         
      };
      
      $scope.clearForm = function(){
    	  $scope.description = '';
    	  $scope.botNodeName = '';
    	  $scope.nodeTypeValue = '';
      };
      
      $scope.refreshCampaigns = function(){
    	  $http({
        	  method: 'POST',
        	  url: urlName + 'vbrain/vBrainService/refreshCampaigns',
        	  data:{
         		 requestParameter: {}
        	  },
        	  headers: {
        		   'Content-Type': 'application/json'
        	  }
        	}).then(
    				function(response){
    					$scope.campaignsList = response.data.responseData.dataList[0].campaigns;
    					$scope.fullCampaignsList = $scope.campaignsList;
    					alert("Processes Refreshed");
    				},
    				function(e){alert("error: "+e);}
    			);
      };
          
      $scope.addNode = function(){
          
    	  console.log('addNode function called');
    	  //alert('addNode function called')
    	  
         // console.log($scope.dataId+$scope.dataParantId+$scope.dataParantGroupId)
          //console.log('edit data above');
          $scope.userForm = false;
          var nodeData = $scope.data;
          
          //alert("|"+$scope.nodeTypeValue+"|");
          
          if(!$scope.botNodeName){
        	  alert("Please enter the Group Name");
        	  return false
        	  
          }
          else if(!$scope.nodeTypeValue ){
        	  alert("Please enter the Group Type");
        	  return false;
          }
          
          //alert($scope.isNew);
          
          if( !$scope.isNew ){

        	  
	    	  
        	  
             $scope.dataAPIUrl = urlName + 'vbrain/vBrainService/editGroup';
             $scope.newNode = {
            		 requestParameter: {
             			group:{
             			 id:$scope.dataId,
             			 name:$scope.botNodeName,
             			 description:$scope.description,
             			 type:$scope.nodeTypeValue,
             			 parentId: $scope.dataParantId,
             			 parentGroupId: $scope.dataParantGroupId
             			}
             		}
               };
          }
          else{
	       		console.log('data parent id is '+$scope.dataParantId);
	        	//$scope.dataParantId = '0'
	        	$scope.dataParantGroupId = '0'
        		$scope.dataAPIUrl = urlName + 'vbrain/vBrainService/addGroup';
        		$scope.newNode = {requestParameter: {
        			group:{
           			
           			 name:$scope.botNodeName,
           			 description:$scope.description,
           			 type:$scope.nodeTypeValue,
           			 parentId: $scope.dataParantId,
           			 parentGroupId: $scope.dataParantGroupId
           			}
           		}
              };
            }
          if($scope.nodeTypeValue == "process") {
        	  $scope.newNode.requestParameter.group.bpId=$scope.businessProcess.processId;
        	  $scope.newNode.requestParameter.group.mappingId = $scope.campaignStep.mappingId;
        	  $scope.newNode.requestParameter.group.wfVersion = $scope.businessProcess.wfVersion;
          }
                    
          console.log($scope.newNode)
          console.log($scope.dataAPIUrl);
          
          //alert($scope.dataAPIUrl);
         
          /* call add node url here with form data */
          $http({
        	  method: 'POST',
        	  url: $scope.dataAPIUrl,
        	  data:$scope.newNode,
        	  headers: {
        		   'Content-Type': 'application/json'
        	  }
        	}).then(
    				function(response){
    					console.log('adding node response here');
    					console.log(response.message);
    					//$scope.data = response.data.responseData.dataList[0].groups;
    					
    					alert(response.data.responseData.message);
    					window.location.reload();
    				},
    				function(e){alert("error: "+e);}
    			);
          
    	
           $scope.getGroups();
           //$scope.clearForm();
           
       };
          
    
        
       $scope.editNode = function (refNode, isDisabled) {
         /*  console.log(refNode.$element[0].childNodes[5].getAttribute('data-id'))
           console.log(refNode.$element[0].childNodes[5].getAttribute('data-parentid'))
           console.log(refNode.$element[0].childNodes[5].getAttribute('data-parantgroupid'))
          */ 
           
           
           //$scope.userForm = false;
    	   
    	   //alert(isDisabled);
    	   
    	   $scope.btnEdit = true;
    	   $scope.btnCancel = true;
    	   $scope.btnRemove = true;
    	   $scope.btnAssign = true;
    	   
    	   
    	   if("disabled" == isDisabled || "0" == $scope.CreateGroup ){
    	   		$scope.btnEdit = false;
    	   		$scope.btnCancel = false;
    	   		$scope.btnRemove = false;
    	   		$scope.btnAssign = false;
    	   }
    	  
    	   
    	   $scope.isNew = false;
    	   
           $scope.fieldName = refNode.$element[0].innerText;
          // $scope.botNodeName = $scope.fieldName;
           
           
           if(refNode.$element[0].childNodes[5].getAttribute('data-id') == null){
        	   var dataHtmlNode = refNode.$element[0].childNodes[3];
        	  
        	   
           }else{
        	   var dataHtmlNode = refNode.$element[0].childNodes[5];
        	   
        	   
           }
           $scope.dataId = dataHtmlNode.getAttribute('data-id');
           
           $scope.botNodeName =  dataHtmlNode.getAttribute('data-name');
           
           $scope.dataParantId = dataHtmlNode.getAttribute('data-parentid');
           $scope.dataParantGroupId = dataHtmlNode.getAttribute('data-parantgroupid');
           $scope.nodeTypeValue = dataHtmlNode.getAttribute('data-nodetype');
           $scope.description = dataHtmlNode.getAttribute('data-description');
           
           console.log($scope.dataId+$scope.dataParantId+$scope.dataParantGroupId+$scope.description);
           $scope.userForm = false;
           
           //alert("|"+$scope.botNodeName+"|");
           
           
           $scope.getGroupUsers($scope.dataId);
           $scope.getAllUsers($scope.dataId);
           
           if($scope.nodeTypeValue == "process") {
        	   getBPNames();
        	   getCampaignsList();
           }
           
           $http({
         	  method: 'POST',
         	  url: urlName + "vbrain/vBrainService/checkCanDeleteGroup",
         	  data:{
		     		 requestParameter: {
			      			groupId:$scope.dataId
			      		}
			        },
         	  headers: {
         		   'Content-Type': 'application/json'
         	  }
         	}).then(
 				function(response){
 					$scope.showDeleteGroup = response.data.canDelete;
 				},
 				function(e){alert("error: "+e);}
 			);
           
      };
      
      $scope.deleteGroup = function() {
    	  $http({
         	  method: 'POST',
         	  url: urlName + "vbrain/vBrainService/deleteGroup",
         	  data:{
		     		 requestParameter: {
			      			groupId:$scope.dataId
			      		}
			        },
         	  headers: {
         		   'Content-Type': 'application/json'
         	  }
         	}).then(
 				function(response){
 					alert(response.data.responseData.message);
 					window.location.reload();
 				},
 				function(e){alert("error: "+e);}
 			);
      };
        
      $scope.collapseAll = function () {
        $scope.$broadcast('angular-ui-tree:collapse-all');
      };

      $scope.expandAll = function () {
        $scope.$broadcast('angular-ui-tree:expand-all');
      };

      
      $scope.dataNodeUrl = urlName + "vbrain/vBrainService/getGroups";
      $http({
    	  method: 'POST',
    	  url: $scope.dataNodeUrl,
    	  data:{},
    	  headers: {
    		   'Content-Type': 'application/json'
    	  }
    	}).then(
				function(response){
					
					console.log(response.data.responseData.dataList[0].groups);
					$scope.data = response.data.responseData.dataList[0].groups;
					
					
				},
				function(e){alert("error: "+e);}
			);
      
      
      $scope.getGroups = function () {
    	  
    	  //alert("getGroups");
          
    	  $http({
        	  method: 'POST',
        	  url: $scope.dataNodeUrl,
        	  data:{},
        	  headers: {
        		   'Content-Type': 'application/json'
        	  }
        	}).then(
    				function(response){
    					
    					console.log(response.data.responseData.dataList[0].groups);
    					$scope.data = response.data.responseData.dataList[0].groups;
    					
    					
    				},
    				function(e){alert("error: "+e);}
    			);
     };
     
     
     //$scope.users = {};
     
     $scope.getGroupUsers = function (groupId) {
   	     
    	 // alert("groupId : "+groupId)
    	 
	   	 $http({
	       	  method: 'POST',
	       	  url: urlName + "vbrain/vBrainService/getGroupUsers",
	       	  data:{
		     		 requestParameter: {
			      			groupId:groupId
			      		}
			        },
	       	  headers: {
	       		   'Content-Type': 'application/json'
	       	  }
	       	}).then(
	   				function(response){
	   					
	   					console.log(response.data.responseData.dataList[0].group);
	   					$scope.users = response.data.responseData.dataList[0].group.users;
	   					
	   					
	   				},
	   				function(e){alert("error: "+e);}
	   			);
	    };
	    
	    
	    $scope.getAllUsers = function (groupId) {
	   	     
	    	 //alert("getAllUsers | groupId : "+groupId)
	    	 
		   	 $http({
		       	  method: 'POST',
		       	  url: urlName + "vbrain/vBrainService/getNonGroupUsers",
		       	  data:{
			     		 requestParameter: {
				      			groupId:groupId
				      		}
				        },
		       	  headers: {
		       		   'Content-Type': 'application/json'
		       	  }
		       	}).then(
		   				function(response){
		   					
		   					console.log("users ::::::: "+response.data.responseData.dataList[0].group);
		   					$scope.allUsers = response.data.responseData.dataList[0].group.users;
		   					
		   					
		   				},
		   				function(e){alert("error: "+e);}
		   			);
		    };
		    
		    
		    
		    
		    $scope.assignUser = function () {
		   	     
		    	 if(! $scope.aUsers){
		    		 alert("Please select the user");
		    		 return false;
		    	 }
		    	 
			   	 $http({
			       	  method: 'POST',
			       	  url: urlName + "vbrain/vBrainService/addGroupUsers",
			       	  data:{
				     		 requestParameter: {
					      			groupId:$scope.dataId,
					      			userIds:$scope.aUsers
					      		}
					        },
			       	  headers: {
			       		   'Content-Type': 'application/json'
			       	  }
			       	}).then(
			   				function(response){
			   					
			   					$scope.getGroupUsers($scope.dataId);
			   					$scope.getAllUsers($scope.dataId);
			   					
			   					alert(response.data.responseData.message);
			   				},
			   				function(e){alert("error: "+e);}
			   			);
			    };
			   
			    
			    
			    $scope.removeUserData = function (userData) {
			   	     
			    	 console.log("remove function called");
			    	 if(! $scope.assignedUsers){
			    		 alert("Please select the user");
			    		 return false;
			    	 }
			    	 
				   	 $http({
				       	  method: 'POST',
				       	  url: urlName + "vbrain/vBrainService/deleteGroupUser",
				       	  data:{
					     		 requestParameter: {
						      			groupId:$scope.dataId,
						      			userIds:$scope.assignedUsers
						      		}
						        },
				       	  headers: {
				       		   'Content-Type': 'application/json'
				       	  }
				       	}).then(
				   				function(response){
				   					//alert("assignUser ::::: ");
				   					
				   					
				   					$scope.getGroupUsers($scope.dataId);
				   					$scope.getAllUsers($scope.dataId);
				   					
				   					alert(response.data.responseData.message);
				   				},
				   				function(e){alert("error: "+e);}
				   			);
				    };
			    
			    
		    
		    
			    
			    
	
      
     /* 
      $scope.data = [
        {
	        'id': 1,
	        'title': 'Nodex',
	        'type': 'Bot Type',
	        'nodes': [
	          {
	            'id': 21,
	            'title': 'node1.1',
	            'type': 'Bot Type 1.1',
	            'nodes': [
	              {
	                'id': 111,
	                'title': 'Node 1.1.1',
	                'type': 'Bot Type 1.1.1',
	                'nodes': []
	              }
	            ]
	          }          
	        ]
	      },
	      {
	        'id': 1,
	        'title': 'NodeY',
	        'type': 'Bot Type',
	        'nodes': [
	          {
	            'id': 1,
	            'title': 'node1.1',
	            'type': 'Bot Type 1.1',
	            'nodes': [
	              {
	                'id': 1,
	                'title': 'Node 1.1.1',
	                'type': 'Bot Type 1.1.1',
	                'nodes': []
	              }
	            ]
	          }          
	        ]
	      }
        
      ];  */
    }]);

}());
