(function () {
  'use strict';
  
  // var urlName = "http://lowcost-env.yv5sv2bh2p.ap-south-1.elasticbeanstalk.com/";
  var urlName = window.location.origin + "/vBrain/";
  
  angular.module('demoApp')
    .controller('ProcessCtrl', ['$scope','$http', function ($scope,$http) {
     
	   	 $http({
	       	  method: 'POST',
	       	  url: urlName + "vbrain/vBrainService/getProcesses",
	       	  data:{},
	       	  headers: {
	       		   'Content-Type': 'application/json'
	       	  }
	       	}).then(
	   				function(response){
	   					
	   					console.log(response.data.responseData.dataList[0].group);
	   					$scope.processes = response.data.responseData.dataList[0].groups;
	   					
	   					
	   				},
	   				function(e){alert("error: "+e);}
	   			);
	   	 
	   	 
	 	$scope.clearBotFields = function (){
	 		  $scope.botId = "";
		        $scope.provider = '';
		    	$scope.ipName = '';
		    	$scope.description = '';
		    	$scope.bAvgEfforts ="";
				$scope.bAvgCost ="";
				$scope.bCycleTime ="";
				$scope.bTransactions ="";
			    
	 	}
	 	
	 	$scope.clearHumanFields = function (){
	 		 $scope.humanId = "";
		    $scope.workerId = "";
		    $scope.hName="";
		    $scope.hDescription="";
		    $scope.hAvgEfforts ="";
			$scope.hAvgCost ="";
			$scope.hCycleTime ="";
			$scope.hTransactions ="";
	 	}
	   	 
	   	$scope.getWorkers = function (){
	   		$scope.editBotMode = 0;
		    $scope.botId = "";
		    $scope.editHumanMode = 0;
		    $scope.humanId = "";

		    $scope.clearBotFields();
		    $scope.clearHumanFields();
		   
		    $scope.getBots();
	   		$scope.getHumans();
	   		
	   		
	   	}
	   	 
	   	$scope.getBots = function () {
	   		//alert($scope.aProcess);
	   		
			 $http({
		       	  method: 'POST',
		       	  url: urlName + "vbrain/vBrainService/getBots",
		       	  data:{
		     		 requestParameter: {
			      			processId:$scope.aProcess
			      		}
			      },
		       	  headers: {
		       		   'Content-Type': 'application/json'
		       	  }
		       	}).then(
		   				function(response){
		   					
		   					console.log(response.data.responseData.dataList[0].bots);
		   					$scope.bots = response.data.responseData.dataList[0].bots;
		   					
		   					
		   				},
		   				function(e){alert("error: "+e);}
		   			);
	   	}
	   	
	    $scope.addBot = function () {
	   	     
	    	var endPoint = "addBot";
	    	if($scope.editBotMode == 1){
	    		endPoint = "editBot";
	    	}
	    	//alert(endPoint);
		   	 $http({
		       	  method: 'POST',
		       	  url: urlName + "vbrain/vBrainService/"+endPoint,
		       	  data:{
			     		 requestParameter: {
			     			 bot:{
			     				id:$scope.botId,
			     				provider:$scope.provider,
			     				hostName:$scope.ipName,
			     				description:$scope.description,
			     				processId:$scope.aProcess,
			     				avgEfforts:$scope.bAvgEfforts,
			     				avgCost:$scope.bAvgCost,
			     				cycleTime:$scope.bCycleTime,
			     				noOftransactions:$scope.bTransactions
			     				
			     			 }
				      			
				      	  }
				        },
		       	  headers: {
		       		   'Content-Type': 'application/json'
		       	  }
		       	}).then(
		   				function(response){
		   					//alert("assignUser ::::: ");
		   					alert(response.data.responseData.message);
		   					
		   				    $scope.clearBotFields();
			   		    	
		   					$scope.getBots();
		   				},
		   				function(e){alert("error: "+e);}
		   			);
		    };
		    
		    $scope.editBotMode = 0;
		    $scope.botId = "";
		   		    
		    $scope.dispBot = function (bot) {
		   	     
		    	console.log("disp bot function called");
		    	
			 	$scope.provider = bot.provider;
		    	$scope.ipName = bot.hostName;
		    	$scope.description = bot.description;
		    	$scope.bAvgEfforts = bot.avgEfforts;
 				$scope.bAvgCost = bot.avgCost;
 				$scope.bCycleTime = bot.cycleTime;
 				$scope.bTransactions = bot.noOftransactions;
		    	
		    	$scope.editBotMode = 1;
		    	$scope.botId = bot.id;
		    	
		    	
		    };
		    
		    $scope.editBot = function (botId) {
		   	     
		    	 console.log("edit bot function called");
		    	 
			   	 $http({
			       	  method: 'POST',
			       	  url: urlName + "vbrain/vBrainService/editBot",
			       	  data:{
				     		 requestParameter: {
				     			 bot:{	
				     				 	id:botId,
					     				provider:$scope.provider,
					     				hostName:$scope.ipName,
					     				description:$scope.description,
					     				processId:$scope.aProcess
					     				 
					     			 }
					      		}
					        },
			       	  headers: {
			       		   'Content-Type': 'application/json'
			       	  }
			       	}).then(
			   				function(response){
			   					//alert("assignUser ::::: ");
			   					alert(response.data.responseData.message);
			   					$scope.botId = "";
			   			        $scope.provider = '';
				   		    	$scope.ipName = '';
				   		    	$scope.description = '';
				   		    	
				   		    	$scope.bAvgEfforts ="";
			     				$scope.bAvgCost ="";
			     				$scope.bCycleTime ="";
			     				$scope.bTransactions ="";
			   					
			   				},
			   				function(e){alert("error: "+e);}
			   			);
			    };
		    
			    $scope.removeBot = function (botId) {
			   	     
			    	 console.log("remove function called");
			    	 
				   	 $http({
				       	  method: 'POST',
				       	  url: urlName + "vbrain/vBrainService/disableBot",
				       	  data:{
					     		 requestParameter: {
						      			bot:{
						      				id:botId
						      			}
						      		}
						        },
				       	  headers: {
				       		   'Content-Type': 'application/json'
				       	  }
				       	}).then(
				   				function(response){
				   					//alert("assignUser ::::: ");
				   					alert(response.data.responseData.message);
				   					
				   					$scope.clearHumanFields();
				   					$scope.getBots();
				   					
				   				},
				   				function(e){alert("error: "+e);}
				   			);
				    };
			    
		    
		    $scope.addHuman = function () {
		   	     
		    	var endPoint = "addHuman";
		    	if($scope.editHumanMode == 1){
		    		endPoint = "editHuman";
		    	}
		    	// alert(endPoint);
		    	 
			   	 $http({
			       	  method: 'POST',
			       	  url: urlName + "vbrain/vBrainService/"+endPoint,
			       	  data:{
				     		 requestParameter: {
				     			 human:{
				     				id:$scope.humanId,
				     				workerId:$scope.workerId,
				     				name:$scope.hName,
				     				description:$scope.hDescription,
				     				processId:$scope.aProcess,
				     				
				     				avgEfforts:$scope.hAvgEfforts,
				     				avgCost:$scope.hAvgCost,
				     				cycleTime:$scope.hCycleTime,
				     				noOftransactions:$scope.hTransactions

				     				 
				     			 }
					      			
					      	  }
					        },
			       	  headers: {
			       		   'Content-Type': 'application/json'
			       	  }
			       	}).then(
			   				function(response){
			   					//alert("assignUser ::::: ");
			   					alert(response.data.responseData.message);
			   				
			   				    $scope.clearHumanFields();
			   					
			   					$scope.getHumans();
			   					
			   					
			   				},
			   				function(e){alert("error: "+e);}
			   			);
			    };
		
			    $scope.editHumanMode = 0;
			    $scope.humanId = "";
			    
			    $scope.workerId = "";
			    $scope.name="";
			    $scope.description="";
			    
			    $scope.dispHuman = function (human) {
			   	     
			    	console.log("disp bot function called");
			    	
			    	$scope.workerId = human.workerId;
			    	$scope.hName = human.name;
			    	$scope.hDescription = human.description;
			    	$scope.hAvgEfforts = human.avgEfforts;
	 				$scope.hAvgCost = human.avgCost;
	 				$scope.hCycleTime = human.cycleTime;
	 				$scope.hTransactions = human.noOftransactions;
			    	
			    	$scope.editHumanMode = 1;
			    	$scope.humanId = human.id;
			    	
			    };
			    
				    $scope.removeHuman = function (humanId) {
				   	     
				    	 console.log("remove function called");
				    	 
					   	 $http({
					       	  method: 'POST',
					       	  url: urlName + "vbrain/vBrainService/disableHuman",
					       	  data:{
						     		 requestParameter: {
							      			human:{
							      				id:humanId
							      			}
							      		}
							        },
					       	  headers: {
					       		   'Content-Type': 'application/json'
					       	  }
					       	}).then(
					   				function(response){
					   					//alert("assignUser ::::: ");
					   					alert(response.data.responseData.message);
					   					$scope.getHumans();
					   					$scope.clearHumanFields();
					   					
					   				},
					   				function(e){alert("error: "+e);}
					   			);
					    };
				    
			    
			    
			    
			    
			    
	   	
		$scope.getHumans = function () {
	   		//alert($scope.aProcess);
	   		
			 $http({
		       	  method: 'POST',
		       	  url: urlName + "vbrain/vBrainService/getHumans",
		       	  data:{
		     		 requestParameter: {
			      			processId:$scope.aProcess
			      		}
			      },
		       	  headers: {
		       		   'Content-Type': 'application/json'
		       	  }
		       	}).then(
		   				function(response){
		   					
		   					console.log(response.data.responseData.dataList[0].humans);
		   					$scope.humans = response.data.responseData.dataList[0].humans;
		   					
		   					
		   				},
		   				function(e){alert("error: "+e);}
		   			);
	   	}
		

         }]);

}());
