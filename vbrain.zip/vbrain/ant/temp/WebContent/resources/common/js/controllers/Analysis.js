(function () {
  'use strict';
  
  var urlName = window.location.origin + "/vBrain/";
  var locationPath = "vBrain/resources/";

  
  angular.module('vBrainApp', ['ngRoute', 'ui.bootstrap'])
    .controller('AnalysisCtrl', ['$scope','$http', '$compile', '$window', function ($scope,$http,$compile, $window) {
    	
    	if(! $window.sessionStorage.getItem('analysisLoginId') || $window.sessionStorage.getItem('analysisLoginId') == null){
  			alert("Invalid access! Please login...");
  			
  			window.location.pathname = locationPath + 'analysis-index.html';
  		}
    	
    	$scope.rows = [];
    	
    	$scope.mappings = [{
    		name: "Must map",
    		value: "must-map"
    	},{
    		name: "If Available maps",
    		value: "if-available"
    	}];
    	
    	$scope.canSubmit = false;
    	
    	var addRowObject = function() {
    		var row = {};
    		row.tableName = "";
    		row.trackingIdField = "";
    		row.errorMessageField = "";
    		row.systemIdField = "";
    		row.startDateField = "";
    		
    		row.alias = String.fromCharCode(97 + $scope.rows.length);
    		
    		if($scope.rows.length > 1) {
    			row.map = "";
    			row.dependingTable = "";
    			row.dependingTableField = "";
    			row.dependentField = "";
    		}
    		
    		$scope.rows.push(row);
    	}
    	
    	$scope.showResults = function() {
    		var dataAPIUrl = urlName + 'vbrain/vBrainService/wfMultiQuery2';

    		/*var tableName = $scope.rows[0].tableName + " " + $scope.rows[0].alias;
    		var trackingIdField = "";
    		var errorMessageField = "";
    		var systemIdField = "";
    		var startDateField = "";
    		
    		for (var int = 0; int < $scope.rows.length; int++) {
				var row = $scope.rows[int];
				
				if(int != 0) {
					tableName += "|" + row.tableName + " " + row.alias + "|" 
						+ row.dependingTable.alias + "." + row.dependingTableField + "," + row.alias + "." + row.dependentField;
				}
				if(row.trackingIdField) {
					trackingIdField = row.alias + "." + row.trackingIdField;
				}
				if(row.errorMessageField) {
					errorMessageField = row.alias + "." + row.errorMessageField;
				}
				if(row.systemIdField) {
					systemIdField = row.alias + "." + row.systemIdField;
				}
				if(row.startDateField) {
					startDateField = row.alias + "." + row.startDateField;
				}
			}
    		
    		console.log(JSON.stringify($scope.rows));*/
    		
    		var data = [];
    		for (var int = 0; int < $scope.rows.length; int++) {
    			var row = $scope.rows[int];
    			var dataObj = {
	    			"tableName" : row.tableName,
	    			"trackingIdField" : row.trackingIdField,
	    			"errorMessageField" : row.errorMessageField,
	    			"systemIdField" : row.systemIdField,
	    			"startDateField" :  row.startDateField,
	    			"bpUuidField" : row.bpUuidField,
	    			"endDateField" : row.endDateField,
	    			"processingTimeField" : row.processingTimeField,
	    			"alias" : row.alias
    			};
    			if(row.dependingTable) {
    				dataObj.map = {
    						"type" : row.map,
    						"dependentField" : row.dependentField,
    						//"dependingTableName" : row.dependingTable.tableName,
    						"dependingTableAlias" : row.dependingTable.alias,
    						"dependingTableField" : row.dependingTableField
    				};
    			}
    			data.push(dataObj);
    		}
    		
    		console.log(data);
    		console.log($scope.rows);
    		
    		$http({
				method : 'POST',
				url : dataAPIUrl,
				data : {
					version: $scope.wfVersion,
					queryList: {data: data}
				},
				headers : {
					'Content-Type' : 'application/json'
				}
			}).then(function(response) {
				$scope.resultSet = response.data.content;
				$scope.query = response.data.query;
				$scope.canSubmit = true;

			}, function(e) {
				console.log("error: " + e);
			});
    	};
    	
    	$scope.addBusinessProcess = function() {
    		
    		var dataAPIUrl = urlName + 'vbrain/vBrainService/addBusinessProcess2';

    		var data = [];
    		for (var int = 0; int < $scope.rows.length; int++) {
    			var row = $scope.rows[int];
    			var dataObj = {
	    			"tableName" : row.tableName,
	    			"trackingIdField" : row.trackingIdField,
	    			"errorMessageField" : row.errorMessageField,
	    			"systemIdField" : row.systemIdField,
	    			"startDateField" :  row.startDateField,
	    			"bpUuidField" : row.bpUuidField,
	    			"endDateField" : row.endDateField,
	    			"processingTimeField" : row.processingTimeField,
	    			"alias" : row.alias
    			};
    			if(row.dependingTable) {
    				dataObj.map = {
    						"type" : row.map,
    						"dependentField" : row.dependentField,
    						//"dependingTableName" : row.dependingTable.tableName,
    						"dependingTableAlias" : row.dependingTable.alias,
    						"dependingTableField" : row.dependingTableField
    				};
    				
    			}
    			data.push(dataObj);
    		}

    		var tableNameExists=data.filter(function(item){
    		    return item.tableName;         
    		}).length > 0;
    		var trackingIdFieldExists=data.filter(function(item){
    		    return item.trackingIdField;         
    		}).length > 0;
    		var errorMessageFieldExists=data.filter(function(item){
    		    return item.errorMessageField;         
    		}).length > 0;
    		var systemIdFieldExists=data.filter(function(item){
    		    return item.systemIdField;         
    		}).length > 0;
    		var startDateFieldExists=data.filter(function(item){
    		    return item.startDateField;         
    		}).length > 0;
    		
    		if(!$scope.businessProcessName || !$scope.startDateFormat
    				|| !tableNameExists || !trackingIdFieldExists|| !errorMessageFieldExists || !systemIdFieldExists|| !startDateFieldExists) {
    			alert("Business Process and Start Date Format and atleast one Tracking ID, Error Message, System ID and Start Date Fields are required!");
    			return;
    		}
    		
    		console.log(data);
    		console.log($scope.rows);
    		
    		$http({
				method : 'POST',
				url : dataAPIUrl,
				data : {
					bpName: $scope.businessProcessName,
					startDateFormat: $scope.startDateFormat,
					orderBy: $scope.orderBy,
					version: $scope.wfVersion,
					queryList: {data: data}
				},
				headers : {
					'Content-Type' : 'application/json'
				}
			}).then(function(response) {
				alert(response.data.responseData.message);

			}, function(e) {
				console.log("error: " + e);
			});
    	};
    	
    	$scope.addRow = function($event) {
    		addRowObject();
    		
    	};
    	
    	$scope.deleteRow = function(idx) {
    		$scope.rows.splice(idx,1);
    	};
    	
    	$scope.getListedTables = function() {
    		var tables = [];
    		for (var int = 0; int < $scope.rows.length-1; int++) {
				var row = $scope.rows[int];
				if(row.tableName)
					tables.push(row.tableName);
			}
    		return tables;
    	};
    	
    	$scope.emptyOthers = function(idx, field) {
    		for (var int = 0; int < $scope.rows.length; int++) {
				var row = $scope.rows[int];
				if(int != idx)
					row[field] = "";
			}
    	};
    	
    	$scope.editDetails = function () {
    		$scope.canSubmit = false;
    	};
    	
    	$scope.triggerScheduler = function() {
    		$http({
				method : 'GET',
				url : urlName + 'vbrain/vBrainService/triggerScheduler'
			}).then(function(response) {
				alert(response.data);
			}, function(e) {
				console.log("error: " + e);
			});
    	}
    	
    	addRowObject();
    }]);
}());
