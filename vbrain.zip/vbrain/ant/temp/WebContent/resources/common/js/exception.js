(function() {
	'use strict';
	console.log('exceptions  loaded...');

	var hostName = window.location.origin + "/vBrain/";
	var locationPath = "vBrain/resources/";

	angular.module('vBrainApp')
		.controller('ExceptionCtrl', ['$scope', '$http', '$window', function($scope, $http, $window) {
			
			
			var retrieveItemList = function(groupType) {
				var postReq = {
					method : 'POST',
					url : hostName + 'vbrain/vBrainService/getGroupNames',
					headers : {
						'Content-Type' : 'application/json'
					},
					data : {
						"requestParameter" : {
							"type" : groupType
						}
					}
				};
				$http(postReq)
					.then(function(response) {
						$scope.lobNameList = response.data.responseData.dataList;
					},
					function(e) {
						console.log("error: "+ e);
					});
				
			};

			var getExceptionTypeList = function() {
				var postReq = {
						method : 'POST',
						url : hostName + 'vbrain/vBrainService/getExceptionTypes',
						headers : {
							'Content-Type' : 'application/json'
						},
						data : {}
					};
					$http(postReq)
						.then(function(response) {
							var respData = response.data;
							var returnOptions = [];
							for ( var key in respData) {
								if(respData.hasOwnProperty(key)) {
									var option = {};
									option.id = key;
									option.name = respData[key];
									returnOptions.push(option);
								}
							}
							$scope.exceptionTypes = respData;
							$scope.exceptionTypeOptions = returnOptions;
						
						},
						function(e) {
							console.log("error: " + e);
						});
					
			};
			
			var getAllExceptionsByLob = function() {
				var lobId=" ";
				var postReq = {
					method : 'POST',
					url : hostName + 'vbrain/vBrainService/getExceptionsByLob',
					headers : {
						'Content-Type' : 'application/json'
					},
					data : {
						"requestParameter" : {
							"groupId" : lobId
						}
					}
				};
				$http(postReq)
					.then(function(response) {
						 var dataList = response.data.responseData.dataList;
						 if(dataList && dataList.length > 0) {
							 var exceptionsList = dataList[0].exceptions;
							 for (var i = 0; i < exceptionsList.length; i++) {
								 exceptionsList[i].exceptionTypeName = $scope.exceptionTypes[exceptionsList[i].exceptionType];
							 }
							 $scope.excpetionsList = exceptionsList;
						 }
					},
					function(e) {
						console.log("error: " + e);
					});
				// Default selecting full match No
				 $scope.fullMatchValue="Contains";
				 
			}
			
			var setExceptionEditMode = function(excpetionId, inEditMode) {
				for(var i = 0; i < $scope.excpetionsList.length; i++) {
					
					if($scope.excpetionsList[i].id == excpetionId) {
						$scope.excpetionsList[i].inEditMode = inEditMode;
						
						break;
					}
				}
			}

			retrieveItemList('lob');
			getExceptionTypeList();
			getAllExceptionsByLob("");
			

			$scope.addException = function() {
				if(!$scope.lob || !$scope.exceptionType || !$scope.exceptionValue || !$scope.fullMatchValue) {
					alert("Error in adding Exceptions. Please select all mandatory fields!!!")
					return;
				}
				var dataAPIUrl = hostName + '/vbrain/vBrainService/addException';
				var newNode = {
					requestParameter : {
						exception : {
							lob : $scope.lob,
							exceptionType : $scope.exceptionType,
							exceptionValue : $scope.exceptionValue,
							fullMatchValue : $scope.fullMatchValue
						}
					}
				};
				$http({
					method : 'POST',
					url : dataAPIUrl,
					data : newNode,
					headers : {
						'Content-Type' : 'application/json'
					}
				}).then(function(response) {
					console.log(response.data);
					getAllExceptionsByLob("");
					alert(response.data.responseData.message);

				}, function(e) {
					console.log("error: " + e);
				});

			};
			
			$scope.deleteException = function (exceptionId) {
				var r = confirm("Are you sure you want to delete the exception?");
				if (r == true) {
					var postReq = {
						method : 'POST',
						url : hostName + 'vbrain/vBrainService/deleteException',
						headers : {
							'Content-Type' : 'application/json'
						},
						data : {
							"requestParameter" : {
								"exceptionId" : exceptionId
							}
						}
					};
					$http(postReq)
						.then(function(response) {
							getAllExceptionsByLob("");
							alert(response.data.responseData.message);
						},
						function(e) {
							console.log("error: " + e);
						});
				}
			};
			
			$scope.editException = function (excpetionId) {
				setExceptionEditMode(excpetionId, true);
			}
			
			$scope.cancelUpdate = function (excpetionId) {
				setExceptionEditMode(excpetionId, false);
			}
			
			$scope.saveException = function (exception) {
				var dataAPIUrl = hostName + '/vbrain/vBrainService/updateException';
				var newNode = {
					requestParameter : {
						exception : {
							id: exception.id,
							lob: exception.lob,
							exceptionType: exception.exceptionType,
							exceptionValue: exception.exceptionValue,
							fullMatchValue: exception.fullMatchValue
						}
					}
				};

				$http({
					method : 'POST',
					url : dataAPIUrl,
					data : newNode,
					headers : {
						'Content-Type' : 'application/json'
					}
				}).then(function(response) {
					console.log(response.data);
					setExceptionEditMode(exception.id, false);
					alert(response.data.responseData.message);

				}, function(e) {
					console.log("error: " + e);
				});
			}

		} ]);
}());
