

(function () {
	'use strict';
	console.log('ou-dashboard loaded...');

	var hostName = window.location.origin + "/vBrain/";


	//var locationPath = "resources/";
	var locationPath = "vBrain/resources/";


	angular.module('vBrainApp')
		.controller('OuDashboardCtrl', ['$scope', '$http', '$window', function ($scope, $http, $window) {
			

			if (!$window.sessionStorage.getItem('loginId') || $window.sessionStorage.getItem('loginId') == null) {
				alert("Invalid access! Please login...");

				window.location.pathname = locationPath + 'index.html';

			}

			console.log('ou-dashboard loaded...');

			document.getElementById("loginId").innerHTML = $window.sessionStorage.getItem('loginId');
			document.getElementById("loginRole").innerHTML = $window.sessionStorage.getItem('loginRole');

			document.getElementById("aFunctionName").innerHTML = $window.sessionStorage.getItem('functionName');
			document.getElementById("aLob").innerHTML = $window.sessionStorage.getItem('lobName');
			document.getElementById("dateFromDiv").innerHTML = $window.sessionStorage.getItem('fromDate');
			//alert($window.sessionStorage.getItem('fromDate'));

			document.getElementById("dateToDiv").innerHTML = $window.sessionStorage.getItem('toDate');

			$scope.changeSelection = function () {
				window.location.pathname = locationPath + 'selection.html';

			}

			$scope.botTransaction = true;

			$scope.botGoBack = function () {
				$scope.botTransaction = true;
				$scope.botDetails = false;
			}

			$scope.getBotWiseTransactions = function (botKey, process, country, transactions) {

				$scope.transactionBotKey = botKey;
				$scope.transactionBotProcess = process;
				$scope.transactionBotCountry = country;
				$scope.transactionBotTransactions = transactions;
				var botTransactions = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/getBotWiseTransactions',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"botKey": botKey,
							"function": document.getElementById("aFunctionName").innerHTML,
							"startDate": document.getElementById("dateFromDiv").innerHTML,
							"endDate": document.getElementById("dateToDiv").innerHTML
						}
					}
				};
				$http(botTransactions).then(
					function (response) {

						$scope.botTransactionList = response.data.responseData.dataList;
						$scope.botTransaction = false;
						$scope.botDetails = true;

					},
					function (e) {
						alert("error: " + e);
					});

			}

			//var workStepTransactions;
			//var groupByTransactions;
			var slaTransactions;
			var slaTransactionsRegionWise;

			$scope.displayCurrentDate = function () {
				var today = new Date();
				var dd = today.getDate();
				var mm = today.getMonth() + 1; //January is 0!

				var yyyy = today.getFullYear();
				if (dd < 10) {
					dd = '0' + dd
				}
				if (mm < 10) {
					mm = '0' + mm
				}
				var today = mm + '/' + dd + "/" + yyyy;
				//alert(today);
				//document.getElementById("dateToDiv").innerHTML = today;
			}

			$scope.displayCurrentDate();


			$scope.enableLoader = function (mode) {
				if (mode == 1) {
					document.getElementById("loaderDiv").style.display = "block";
				}
				else {
					document.getElementById("loaderDiv").style.display = "none";
				}

			}

			$scope.enableLoader(1);

			$scope.slaRegionWise = function () {

				var slaReqRegionWise = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/getSLAListByStatus',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"function": document.getElementById("aFunctionName").innerHTML,
							"startDate": document.getElementById("dateFromDiv").innerHTML,
							"endDate": document.getElementById("dateToDiv").innerHTML,
							"mode": "regionWise"
						}
					}
				};



				$http(slaReqRegionWise).then(
					function (response) {

						$scope.slaTransactionsRegionWise = response.data.responseData.dataList;

						//alert("slaTransactionsRegionWise :::: "+$scope.slaTransactionsRegionWise);

						$scope.dispSLAChart('');
						//$scope.displayHome(workStep, mode);

					},
					function (e) {
						alert("error: " + e);
					});

			}


			$scope.showRightMenu = function (val) {

				var rMenus = ["monitor", "sla", "settings"];

				document.getElementById(val).style.display = "block";
				document.getElementById("menu_" + val).style.background = "black";

				for (var i = 0; i < rMenus.length; i++) {
					if (rMenus[i] != val) {

						document.getElementById(rMenus[i]).style.display = "none";
						document.getElementById("menu_" + rMenus[i]).style.background = "#2c3b4e";
					}
				}

				if (val == "sla") {
					//alert("sla");
					$scope.popSLAMonitor();
				}
				else if (val == "monitor") {
					$scope.menuAction(1);
					$scope.popWorkMonitor();
				}
			}


			$scope.slaMenuAction = function (val) {

				document.getElementById("sla" + val).className = "tabEnable";


				for (var i = 1; i < 2; i++) {

					if (i != val) {
						document.getElementById("sla" + i).className = "tabDisable";
					}
				}
			}

			$scope.menuAction = function (val) {

				document.getElementById("t" + val).className = "tabEnable";


				for (var i = 1; i < 4; i++) {

					if (i != val) {
						document.getElementById("t" + i).className = "tabDisable";
					}
				}
			}

			$scope.getSLAByProcess = function (processName) {
				//alert(processName);

				var slaReqByProcess = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/getSLAListByStatus',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"function": document.getElementById("aFunctionName").innerHTML,
							"startDate": document.getElementById("dateFromDiv").innerHTML,
							"endDate": document.getElementById("dateToDiv").innerHTML,
							"mode": "regionWise",
							"workStep": processName

						}
					}
				};


				$http(slaReqByProcess).then(
					function (response) {

						$scope.slaTransactionsRegionWise = response.data.responseData.dataList;

						//alert("slaTransactionsRegionWise :::: "+$scope.slaTransactionsRegionWise);

						document.getElementById("slaSummary1").style.display = "block";
						document.getElementById("slaSummary2").style.display = "none";

						$scope.dispSLAChart(processName);
						//$scope.displayHome(workStep, mode);

					},
					function (e) {
						alert("error: " + e);
					});



			}

			$scope.popSLAMonitor = function () {

				document.getElementById("homeView").style.display = "none";
				document.getElementById("home").style.display = "none";
				//document.getElementById("subTitle").innerHTML = "&nbsp; "+ workStep + " Processed by BOTs - From "+document.getElementById('startValue').innerHTML +" To " +document.getElementById('endValue').innerHTML;

				document.getElementById("botSection").style.display = "none";


				document.getElementById("slaSummary1").style.display = "block";
				document.getElementById("slaSummary2").style.display = "none";

				document.getElementById("slaView").style.display = "block";
				document.getElementById("slaMonitorRView").style.display = "block";
				document.getElementById("topRTitle").innerHTML = "&nbsp; SLA Status";
				document.getElementById("totTrans").style.display = "none";

				document.getElementById("workMonitorRView").style.display = "none";
				document.getElementById("workMonitorData").style.display = "none";
				document.getElementById("botMontorData").style.display = "none";
				document.getElementById("slaDashboardData").style.display = "block";
				document.getElementById("incidentMonitorData").style.display = "none";
				document.getElementById("incidentSection").style.display = "none";


				$scope.totIncTrans = 0;
				$scope.totIncAchCount = 0;
				$scope.totIncBrhCount = 0;
				var slaReqWorkstepWise = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/getSLAListByStatus',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"function": document.getElementById("aFunctionName").innerHTML,
							"startDate": document.getElementById("dateFromDiv").innerHTML,
							"endDate": document.getElementById("dateToDiv").innerHTML,
							"mode": "workstepWise"
						}
					}
				};

				$http(slaReqWorkstepWise).then(
					function (response) {
						//alert("hi");
						$scope.slaTransactions = response.data.responseData.dataList;

						for (var i = 0; i < $scope.slaTransactions.length; i++) {

							$scope.totIncTrans = $scope.totIncTrans + $scope.slaTransactions[i].totalTransactions;
							$scope.totIncAchCount = $scope.totIncAchCount + $scope.slaTransactions[i].slaAchieved;
							$scope.totIncBrhCount = $scope.totIncBrhCount + $scope.slaTransactions[i].slaBreachedActive;
						}




						$scope.slaRegionWise();
						$scope.dispSlaTotalTransaction();

						//alert("slaTransactions :::: "+$scope.slaTransactions);
						//$scope.displayHome(workStep, mode);

					},
					function (e) {
						alert("error: " + e);
					});
			}


			$scope.popSLARegionWise = function (status) {
				var slaReqWorkstepWise = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/getSLAListByStatus',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"function": document.getElementById("aFunctionName").innerHTML,
							"startDate": document.getElementById("dateFromDiv").innerHTML,
							"endDate": document.getElementById("dateToDiv").innerHTML,
							"status": status,
							"mode": "statusWise"
						}
					}
				};

				$http(slaReqWorkstepWise).then(
					function (response) {

						$scope.slaByStatus = response.data.responseData.dataList;


						$scope.dispSLARegionChart(status, '');

						document.getElementById("slaViewTitle").innderHTML = "Region wise SLA " + status + " summary";
						document.getElementById("slaSummary1").style.display = "none";
						document.getElementById("slaSummary2").style.display = "block";

						$scope.viewSLA('US', status, 'daily');

					},
					function (e) {
						alert("error: " + e);
					});
			}


			$scope.dispSlaTotalTransaction = function () {

				var slaList = $scope.slaTransactions;
				var achCountPer = 0;
				var brcCount = 0;
				var brcCountPer = 0;
				var count = 0;
				for (var i = 0; i < slaList.length; i++) {

					brcCount = brcCount + slaList[i].slaBreachedActivePer;
					count++;
				}

				brcCountPer = brcCount / count;
				achCountPer = 100 - brcCountPer;




				Highcharts.chart('slaMonitorRView', {
					chart: {
						type: 'pie',

					},
					title: {
						text: 'SLA'
					},
					tooltip: {
						pointFormat: '<b> {point.y} %</b>'
					},
					subtitle: {
						text: ''
					},
					plotOptions: {
						pie: {
							allowPointSelect: false,
							showInLegend: true,
							dataLabels: {
								enabled: false

							}
						}
					},
					series: [{
						name: '',
						data: [
							{
								name: "Achieved",
								color: {
									linearGradient: { x1: 0, x2: 0, y1: 1, y2: 0 },
									stops: [
										[0, '#556B2F'],
										[1, '#32CD32']
									]
								},
								y: achCountPer

							},
							{
								name: "Breached",
								color: {
									linearGradient: { x1: 0, x2: 0, y1: 1, y2: 0 },
									stops: [
										[0, '#8B0000'],
										[1, '#EE2C2C']

									]
								},
								y: brcCountPer

							}
						]

					}]
				});

			}


			$scope.dispIncidentChart = function () {

				document.getElementById("incidentsMap").style.display = "block";
				document.getElementById("incidentDetails").style.display = "none";
				document.getElementById("incindentTitle").innerHTML = "&nbsp; Incident Summary";
				// Create the chart
				Highcharts.chart('incidentsMap', {
					chart: {
						type: 'column'
					},
					title: {
						text: 'Incident Details - Region Wise'
					},
					subtitle: {
						text: ''
					},
					xAxis: {
						type: 'category'
					},
					yAxis: {
						min: 0,
						title: {
							text: ''
						}
					},
					plotOptions: {
						column: {
							pointPadding: 0,
							borderWidth: 0
						},
						series: {
							borderWidth: 0,
							dataLabels: {
								enabled: true
							}
						}
					},

					series: [{
						name: 'Total Incidents',
						color: {
							linearGradient: { x1: 0, x2: 0, y1: 1, y2: 0 },
							stops: [
								[0, '#556B2F'],
								[1, '#32CD32']
							]
						},
						data: [
							{
								name: 'US',
								y: 4,
								drilldown: 'US - 1'
							}
						]
					}, {
						name: 'Closed',
						color: {
							linearGradient: { x1: 0, x2: 0, y1: 1, y2: 0 },
							stops: [
								[0, '#CD6600'],
								[1, '#FFA500']
							]
						},
						data: [{
							name: 'US',
							y: 1,
							drilldown: 'US - 2'
						}]
					}, {
						name: 'Open',
						color: {
							linearGradient: { x1: 0, x2: 0, y1: 1, y2: 0 },
							stops: [
								[0, '#8B0000'],
								[1, '#EE2C2C']
							]
						},
						data: [{
							name: 'US',
							y: 3,
							drilldown: 'US - 3'
						}]
					}],
					drilldown: {
						series: [{
							id: 'US - 1',
							name: 'Total Incidents US',

							data: [
								['Create FNOL', 4]
							]
						}, {
							id: 'US - 2',
							name: 'Closed US',
							data: [
								['Create FNOL', 1]
							]
						}, {
							id: 'US - 3',
							name: 'Open US',
							data: [
								['Create FNOL', 3]
							]
						}]
					}
				});
			}

			$scope.dispSLAChart = function (processName) {

				//alert("data List: "+$scope.slaTransactionsRegionWise.length);

				$scope.region = [];
				$scope.slaRTransAchieved = [];
				//$scope.slaRTransBreachedF =	[];
				$scope.slaRTransBreachedA = [];

				for (var i = 0; i < $scope.slaTransactionsRegionWise.length; i++) {
					//alert("Region:::::: "+$scope.slaTransactionsRegionWise[i].region);

					$scope.region.push($scope.slaTransactionsRegionWise[i].region);
					$scope.slaRTransAchieved.push($scope.slaTransactionsRegionWise[i].slaAchievedPer);
					//$scope.slaRTransBreachedF.push($scope.slaTransactionsRegionWise[i].slaBreachedFulfilledPer);
					$scope.slaRTransBreachedA.push($scope.slaTransactionsRegionWise[i].slaBreachedActivePer);


				}


				$('#containerSLA').highcharts({

					chart: {
						type: 'column'
					},
					title: {
						text: processName + ' Region Wise SLA Summary'
					},
					subtitle: {
						text: ''
					},
					xAxis: {
						categories: $scope.region,
						crosshair: true
					},
					yAxis: {
						min: 0,
						title: {
							text: 'Count %'
						}
					},
					tooltip: {
						headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
						pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
							'<td style="padding:0"><b>{point.y}% </b></td></tr>',
						footerFormat: '</table>',
						shared: true,
						useHTML: true
					},
					plotOptions: {
						column: {
							pointPadding: 0,
							borderWidth: 0
						}
					},

					series: [{
						name: 'Achieved',
						color: {
							linearGradient: { x1: 0, x2: 0, y1: 1, y2: 0 },
							stops: [
								[0, '#556B2F'],
								[1, '#32CD32']
							]
						},
						data: $scope.slaRTransAchieved

					},
					{
						name: 'Breached',
						color: {
							linearGradient: { x1: 0, x2: 0, y1: 1, y2: 0 },
							stops: [
								[0, '#8B0000'],
								[1, '#EE2C2C']
							]
						},
						data: $scope.slaRTransBreachedA

					}]

				});

			}
			

			$scope.getTransactionsReport = function() {
				
				
				var req = {
						method: 'POST',
						url: hostName + 'vbrain/vBrainService/getTransactionsReport',
						headers: {
							'Content-Type': 'application/json'
						},
						data: {
							"requestParameter": {
								"function": document.getElementById("aFunctionName").innerHTML,
								"startDate": document.getElementById("dateFromDiv").innerHTML,
								"endDate": document.getElementById("dateToDiv").innerHTML
							}
						}
					};

					$http(req).then(
						function (response) {
							var blob = new Blob([response.data], {type: "text/csv"});
							
							var fileURL = URL.createObjectURL(blob);
				            var a         = document.createElement('a');
				            a.href        = fileURL; 
				            a.target      = '_blank';
				            a.download    = new Date().toString("MMddyyyyhhmm") + '-transaction-report.csv';
				            document.body.appendChild(a);
				            a.click();

						});
			}

			$scope.getTransByProcess = function (mode, workStep, bp_uuid) {
				
				//alert("mode : "+$scope.tTrans);
				$scope.enableLoader(1);

				$scope.tTrans = 0; $scope.tTime = 0; $scope.tEffort = 0; $scope.tAvg = 0; $scope.tCnt = 0;

				if (workStep == "") {
					workStep = document.getElementById("currentWorkStep").value;
				}

				if (mode == "Daily") {
					document.getElementById("durationDaily").checked = true;
				}
				
				if(!bp_uuid) {
					bp_uuid = document.getElementById("currentBpUuid").value ;
				}
				

				//alert("workStep: "+workStep+" mode: "+mode);

				var dataObj = {
						"requestParameter": {
							"function": document.getElementById("aFunctionName").innerHTML,
							"startDate": document.getElementById("dateFromDiv").innerHTML,
							"endDate": document.getElementById("dateToDiv").innerHTML,
							"workStep": workStep,
							"groupBy": mode
						}
					};
				if(bp_uuid) {
					dataObj["requestParameter"]["bp_uuid"]=bp_uuid;
				}
				var httpReq = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/getTransactionsListByMode',
					headers: {
						'Content-Type': 'application/json'
					},
					data: dataObj
				};

				$http(httpReq).then(
					function (response) {

						document.getElementById("currentWorkStep").value = workStep;
						if(bp_uuid) {
							document.getElementById("currentBpUuid").value = bp_uuid;
						}

						//groupByTransactions = response.data.responseData.dataList;
						$scope.groupByTransactions = response.data.responseData.dataList;

						//$scope.popTransSummary(mode);
						$scope.displayHome(response, workStep, mode);

						$scope.enableLoader(0);

					}, function (e) { alert("error: " + e); });
			}



			$scope.dispRegionWiseTransaction = function () {
				var reqTransRegion = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/getTransactionsByMode',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"function": document.getElementById("aFunctionName").innerHTML,
							"startDate": document.getElementById("dateFromDiv").innerHTML,
							"endDate": document.getElementById("dateToDiv").innerHTML,
							"mode": "regionWise"
						}
					}
				};
				$http(reqTransRegion).then(
					function (response) {
						//alert(response.data.responseData.dataList.length);


						$scope.transactionsByRegionWise = response.data.responseData.dataList;
						$scope.dispRegionWiseGraph();

					},
					function (e) { alert("error: " + e); });
			}


			$scope.dispRegionWiseGraph = function () {

				var linearGradient = { x1: 0, x2: 0, y1: 1, y2: 0 };

				var seriesData = [];
				var sDataStringDrill = [];

				var cWorkStep = "";
				var totTransCount = 0;
				var cRegion = "";
				var isSameRegion = false;
				for (var i = 0; i < $scope.transactionsByRegionWise.length; i++) {
					var data = {};
					var dataDrill = {};
					var seriesString = {};
					var sDataString = [];
					var colorString = {};
					var workStep = $scope.transactionsByRegionWise[i].processName;

					//alert(workStep);

					var transList = $scope.transactionsByRegionWise[i].transactionList;

					var tmpRegion = "";
					var totTrans = 0;
					var totBotTrans = 0;
					var totHumanTrans = 0;
					for (var j = 0; j < transList.length; j++) {

						if (j > 0 && tmpRegion != transList[j].region) {

							data.name = tmpRegion;
							data.drilldown = workStep + " " + tmpRegion;
							data.y = totTrans;

							sDataString.push(data);
							data = {};
							totTrans = 0;

							dataDrill.id = workStep + " " + tmpRegion;
							dataDrill.name = workStep + " " + tmpRegion;
							dataDrill.data = [['BOT', totBotTrans], ['HUMAN', totHumanTrans]];

							sDataStringDrill.push(dataDrill);
							dataDrill = {};
							totBotTrans = 0;
							totHumanTrans = 0;

						}
						tmpRegion = transList[j].region;
						totTrans = totTrans + transList[j].totalTransactions;

						if ("BOT" == transList[j].worker) {
							totBotTrans = totBotTrans + transList[j].totalTransactions;
						}
						else {
							totHumanTrans = totHumanTrans + transList[j].totalTransactions;
						}

						if (j == (transList.length - 1)) {

							data.name = tmpRegion;
							data.y = totTrans;
							data.drilldown = workStep + " " + tmpRegion;

							sDataString.push(data);
							data = {};
							totTrans = 0;

							dataDrill.id = workStep + " " + tmpRegion;
							dataDrill.name = workStep + " " + tmpRegion;
							dataDrill.data = [['BOT', totBotTrans], ['HUMAN', totHumanTrans]];

							sDataStringDrill.push(dataDrill);
							dataDrill = {};
							totBotTrans = 0;
							totHumanTrans = 0;

						}
					}

					seriesString.name = workStep;

					if (workStep == "Data Analytics") {
						colorString.linearGradient = linearGradient;
						colorString.stops = [[0, '#556B2F'], [1, '#32CD32']];
						seriesString.color = colorString;
					}
					else if (workStep == "Underwrite and Generate Quote") {
						colorString.linearGradient = linearGradient;
						colorString.stops = [[0, '#CD6600'], [1, '#FFA500']];
						seriesString.color = colorString;
					}
					else if (workStep == "Mail Quote") {
						colorString.linearGradient = linearGradient;
						colorString.stops = [[0, '#8B0000'], [1, '#EE2C2C']];
						seriesString.color = colorString;
					}
					else if (workStep == "Read email and OCR") {
						colorString.linearGradient = linearGradient;
						colorString.stops = [[0, '#4A708B'], [1, '#6CA6CD']];
						seriesString.color = colorString;
					}
					else if (workStep == "Create FNOL") {
						colorString.linearGradient = linearGradient;
						colorString.stops = [[0, '#556B2F'], [1, '#32CD32']];
						seriesString.color = colorString;
					}
					else if (workStep == "Adjudicate Claim") {
						colorString.linearGradient = linearGradient;
						colorString.stops = [[0, '#CD6600'], [1, '#FFA500']];
						seriesString.color = colorString;
					}
					else if (workStep == "Approve Claim") {
						colorString.linearGradient = linearGradient;
						colorString.stops = [[0, '#8B0000'], [1, '#EE2C2C']];
						seriesString.color = colorString;
					}


					seriesString.data = sDataString;
					seriesData.push(seriesString);


				}


				//alert("seriesData : "+seriesData);
				//alert("sDataStringDrill : "+sDataStringDrill);

				Highcharts.chart('containerM', {
					chart: {
						type: 'column'
					},
					title: {
						text: 'Transactions Processed - Region Wise'
					},
					subtitle: {
						text: ''
					},
					xAxis: {
						type: 'category'
					},
					yAxis: {
						min: 0,
						title: {
							text: 'Transactions Processed'
						}
					},
					plotOptions: {

						column: {
							pointPadding: 0,
							borderWidth: 0
						},


						series: {
							borderWidth: 0,
							dataLabels: {
								enabled: true,
								style: {
									fontWeight: 'bold',
									color: 'gray'
								}
							}
						}
					},

					series: seriesData,
					drilldown: {
						series: sDataStringDrill
					}
				});

				/*
				$('containerM').highcharts({
				
					chart: {
						type: 'column'
					},
					title: {
						text: 'Transactions Processed - Region Wise'
					},
					subtitle: {
						text: ''
					},
					xAxis: {
						type: 'category'
					},
							yAxis: {
					  min: 0,
					  title: {
						text: 'Transactions Processed'
					  }
							},
					plotOptions: {
						
						column: {
								pointPadding: 0,
								borderWidth: 0
							},
						
						
						series: {
							borderWidth: 0,
							dataLabels: {
								enabled: true,
								style: {
									fontWeight: 'bold',
									color: 'gray'
								}
							}
						}
					},
	
					series: seriesData,
					
					drilldown: {
						series: sDataStringDrill
					}
				});
				*/
			};


			$scope.loadPage = function () {

				var req = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/getTransactionsByMode',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"function": document.getElementById("aFunctionName").innerHTML,
							"startDate": document.getElementById("dateFromDiv").innerHTML,
							"endDate": document.getElementById("dateToDiv").innerHTML
						}
					}
				};

				$http(req).then(
					function (response) {
						//alert(response.data.responseData.dataList.length);
						$scope.totalTrans = 0; $scope.totTimeTaken = 0; $scope.totEffortSaved = 0; $scope.totWorker = 0;
						$scope.totalSuccesstransactionCount = 0; $scope.totalBusinessExceptionCount = 0; $scope.totalTechnicalExceptionCount = 0;
						//workStepTransactions = response.data.responseData.dataList;
						$scope.transactionsByWorkStep = response.data.responseData.dataList;

						//var workmonitorList = [];

						//var transactionsList = response.data.responseData.dataList;
						var totTrans = 0;


						var dataString = [];


						for (var i = 0; i < $scope.transactionsByWorkStep.length; i++) {
							//var workStep = $scope.transactionsByWorkStep[i].processName;

							var transactionList = $scope.transactionsByWorkStep[i].transactionList;

							var count = 0;
							for (var j = 0; j < transactionList.length; j++) {

								count = count + Number(transactionList[j].totalTransactions);
								$scope.totTimeTaken = $scope.totTimeTaken + Number(transactionList[j].totalTimeTaken);
								$scope.totEffortSaved = $scope.totEffortSaved + Number(transactionList[j].effortSaved);
								$scope.totWorker = $scope.totWorker + Number(transactionList[j].totalWorker);
								$scope.totalSuccesstransactionCount = $scope.totalSuccesstransactionCount + Number(transactionList[j].successtransactionCount);
								$scope.totalBusinessExceptionCount = $scope.totalBusinessExceptionCount + Number(transactionList[j].businessExceptionCount);
								$scope.totalTechnicalExceptionCount = $scope.totalTechnicalExceptionCount + Number(transactionList[j].technicalExceptionCount);

							}

							$scope.totalTrans = $scope.totalTrans + count;
						}

						var successData = {};
						successData.name = "Success";
						successData.y = Math.round(($scope.totalSuccesstransactionCount / $scope.totalTrans) * 100);
						dataString.push(successData);
						
						var businessEData = {};
						businessEData.name = "Business Error";
						businessEData.y = Math.round(($scope.totalBusinessExceptionCount / $scope.totalTrans) * 100);
						dataString.push(businessEData);
						
						var technicalEData = {};
						technicalEData.name = "Technical Error";
						technicalEData.y = Math.round(($scope.totalTechnicalExceptionCount / $scope.totalTrans) * 100);
						technicalEData.color = "#DC143C";//"#FFBF00";
						dataString.push(technicalEData);
						

						/*for (var i = 0; i < $scope.transactionsByWorkStep.length; i++) {
							var workStep = $scope.transactionsByWorkStep[i].processName;
							var data = {};

							var transactionList = $scope.transactionsByWorkStep[i].transactionList;

							var count = 0;
							for (var j = 0; j < transactionList.length; j++) {
								count = count + Number(transactionList[j].totalTransactions);
								// add Business error, Technical error, Success counts
							}

							data.name = workStep;
							data.y = Math.round((count / $scope.totalTrans) * 100);

							// Change the data to use Business error, Technical error, Success counts
							var colorX = "";
							var colorY = "";
							if (workStep == "Data Analytics") {
								colorX = '#556B2F';
								colorY = '#32CD32';
							}

							else if (workStep == "Underwrite and Generate Quote") {
								colorX = '#CD6600';
								colorY = '#FFA500';
							}
							else if (workStep == "Mail Quote") {
								colorX = '#8B0000';
								colorY = '#EE2C2C';
							}
							else if (workStep == "Read email and OCR") {
								colorX = '#4A708B';
								colorY = '#6CA6CD';
							}
							else if (workStep == "Create FNOL") {
								colorX = '#556B2F';
								colorY = '#32CD32';
							}
							else if (workStep == "Adjudicate Claim") {
								colorX = '#CD6600';
								colorY = '#FFA500';
							}
							else if (workStep == "Approve Claim") {
								colorX = '#8B0000';
								colorY = '#EE2C2C';
							}
							else if (workStep == "Card Issuance") {
								colorX = '#CD6600';
								colorY = '#FFA500';
							}
							else if (workStep == "KYC Check") {
								colorX = '#00A5DF';
								colorY = '#00CD66';
							}
							else if (workStep == "KYC Verification") {
								colorX = '#E4550F';
								colorY = '#3D89A6';
							}
							else {
								colorX = '#4D6600';
								colorY = '#4530DF';
							}


							data.color = { linearGradient: { x1: 0, x2: 0, y1: 1, y2: 0 }, stops: [[0, colorX], [1, colorY]] };


							dataString.push(data);
						}*/



						/*
						for(var i=0; i<$scope.transactionsByWorkStep.length; i++){
							
							var dataS = {};
							
							dataS.processName = $scope.transactionsByWorkStep[i].processName;
							
							
							
							var transactionList = $scope.transactionsByWorkStep[i].transactionList;
							
							var count = 0;
							var botTotTrans = 0;
							var botTotTimeTaken = 0;
							var botTotEffortSaved = 0;
							var botTotWorker = 0;
							
							var humanTotTrans = 0;
							var humanTotTimeTaken = 0;
							var humanTotEffortSaved = 0;
							var humanTotWorker = 0;
							
							
							var tList = [];
							
							for(var j=0; j<transactionList.length; j++){
								
								
								
								if(transactionList[j].worker == "BOT"){
									botTotTrans = botTotTrans + Number(transactionList[j].totalTransactions);
									botTotTimeTaken = botTotTimeTaken + Number(transactionList[j].totalTimeTaken);
									botTotEffortSaved = botTotEffortSaved + Number(transactionList[j].effortSaved);
									botTotWorker = botTotWorker + Number(transactionList[j].totalWorker);
								}
								else if (transactionList[j].worker == "HUMAN"){
									
									
									
									humanTotTrans = humanTotTrans + Number(transactionList[j].totalTransactions);
									humanTotTimeTaken = humanTotTimeTaken + Number(transactionList[j].totalTimeTaken);
									humanTotEffortSaved = humanTotEffortSaved + Number(transactionList[j].effortSaved);
									humanTotWorker = humanTotWorker + Number(transactionList[j].totalWorker);
								}
							}
							
							var transData = {};
							transData.worker = "BOT";
							transData.totalTransactions = botTotTrans;
							transData.totalTimeTaken = botTotTimeTaken;
							transData.effortSaved = botTotEffortSaved;
							transData.totalWorker = botTotWorker;
							tList.push(transData);
							
							transData = {};
							transData.worker = "HUMAN";
							transData.totalTransactions = humanTotTrans;
							transData.totalTimeTaken = humanTotTimeTaken;
							transData.effortSaved = humanTotEffortSaved;
							transData.totalWorker = humanTotWorker;
							tList.push(transData);
							
							dataS.transList = tList;
							
							workmonitorList.push(dataS);
							
						}
						
						
						$scope.workMonitorList = workmonitorList;
						*/

						dispTotalTransaction(dataString);

						$scope.popWorkMonitor();

						$scope.dispRegionWiseTransaction();

						$scope.enableLoader(0);
					},
					function (e) { alert("error: " + e); });

			}


			$scope.popWorkMonitor = function () {
				//alert("popWorkMonitor :::: ");
				$scope.homeView();
				$scope.dispRegionWiseTransaction();
			}

			$scope.popBotMonitor = function () {

				$scope.enableLoader(1);

				$scope.botTransaction = true;
				$scope.botDetails = false;

				var httpReq = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/getBotStatusWiseWorkDetails',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"function": document.getElementById("aFunctionName").innerHTML,
						}
					}
				};

				$scope.totActBots = 0;
				$scope.totWaitBots = 0;
				$scope.totInaBots = 0;

				$http(httpReq).then(
					function (response) {



						//groupByTransactions = response.data.responseData.dataList;
						$scope.botList = response.data.responseData.dataList;

						for (var i = 0; i < $scope.botList.length; i++) {

							$scope.totActBots = $scope.totActBots + $scope.botList[i].botActiveCount;
							$scope.totWaitBots = $scope.totWaitBots + $scope.botList[i].botWaitingCount;
							$scope.totInaBots = $scope.totInaBots + $scope.botList[i].botInactiveCount;
						}

						$scope.displayBot('all', 'all');

						$scope.enableLoader(0);


						/*
						$scope.botSeries =	[];
						$scope.slaRTransAchieved =	[];
						$scope.slaRTransBreachedF =	[];
						$scope.slaRTransBreachedA =	[];
						
						for(var i=0; i<$scope.botList.length; i++){
							//alert("Region:::::: "+$scope.slaTransactionsRegionWise[i].region);
							
							$scope.region.push($scope.slaTransactionsRegionWise[i].region);
							$scope.slaRTransAchieved.push($scope.slaTransactionsRegionWise[i].slaAchievedPer);
							$scope.slaRTransBreachedF.push($scope.slaTransactionsRegionWise[i].slaBreachedFulfilledPer);
							$scope.slaRTransBreachedA.push($scope.slaTransactionsRegionWise[i].slaBreachedActivePer);
						}
						
						 $('#container').highcharts({
								chart: {
									type: 'column'
								},
								title: {
									text: ''
								},
								xAxis: {
									categories: [
										'Processing BOTs',
										'Waiting BOTs',
										'Inactive BOTs'
									]
								},
								yAxis: [{
									min: 0,
									title: {
							text: '',
							style: {
							   color: Highcharts.getOptions().colors[0]
							  }
									    
									}
								}, {
									title: {
										text: '',
							style: {
							   color: Highcharts.getOptions().colors[8]
							  }
									},
									opposite: true
								}],
								legend: {
									shadow: false
								},
								tooltip: {
									shared: true
								},
								plotOptions: {
									column: {
										grouping: false,
										shadow: false,
										borderWidth: 0
									},
						   series: {
							   cursor: 'pointer',
							   point: {
								events: {
								 click: function (e) {
								  e.preventDefault();
								  //var url = "Discount%20Detail.html?Month=" + encodeURIComponent(this.x) + "&Event=" + encodeURIComponent(this.series.name)+ "&Value=" + encodeURIComponent(this.y);
								  //window.open(url, '_blank');
								  displayBot(encodeURIComponent(this.x));
								 }
								}
							   }
							  }
								},
						  credits: {
							  enabled: false
							 },
								series: [ 
						  {
									name: 'Create FNOL',
									color: '#E2752C',
									data: [4,2,1],
									pointPadding: 0.35,
									pointPlacement: -0.1
						   //pointPlacement: -0.078
								},
						  {
									name: 'Underwrite',
									color: '#2F9331',   
									data: [4, 1, 0],
									pointPadding: 0.35,
									pointPlacement:0.1
								}
						  ]
							});
						*/


					}, function (e) { alert("error: " + e); });



				/*
				var jsObj = botListJSON.workSteps;
				var workStep = "";
				var tHeader = "	<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"margin:0px;\"><tr style='font-weight:bold; background:#00719E; color:white;'><td></td><td align='right'  style='padding-top:6px;padding-bottom:6px;'>Active BOTs</td><td align='right'>Waiting BOTs</td><td align='right'>Inactive BOTs</td></tr>" ;	

				var tRow = "";
				for(var i=0; i<jsObj.length; i++){
					workStep = jsObj[i].name;
					var color = jsObj[i].color;
					var botsList = jsObj[i].bots;
					
						for(var j=0; j<botsList.length; j++){
							var activeBots = botsList[j].activeBots;
							var waitingBots = botsList[j].waitingBots;
							var inactiveBots = botsList[j].inactiveBots;
							
							tRow = tRow + "<tr style='background:#E8E8E8;font-weight:bold;border-bottom:4px solid white'><td width='16.5%' style='background:"+color+"; color:white; font-weight:bold; font-size:12px; padding-top:10px;padding-bottom:10px;'>"+workStep+"</td><td align='right'>"+activeBots+"</td><td align='right'>"+waitingBots+"</td><td align='right'>"+inactiveBots+"</td></tr>";
																
						}
					}
				
				
				var tData = tHeader + tRow + "</table>";
				
				document.getElementById("workMonitorData").innerHTML = tData;
				*/

			}



			$scope.displayHome = function (response, workStep, mode) {


				document.getElementById("homeView").style.display = "none";
				document.getElementById("home").style.display = "block";
				document.getElementById("botMontorData").style.display = "none";
				document.getElementById("workMonitorData").style.display = "block";

				document.getElementById("subTitle").innerHTML = "&nbsp; " + workStep + " Detailed Summary ";

				document.getElementById("botSection").style.display = "none";
				//document.getElementById("transactionReport").style.display="none";


				/*var reqWR = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/getTransactionsByMode',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"function": document.getElementById("aFunctionName").innerHTML,
							"startDate": document.getElementById("dateFromDiv").innerHTML,
							"endDate": document.getElementById("dateToDiv").innerHTML,
							"mode": "regionAndWorkstepWise",
							"workStep": workStep
						}
					}
				};
				$http(reqWR).then(
						function (response) {

							$scope.transByWorkStepR = response.data.responseData.dataList;

							var dataString = [];
						
						$scope.transByWorkStepR = response.data.responseData.dataList;

						var dataString = [];

						for (var i = 0; i < $scope.transByWorkStepR.length; i++) {

							var data = {};

							var geo = $scope.transByWorkStepR[i].region;
							var totCount = $scope.transByWorkStepR[i].totalTransactions;


							data.name = geo;
							data.y = totCount;

							if (geo == "US") {
								data.color = { linearGradient: { x1: 0, x2: 0, y1: 1, y2: 0 }, stops: [[0, '#556B2F'], [1, '#32CD32']] };
							}
							else if (geo == "UK") {
								data.color = { linearGradient: { x1: 0, x2: 0, y1: 1, y2: 0 }, stops: [[0, '#556B2F'], [1, '#FFA500']] };
							}
							else if (geo == "Canada") {
								data.color = { linearGradient: { x1: 0, x2: 0, y1: 1, y2: 0 }, stops: [[0, '#8B0000'], [1, '#EE2C2C']] };
							}
							else if (geo == "Singapore") {
								data.color = { linearGradient: { x1: 0, x2: 0, y1: 1, y2: 0 }, stops: [[0, '#4A708B'], [1, '#6CA6CD']] };
							}

							dataString.push(data);

						
						
						}
						$scope.dispTransSummary(dataString);
						}, function (e) { alert("error: " + e); });*/

			}


			$scope.popTransSummary = function (param) {

				/*
			
				var val = "";
			if(param == "Daily"){
				val = "Date";
			}
			else if(param == "Monthly"){
				val = "Month";
			}
			else if(param == "Yearly"){
				val = "Year";
			}
				
				
			
				var tblHeaderTranSummary = "<table cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" style=\"  border:1px solid white\" > "+
				"<thead><tr style=\"border-bottom:1px solid silver;\"> "+
				"<th align='right' width=\"1%\"  >#</th> "+
				"<th align='left' >"+val+"</th>  "+	
				"<th align='right' >Count Processed</th>  "+
				"<th align='right' >Total Processing Time (in hours)</th>  "+
				"<th align='right' >Average Processing Time (in hours)</th>  "+
				"<th align='right' >Time Saved (in hours)</th> "+
				" </tr> </thead>"; 
				
			var tBody = "<tbody >";	
			var tRow = "";
			var tStyle = "";
			var totalPS = 0.00;
			var totalES = 0.00;
			var totalC = 0;
				for(var i=0; i<groupByTransactions.length;i++){
					var date = groupByTransactions[i].date;
					
					var totalCount = jsObj[i].totalCount;
					var processingTime = totalCount/60 ;
					//var effortSaved = ( ((totalCount * 5)/60)/24)/20;
					var effortSaved = (totalCount * 5)/60;
					
					totalPS = totalPS + processingTime;
					totalES = totalES + effortSaved;
					totalC = totalC + totalCount;
					
					//jsObj[i].processingTime;
					var avgProcessingTime = jsObj[i].avgProcessingTime;
					//var effortSaved = jsObj[i].effortSaved;
					
					if(i == (jsObj.length -1) ){
						tStyle = "style='font-weight:bold' ";
					}
					
					if(date == "Total"){
						tRow = tRow + "<tr id='even1' "+tStyle+"> "+
						"<td align='right'></td> "+
						"<td align='right'>"+date+"</td> "+
					"<td align='right' >"+totalC+"</td> "+
					"<td align='right' >"+totalPS.toFixed(2)+"</td> "+
					"<td align='right' >"+avgProcessingTime+"</td> "+
					"<td align='right' >"+totalES.toFixed(2)+"</td> "+
					"</tr>";
						
					}
					else{
						
					
						tRow = tRow + "<tr id='even1' "+tStyle+"> "+
							"<td align='right'>"+(i+1)+"</td> "+
							"<td align='left' >"+date+"</td> "+
						"<td align='right' >"+totalCount+"</td> "+
						"<td align='right' >"+processingTime.toFixed(2)+"</td> "+
						"<td align='right' >"+avgProcessingTime+"</td> "+
						"<td align='right' >"+effortSaved.toFixed(2)+"</td> "+
						"</tr>";
					}
				}
				
				
				document.getElementById("transactionSummary").innerHTML = 	tblHeaderTranSummary + "<tbody>" + tRow + "</tBody> </table>";
				
			*/
			}

			$scope.displayIncidents = function (workStep) {
				$scope.enableLoader(1);
				document.getElementById("incidentsMap").style.display = "none";
				document.getElementById("incidentDetails").style.display = "block";

				var httpBotReq = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/getIncidentList',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"processName": workStep,
							"startDate": document.getElementById("dateFromDiv").innerHTML,
							"endDate": document.getElementById("dateToDiv").innerHTML
						}
					}
				};

				$http(httpBotReq).then(
					function (response) {

						$scope.incidentListByProcessName = response.data.responseData.dataList;
						document.getElementById("incindentTitle").innerHTML = "&nbsp; Incidents Occurred on '" + workStep + "' ";
						$scope.enableLoader(0);

					}, function (e) {
						alert("error: " + e);
					});

			}

			$scope.displayBot = function (status, workStep) {

				$scope.enableLoader(1);
				//alert(status + " " +workStep)

				$scope.botTransaction = true;
				$scope.botDetails = false;


				if (status == "all") {
					document.getElementById("grpByAll").checked = true;
				}

				if (workStep == "") {
					workStep = document.getElementById("botWorkStep").value;
				}
				else {
					document.getElementById("botWorkStep").value = workStep
				}

				document.getElementById("botSection").style.display = "block";
				document.getElementById("botMontorData").style.display = "block";

				document.getElementById("workMonitorData").style.display = "none";
				document.getElementById("slaDashboardData").style.display = "none";
				document.getElementById("slaView").style.display = "none";
				document.getElementById("incidentMonitorData").style.display = "none";
				document.getElementById("incidentSection").style.display = "none";

				document.getElementById("home").style.display = "none";
				document.getElementById("homeView").style.display = "none";

				if (workStep == 'all')
					document.getElementById("subTitle1").innerHTML = "&nbsp; BOTs Status across all process";
				else
					document.getElementById("subTitle1").innerHTML = "&nbsp; " + workStep + " BOTs Status";


				var httpBotReq = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/getBotListByProcessAndStatus',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"function": document.getElementById("aFunctionName").innerHTML,
							"status": status,
							"workStep": workStep
						}
					}
				};

				$http(httpBotReq).then(
					function (response) {

						$scope.botListByWorkstep = response.data.responseData.dataList;

						$scope.enableLoader(0);

					}, function (e) {
						alert("error: " + e);
					});






			}

			$scope.popIncidentMonitor = function () {

				document.getElementById("incidentMonitorData").style.display = "block";
				document.getElementById("incidentSection").style.display = "block";

				document.getElementById("homeView").style.display = "none";
				document.getElementById("workMonitorData").style.display = "none";
				document.getElementById("slaDashboardData").style.display = "none";
				document.getElementById("botMontorData").style.display = "none";
				document.getElementById("botSection").style.display = "none";
				document.getElementById("home").style.display = "none";
				document.getElementById("slaView").style.display = "none";


				$scope.totIncidents = 0;
				$scope.totTktClosed = 0;
				$scope.totTktOpen = 0;

				var incidentReq = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/getIncidentsByMode',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"function": document.getElementById("aFunctionName").innerHTML,
							"startDate": document.getElementById("dateFromDiv").innerHTML,
							"endDate": document.getElementById("dateToDiv").innerHTML,
							"mode": "workstepWise"
						}
					}
				};

				$http(incidentReq).then(
					function (response) {

						$scope.incidents = response.data.responseData.dataList;

						for (var i = 0; i < $scope.incidents.length; i++) {

							$scope.totIncidents = $scope.totIncidents + $scope.incidents[i].totalIncidents;
							$scope.totTktClosed = $scope.totTktClosed + $scope.incidents[i].ticketsClosed;
							$scope.totTktOpen = $scope.totTktOpen + $scope.incidents[i].ticketsOpen;
						}

						// 8-18-18
						$scope.dispRegionWiseIncidents();

					},
					function (e) {
						alert("error: " + e);
					});


			}

			$scope.dispRegionWiseIncidents = function () {
				var reqIncidentRegion = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/getIncidentsByMode',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"function": document.getElementById("aFunctionName").innerHTML,
							"startDate": document.getElementById("dateFromDiv").innerHTML,
							"endDate": document.getElementById("dateToDiv").innerHTML,
							"mode": "regionWise"
						}
					}
				};
				$http(reqIncidentRegion).then(
					function (response) {
						//alert(response.data.responseData.dataList.length);


						$scope.incidentsByRegionWise = response.data.responseData.dataList;
						$scope.dispRegionIncidentChart();

					},
					function (e) { alert("error: " + e); });
			}

			$scope.dispRegionIncidentChart = function () {

				var linearGradient = { x1: 0, x2: 0, y1: 1, y2: 0 };

				var seriesData = [];
				var sDataStringDrill = [];

				var cWorkStep = "";
				var cRegion = "";
				var isSameRegion = false;
				for (var i = 0; i < $scope.incidentsByRegionWise.length; i++) {
					var data = {};
					var dataDrill = {};
					var seriesString = {};
					var sDataString = [];
					var colorString = {};
					var workStep = $scope.incidentsByRegionWise[i].processName;

					var transList = $scope.incidentsByRegionWise[i].transactionList;

					var tmpRegion = "";
					var totIncidents = 0;
					var totBotIncidents = 0;
					var totHumanIncidents = 0;
					for (var j = 0; j < transList.length; j++) {

						if (j > 0 && tmpRegion != transList[j].region) {

							data.name = tmpRegion;
							data.drilldown = workStep + " " + tmpRegion;
							data.y = totIncidents;

							sDataString.push(data);
							data = {};
							totIncidents = 0;

							dataDrill.id = workStep + " " + tmpRegion;
							dataDrill.name = workStep + " " + tmpRegion;
							dataDrill.data = [['BOT', totBotIncidents], ['HUMAN', totHumanIncidents]];

							sDataStringDrill.push(dataDrill);
							dataDrill = {};
							totBotIncidents = 0;
							totHumanIncidents = 0;

						}
						tmpRegion = transList[j].region;
						totIncidents = totIncidents + transList[j].totalIncidents;

						if ("BOT" == transList[j].worker) {
							totBotIncidents = totBotIncidents + transList[j].totalIncidents;
						}
						else {
							totBotIncidents = totBotIncidents + transList[j].totalIncidents;
						}

						if (j == (transList.length - 1)) {

							data.name = tmpRegion;
							data.y = totIncidents;
							data.drilldown = workStep + " " + tmpRegion;

							sDataString.push(data);
							data = {};
							totIncidents = 0;

							dataDrill.id = workStep + " " + tmpRegion;
							dataDrill.name = workStep + " " + tmpRegion;
							dataDrill.data = [['BOT', totBotIncidents], ['HUMAN', totHumanIncidents]];

							sDataStringDrill.push(dataDrill);
							dataDrill = {};
							totBotIncidents = 0;
							totHumanIncidents = 0;

						}
					}

					seriesString.name = workStep;

					if (workStep == "Data Analytics") {
						colorString.linearGradient = linearGradient;
						colorString.stops = [[0, '#556B2F'], [1, '#32CD32']];
						seriesString.color = colorString;
					}
					else if (workStep == "Underwrite and Generate Quote") {
						colorString.linearGradient = linearGradient;
						colorString.stops = [[0, '#CD6600'], [1, '#FFA500']];
						seriesString.color = colorString;
					}
					else if (workStep == "Mail Quote") {
						colorString.linearGradient = linearGradient;
						colorString.stops = [[0, '#8B0000'], [1, '#EE2C2C']];
						seriesString.color = colorString;
					}
					else if (workStep == "Read email and OCR") {
						colorString.linearGradient = linearGradient;
						colorString.stops = [[0, '#4A708B'], [1, '#6CA6CD']];
						seriesString.color = colorString;
					}
					else if (workStep == "Create FNOL") {
						colorString.linearGradient = linearGradient;
						colorString.stops = [[0, '#556B2F'], [1, '#32CD32']];
						seriesString.color = colorString;
					}
					else if (workStep == "Adjudicate Claim") {
						colorString.linearGradient = linearGradient;
						colorString.stops = [[0, '#CD6600'], [1, '#FFA500']];
						seriesString.color = colorString;
					}
					else if (workStep == "Approve Claim") {
						colorString.linearGradient = linearGradient;
						colorString.stops = [[0, '#8B0000'], [1, '#EE2C2C']];
						seriesString.color = colorString;
					}


					seriesString.data = sDataString;
					seriesData.push(seriesString);


				}
				document.getElementById("incidentsMap").style.display = "block";
				document.getElementById("incidentDetails").style.display = "none";
				document.getElementById("incindentTitle").innerHTML = "&nbsp; Incident Summary";
				// Create the chart
				Highcharts.chart('incidentsMap', {
					chart: {
						type: 'column'
					},
					title: {
						text: 'Incidents - Region Wise'
					},
					subtitle: {
						text: ''
					},
					xAxis: {
						type: 'category'
					},
					yAxis: {
						min: 0,
						title: {
							text: 'Incidents Reported'
						}
					},
					plotOptions: {

						column: {
							pointPadding: 0,
							borderWidth: 0
						},


						series: {
							borderWidth: 0,
							dataLabels: {
								enabled: true,
								style: {
									fontWeight: 'bold',
									color: 'gray'
								}
							}
						}
					},

					series: seriesData,
					drilldown: {
						series: sDataStringDrill
					}
				});
			};

			$scope.homeView = function () {
				//alert("hi");
				document.getElementById("totTrans").style.display = "block";
				document.getElementById("homeView").style.display = "block";
				document.getElementById("workMonitorData").style.display = "block";
				document.getElementById("slaDashboardData").style.display = "none";
				document.getElementById("botMontorData").style.display = "none";
				document.getElementById("botSection").style.display = "none";
				document.getElementById("home").style.display = "none";
				document.getElementById("slaView").style.display = "none";
				document.getElementById("incidentMonitorData").style.display = "none";
				document.getElementById("incidentSection").style.display = "none";

				document.getElementById("slaMonitorRView").style.display = "none";
				document.getElementById("workMonitorRView").style.display = "block";
				document.getElementById("topRTitle").innerHTML = "&nbsp; Transaction View";


			}

			$scope.displayTransaction = function () {
				document.getElementById("homeView").style.display = "none";
				document.getElementById("botSection").style.display = "none";
				document.getElementById("slaDashboardData").style.display = "none";
				document.getElementById("botMontorData").style.display = "none";
				//document.getElementById("transactionReport").style.display="block";
				//document.getElementById("transactionReportId").style.backgroundColor="#A9A9A9";
				//document.getElementById("homeId").style.backgroundColor="#CCCCCC";
				document.getElementById("home").style.display = "none";
				document.getElementById("incidentMonitorData").style.display = "none";
				document.getElementById("incidentSection").style.display = "none";
				//alert("hi");
				//document.getElementById("transactionReportId").style.Color="white";
			}

			$scope.triggerBot = function (botKey) {

				$scope.enableLoader(1);
				var triggerReq = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/triggerBot',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"botKey": botKey
						}
					}
				};
				$http(triggerReq).then(
					function (response) {

						$scope.popBotMonitor();


					},
					function (e) {
						alert("error: " + e);
					});
			}

			$scope.changeBotStatus = function (botKey, status) {

				$scope.enableLoader(1);
				var triggerBotReq = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/activateDeactivateBot',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"botKey": botKey,
							"botStatusId": status
						}
					}
				};
				$http(triggerBotReq).then(
					function (response) {

						$scope.popBotMonitor();


					},
					function (e) {
						alert("error: " + e);
					});


			}


			$scope.slaRegionWiseByStatus = function (workStep, status) {

				var slaReqStatusWise = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/getSLAListByStatus',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"function": document.getElementById("aFunctionName").innerHTML,
							"startDate": document.getElementById("dateFromDiv").innerHTML,
							"endDate": document.getElementById("dateToDiv").innerHTML,
							"workStep": workStep,
							"status": status,
							"mode": "statusWise"
						}
					}
				};



				$http(slaReqStatusWise).then(
					function (response) {

						$scope.slaByStatus = response.data.responseData.dataList;

						$scope.dispSLARegionChart(status, workStep);

						document.getElementById("slaViewTitle").innderHTML = "SLA " + status + " by " + workStep;
						document.getElementById("slaSummary1").style.display = "none";
						document.getElementById("slaSummary2").style.display = "block";


					},
					function (e) {
						alert("error: " + e);
					});

			}



			$scope.dispSLARegionChart = function (status, workStep) {

				var dataString = [];
				for (var i = 0; i < $scope.slaByStatus.length; i++) {
					var data = {};
					//alert($scope.slaByStatus[i].region);
					//$scope.slaByStatus[i].totalPer;
					data.name = $scope.slaByStatus[i].region;
					data.y = $scope.slaByStatus[i].totalTransactions;
					if (i == 0) {
						data.sliced = true;
						data.selected = true;
					}
					dataString.push(data);

				}

				//alert('dispSLARegionChart: '+dataString);

				$('#slaRegionSummaryChart').highcharts({
					chart: {
						plotBackgroundColor: null,
						plotBorderWidth: null,
						plotShadow: false,
						type: 'pie'
					},
					title: {
						text: 'SLA region wise - ' + status
					},
					tooltip: {
						pointFormat: '{series.name}: <b> {point.y}</b>'
					},
					plotOptions: {
						pie: {
							allowPointSelect: true,
							cursor: 'pointer',
							point: {
								events: {
									click: function () {
										//location.href = this.options.url;
										$scope.viewSLA(this.name, status, 'daily');
									}
								}
							},
							dataLabels: {
								enabled: true,
								format: '{point.name}:<br> {point.y}',
								style: {
									color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
								}
							}
						}
					},


					series: [{
						name: 'SLA ' + status,
						colorByPoint: true,
						data: dataString
					}]
				});
			}


			$scope.viewSLA = function (region, status, groupBy) {

				if (region.length == 0 && status.length == 0) {
					region = document.getElementById("hidSlaRegion").value;
					status = document.getElementById("hidSlaStatus").value;
				}
				else {
					document.getElementById("hidSlaRegion").value = region;
					document.getElementById("hidSlaStatus").value = status;
				}


				var viewSLAReq = {
					method: 'POST',
					url: hostName + 'vbrain/vBrainService/getSLAListByStatus',
					headers: {
						'Content-Type': 'application/json'
					},
					data: {
						"requestParameter": {
							"function": document.getElementById("aFunctionName").innerHTML,
							"startDate": document.getElementById("dateFromDiv").innerHTML,
							"endDate": document.getElementById("dateToDiv").innerHTML,
							"region": region,
							"status": status,
							"groupBy": groupBy,
							"mode": "statusAndRegionWise"
						}
					}
				};

				$http(viewSLAReq).then(
					function (response) {

						$scope.slaAchList = response.data.responseData.dataList;

						$scope.dispSLAStatusSummary(groupBy, region, status);
					},
					function (e) {
						alert("error: " + e);
					});

			}


			$scope.dispSLAStatusSummary = function (groupBy, region, status) {
				//alert($scope.slaAchList);
				var catString = [];
				var wStep = ['Data Analytics', 'Underwrite', 'Issue Quote'];

				if (groupBy == "daily") {
					catString = ['04/01/2017', '04/02/2017', '04/03/2017', '04/04/2017', '04/05/2017', '04/06/2017', '04/07/2017', '04/08/2017', '04/09/2017', '04/10/2017'];
				}
				else if (groupBy == "monthly") {
					catString = ['April'];
				}
				else if (groupBy == "yearly") {
					catString = ['2017'];
				}

				var seriesData = [];

				for (var i = 0; i < wStep.length; i++) {

					var ws = wStep[i];
					var count = [];
					var dataString = {};
					dataString.name = ws;

					for (j = 0; j < catString.length; j++) {
						var cat = catString[j];

						for (var k = 0; k < $scope.slaAchList.length; k++) {
							var slaL = $scope.slaAchList[k];

							if (ws == slaL.processName && cat == slaL.transactionDate) {
								count.push(slaL.totalTransactions);
							}
						}
					}

					//alert(count.length);
					dataString.data = count;

					seriesData.push(dataString);
				}


				Highcharts.chart('SLAAchievedChart', {
					chart: {
						type: 'line'
					},
					title: {
						text: 'SLA metric ' + status + ' ' + groupBy + ' for ' + region + ' region'
					},
					subtitle: {
						text: ''
					},
					xAxis: {
						categories: catString
					},
					yAxis: {
						title: {
							text: ''
						}
					},
					plotOptions: {
						line: {
							dataLabels: {
								enabled: true
							},
							enableMouseTracking: false
						}
					},
					series: seriesData
				});
			}

			/*
		   series: [{
			   name: 'Tokyo',
			   data: [7.0, 6.9, 9.5, 14.5, 18.4, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
		   }, {
			   name: 'London',
			   data: [3.9, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 16.6, 14.2, 10.3, 6.6, 4.8]
		   }]
		   */


			$scope.loadPage();

			$scope.dispTransSummary = function (dataString) {
				//alert('dispTransSummary: '+dataString);

				$('#transSummaryMap').highcharts({
					chart: {
						plotBackgroundColor: null,
						plotBorderWidth: null,
						plotShadow: false,
						type: 'pie'
					},
					title: {
						text: 'Region Wise Process'
					},
					tooltip: {
						pointFormat: '{series.name}: <b> {point.y}</b>'
					},
					plotOptions: {
						pie: {
							showInLegend: true,
							allowPointSelect: true,
							cursor: 'pointer',
							point: {
								events: {
									click: function () {
										//location.href = this.options.url;
										//$scope.viewSLA(this.name);
									}
								}
							},
							dataLabels: {
								enabled: false,
								format: '{point.y}',
								style: {
									color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
								}
							}
						}
					},


					series: [{
						name: 'Transactions Processed',
						colorByPoint: true,
						data: dataString
					}]
				});
			}










			/*
			 var tranSummaryFNOL = [{
					name: 'Installation',
					data: [43934, 52503, 57177, 69658, 97031, 119931, 137133, 154175]
				}, {
					name: 'Manufacturing',
					data: [24916, 24064, 29742, 29851, 32490, 30282, 38121, 40434]
				}, {
					name: 'Sales & Distribution',
					data: [11744, 17722, 16005, 19771, 20185, 24377, 32147, 39387]
				}, {
					name: 'Project Development',
					data: [null, null, 7988, 12169, 15112, 22452, 34400, 34227]
				}, {
					name: 'Other',
					data: [12908, 5948, 8105, 11248, 8989, 11816, 18274, 18111]
				}]
			
			var tranSummaryFNOLJSON = JSON.parse(tranSummaryFNOL);
			//alert(tranSummaryFNOLDayJSON.monthly[0].month);
				*/

			function popTransMonitor(val) {
				//alert("hi");
				/*
					var jsObj = transactionsJSON.daily;
					
					if(val == "Daily"){
						jsObj = transactionsJSON.daily;
					}
					else if(val == "Monthly"){
						jsObj = transactionsJSON.monthly;
					}
					
					for(var i=0; i<jsObj.length;i++){
						var workStep = jsObj[i].workStep;
						
						var totalCount = jsObj[i].totalCount;
						var processingTime = jsObj[i].processingTime;
						var effortSaved = jsObj[i].effortSaved;
						
						document.getElementById(workStep + "_T").innerHTML = totalCount;
						document.getElementById(workStep + "_P_Time").innerHTML = processingTime;
						document.getElementById(workStep + "_T_Saved").innerHTML = effortSaved;
						
					}
				*/
				//document.getElementById("totTrans").innerHTML = addCommas(17800);
			}

			function addCommas(nStr) {
				nStr += '';
				x = nStr.split('.');
				x1 = x[0];
				x2 = x.length > 1 ? '.' + x[1] : '';
				var rgx = /(\d+)(\d{3})/;
				while (rgx.test(x1)) {
					x1 = x1.replace(rgx, '$1' + ',' + '$2');
				}
				return x1 + x2;
			}


			function dispTotalTransaction(dataString) {

				Highcharts.chart('workMonitorRView', {
					chart: {
						type: 'pie'
					},
					title: {
						text: 'T'
					},
					tooltip: {
						pointFormat: '<b> {point.y} %</b>'
					},
					subtitle: {
						text: ''
					},
					plotOptions: {
						pie: {
							allowPointSelect: false,
							showInLegend: true,
							dataLabels: {
								enabled: false

							}
						}
					},
					series: [{
						name: 'Transactions Processed',
						data: dataString

					}]
				});
			}

		}]);

}());