(function () {
  'use strict';
  
  //var urlName = "http://lowcost-env.yv5sv2bh2p.ap-south-1.elasticbeanstalk.com/";
  var urlName = window.location.origin + "/vBrain/";
  
  //var locationPath = "resources/";
  var locationPath = "vBrain/resources/";
  
  angular.module('vBrainApp', ['ngRoute', 'ui.bootstrap'])
  	.controller('AnalysisLoginCtrl', ['$scope', '$http', '$window', function ($scope, $http, $window) {
  		
  		//clear all the session values
  		$window.sessionStorage.clear();
		
	    //Reset headers to avoid OPTIONS request (aka preflight)
	    $http.defaults.headers.common = {};
	    $http.defaults.headers.post = {};
	    $http.defaults.headers.put = {};
	    $http.defaults.headers.patch = {};
  		
	    $scope.submitUser = function(){
				 $http({
			       	  method: 'POST',
			       	  url: urlName + "vbrain/vBrainService/getAnalysisUserPrivilege",
			       	  data:{
			     		 requestParameter: {
			     			 user:{
			     				 	userId:$scope.username,
			     				 	password:$scope.password
			     			 }
				      	 }
				      },
			       	  headers: {
			       		   'Content-Type': 'application/json'
			       	  }
			       	}).then(function(response){
	   					var user = response.data.user;
	   					
	   					if(user){
							$window.sessionStorage.setItem("analysisLoginId", user.userId);
								
							window.location.pathname = locationPath + 'analysis.html';
	   					}
	   					else {
	   						alert("Invalid User Name/ Password !");
	   						$scope.password = '';
	   					}
	   				},
	   				function(e){alert("error: "+e);}
			    );
		   	}
    }]);
})();