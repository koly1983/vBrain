(function () {
  'use strict';

  angular.module('demoApp')
    .controller('BasicExampleCtrl', ['$scope','$http', function ($scope,$http) {
      $scope.remove = function (scope) {
        scope.remove();
      };

      $scope.toggle = function (scope) {
        scope.toggle();
      };

      $scope.moveLastToTheBeginning = function () {
        var a = $scope.data.pop();
        $scope.data.splice(0, 0, a);
      };

      $scope.newSubItem = function (scope) {
        var nodeData = scope.$modelValue;
          
          console.log(nodeData)
          nodeData.nodes.push({
          id: nodeData.id * 10 + nodeData.nodes.length,
          title: nodeData.title + '.' + (nodeData.nodes.length + 1),
          nodes: []
        });
      };
      
      $scope.userForm = true;
      $scope.isNew = false;
      
      $scope.newItem = function () {
        //$scope.data = [];
    	  
    	  $scope.isNew = true;
          
          $scope.userForm = false;
          $scope.dataId = '';
          $scope.dataParantId = '0';
          $scope.dataParantGroupId = '0'
          
          console.log('newItem function called')
         
      }
          
          $scope.addNode = function(){
              
        	  console.log('addNode function called')
              
              $scope.userForm = false;
              var nodeData = $scope.data;
              
              alert(nodeData[0]);
              
              var hostName = window.location.origin + "/vBrain";

              if( nodeData[0] != undefined){

                         $scope.dataAPIUrl = hostName + '/vbrain/vBrainService/updateGroups';
                         $scope.newNode = {
                        		 requestParameter: {
                         			group:{
                         			 id:$scope.dataId,
                         			 name:$scope.botNodeName,
                         			 description:$scope.description,
                         			 type:$scope.nodeTypeValue,
                         			 parentId: $scope.dataParantId,
                         			 parentGroupId: $scope.dataParantGroupId
                         			}
                         		}
                           };
                         
                         
                    }else{
                    	
                    	$scope.dataParantId = '0'
                    	$scope.dataParantGroupId = '0'
                    		 $scope.dataAPIUrl = hostName + '/vbrain/vBrainService/addGroups';
                    		$scope.newNode = {requestParameter: {
                    			group:{
                       			
                       			 name:$scope.botNodeName,
                       			 description:$scope.description,
                       			 type:$scope.nodeTypeValue,
                       			 parentId: $scope.dataParantId,
                       			 parentGroupId: $scope.dataParantGroupId
                       			}
                       		}
                          };
                    }
                    
              console.log($scope.newNode)
              console.log($scope.dataAPIUrl);
              
              /* call add node url here with form data */
             
              
              $http({
            	  method: 'POST',
            	  url: $scope.dataAPIUrl,
            	  data:$scope.newNode,
            	  headers: {
            		   'Content-Type': 'application/json'
            	  }
            	}).then(
        				function(response){
        					console.log('adding node response here');
        					console.log(response.data);
        					//$scope.data = response.data.responseData.dataList[0].groups;
        					
        					
        				},
        				function(e){alert("error: "+e);}
        			);
        	
              
              
              
            }
          
    
        
       $scope.editNode = function (refNode) {
         /*  console.log(refNode.$element[0].childNodes[5].getAttribute('data-id'))
           console.log(refNode.$element[0].childNodes[5].getAttribute('data-parentid'))
           console.log(refNode.$element[0].childNodes[5].getAttribute('data-parantgroupid'))
          */ 
           
           
           //$scope.userForm = false;
    	   $scope.isNew = false;
    	   
           $scope.fieldName = refNode.$element[0].innerText;
           $scope.botNodeName = $scope.fieldName
           $scope.dataId = refNode.$element[0].childNodes[5].getAttribute('data-id');
           $scope.dataParantId = refNode.$element[0].childNodes[5].getAttribute('data-parentid')
           $scope.dataParantGroupId = refNode.$element[0].childNodes[5].getAttribute('data-parantgroupid')
           
           console.log($scope.dataId+$scope.dataParantId+$scope.dataParantGroupId)
           
           //console.log(refNode.$element[0].innerText)
           //console.log($scope.userForm)
           $scope.userForm = false;
          
           console.log($scope.userForm)
      };
        
      $scope.collapseAll = function () {
        $scope.$broadcast('angular-ui-tree:collapse-all');
      };

      $scope.expandAll = function () {
        $scope.$broadcast('angular-ui-tree:expand-all');
      };

      var hostName = window.location.origin + "/vBrain";
      $scope.dataNodeUrl = hostName + "/vbrain/vBrainService/getGroups";
      $http({
    	  method: 'POST',
    	  url: $scope.dataNodeUrl,
    	  data:{},
    	  headers: {
    		   'Content-Type': 'application/json'
    	  }
    	}).then(
				function(response){
					
					console.log(response.data.responseData.dataList[0].groups);
					$scope.data = response.data.responseData.dataList[0].groups;
					
					
				},
				function(e){alert("error: "+e);}
			);
	
      
     /* 
      $scope.data = [
        {
	        'id': 1,
	        'title': 'Nodex',
	        'type': 'Bot Type',
	        'nodes': [
	          {
	            'id': 21,
	            'title': 'node1.1',
	            'type': 'Bot Type 1.1',
	            'nodes': [
	              {
	                'id': 111,
	                'title': 'Node 1.1.1',
	                'type': 'Bot Type 1.1.1',
	                'nodes': []
	              }
	            ]
	          }          
	        ]
	      },
	      {
	        'id': 1,
	        'title': 'NodeY',
	        'type': 'Bot Type',
	        'nodes': [
	          {
	            'id': 1,
	            'title': 'node1.1',
	            'type': 'Bot Type 1.1',
	            'nodes': [
	              {
	                'id': 1,
	                'title': 'Node 1.1.1',
	                'type': 'Bot Type 1.1.1',
	                'nodes': []
	              }
	            ]
	          }          
	        ]
	      }
        
      ];  */
    }]);

}());
