function initZoomIcon() {
    $("#flowChart").mousemove(function(e) {
        //console.log($('.whiteBg').offset().top,e.clientY,$(window).scrollTop())
        $('#zoomIcon').show()
        $('#zoomIcon').css({
            'top': e.clientY + 20,
            'left': e.clientX - 40
        });
    }).mouseout(function(e) {
        $('#zoomIcon').hide()
    })
}

function initFlowChartMouseWeel(id) {
    var slideshow = document.getElementById(id)
    var nextslideindex = 0;

    function zoomChart(e) {
        var evt = window.event || e; //equalize event object

        var delta = evt.detail ? evt.detail * (-120) : evt.wheelDelta; //delta returns +120 when wheel is scrolled up, -120 when scrolled down

        if (delta == -120) {
            flowChartZoom('out');
        } else if (delta == 120) {
            flowChartZoom('in');
        }

        if (evt.preventDefault) //disable default wheel action of scrolling page
            evt.preventDefault();
        else
            return false;

    }

    var mousewheelevt = (/Firefox/i.test(navigator.userAgent)) ? "DOMMouseScroll" : "mousewheel"; //FF doesn't recognize mousewheel as of FF3.x

    if (slideshow.attachEvent) { //if IE (and Opera depending on user setting)
        slideshow.attachEvent("on" + mousewheelevt, zoomChart);
    } else if (slideshow.addEventListener) { //WC3 browsers
        slideshow.addEventListener(mousewheelevt, zoomChart, false);
    }

}

function flowChartZoom(direction) {
    var currentZoom = Math.round($('.virtui-workflow-container').css('zoom') * 100) ||
        Math.round($('.virtui-workflow-container').css('-moz-transform') * 100) ||
        Math.round($('.virtui-workflow-container').css('-webkit-transform') * 100);

    var zoom;
    if (direction == undefined) {
        if (currentZoom <= zoomSettings.min) {
            direction = 'in';
        } else {
            direction = 'out';
        }
    }

    direction == 'in' ? zoom = (currentZoom + zoomSettings.step) : zoom = (currentZoom - zoomSettings.step);
    if (zoom < zoomSettings.min || zoom > zoomSettings.max) {
        return
    } else {
        zoom = zoom + '%';
        // addZoom($('.virtui-workflow-container'),zoom)
    }



    if (direction == 'out') {
        $('.virtui-workflow-container').css({
            'zoom': zoom,
            '-moz-transform': 'scale(' + zoom + ')'
        });
    } else if (direction == 'in') {
        //$('.virtui-workflow-container').css('zoom', SHAREDDATA.chartWidth)
        $('.virtui-workflow-container').css('zoom', zoom);
    }
    $("#zoomPercent").html(zoom);
    centerAlignFlowChart()
}

function addZoom(element, size) {
    element.css('width', size)
        //for other browser suppor
        /*var newVal=size/100;
        newVal=Math.round( newVal * 10 ) / 10
        element.css({
            'zoom':size+'px',
            '-moz-transform':'scale('+newVal+')',
            '-webkit-transform':'scale('+newVal+')'
        })*/
}

function centerAlignFlowChart() {
    var whiteBgW = $('.whiteBg').width();
    var flowChart = $("#flowChart");
    //console.log((whiteBgW - flowChart.width()) / 2)
    if (whiteBgW > flowChart.width()) {
        flowChart.css({
            left: (whiteBgW - flowChart.width()) / 2
        })
    }
}
$(window).scroll(function(){
    //console.log("scrollTop: ",$(window).scrollTop());
    if($('#homeloader').css("display")=="block"){
        return;
    }
    if($(window).scrollTop()>0){
        var topPosition=$('#filtermodel').offset().top-$(window).scrollTop()
        $('#filtermodel').css('top',(58-$(window).scrollTop())+"px")
    }else{
        $('#filtermodel').css('top',"58px")
    }
    
})