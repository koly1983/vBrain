function formatDate(date)
{
  var d = new Date(date);
  var month = d.getMonth()+1;
  var day = d.getDate();

  var output = ((month<10 ? '0' : '') + month + '/' + (day<10 ? '0' : '') + day + "/" + d.getFullYear()) ;
  return output;
}

(function () {
  'use strict';
  
  //var urlName = "http://lowcost-env.yv5sv2bh2p.ap-south-1.elasticbeanstalk.com/";
  var urlName = window.location.origin + "/vBrain/";
  
  //var locationPath = "resources/";
  var locationPath = "vBrain/resources/";
  
  angular.module('vBrainApp', ['ngRoute', 'ui.bootstrap'])
  	.controller('SelectionCtrl', ['$scope', '$http', '$window', function ($scope, $http, $window) {
    	
    	//alert('selection loaded...');
  		
  		if(! $window.sessionStorage.getItem('loginId') || $window.sessionStorage.getItem('loginId') == null){
  			alert("Invalid access! Please login...");
  			
  			window.location.pathname = locationPath + 'index.html';
  		}
    	
    	 document.getElementById("loginId").innerHTML = $window.sessionStorage.getItem('loginId');
    	 document.getElementById("loginRole").innerHTML = $window.sessionStorage.getItem('loginRole');
    	
    	 //alert( Date.parse($window.sessionStorage.getItem('fromDate')) );
    	
    	 $scope.functionName = $window.sessionStorage.getItem('functionName');
    	 $scope.lob = $window.sessionStorage.getItem('lob');
    	 $scope.fromDate = Date.parse($window.sessionStorage.getItem('fromDate'));
		 $scope.toDate = Date.parse($window.sessionStorage.getItem('toDate'));
		 
		 $scope.convertToDateStr = function(d) {
			 var m = d.getUTCMonth() +1;
			 var j = d.getUTCDate();
			 var y = d.getUTCFullYear();
			 return "" + m + "/" + j + "/" + y;
		 }
    	 
		 $scope.retrieveItemList = function (groupType){
			var postReq = {
					 method: 'POST',
					 url: urlName+'vbrain/vBrainService/getGroupNames',
					 headers: {
					   'Content-Type': 'application/json'
					 },
					 data: {
						 "requestParameter": {
							 "type":groupType
						    }
						}
				};
				$http(postReq).then(
					function(response){
						/*if (groupType == "lob") {*/
							$scope.lobNameList = response.data.responseData.dataList;
						/*} else if (groupType == "function") {
							$scope.functionNameList = response.data.responseData.dataList;
						}*/
					},
					function(e){alert("error: "+e);
				});
		 }
    	 $scope.retrieveItemList('lob');
    	 
    	 
    	 $scope.retrieveFunctionList = function (groupType, transGroupId){
 			var postReq = {
 					 method: 'POST',
 					 url: urlName+'vbrain/vBrainService/getFunctionNames',
 					 headers: {
 					   'Content-Type': 'application/json'
 					 },
 					 data: {
 						 "requestParameter": {
 							 "type":groupType,
 							 "transGroupId":transGroupId
 						    }
 						}
 				};
 				$http(postReq).then(
 					function(response){
 							$scope.functionNameList = response.data.responseData.dataList;
 					},
 					function(e){alert("error: "+e);
 				});
 		 }
    	 
    	 $scope.retrieveFunctionList('function',$scope.lob);
    	 
		 $('#groupDropDown').change(function(){ 
			var groupId = $(this).val();
			$scope.retrieveFunctionList('function',groupId);
		});
    	
    	 $scope.proceed = function(){
    		
    		//alert($scope.fromDate);
    		
    		if(! $scope.lob){
    			alert("Please select the Line of Business!");
    			
    		}
    		else if(! $scope.functionName){
    			alert("Please select the Function!");
    			
    		}
    		else if(! $scope.fromDate){
    			alert("Please select the From date!");
    			
    		}
    		else if(! $scope.toDate){
    			alert("Please select the To date!");
    			
    		}
    		/*else if(Date.parse($scope.toDate) > new Date()  ){
    			alert("To date should be lesser than current date!");
    			
    		}*/
    		else if(Date.parse($scope.fromDate) > Date.parse($scope.toDate) ){
    			alert("From date should be lesser than To date!");
    			
    		}
    		else {
    			
    			//alert( Date.parse($scope.fromDate).toString("MM/dd/yyyy"));
    			$scope.lobName = getLobName($scope.lob, $scope.lobNameList);
    			$window.sessionStorage.setItem("lob", $scope.lob);
    			$window.sessionStorage.setItem("lobName", $scope.lobName);
    			$window.sessionStorage.setItem("functionName", $scope.functionName);
    			$window.sessionStorage.setItem("fromDate", formatDate($scope.fromDate));
    			$window.sessionStorage.setItem("toDate", formatDate($scope.toDate));
    			
    			window.location.pathname = locationPath + 'vbrain.html';
    		}
    	 }
    	 
    	 var getLobName = function(lobId, lobNameList) {
    		 var lobName = lobId + "";
    		 for(var i = 0; i < lobNameList.length; i++) {
    			 var lobObj = lobNameList[i];
    			 if(lobObj.groupID == lobId) {
    				 lobName = lobObj.groupName;
    				 break;
    			 }
    		 }
    		 return lobName;
    	 };
    }]);
}());