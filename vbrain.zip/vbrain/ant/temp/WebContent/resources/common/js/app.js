(function () {
  'use strict';
  angular.module('vBrainApp', ['ui.tree', 'ngRoute', 'ui.bootstrap','ui.grid','ui.grid.edit', 'ui.grid.cellNav'])

    .config(['$routeProvider', '$compileProvider', function ($routeProvider, $compileProvider) {
      $routeProvider
        .when('/', {
          controller: 'OuDashboardCtrl',
          templateUrl: 'views/ou-dashboard-view.html'
        })
        .when('/org-structure', {
          controller: 'orgStructureCtrl',
          templateUrl: 'views/ou-structure-view.html'
        })
        .when('/process', {
          controller: 'ProcessCtrl',
          templateUrl: 'views/process.html'
        })
        .when('/user', {
          controller: 'UserCtrl',
          templateUrl: 'views/user.html'
        })
        .when('/privilage', {
          controller: 'PrivilageCtrl',
          templateUrl: 'views/privilage.html'
        })
        .when('/cloning', {
          controller: 'CloningCtrl',
          templateUrl: 'views/cloning.html'
        })
        .when('/connected-trees', {
          controller: 'ConnectedTreesCtrl',
          templateUrl: 'views/connected-trees.html'
        })
        .when('/filter-nodes', {
          controller: 'FilterNodesCtrl',
          templateUrl: 'views/filter-nodes.html'
        })
        .when('/nodrop', {
          controller: 'BasicExampleCtrl',
          templateUrl: 'views/nodrop.html'
        })
        .when('/table-example', {
          controller: 'TableExampleCtrl',
          templateUrl: 'views/table-example.html'
        })
        .when('/drop-confirmation', {
          controller: 'DropConfirmationCtrl',
          templateUrl: 'views/drop-confirmation.html'
        })
        .when('/expand-on-hover', {
          controller: 'ExpandOnHoverCtrl',
          templateUrl: 'views/expand-on-hover.html'
        })
        .otherwise({
          redirectTo: '/'
        });

      // testing issue #521
      $compileProvider.debugInfoEnabled(false);
    }]);
})();
