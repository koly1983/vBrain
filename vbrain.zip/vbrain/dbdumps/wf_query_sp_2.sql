DROP PROCEDURE IF EXISTS vbrain.wf_query_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`wf_query_sp_2`(IN params VARCHAR(1000))
BEGIN
    DECLARE t VARCHAR(100);
    DECLARE value VARCHAR(1000);
    DECLARE o VARCHAR(100) DEFAULT NULL;
    DECLARE w VARCHAR(1000) DEFAULT NULL;
    DECLARE front TEXT DEFAULT NULL;
    DECLARE frontlen INT DEFAULT NULL;
    DECLARE TempValue TEXT DEFAULT NULL;

    SET t = SPLIT_STR(params,'$^',1);
    SET value = SPLIT_STR(params,'$^',2);
    SET o = SPLIT_STR(params,'$^',3);
    SET w = SPLIT_STR(params,'$^',4);

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`wf_query_tmp`;

    CREATE TEMPORARY TABLE `vbrain`.`wf_query_tmp` (
        QE varchar(1000),
        QT varchar(1)
    ); 

    iterator: LOOP
        IF LENGTH(TRIM(value)) = 0 OR value IS NULL THEN
            LEAVE iterator;
        END IF;
        SET front = SUBSTRING_INDEX(Value,'$$',1);
        SET frontlen = LENGTH(front);
        SET TempValue = TRIM(front);

        IF SPLIT_STR(TempValue,'$=',2) IS NULL THEN
            INSERT INTO wf_query_tmp(QE, QT) VALUES 
            (CONCAT('|',TempValue,'|',TempValue),'S');
        ELSE
            INSERT INTO wf_query_tmp(QE, QT) VALUES 
            (CONCAT('|',SPLIT_STR(TempValue,'$=',1),'|',SPLIT_STR(TempValue,'$=',2)),'S');
        END IF;

        SET value = INSERT(value,1,frontlen + 2,'');
    END LOOP;

    INSERT INTO wf_query_tmp(QE, QT) VALUES 
    (t,'F');

    IF w IS NOT NULL THEN
        INSERT INTO wf_query_tmp(QE, QT) VALUES 
        (w,'W');
    END IF;
    
    IF o IS NOT NULL THEN
        SET value = o;

        iterator: LOOP
            IF LENGTH(TRIM(value)) = 0 OR value IS NULL THEN
                LEAVE iterator;
            END IF;
            SET front = SUBSTRING_INDEX(Value,'$$',1);
            SET frontlen = LENGTH(front);
            SET TempValue = TRIM(front);

            INSERT INTO wf_query_tmp(QE, QT) VALUES 
            (CONCAT('|',SPLIT_STR(TempValue,'$#',1),'|',IFNULL(SPLIT_STR(TempValue,'$#',2),'A')),'O');

            SET value = INSERT(value,1,frontlen + 2,'');
        END LOOP;
    END IF;

    INSERT INTO wf_query_tmp(QE, QT) VALUES 
    ('500','L');
    
    SELECT * FROM wf_query_tmp;

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`wf_query_tmp`;
END$$
DELIMITER ;