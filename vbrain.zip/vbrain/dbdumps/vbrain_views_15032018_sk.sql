DROP VIEW IF EXISTS `group_bot_view`;
CREATE VIEW `group_bot_view` AS
    SELECT 
        `b`.`ID` AS `id`,
        `b`.`Bot_Key` AS `botKey`,
        `b`.`Provider` AS `provider`,
        `b`.`Description` AS `description`,
        `b`.`Process_Id` AS `processId`,
        `b`.`status` AS `status`,
        `g`.`Name` AS `processName`
    FROM
        (`vbrain`.`bot` `b`
        JOIN `vbrain`.`groups` `g`)
    WHERE
        ((`g`.`ID` = `b`.`Process_Id`)
            AND (`b`.`isDisabled` = '0'));

			
DROP VIEW IF EXISTS `group_incidents_view`;
CREATE VIEW `group_incidents_view` AS
    SELECT 
        `vi`.`TICKET_ID` AS `ticket_id`,
        `vi`.`STATUS` AS `status`,
        `vt`.`ID` AS `transaction_id`,
        (CASE
            WHEN
                (`vt`.`WORKER_TYPE` = 'BOT')
            THEN
                (SELECT 
                        `vbrain`.`bot`.`Process_Id`
                    FROM
                        `vbrain`.`bot`
                    WHERE
                        ((`vbrain`.`bot`.`ID` = `vt`.`WORKER_ID`)
                            AND (`vt`.`WORKER_TYPE` = 'BOT')))
            ELSE (SELECT 
                    `vbrain`.`human_worker`.`Process_Id`
                FROM
                    `vbrain`.`human_worker`
                WHERE
                    ((`vbrain`.`human_worker`.`ID` = `vt`.`WORKER_ID`)
                        AND (`vt`.`WORKER_TYPE` = 'HUMAN')))
        END) AS `process_id`,
        (CASE
            WHEN
                (`vt`.`WORKER_TYPE` = 'BOT')
            THEN
                (SELECT 
                        `vbrain`.`groups`.`Name`
                    FROM
                        `vbrain`.`groups`
                    WHERE
                        (`vbrain`.`groups`.`ID` = (SELECT 
                                `vbrain`.`bot`.`Process_Id`
                            FROM
                                `vbrain`.`bot`
                            WHERE
                                ((`vbrain`.`bot`.`ID` = `vt`.`WORKER_ID`)
                                    AND (`vt`.`WORKER_TYPE` = 'BOT')))))
            ELSE (SELECT 
                    `vbrain`.`groups`.`Name`
                FROM
                    `vbrain`.`groups`
                WHERE
                    (`vbrain`.`groups`.`ID` = (SELECT 
                            `vbrain`.`human_worker`.`Process_Id`
                        FROM
                            `vbrain`.`human_worker`
                        WHERE
                            ((`vbrain`.`human_worker`.`ID` = `vt`.`WORKER_ID`)
                                AND (`vt`.`WORKER_TYPE` = 'HUMAN')))))
        END) AS `process_name`,
        `vt`.`START_TIME` AS `start_time`,
        `vt`.`END_TIME` AS `end_time`,
        `vt`.`COUNTRY` AS `country`
    FROM
        (`vbrain`.`vbrain_incidents` `vi`
        JOIN `vbrain`.`transactions` `vt`)
    WHERE
        (`vt`.`ID` = `vi`.`TRANSACTION_ID`);


DROP VIEW IF EXISTS `group_sla_view`;
CREATE VIEW `group_sla_view` AS
    SELECT 
        `vt`.`ID` AS `transaction_id`,
        (CASE
            WHEN
                (`vt`.`WORKER_TYPE` = 'BOT')
            THEN
                (SELECT 
                        `vbrain`.`bot`.`avgEfforts`
                    FROM
                        `vbrain`.`bot`
                    WHERE
                        ((`vbrain`.`bot`.`ID` = `vt`.`WORKER_ID`)
                            AND (`vt`.`WORKER_TYPE` = 'BOT')))
            ELSE (SELECT 
                    `vbrain`.`human_worker`.`avgEfforts`
                FROM
                    `vbrain`.`human_worker`
                WHERE
                    ((`vbrain`.`human_worker`.`ID` = `vt`.`WORKER_ID`)
                        AND (`vt`.`WORKER_TYPE` = 'HUMAN')))
        END) AS `sla`,
        (CASE
            WHEN
                (`vt`.`WORKER_TYPE` = 'BOT')
            THEN
                (SELECT 
                        `vbrain`.`bot`.`Process_Id`
                    FROM
                        `vbrain`.`bot`
                    WHERE
                        ((`vbrain`.`bot`.`ID` = `vt`.`WORKER_ID`)
                            AND (`vt`.`WORKER_TYPE` = 'BOT')))
            ELSE (SELECT 
                    `vbrain`.`human_worker`.`Process_Id`
                FROM
                    `vbrain`.`human_worker`
                WHERE
                    ((`vbrain`.`human_worker`.`ID` = `vt`.`WORKER_ID`)
                        AND (`vt`.`WORKER_TYPE` = 'HUMAN')))
        END) AS `process_id`,
        (CASE
            WHEN
                (`vt`.`WORKER_TYPE` = 'BOT')
            THEN
                (SELECT 
                        `vbrain`.`groups`.`Name`
                    FROM
                        `vbrain`.`groups`
                    WHERE
                        (`vbrain`.`groups`.`ID` = (SELECT 
                                `vbrain`.`bot`.`Process_Id`
                            FROM
                                `vbrain`.`bot`
                            WHERE
                                ((`vbrain`.`bot`.`ID` = `vt`.`WORKER_ID`)
                                    AND (`vt`.`WORKER_TYPE` = 'BOT')))))
            ELSE (SELECT 
                    `vbrain`.`groups`.`Name`
                FROM
                    `vbrain`.`groups`
                WHERE
                    (`vbrain`.`groups`.`ID` = (SELECT 
                            `vbrain`.`human_worker`.`Process_Id`
                        FROM
                            `vbrain`.`human_worker`
                        WHERE
                            ((`vbrain`.`human_worker`.`ID` = `vt`.`WORKER_ID`)
                                AND (`vt`.`WORKER_TYPE` = 'HUMAN')))))
        END) AS `process_name`,
        (CASE
            WHEN
                (`vt`.`WORKER_TYPE` = 'BOT')
            THEN
                (SELECT 
                        `vbrain`.`bot`.`isDisabled`
                    FROM
                        `vbrain`.`bot`
                    WHERE
                        ((`vbrain`.`bot`.`ID` = `vt`.`WORKER_ID`)
                            AND (`vt`.`WORKER_TYPE` = 'BOT')))
            ELSE (SELECT 
                    `vbrain`.`human_worker`.`isDisabled`
                FROM
                    `vbrain`.`human_worker`
                WHERE
                    ((`vbrain`.`human_worker`.`ID` = `vt`.`WORKER_ID`)
                        AND (`vt`.`WORKER_TYPE` = 'HUMAN')))
        END) AS `worker_status`,
        `vt`.`START_TIME` AS `start_time`,
        `vt`.`END_TIME` AS `end_time`,
        `vt`.`COUNTRY` AS `country`,
        TIMESTAMPDIFF(MINUTE,
            `vt`.`START_TIME`,
            `vt`.`END_TIME`) AS `Duration`,
        `vt`.`WORKER_TYPE` AS `worker`,
        `vt`.`WORKER_ID` AS `worker_id`
    FROM
        `vbrain`.`transactions` `vt`
    WHERE
        (`vt`.`STATUS` = '0');


DROP VIEW IF EXISTS `group_transaction_view`;
CREATE VIEW `group_transaction_view` AS
    SELECT 
        `vbrain`.`transactions`.`ID` AS `transaction_id`,
        (CASE
            WHEN
                (`vbrain`.`transactions`.`WORKER_TYPE` = 'BOT')
            THEN
                (SELECT 
                        `vbrain`.`bot`.`Bot_Key`
                    FROM
                        `vbrain`.`bot`
                    WHERE
                        ((`vbrain`.`bot`.`ID` = `vbrain`.`transactions`.`WORKER_ID`)
                            AND (`vbrain`.`transactions`.`WORKER_TYPE` = 'BOT')))
            ELSE (SELECT 
                    `vbrain`.`human_worker`.`Worker_Id`
                FROM
                    `vbrain`.`human_worker`
                WHERE
                    ((`vbrain`.`human_worker`.`ID` = `vbrain`.`transactions`.`WORKER_ID`)
                        AND (`vbrain`.`transactions`.`WORKER_TYPE` = 'HUMAN')))
        END) AS `worker_id`,
        (CASE
            WHEN
                (`vbrain`.`transactions`.`WORKER_TYPE` = 'BOT')
            THEN
                (SELECT 
                        `vbrain`.`bot`.`isDisabled`
                    FROM
                        `vbrain`.`bot`
                    WHERE
                        ((`vbrain`.`bot`.`ID` = `vbrain`.`transactions`.`WORKER_ID`)
                            AND (`vbrain`.`transactions`.`WORKER_TYPE` = 'BOT')))
            ELSE (SELECT 
                    `vbrain`.`human_worker`.`isDisabled`
                FROM
                    `vbrain`.`human_worker`
                WHERE
                    ((`vbrain`.`human_worker`.`ID` = `vbrain`.`transactions`.`WORKER_ID`)
                        AND (`vbrain`.`transactions`.`WORKER_TYPE` = 'HUMAN')))
        END) AS `worker_status`,
        (CASE
            WHEN
                (`vbrain`.`transactions`.`WORKER_TYPE` = 'BOT')
            THEN
                (SELECT 
                        `vbrain`.`bot`.`Process_Id`
                    FROM
                        `vbrain`.`bot`
                    WHERE
                        ((`vbrain`.`bot`.`ID` = `vbrain`.`transactions`.`WORKER_ID`)
                            AND (`vbrain`.`transactions`.`WORKER_TYPE` = 'BOT')))
            ELSE (SELECT 
                    `vbrain`.`human_worker`.`Process_Id`
                FROM
                    `vbrain`.`human_worker`
                WHERE
                    ((`vbrain`.`human_worker`.`ID` = `vbrain`.`transactions`.`WORKER_ID`)
                        AND (`vbrain`.`transactions`.`WORKER_TYPE` = 'HUMAN')))
        END) AS `process_id`,
        (CASE
            WHEN
                (`vbrain`.`transactions`.`WORKER_TYPE` = 'BOT')
            THEN
                (SELECT 
                        `vbrain`.`groups`.`Name`
                    FROM
                        `vbrain`.`groups`
                    WHERE
                        (`vbrain`.`groups`.`ID` = (SELECT 
                                `vbrain`.`bot`.`Process_Id`
                            FROM
                                `vbrain`.`bot`
                            WHERE
                                ((`vbrain`.`bot`.`ID` = `vbrain`.`transactions`.`WORKER_ID`)
                                    AND (`vbrain`.`transactions`.`WORKER_TYPE` = 'BOT')))))
            ELSE (SELECT 
                    `vbrain`.`groups`.`Name`
                FROM
                    `vbrain`.`groups`
                WHERE
                    (`vbrain`.`groups`.`ID` = (SELECT 
                            `vbrain`.`human_worker`.`Process_Id`
                        FROM
                            `vbrain`.`human_worker`
                        WHERE
                            ((`vbrain`.`human_worker`.`ID` = `vbrain`.`transactions`.`WORKER_ID`)
                                AND (`vbrain`.`transactions`.`WORKER_TYPE` = 'HUMAN')))))
        END) AS `process_name`,
        `vbrain`.`transactions`.`START_TIME` AS `start_time`,
        `vbrain`.`transactions`.`END_TIME` AS `end_time`,
        TIMESTAMPDIFF(MINUTE,
            `vbrain`.`transactions`.`START_TIME`,
            `vbrain`.`transactions`.`END_TIME`) AS `duration`,
        (SELECT 
                `vbrain`.`bot`.`avgEffortsSaved`
            FROM
                `vbrain`.`bot`
            WHERE
                ((`vbrain`.`bot`.`ID` = `vbrain`.`transactions`.`WORKER_ID`)
                    AND (`vbrain`.`transactions`.`WORKER_TYPE` = 'BOT'))) AS `efforts_saved`,
        `vbrain`.`transactions`.`STATUS` AS `status`,
        `vbrain`.`transactions`.`WORKER_TYPE` AS `worker_type`,
        `vbrain`.`transactions`.`OUT_COME` AS `out_come`,
        `vbrain`.`transactions`.`DESCRIPTION` AS `description`,
        `vbrain`.`transactions`.`TRACKING_ID` AS `tracking_id`,
        `vbrain`.`transactions`.`COUNTRY` AS `country`,
        `vbrain`.`transactions`.`B_FUNCTION` AS `function`
    FROM
        `vbrain`.`transactions`;

		
DROP VIEW IF EXISTS `incidents_view`;
CREATE VIEW `incidents_view` AS
    SELECT 
        `vi`.`TICKET_ID` AS `ticket_id`,
        `vi`.`STATUS` AS `status`,
        `vi`.`DESCRIPTION` AS `description`,
        `vp`.`ID` AS `process_id`,
        `vp`.`PROCESS_NAME` AS `process_name`,
        `vp`.`SLA` AS `SLA`,
        `vp`.`EFFORT_SAVED` AS `effort_saved`,
        `vp`.`SEQUENCE` AS `sequence`,
        `vg`.`GEOGRAPHY` AS `geography`,
        `vg`.`REGION` AS `region`,
        `vt`.`START_TIME` AS `start_time`,
        `vt`.`END_TIME` AS `end_time`,
        TIMESTAMPDIFF(MINUTE,
            `vt`.`START_TIME`,
            `vt`.`END_TIME`) AS `Duration`,
        `vt`.`WORKER` AS `worker`
    FROM
        ((((`vbrain`.`vbrain_incidents` `vi`
        JOIN `vbrain`.`vbrain_process` `vp`)
        JOIN `vbrain`.`vbrain_transaction` `vt`)
        JOIN `vbrain`.`vbrain_geo` `vg`)
        JOIN `vbrain`.`vbrain_bot` `vb`)
    WHERE
        ((`vb`.`ID` = `vt`.`BOT_ID`)
            AND (`vb`.`PROCESS_ID` = `vp`.`ID`)
            AND (`vg`.`ID` = `vb`.`GEO_ID`)
            AND (`vt`.`ID` = `vi`.`TRANSACTION_ID`));		


DROP VIEW IF EXISTS `sla_view`;			
CREATE VIEW `sla_view` AS
    SELECT 
        `vs`.`SLA` AS `sla`,
        `vp`.`PROCESS_NAME` AS `process_name`,
        `vp`.`ID` AS `process_id`,
        `vp`.`EFFORT_SAVED` AS `effort_saved`,
        `vp`.`SEQUENCE` AS `sequence`,
        `vg`.`GEOGRAPHY` AS `geography`,
        `vg`.`REGION` AS `region`,
        `vt`.`START_TIME` AS `start_time`,
        `vt`.`END_TIME` AS `end_time`,
        TIMESTAMPDIFF(MINUTE,
            `vt`.`START_TIME`,
            `vt`.`END_TIME`) AS `Duration`,
        `vt`.`WORKER` AS `worker`
    FROM
        ((((`vbrain`.`vbrain_sla` `vs`
        JOIN `vbrain`.`vbrain_process` `vp`)
        JOIN `vbrain`.`vbrain_transaction` `vt`)
        JOIN `vbrain`.`vbrain_geo` `vg`)
        JOIN `vbrain`.`vbrain_bot` `vb`)
    WHERE
        ((`vb`.`ID` = `vt`.`BOT_ID`)
            AND (`vb`.`PROCESS_ID` = `vp`.`ID`)
            AND (`vg`.`ID` = `vb`.`GEO_ID`)
            AND (`vs`.`PROCESS_ID` = `vb`.`PROCESS_ID`))
    GROUP BY `vt`.`ID`;
	

DROP VIEW IF EXISTS `transation_view`;		
CREATE VIEW `transation_view` AS
    SELECT 
        `vb`.`BOT_KEY` AS `bot_key`,
        `vp`.`ID` AS `process_id`,
        `vp`.`PROCESS_NAME` AS `process_name`,
        `vp`.`SLA` AS `SLA`,
        `vp`.`EFFORT_SAVED` AS `effort_saved`,
        `vp`.`SEQUENCE` AS `sequence`,
        `vg`.`GEOGRAPHY` AS `geography`,
        `vg`.`REGION` AS `region`,
        `vt`.`START_TIME` AS `start_time`,
        `vt`.`END_TIME` AS `end_time`,
        TIMESTAMPDIFF(MINUTE,
            `vt`.`START_TIME`,
            `vt`.`END_TIME`) AS `Duration`,
        `vt`.`STATUS` AS `status`,
        `vt`.`WORKER` AS `worker`,
        `vt`.`OUT_COME` AS `out_come`,
        `vt`.`DESCRIPTION` AS `description`
    FROM
        (((`vbrain`.`vbrain_bot` `vb`
        JOIN `vbrain`.`vbrain_process` `vp`)
        JOIN `vbrain`.`vbrain_transaction` `vt`)
        JOIN `vbrain`.`vbrain_geo` `vg`)
    WHERE
        ((`vb`.`ID` = `vt`.`BOT_ID`)
            AND (`vb`.`PROCESS_ID` = `vp`.`ID`)
            AND (`vg`.`ID` = `vb`.`GEO_ID`));
			
