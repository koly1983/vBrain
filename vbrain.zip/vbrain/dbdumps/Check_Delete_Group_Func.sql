DROP FUNCTION IF EXISTS check_can_delete_group;

DELIMITER &&

 CREATE FUNCTION check_can_delete_group (id INT(11)) RETURNS TINYINT(1) 
 DETERMINISTIC 
 BEGIN
	 DECLARE gtype varchar(45);
	 DECLARE flag TINYINT(1) DEFAULT 0;
	 SELECT g.`Type` INTO gtype FROM groups g WHERE g.ID = id;
     IF gtype = 'process' THEN
         SELECT COUNT(*) = 0 INTO flag FROM 
			(SELECT 1 as exist FROM bot b WHERE Process_Id = id
			UNION ALL
			SELECT 1 as exist FROM transactions t WHERE t.WORKER_ID = (SELECT b.ID FROM bot b WHERE Process_Id = id LIMIT 1)
			UNION ALL
			SELECT 1 as exist FROM wf_temp_transactions tt WHERE tt.CAMPAIGN_ID = (SELECT m.campaign_id FROM vbrain.wf_bp_mapping m
				WHERE process_id = id)
			UNION ALL
			SELECT 1 as exist FROM wf_temp_datastore td WHERE td.name = (SELECT m.datastore_name FROM vbrain.wf_bp_mapping m
				WHERE process_id = id)) AS total;
	 ELSE 
	 	SELECT COUNT(*) = 0 INTO flag FROM groups g WHERE g.Parent_Id = id;
     END IF;
     RETURN flag;
 END&&

 DELIMITER ;