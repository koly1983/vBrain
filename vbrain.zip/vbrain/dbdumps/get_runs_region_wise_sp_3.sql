DROP PROCEDURE IF EXISTS vbrain.get_runs_region_wise_sp_3;

DELIMITER $$
$$
CREATE PROCEDURE vbrain.get_runs_region_wise_sp_3(IN p_function VARCHAR(100), IN p_start_date VARCHAR(20), IN p_end_date VARCHAR(20))
BEGIN
	SELECT COUNT(*) totalTransaction, 
	    bp_uuid, 
	    process_Name, 
	    MIN(CAST(vt.start_time AS CHAR)) first_trans_start_date_time, 
	    country, worker_type, 
	    (SELECT sequence FROM sequence_temp WHERE process_name = vt.process_name) AS sequence 
	FROM group_transaction_view vt 
	WHERE vt.tracking_id IS NOT NULL AND vt.status = '0' AND vt.worker_status = '0' AND 
	    vt.process_id = (SELECT id FROM groups WHERE isDisabled = '0'  AND id = vt.process_id ) AND 
	    vt.function = p_function AND 
	    vt.START_TIME >= STR_TO_DATE(p_start_date, '%m/%d/%Y') AND 
	    vt.END_TIME <=  DATE_ADD( STR_TO_DATE(p_end_date, '%m/%d/%Y'), INTERVAL 1 DAY) 
	GROUP BY bp_uuid, country, worker_type 
	ORDER BY sequence, country, worker_type;
END$$
DELIMITER ;
