DROP PROCEDURE IF EXISTS vbrain.bp_run_import_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `bp_run_import_sp_2`()
BEGIN
        DECLARE v_max_wf_id BIGINT(20) DEFAULT 0;
        DECLARE min_start_date DATETIME DEFAULT NULL;
        DECLARE campaignIdList VARCHAR(2000) DEFAULT NULL;
        DECLARE w VARCHAR(5000) DEFAULT NULL;

        SELECT MAX(max_wf_id) INTO v_max_wf_id FROM wf_bp_run;
        
        SET min_start_date = DATE_SUB(NOW(), INTERVAL 50 day);

        SELECT GROUP_CONCAT(bp.campaign_id SEPARATOR ',') INTO campaignIdList
        FROM business_process_view_2 bp
        WHERE bp.isDisabled = 0;

        IF IFNULL(v_max_wf_id,0) = 0 THEN
            SET w = CONCAT('startDate > \'',DATE(min_start_date),'\'');
        ELSE
            SET w = CONCAT('(', bp_run_import_sub_func_2(), ')');
        END IF;

        IF campaignIdList IS NOT NULL THEN
            SET w = CONCAT(w, ' AND campaign_id IN (',campaignIdList,')');
        END IF;
        
        SET w = CONCAT(w, ' AND rootRunUUID IS NOT NULL GROUP BY rootRunUUID');

        DROP TEMPORARY TABLE IF EXISTS `vbrain`.`bp_run_import_tmp`;

        CREATE TEMPORARY TABLE `vbrain`.`bp_run_import_tmp` (
            QE varchar(1000),
            QT varchar(1)
        );

        INSERT INTO bp_run_import_tmp(QE, QT) VALUES
        ('|campaign_id|campaign_id','S'),
        ('|rootRunUUID|bp_uuid','S'),
        ('|MIN(startDate)|start_time','S'),
        ('|IFNULL(MAX(endDate),MAX(startDate))|end_time','S'),
        ('|MAX(id)|max_wf_id','S'),
        ('Run','F'),
        (w,'W'),
        ('|startDate|A','O'),
        ('1000','L'),
        ('wf_bp_run|i','T');

        SELECT * FROM bp_run_import_tmp;

        DROP TEMPORARY TABLE IF EXISTS `vbrain`.`bp_run_import_tmp`;
END$$
DELIMITER ;