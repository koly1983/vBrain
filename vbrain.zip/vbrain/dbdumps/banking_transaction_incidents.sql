DELETE FROM `transactions` where ID >= 1000 and ID <=10000;
INSERT INTO `transactions` VALUES 
(1000,13,'BOT','0','2018-01-12 15:03:04','2018-01-12 15:03:14','10','','','successful issued card ending #1234','BOT',NULL,NULL,'Canada','Cards'),
(1001,13,'BOT','0','2018-01-12 15:25:04','2018-01-12 15:25:24','20','','','successful issued card ending #3456','BOT',NULL,NULL,'Canada','Cards'),
(1002,13,'BOT','0','2018-01-16 16:25:04','2018-01-16 16:25:16','12','','','successful issued card ending #5631','BOT',NULL,NULL,'Canada','Cards'),
(1003,13,'BOT','0','2018-02-15 10:21:04','2018-02-15 10:28:16','7','','','successful issued card ending #5631','BOT',NULL,NULL,'Canada','Cards'),

(1020,16,'BOT','0','2018-01-12 16:03:04','2018-01-12 16:03:14','10','','','KYC check done on card ending #5630','BOT',NULL,NULL,'Canada','Cards'),
(1021,16,'BOT','0','2018-01-12 16:25:04','2018-01-12 16:25:24','20','','','KYC check done on card ending #5631','BOT',NULL,NULL,'Canada','Cards'),
(1022,16,'BOT','0','2018-01-16 17:25:04','2018-01-16 17:25:16','12','','','KYC check done on card ending #5632','BOT',NULL,NULL,'Canada','Cards'),
(1023,16,'BOT','0','2018-02-15 20:21:04','2018-02-15 20:28:16','7','','','KYC check done on card ending #5633','BOT',NULL,NULL,'Canada','Cards'),

(2000,14,'BOT','0','2018-03-12 12:03:04','2018-03-12 12:03:14','10','','','Verified user John B','BOT',NULL,NULL,'Canada','Cards'),
(2001,14,'BOT','0','2018-03-12 12:25:04','2018-03-12 12:25:24','20','','','Verified user Sam X','BOT',NULL,NULL,'Canada','Cards'),
(2002,14,'BOT','0','2018-04-16 13:25:04','2018-04-16 13:25:16','12','','','Verified user Francois G','BOT',NULL,NULL,'Canada','Cards'),
(2003,14,'BOT','0','2018-05-15 15:21:04','2018-05-15 15:28:16','7','','','Verification paused on Martin Miller','BOT',NULL,NULL,'Canada','Cards'),
(2004,14,'BOT','0','2018-06-21 17:21:14','2018-06-21 17:28:26','7','','','Verification paused on Jimmy F','BOT',NULL,NULL,'Canada','Cards'),

(3000,15,'BOT','0','2018-01-22 15:03:04','2018-01-22 15:03:14','10','','','successful issued card ending #1234','BOT',NULL,NULL,'India','Cards'),
(3001,15,'BOT','0','2018-01-22 15:25:04','2018-01-22 15:25:24','20','','','successful issued card ending #3456','BOT',NULL,NULL,'India','Cards'),
(3002,15,'BOT','0','2018-01-06 16:25:04','2018-01-06 16:25:16','12','','','successful issued card ending #6633','BOT',NULL,NULL,'India','Cards'),
(3003,15,'BOT','0','2018-04-15 10:21:04','2018-04-15 10:28:16','7','','','successful issued card ending #7854','BOT',NULL,NULL,'India','Cards'),
(3004,15,'BOT','0','2018-04-16 10:21:04','2018-04-16 10:30:16','9','','','successful issued card ending #3453','BOT',NULL,NULL,'India','Cards'),
(3005,15,'BOT','0','2018-04-26 11:21:04','2018-04-26 11:32:16','11','','','successful issued card ending #1236','BOT',NULL,NULL,'India','Cards'),

(1200,13,'BOT','1','2017-06-14 23:42:18','2017-06-14 23:50:33',NULL,'Network Level-2 Router Outage','OU','Network Level-2 Router Outage','BOT',NULL,'Ref#1027061450','Canada','Cards'),
(1201,13,'BOT','1','2017-07-15 23:42:18','2017-07-15 23:50:33',NULL,'Insufficient fund','OU','Insufficient fund','BOT',NULL,'Ref#1027061450','Canada','Cards'),
(1202,13,'BOT','1','2017-08-10 23:42:18','2017-08-15 23:50:33',NULL,'Insufficient fund','OU','Insufficient fund','BOT',NULL,'Ref#1027061567','Canada','Cards'),
(1203,13,'BOT','1','2017-06-14 23:42:18','2017-06-14 23:50:33',NULL,'Backend System Down','OU','Backend System Down','BOT',NULL,'Ref#1027061450','Canada','Cards'),

(2200,14,'BOT','1','2017-06-14 23:42:18','2017-06-14 23:50:33',NULL,'Network connection timeout','OU','Network connection timeout','BOT',NULL,'Ref#1027061451','Canada','Cards'),
(2201,14,'BOT','1','2017-07-15 23:42:18','2017-07-15 23:50:33',NULL,'Incomplete credentials','OU','Incomplete credentials','BOT',NULL,'Ref#1027061452','Canada','Cards'),
(2202,14,'BOT','1','2017-08-10 23:42:18','2017-08-15 23:50:33',NULL,'High probability of fraudulence','OU','High probability of fraudulence','BOT',NULL,'Ref#1027062567','Canada','Cards'),
(2203,14,'BOT','1','2017-06-14 23:42:18','2017-06-14 23:50:33',NULL,'Backend System Down','OU','Backend System Down','BOT',NULL,'Ref#1027061456','Canada','Cards'),

(3200,15,'BOT','1','2018-02-10 23:42:18','2018-02-10 23:50:33',NULL,'Database transaction timeout','OU','Database transaction timeout','BOT',NULL,'Ref#1027061450','India','Cards'),
(3201,15,'BOT','1','2018-02-25 23:42:18','2018-02-25 23:50:33',NULL,'Insufficient fund','OU','Insufficient fund','BOT',NULL,'Ref#1027061450','India','Cards'),
(3202,15,'BOT','1','2018-03-11 23:42:18','2018-03-11 23:50:33',NULL,'Password not meeting requirements','OU','Password not meeting requirements','BOT',NULL,'Ref#1027061567','India','Cards'),
(3203,15,'BOT','1','2018-03-28 23:42:18','2018-03-28 23:50:33',NULL,'Backend System Down','OU','Backend System Down','BOT',NULL,'Ref#1027061450','India','Cards'),
(3204,15,'BOT','1','2018-04-20 23:42:18','2018-04-20 23:50:33',NULL,'Backup restore failed','OU','Backup restore failed','BOT',NULL,'Ref#1027061455','India','Cards');


DELETE FROM `vbrain_incidents` where ID >= 1000 and ID <=10000;
INSERT INTO `vbrain_incidents` VALUES 
(1000,1200,13,'TK-01000','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),
(1001,1201,13,'TK-01001','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),
(1002,1202,13,'TK-01002','1','Ticket Closed (Issue Resolved)','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),
(1003,1203,13,'TK-01003','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),

(2000,2200,14,'TK-02000','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),
(2001,2201,14,'TK-02001','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),
(2002,2202,14,'TK-02002','0','Ticket Closed (Issue Resolved)','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),
(2003,2203,14,'TK-02003','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),

(3000,3200,15,'TK-03000','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),
(3001,3201,15,'TK-03001','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),
(3002,3202,15,'TK-03002','0','Ticket Closed (Issue Resolved)','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),
(3003,3203,15,'TK-03003','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),
(3004,3204,15,'TK-03004','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL);