DROP PROCEDURE IF EXISTS vbrain.select_unmapped_campaigns_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`select_unmapped_campaigns_sp_2`(IN include_group_id INT(11))
BEGIN
	IF include_group_id IS NOT NULL OR include_group_id > 0 THEN
		SELECT c.campaign_id, c.step_id, MAX(c.mapping_id) as mapping_id, c.bp_name, c.step_title, c.step_index 
		FROM wf_campaign c 
		WHERE campaign_id NOT IN (
			SELECT c.campaign_id FROM wf_business_process bp JOIN wf_campaign c ON c.mapping_id = bp.mapping_id
			WHERE bp.group_process_id <> include_group_id) 
		GROUP BY c.campaign_id, c.step_id
		ORDER BY c.bp_name, c.bp_lastmodified DESC;
	ELSE 
		SELECT c.campaign_id, c.step_id, MAX(c.mapping_id) as mapping_id, c.bp_name, c.step_title, c.step_index 
		FROM wf_campaign c 
		WHERE campaign_id NOT IN (SELECT c.campaign_id FROM wf_business_process bp JOIN wf_campaign c ON c.mapping_id = bp.mapping_id) 
		GROUP BY c.campaign_id, c.step_id
		ORDER BY c.bp_name, c.bp_lastmodified DESC;
	END IF;

END$$
DELIMITER ;
