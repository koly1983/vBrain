DROP PROCEDURE IF EXISTS `vbrain`.`update_lastrecord_campaign_sp`;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`update_lastrecord_campaign_sp`()
BEGIN
	DECLARE max_time DATETIME;
	
	SELECT GREATEST(MAX(bp_lastmodified),MAX(step_lastmodified)) INTO max_time FROM vbrain.wf_campaign;

	IF max_time > (SELECT lastrecord_timestamp_campaign FROM wf_configuration) THEN
		UPDATE wf_configuration SET lastrecord_timestamp_campaign = max_time;
	END IF;
END$$
DELIMITER ;