DROP PROCEDURE IF EXISTS vbrain.update_lastrecord_datastore_sp_2;

DELIMITER $$
$$
CREATE PROCEDURE vbrain.update_lastrecord_datastore_sp_2()
BEGIN
	DECLARE max_time BIGINT;
	
	SELECT GROUP_CONCAT(t.LAST_UPDATED_TIMESTAMP SEPARATOR ',') INTO max_time
		FROM wf_datastores_master m JOIN
			(SELECT NAME as DS_NAME, MAX(ts) as LAST_UPDATED_TIMESTAMP FROM (
			SELECT NAME, MAX(UNIX_TIMESTAMP(start_date)*100000 + system_id) as ts FROM wf_temp_datastore_trash GROUP BY name
			UNION
			SELECT NAME, MAX(UNIX_TIMESTAMP(start_date)*100000 + system_id) as ts FROM wf_temp_datastore GROUP BY name) AS ds GROUP BY NAME) as t
			ON m.display_name = t.DS_NAME 
		ORDER BY m.query_order;
	
	UPDATE wf_configuration SET LASTRECORD_TIMESTAMP_DATASTORE = max_time;
END$$
DELIMITER ;
