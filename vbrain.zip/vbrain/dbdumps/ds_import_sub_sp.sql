DROP PROCEDURE IF EXISTS vbrain.ds_import_sub_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ds_import_sub_sp`(IN bp_id INT(11), IN include_limit TINYINT(1))
BEGIN
        DECLARE max_wf_id BIGINT(20) DEFAULT 0;
    
        DECLARE ds_display_name VARCHAR(100) DEFAULT NULL;
        DECLARE postgre_start_date_format VARCHAR(50);
        DECLARE ds_table_name VARCHAR(500);
        DECLARE field_tracking_id VARCHAR(200);
        DECLARE field_error_msg VARCHAR(200);
        DECLARE field_system_id VARCHAR(200);
        DECLARE field_start_date VARCHAR(200);
        DECLARE field_id_order VARCHAR(200);
        DECLARE field_bp_uuid VARCHAR(200);

        DECLARE front TEXT DEFAULT NULL;
        DECLARE frontlen INT DEFAULT NULL;
        DECLARE lp_str VARCHAR(1000);
        DECLARE lp_substr TEXT DEFAULT NULL;

        DECLARE w VARCHAR(5000) DEFAULT NULL;

        DECLARE max_wf_id_tds BIGINT(20) DEFAULT 0;
        DECLARE max_wf_id_tdst BIGINT(20) DEFAULT 0;

        DECLARE start_date_str VARCHAR(500);

        SELECT IFNULL(MAX(tds.wf_id),0) INTO max_wf_id_tds FROM wf_temp_datastore tds WHERE tds.business_process_id = bp_id;
        SELECT IFNULL(MAX(tdst.wf_id),0) INTO max_wf_id_tdst FROM wf_temp_datastore_trash tdst WHERE tdst.business_process_id = bp_id;
        SELECT GREATEST(max_wf_id_tds,max_wf_id_tdst) INTO max_wf_id;
		
		IF max_wf_id = 0 THEN
			 SELECT IFNULL(UNIX_TIMESTAMP(MIN(start_time))*100000,0) INTO max_wf_id FROM wf_temp_transactions WHERE campaign_id = (SELECT campaign_id FROM business_process_view_2 WHERE business_process_id = bp_id); 
		END IF;

        SELECT display_name, start_date_postgre_format, mapped_datastores, tracking_id_field, error_msg_field, system_id_field, start_date_field, id_order_field, bp_uuid_field
                INTO ds_display_name, postgre_start_date_format, ds_table_name, field_tracking_id, field_error_msg, field_system_id, field_start_date, field_id_order, field_bp_uuid
                FROM wf_business_process bp WHERE id = bp_id;

        SELECT CONCAT('to_timestamp(',field_start_date,', \'',postgre_start_date_format,'\')') INTO start_date_str;
        SELECT CONCAT('(EXTRACT(EPOCH FROM ',start_date_str,')*100000+ CAST(',field_system_id,' AS BIGINT)) > ',max_wf_id) INTO w;
            
        SET w = CONCAT('(',w,') AND ',field_start_date,' IS NOT NULL');

        DROP TEMPORARY TABLE IF EXISTS `vbrain`.`d_import_tmp`;

        CREATE TEMPORARY TABLE `vbrain`.`d_import_tmp` (
                QE varchar(1000),
                QT varchar(1)
        );

        INSERT INTO d_import_tmp(QE, QT) VALUES
        (CONCAT('|',IFNULL(field_tracking_id,'NULL'),'|tracking_id'),'S'),
        (CONCAT('|',IFNULL(field_error_msg,'NULL'),'|error_msg'),'S'),
        (CONCAT('|',IFNULL(field_system_id,'NULL'),'|system_id'),'S'),
        (CONCAT('|',IFNULL(field_start_date,'NULL'),'|start_date'),'S'),
        (CONCAT('|\'',ds_display_name,'\'|name'),'S'),
        (CONCAT('|',bp_id,'|business_process_id'),'S'),
        (CONCAT('|',IFNULL(field_bp_uuid,'NULL'),'|bp_uuid'),'S'),
        (ds_table_name,'F'),
        (w,'W');

        IF field_id_order IS NOT NULL THEN
            SET lp_str = field_id_order;

            iterator: LOOP
                IF LENGTH(TRIM(lp_str)) = 0 OR lp_str IS NULL THEN
                    LEAVE iterator;
                END IF;
                SET front = SUBSTRING_INDEX(lp_str,'$$',1);
                SET frontlen = LENGTH(front);
                SET lp_substr = TRIM(front);

                INSERT INTO d_import_tmp(QE, QT) VALUES
                (CONCAT('|',lp_substr,'|A'),'O');

                SET lp_str = INSERT(lp_str,1,frontlen + 2,'');
            END LOOP;
        END IF;

        INSERT INTO d_import_tmp(QE, QT) VALUES
        ('1000','L'),
        ('wf_temp_datastore|ii','T');

        SELECT * FROM d_import_tmp;

        DROP TEMPORARY TABLE IF EXISTS `vbrain`.`d_import_tmp`;
END$$
DELIMITER ;