DROP PROCEDURE IF EXISTS vbrain.delete_group_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`delete_group_sp`(IN group_id INT(11))
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
	    ROLLBACK;  -- Rollback any changes made in the transaction
        RESIGNAL;  -- Resignal the error to the caller
    END;
    IF CHECK_CAN_DELETE_GROUP(group_id) = 1 THEN
	    SET autocommit = 0;
	
		-- Start SQL transaction
		START TRANSACTION;
	
		DELETE FROM wf_bp_mapping WHERE process_id = group_id;	
		DELETE FROM groups WHERE ID = group_id; 
	
		COMMIT;
		-- End SQL transaction 
		SET autocommit = 1;
	END IF;
END$$
DELIMITER ;
