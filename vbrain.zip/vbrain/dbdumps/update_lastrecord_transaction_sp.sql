DROP PROCEDURE IF EXISTS `vbrain`.`update_lastrecord_transaction_sp`;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`update_lastrecord_transaction_sp`()
BEGIN
	DECLARE max_time DATETIME;
	
	SELECT MAX(START_TIME) INTO max_time FROM vbrain.wf_temp_transactions;

	IF max_time > (SELECT LASTRECORD_TIMESTAMP FROM wf_configuration) THEN
		UPDATE wf_configuration SET LASTRECORD_TIMESTAMP = max_time;
	END IF;
END$$
DELIMITER ;