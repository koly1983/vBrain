DROP FUNCTION IF EXISTS vbrain.bp_run_import_sub_func_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` FUNCTION `bp_run_import_sub_func_2`() RETURNS varchar(5000) CHARSET latin1
BEGIN
    DECLARE v_cmp_id INT(11);
    DECLARE v_max_wf_id INT(11) DEFAULT 1;
    DECLARE v_max_wf_id_str VARCHAR(500) DEFAULT NULL;
    DECLARE finished INT(1) DEFAULT 0;
    DECLARE sub_str VARCHAR(5000) DEFAULT '';
    DECLARE min_start_date DATETIME DEFAULT NULL;

    DECLARE bp_run_cursor CURSOR FOR
        SELECT bp.campaign_id, MAX(r.max_wf_id) FROM business_process_view_2 bp LEFT JOIN wf_bp_run r ON r.campaign_id = bp.campaign_id WHERE bp.isDisabled=0 GROUP BY bp.campaign_id;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;

    SET min_start_date = DATE_SUB(NOW(), INTERVAL 50 day);

    OPEN bp_run_cursor;

        get_bp_run_data: LOOP
            FETCH bp_run_cursor INTO v_cmp_id, v_max_wf_id;
            IF finished = 1 THEN
                LEAVE get_bp_run_data;
            END IF;
            
            IF IFNULL(v_max_wf_id,0) = 0 THEN
                SET v_max_wf_id_str = CONCAT('startDate > \'',DATE(min_start_date),'\'');
            ELSE
                SET v_max_wf_id_str = CONCAT('id > ',v_max_wf_id);
            END IF;
    
            SET sub_str = CONCAT(sub_str, ' (', v_max_wf_id_str , ' AND campaign_id = ', v_cmp_id, ') OR');

        END LOOP get_bp_run_data;

        CLOSE bp_run_cursor;
    
        IF sub_str <> '' THEN
            SET sub_str = SUBSTRING(sub_str, 1, CHAR_LENGTH(sub_str) - 2);
        END IF;

        RETURN sub_str;
END$$
DELIMITER ;