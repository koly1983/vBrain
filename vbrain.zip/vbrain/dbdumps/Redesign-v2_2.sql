CREATE TABLE vbrain.wf_exception_category (
    id INT(11) NOT NULL AUTO_INCREMENT,
    `type` varchar(100) NOT NULL,
    CONSTRAINT wf_exception_type_pk PRIMARY KEY (id)
)
ENGINE=InnoDB
DEFAULT CHARSET=latin1
COLLATE=latin1_swedish_ci;

INSERT INTO vbrain.wf_exception_category (`type`) VALUES 
('Data Exception')
,('System Exception');

ALTER TABLE vbrain.exceptions MODIFY COLUMN Exception_Value VARCHAR(500) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL;
ALTER TABLE vbrain.exceptions MODIFY COLUMN Exception_Type INT(11) NOT NULL;
ALTER TABLE vbrain.exceptions MODIFY COLUMN Lob INT(11) NOT NULL;
ALTER TABLE vbrain.exceptions ADD CONSTRAINT exceptions_groups_fk FOREIGN KEY (Lob) REFERENCES vbrain.groups(ID);
ALTER TABLE vbrain.exceptions ADD CONSTRAINT exceptions_wf_exception_category_fk FOREIGN KEY (Exception_Type) REFERENCES vbrain.wf_exception_category(id);
ALTER TABLE vbrain.exceptions ADD CONSTRAINT exceptions_un UNIQUE KEY (Lob,Exception_Type,Exception_Value);


-- BP BOT view
create
or replace
view `business_process_bot_view_2` as select
    `bp`.`business_process_id` as `business_process_id`,
    `bp`.`display_name` as `display_name`,
    `bp`.`bp_group_name` as `bp_group_name`,
    `bp`.`campaign_name` as `campaign_name`,
    `bp`.`function` as `function`,
    `bp`.`lob` as `lob`,
    `bp`.`country` as `country`,
    `bp`.`region` as `region`,
    `bp`.`campaign_id` as `campaign_id`,
    `bp`.`mapping_id` as `mapping_id`,
    `bp`.`bp_group_id` as `bp_group_id`,
    `bp`.`function_id` as `function_id`,
    `bp`.`lob_id` as `lob_id`,
    `bp`.`country_id` as `country_id`,
    `bp`.`region_id` as `region_id`,
    `bp`.`mapped_datastores` as `mapped_datastores`,
    `bp`.`query_order` as `query_order`,
    `bp`.`start_date_convert_format` as `start_date_convert_format`,
    `bp`.`start_date_postgre_format` as `start_date_postgre_format`,
    `bp`.`tracking_id_field` as `tracking_id_field`,
    `bp`.`error_msg_field` as `error_msg_field`,
    `bp`.`system_id_field` as `system_id_field`,
    `bp`.`start_date_field` as `start_date_field`,
    `bp`.`isDisabled` as `isDisabled`,
    `b`.`ID` as `BOT_ID`,
    `b`.`isDisabled` as `BOT_DISABLED`
from
    `business_process_view_2` `bp`
join `bot` `b` on
    `b`.`Process_Id` = `bp`.`bp_group_id`;


-- Exception Category update
DROP PROCEDURE IF EXISTS vbrain.insert_or_update_exception_type_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`insert_or_update_exception_type_sp_2`(IN p_exception_id INT(11), IN p_lob_id INT(11), IN p_exception_category_id INT(11), IN p_exception_str VARCHAR(500))
BEGIN
    
    IF p_exception_id IS NULL THEN
        INSERT INTO exceptions (Lob, Exception_Type, Exception_Value) 
        VALUES (p_lob_id, p_exception_category_id, p_exception_str);
    ELSE
        UPDATE exceptions SET Lob = p_lob_id, Exception_Type = p_exception_category_id, Exception_Value = p_exception_str
        WHERE ID = p_exception_id;
    END IF;
    
    UPDATE vbrain.transactions t
    JOIN (SELECT bp.BOT_ID, Exception_Type, Exception_Value
        FROM vbrain.exceptions e 
        JOIN vbrain.business_process_bot_view_2 bp ON bp.lob_id = e.Lob) te 
    ON t.WORKER_ID = te.BOT_ID 
    SET t.ERROR_CAT = te.Exception_Type
    WHERE t.ERROR_CAT IS NULL AND t.ERROR_TYPE LIKE concat('%', te.Exception_Value, '%');
    
    UPDATE vbrain.wf_temp_datastore ds
    JOIN (SELECT bp.business_process_id, Exception_Type, Exception_Value
        FROM vbrain.exceptions e 
        JOIN vbrain.business_process_view_2 bp ON bp.lob_id = e.Lob) te 
    ON ds.business_process_id = te.business_process_id 
    SET ds.ERROR_CAT = te.Exception_Type
    WHERE ds.ERROR_CAT IS NULL AND ds.error_msg LIKE concat('%', te.Exception_Value, '%');

END$$
DELIMITER ;


-- Updating str_split function
DROP FUNCTION IF EXISTS vbrain.split_str;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` FUNCTION `vbrain`.`split_str`( s VARCHAR(1024) , del CHAR(3) , i INT) RETURNS varchar(1024) CHARSET latin1
BEGIN
    DECLARE n INT; 
    
    SET n = (LENGTH(s) - LENGTH(REPLACE(s, del, '')))/LENGTH(del) + 1;
    IF i > n THEN
        RETURN NULL;
    ELSE
        RETURN SUBSTRING_INDEX(SUBSTRING_INDEX(s, del, i) , del , -1 );        
    END IF;
END$$
DELIMITER ;


-- T import condition per bp
DROP FUNCTION IF EXISTS vbrain.t_import_sub_func;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` FUNCTION `vbrain`.`t_import_sub_func`() RETURNS VARCHAR(5000)
BEGIN
    DECLARE v_cmp_id INT(11);
    DECLARE v_max_wf_id INT(11) DEFAULT 1;
    DECLARE v_max_wf_id_str VARCHAR(500) DEFAULT NULL;
    DECLARE finished INT(1) DEFAULT 0;
    DECLARE sub_str VARCHAR(5000) DEFAULT '';
    DECLARE max_submissionDate DATETIME DEFAULT NULL;

    DECLARE t_cursor CURSOR FOR 
        SELECT a.campaign_id, b.WF_ID FROM business_process_view_2 a LEFT OUTER JOIN (SELECT CAMPAIGN_ID, MAX(WF_ID) AS WF_ID FROM (SELECT CAMPAIGN_ID, MAX(WF_ID) AS WF_ID FROM wf_temp_transactions WHERE WF_ID IS NOT NULL GROUP BY CAMPAIGN_ID UNION ALL SELECT CAMPAIGN_ID, MAX(WF_ID) AS WF_ID FROM wf_temp_transactions_trash WHERE WF_ID IS NOT NULL GROUP BY CAMPAIGN_ID) T GROUP BY CAMPAIGN_ID) b ON a.campaign_id = b.CAMPAIGN_ID;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;

    SET max_submissionDate = DATE_SUB(NOW(), INTERVAL 7 day);

    OPEN t_cursor;
    
        get_t_data: LOOP
            FETCH t_cursor INTO v_cmp_id, v_max_wf_id;
            IF finished = 1 THEN
                LEAVE get_t_data;
            END IF;

            SET v_max_wf_id_str = CONCAT(v_max_wf_id);

            IF IFNULL(v_max_wf_id,0) = 0 THEN
                SET v_max_wf_id_str = CONCAT('(SELECT IFNULL(MAX(id),0) FROM wfdb.AwsHit WHERE submissionDate < \'',DATE(max_submissionDate),'\')');
            END IF;

            SET sub_str = CONCAT(sub_str, ' (AwsHit.id > ', v_max_wf_id_str , ' AND Run.campaign_id = ', v_cmp_id, ') OR');

        END LOOP get_t_data;

        CLOSE t_cursor;

        IF sub_str <> '' THEN
            SET sub_str = SUBSTRING(sub_str, 1, CHAR_LENGTH(sub_str) - 2);
        END IF;

        RETURN sub_str;
END$$
DELIMITER ;


DROP PROCEDURE IF EXISTS vbrain.t_import_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`t_import_sp`()
BEGIN
        DECLARE lastupdated_wf_id BIGINT(20) DEFAULT 0;
        DECLARE max_submissionDate DATETIME DEFAULT NULL;
        DECLARE mappingIdList VARCHAR(2000) DEFAULT NULL;
        DECLARE w VARCHAR(5000) DEFAULT NULL;

        SELECT MAX(wf_id), MAX(dt) INTO lastupdated_wf_id, max_submissionDate  FROM (SELECT MAX(wf_id) AS wf_id, MAX(END_TIME) AS dt FROM vbrain.wf_temp_transactions UNION ALL SELECT MAX(wf_id) AS wf_id, MAX(END_TIME) AS dt FROM vbrain.wf_temp_transactions_trash) AS t;

        IF max_submissionDate IS NULL THEN
            SET max_submissionDate = DATE_SUB(NOW(), INTERVAL 50 day);
        END IF;

        SELECT GROUP_CONCAT(bp.mapping_id SEPARATOR ',') INTO mappingIdList
        FROM business_process_view_2 bp 
        WHERE bp.isDisabled = 0;

        IF IFNULL(lastupdated_wf_id,0) = 0 THEN
            SET w = CONCAT('AwsHit.id > (SELECT MAX(id) FROM wfdb.AwsHit WHERE submissionDate < \'',DATE(max_submissionDate),'\') AND (Run.status=\'COMPLETED\' OR Run.hasProcessingIssues = 1)');
        ELSE
            SET w = CONCAT('(', t_import_sub_func(), ')', ' AND (Run.status=\'COMPLETED\' OR Run.hasProcessingIssues = 1)');
        END IF;

        IF mappingIdList IS NOT NULL THEN
            SET w = CONCAT(w, ' AND Run.campaignMap_id IN (',mappingIdList,')');
        END IF;
        
        DROP TEMPORARY TABLE IF EXISTS `vbrain`.`t_import_tmp`;

        CREATE TEMPORARY TABLE `vbrain`.`t_import_tmp` (
            QE varchar(1000),
            QT varchar(1)
        ); 

        INSERT INTO t_import_tmp(QE, QT) VALUES 
        ('Run|title|TITLE','S'),
        ('Run|title|DESCRIPTION','S'),
        ('AwsHit|submissionDate|START_TIME','S'),
        ('Run|campaign_id|CAMPAIGN_ID','S'),
        ('Run|rootRunUUID|BP_UUID','S'),
        ('AwsHit|completionDate|END_TIME','S'),
        ('Run|hasProcessingIssues|STATUS','S'),
        ('AwsHit|id|wf_id','S'),
        ('Run','F'),
        ('AwsHit|run_id|=|Run|id','J'),
        (w,'W'),
        ('AwsHit|id|A','O'),
        ('100','L'),
        ('wf_temp_transactions|ii','T');
        
        SELECT * FROM t_import_tmp;

        DROP TEMPORARY TABLE IF EXISTS `vbrain`.`t_import_tmp`;
END$$
DELIMITER ;


-- Promoting failed transactions
DROP PROCEDURE IF EXISTS vbrain.update_transactions_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`update_transactions_sp_2`()
BEGIN
    DECLARE v_start_date varchar(100);
    DECLARE v_bp_id varchar(100);
    DECLARE max_length INTEGER DEFAULT 0;
    DECLARE finished INTEGER DEFAULT 0;
   
    DECLARE datastore_cursor CURSOR FOR 
        SELECT DISTINCT start_date, business_process_id FROM wf_temp_datastore WHERE transaction_id IS NULL ORDER BY start_date;
              
    -- declare NOT FOUND handler
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
 
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;  -- Rollback any changes made in the transaction
        RESIGNAL;  -- Resignal the error to the caller
    END;
   
         OPEN datastore_cursor;
         
         -- Loop through different runs data and link transactions dump with datastore dump
         -- Update 'ds.transaction_id' (foreign key)
         get_datastore_data: LOOP
                 FETCH datastore_cursor INTO v_start_date,v_bp_id;
                 IF finished = 1 THEN 
                        LEAVE get_datastore_data;
                END IF;
                 UPDATE wf_temp_datastore ds 
                        JOIN (
                                SELECT t2.ID AS trans_id, t1.ID AS ds_id
                                FROM (
                                        -- Select wf_temp_datastore rows with row numbers
                                        SELECT tds.ID, @curRow := @curRow + 1 AS row_number
                                      FROM wf_temp_datastore tds
                                         JOIN
                                                 (SELECT @curRow := 0) r -- Row numbers
                                         WHERE tds.start_date = v_start_date AND tds.business_process_id = v_bp_id ORDER BY tds.system_id) t1
                                JOIN (
                                        -- Select ids from temp transactions with row numbers
                                         SELECT tt.ID, @curRow2 := @curRow2 + 1 AS row_number
                                      FROM wf_temp_transactions tt
                                         JOIN
                                                 (SELECT @curRow2 := 0) r -- Row numbers
                                      JOIN business_process_view_2 bp 
                                                 ON tt.campaign_id = bp.campaign_id 
                                          WHERE tt.END_TIME > v_start_date 
                                                 AND bp.business_process_id = v_bp_id 
                                          ORDER BY tt.END_TIME
                                ) t2 ON t1.row_number = t2.row_number
                        ) AS temp
                        ON temp.ds_id = ds.ID
                        SET ds.transaction_id = temp.trans_id;
         END LOOP get_datastore_data;
 
         CLOSE datastore_cursor;

        SELECT CHARACTER_MAXIMUM_LENGTH INTO max_length
        FROM information_schema.columns
        WHERE table_schema = 'vbrain' AND   
              table_name = 'transactions' AND
              COLUMN_NAME = 'ERROR_TYPE';

        -- Select from the dumps, groups, bot in temporary in mamory table
        DROP TEMPORARY TABLE IF EXISTS `vbrain`.`tmp`;
        CREATE TEMPORARY TABLE `vbrain`.`tmp` engine=memory AS        
        SELECT tt.ID AS transaction_id,
                   b.ID AS botid,
                   tt.STATUS AS status,
                   tt.START_TIME AS hit_submissionDate, 
                   tt.END_TIME AS hit_completionDate,
                   IF(tt.STATUS = 1, 'Unkown Error', '') AS exception_type,
                   tt.DESCRIPTION AS stepTitle,
                   bp.country AS country, 
                   tt.BP_UUID AS bp_instance_uuid,
                   bp.function AS function,
                   ds.error_cat AS error_cat,
                   ds.error_msg AS error_msg,
                   ds.tracking_id AS tracking_id,
                   'BOT' AS WORKER_TYPE,
                   0 AS OUT_COME,
                   'vBrain' AS CREATED_BY
                FROM business_process_view_2 bp 
                JOIN bot b ON bp.bp_group_id = b.Process_Id
                INNER JOIN wf_temp_transactions tt ON tt.campaign_id = bp.campaign_id
                JOIN wf_temp_datastore ds ON ds.transaction_id = tt.ID
                WHERE b.ID > 0 AND b.isDisabled = 0;

        INSERT INTO `vbrain`.`tmp`
        SELECT tt.ID AS transaction_id,
                   b.ID AS botid,
                   tt.STATUS AS status,
                   tt.START_TIME AS hit_submissionDate, 
                   tt.END_TIME AS hit_completionDate,
                   IF(tt.STATUS = 1, 'Unkown Error', '') AS exception_type,
                   tt.DESCRIPTION AS stepTitle,
                   bp.country AS country, 
                   tt.BP_UUID AS bp_instance_uuid,
                   bp.function AS function,
                   1 AS error_cat,
                   'This task has processing issues.' AS error_msg,
                   '-' AS tracking_id,
                   'BOT' AS WORKER_TYPE,
                   0 AS OUT_COME,
                   'vBrain' AS CREATED_BY
                FROM business_process_view_2 bp 
                JOIN bot b ON bp.bp_group_id = b.Process_Id
                INNER JOIN wf_temp_transactions tt ON tt.campaign_id = bp.campaign_id
                WHERE b.ID > 0 AND b.isDisabled = 0 
                AND tt.END_TIME IS NULL AND tt.STATUS = 1;

   
        SET autocommit = 0;

        -- Start SQL transaction
        START TRANSACTION;
        -- Promote to transactions from in memory temporary table
         INSERT INTO transactions (WORKER_ID,STATUS,
                                START_TIME,END_TIME,EXCEPTION_TYPE,DESCRIPTION,COUNTRY,BP_UUID,B_FUNCTION,
                                ERROR_CAT, ERROR_TYPE,TRACKING_ID,WORKER_TYPE,OUT_COME,CREATED_BY)
         SELECT botid, status, hit_submissionDate, hit_completionDate, exception_type,
                   stepTitle, country, bp_instance_uuid, function, error_cat,
                   SUBSTRING(error_msg, 1, max_length), tracking_id, WORKER_TYPE, OUT_COME, CREATED_BY
                FROM `vbrain`.`tmp`;
        
        -- Delete (Move to trash) successfully promoted (moved to transactions table) rows 
        -- from temp tables (wf_temp_transactions, wf_temp_datastore)
        INSERT INTO wf_temp_transactions_trash (ID, STATUS, TITLE, BP_NAME, START_TIME, END_TIME, DESCRIPTION, BP_UUID, campaign_id, WF_ID) 
                SELECT ID, STATUS, TITLE, BP_NAME, START_TIME, END_TIME, DESCRIPTION, BP_UUID, campaign_id, WF_ID FROM wf_temp_transactions 
                WHERE ID IN (SELECT transaction_id FROM tmp);
        
        INSERT INTO wf_temp_datastore_trash (ID, name, transaction_id, error_cat, start_date, system_id, error_msg, tracking_id, business_process_id, wf_id) 
                SELECT ID, name, transaction_id, error_cat, start_date, system_id, error_msg, tracking_id, business_process_id, wf_id FROM wf_temp_datastore 
                WHERE transaction_id IN (SELECT transaction_id FROM tmp);
        
        DELETE FROM wf_temp_datastore WHERE transaction_id IN (SELECT transaction_id FROM tmp);
        DELETE FROM wf_temp_transactions WHERE ID IN (SELECT transaction_id FROM tmp);
        
        COMMIT;
        -- End SQL transaction 
        SET autocommit = 1;

        DROP TEMPORARY TABLE IF EXISTS `vbrain`.`tmp`;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS vbrain.wf_query_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`wf_query_sp_2`(IN params VARCHAR(1000))
BEGIN
    DECLARE t VARCHAR(100);
    DECLARE value VARCHAR(1000);
    DECLARE o VARCHAR(100) DEFAULT NULL;
    DECLARE front TEXT DEFAULT NULL;
    DECLARE frontlen INT DEFAULT NULL;
    DECLARE TempValue TEXT DEFAULT NULL;

    SET t = SPLIT_STR(params,'$^',1);
    SET value = SPLIT_STR(params,'$^',2);
    SET o = SPLIT_STR(params,'$^',3);

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`wf_query_tmp`;

    CREATE TEMPORARY TABLE `vbrain`.`wf_query_tmp` (
        QE varchar(1000),
        QT varchar(1)
    ); 
 
    iterator: LOOP  
        IF LENGTH(TRIM(value)) = 0 OR value IS NULL THEN
            LEAVE iterator;
        END IF;
        SET front = SUBSTRING_INDEX(Value,'$$',1);
        SET frontlen = LENGTH(front);
        SET TempValue = TRIM(front);
           
        IF SPLIT_STR(TempValue,'$=',2) IS NULL THEN
            INSERT INTO wf_query_tmp(QE, QT) VALUES 
            (CONCAT('|',TempValue,'|',TempValue),'S');
        ELSE
            INSERT INTO wf_query_tmp(QE, QT) VALUES 
            (CONCAT('|',SPLIT_STR(TempValue,'$=',1),'|',SPLIT_STR(TempValue,'$=',2)),'S');
        END IF;
       
        SET value = INSERT(value,1,frontlen + 2,'');
    END LOOP;

    INSERT INTO wf_query_tmp(QE, QT) VALUES 
    (t,'F');
    
    IF o IS NOT NULL THEN
        INSERT INTO wf_query_tmp(QE, QT) VALUES 
        (CONCAT('|',SPLIT_STR(o,',',1),'|',IFNULL(SPLIT_STR(o,',',2),'A')),'O');
    END IF;

    INSERT INTO wf_query_tmp(QE, QT) VALUES 
    ('10','L');
    
    SELECT * FROM wf_query_tmp;

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`wf_query_tmp`;
END$$
DELIMITER ;



DROP PROCEDURE IF EXISTS vbrain.add_wf_business_process_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`add_wf_business_process_sp_2`(IN p_display_name VARCHAR(100), IN p_mapped_datastores VARCHAR(500), 
    IN p_tracking_id_field VARCHAR(200), IN p_error_msg_field VARCHAR(200), 
    IN p_system_id_field VARCHAR(200), IN p_start_date_field VARCHAR(200), 
    IN p_start_date_postgre_format VARCHAR(50), IN p_start_date_convert_format VARCHAR(50))
BEGIN
    DECLARE max_query_order INT(11) DEFAULT 0;
    DECLARE display_name_exists TINYINT(1) DEFAULT 0;

    SELECT COUNT(display_name)>0 INTO display_name_exists 
    FROM wf_business_process WHERE display_name = p_display_name;

    IF display_name_exists = 0 THEN
        SELECT MAX(query_order) INTO max_query_order FROM wf_business_process;
        
        INSERT INTO wf_business_process(display_name, mapped_datastores, tracking_id_field, error_msg_field, 
            system_id_field, start_date_field, start_date_postgre_format, start_date_convert_format, query_order)
        VALUES(p_display_name, p_mapped_datastores, p_tracking_id_field, p_error_msg_field, 
            p_system_id_field, p_start_date_field, p_start_date_postgre_format, p_start_date_convert_format, max_query_order+1);
        
        SELECT 'Business Process added successfully' AS message;
    ELSE
        SELECT 'Business Process already exists' AS message;
    END IF;
END$$
DELIMITER ;



-- C import
DROP PROCEDURE IF EXISTS vbrain.c_import_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`c_import_sp_2`()
BEGIN
    DECLARE bp_last_updated_date VARCHAR(50);
    DECLARE s_last_updated_date VARCHAR(50);
    DECLARE w VARCHAR(5000) DEFAULT NULL;

    SELECT IFNULL(MAX(bp_lastmodified), FROM_UNIXTIME(0)), IFNULL(MAX(step_lastmodified), FROM_UNIXTIME(0)) INTO bp_last_updated_date, s_last_updated_date FROM wf_campaign;
    
    SET w = CONCAT('s.lastModified > \'',s_last_updated_date,'\' OR bp.lastModified > \'',bp_last_updated_date, '\'');

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`c_import_tmp`;

    CREATE TEMPORARY TABLE `vbrain`.`c_import_tmp` (
        QE varchar(1000),
        QT varchar(1)
    ); 

    INSERT INTO c_import_tmp(QE, QT) VALUES 
    ('cm|id|mapping_id','S'),
    ('cm|deleted|deleted','S'),
    ('cm|stepIndex|step_index','S'),
    ('bp|id|campaign_id','S'),
    ('bp|title|bp_name','S'),
    ('bp|lastModified|bp_lastmodified','S'),
    ('s|id|step_id','S'),
    ('s|title|step_title','S'),
    ('s|lastModified|step_lastmodified','S'),
    ('CampaignMap cm','F'),
    ('Campaign s|id|=|cm|campaign','J'),
    ('Campaign bp|id|=|cm|parent','J'),
    (w,'W'),
    ('bp|lastModified|A','O'),
    ('s|lastModified|A','O'),
    ('100','L'),
    ('wf_campaign|ii','T');
    
    SELECT * FROM c_import_tmp;

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`c_import_tmp`;
END$$
DELIMITER ;


DROP PROCEDURE IF EXISTS vbrain.import_details_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`import_details_sp`()
BEGIN
    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`import_details_tmp`;

    CREATE TEMPORARY TABLE `vbrain`.`import_details_tmp` (
        entity varchar(1),
        import varchar(100),
        importParamValues varchar(100),
        post varchar(100),
        postParamValues varchar(100)
    ); 

    INSERT INTO import_details_tmp(entity, import, importParamValues, post, postParamValues) VALUES 
    ('T','t_import_sp',NULL,NULL,NULL),
    ('D','ds_import_sp',NULL,'wf_temp_datastore_massage_sp',NULL),
    ('C','c_import_sp_2',NULL,NULL,NULL);
    
    SELECT * FROM import_details_tmp;

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`import_details_tmp`;
END$$
DELIMITER ;
