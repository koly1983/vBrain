-- MySQL dump 10.13  Distrib 5.7.23, for Linux (x86_64)
--
-- Host: localhost    Database: vbrain
-- ------------------------------------------------------
-- Server version	5.7.23-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bot`
--

DROP TABLE IF EXISTS `bot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bot` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Bot_Key` varchar(45) DEFAULT NULL,
  `Provider` varchar(45) DEFAULT NULL,
  `Host_Name` varchar(45) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `Process_Id` int(11) DEFAULT NULL,
  `isDisabled` int(11) DEFAULT '0',
  `avgEfforts` varchar(45) DEFAULT NULL,
  `avgCost` varchar(45) DEFAULT NULL,
  `cycleTime` varchar(45) DEFAULT NULL,
  `noOftransactions` varchar(45) DEFAULT NULL,
  `status` varchar(2) DEFAULT '0',
  `avgEffortsSaved` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `functions`
--

DROP TABLE IF EXISTS `functions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `functions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Category` varchar(100) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `group_bot_view`
--

DROP TABLE IF EXISTS `group_bot_view`;
/*!50001 DROP VIEW IF EXISTS `group_bot_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `group_bot_view` AS SELECT 
 1 AS `id`,
 1 AS `botKey`,
 1 AS `provider`,
 1 AS `description`,
 1 AS `processId`,
 1 AS `status`,
 1 AS `processName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `group_incidents_view`
--

DROP TABLE IF EXISTS `group_incidents_view`;
/*!50001 DROP VIEW IF EXISTS `group_incidents_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `group_incidents_view` AS SELECT 
 1 AS `ticket_id`,
 1 AS `status`,
 1 AS `transaction_id`,
 1 AS `process_id`,
 1 AS `process_name`,
 1 AS `start_time`,
 1 AS `end_time`,
 1 AS `country`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `group_sla_view`
--

DROP TABLE IF EXISTS `group_sla_view`;
/*!50001 DROP VIEW IF EXISTS `group_sla_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `group_sla_view` AS SELECT 
 1 AS `transaction_id`,
 1 AS `sla`,
 1 AS `process_id`,
 1 AS `process_name`,
 1 AS `worker_status`,
 1 AS `start_time`,
 1 AS `end_time`,
 1 AS `country`,
 1 AS `Duration`,
 1 AS `worker`,
 1 AS `worker_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `group_transaction_view`
--

DROP TABLE IF EXISTS `group_transaction_view`;
/*!50001 DROP VIEW IF EXISTS `group_transaction_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `group_transaction_view` AS SELECT 
 1 AS `transaction_id`,
 1 AS `worker_id`,
 1 AS `worker_status`,
 1 AS `process_id`,
 1 AS `process_name`,
 1 AS `start_time`,
 1 AS `end_time`,
 1 AS `duration`,
 1 AS `efforts_saved`,
 1 AS `status`,
 1 AS `worker_type`,
 1 AS `out_come`,
 1 AS `description`,
 1 AS `tracking_id`,
 1 AS `country`,
 1 AS `function`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `group_users`
--

DROP TABLE IF EXISTS `group_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Group_Id` int(11) DEFAULT NULL,
  `User_Id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Description` varchar(300) DEFAULT NULL,
  `Type` varchar(45) DEFAULT NULL,
  `Parent_Id` int(11) DEFAULT NULL,
  `Parent_Group_Id` int(11) DEFAULT NULL,
  `isDisabled` int(11) DEFAULT '0',
  `Created_By` varchar(45) DEFAULT NULL,
  `Created_Date` timestamp NULL DEFAULT NULL,
  `Updated_By` varchar(45) DEFAULT NULL,
  `Updated_Date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=338 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `groups_old`
--

DROP TABLE IF EXISTS `groups_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups_old` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Description` varchar(300) DEFAULT NULL,
  `Type` varchar(45) DEFAULT NULL,
  `Parent_Id` int(11) DEFAULT NULL,
  `Parent_Group_Id` int(11) DEFAULT NULL,
  `isDisabled` int(11) DEFAULT '0',
  `Created_By` varchar(45) DEFAULT NULL,
  `Created_Date` timestamp NULL DEFAULT NULL,
  `Updated_By` varchar(45) DEFAULT NULL,
  `Updated_Date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `human_worker`
--

DROP TABLE IF EXISTS `human_worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `human_worker` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Worker_Id` varchar(45) DEFAULT NULL,
  `Name` varchar(60) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `Process_Id` int(11) DEFAULT NULL,
  `isDisabled` int(11) DEFAULT '0',
  `avgEfforts` varchar(45) DEFAULT NULL,
  `avgCost` varchar(45) DEFAULT NULL,
  `cycleTime` varchar(45) DEFAULT NULL,
  `noOftransactions` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `incidents_view`
--

DROP TABLE IF EXISTS `incidents_view`;
/*!50001 DROP VIEW IF EXISTS `incidents_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `incidents_view` AS SELECT 
 1 AS `ticket_id`,
 1 AS `status`,
 1 AS `description`,
 1 AS `process_id`,
 1 AS `process_name`,
 1 AS `SLA`,
 1 AS `effort_saved`,
 1 AS `sequence`,
 1 AS `geography`,
 1 AS `region`,
 1 AS `start_time`,
 1 AS `end_time`,
 1 AS `Duration`,
 1 AS `worker`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `privilage`
--

DROP TABLE IF EXISTS `privilage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privilage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Function_Id` int(11) DEFAULT NULL,
  `Role_Id` int(11) DEFAULT NULL,
  `access` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `isDisabled` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequence_temp`
--

DROP TABLE IF EXISTS `sequence_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequence_temp` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Process_Name` varchar(100) DEFAULT NULL,
  `sequence` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `sla_view`
--

DROP TABLE IF EXISTS `sla_view`;
/*!50001 DROP VIEW IF EXISTS `sla_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `sla_view` AS SELECT 
 1 AS `sla`,
 1 AS `process_name`,
 1 AS `process_id`,
 1 AS `effort_saved`,
 1 AS `sequence`,
 1 AS `geography`,
 1 AS `region`,
 1 AS `start_time`,
 1 AS `end_time`,
 1 AS `Duration`,
 1 AS `worker`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `WORKER_ID` int(11) DEFAULT '0',
  `WORKER_TYPE` varchar(50) DEFAULT NULL,
  `STATUS` varchar(50) DEFAULT NULL,
  `START_TIME` datetime DEFAULT NULL,
  `END_TIME` datetime DEFAULT NULL,
  `DURATION` varchar(10) DEFAULT NULL,
  `OUT_COME` varchar(50) DEFAULT NULL,
  `EXCEPTION_TYPE` varchar(200) DEFAULT NULL,
  `DESCRIPTION` varchar(400) DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `CREATED_DATE` varchar(50) DEFAULT NULL,
  `TRACKING_ID` varchar(45) DEFAULT NULL,
  `COUNTRY` varchar(100) DEFAULT NULL,
  `B_FUNCTION` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3205 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `transation_view`
--

DROP TABLE IF EXISTS `transation_view`;
/*!50001 DROP VIEW IF EXISTS `transation_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `transation_view` AS SELECT 
 1 AS `bot_key`,
 1 AS `process_id`,
 1 AS `process_name`,
 1 AS `SLA`,
 1 AS `effort_saved`,
 1 AS `sequence`,
 1 AS `geography`,
 1 AS `region`,
 1 AS `start_time`,
 1 AS `end_time`,
 1 AS `Duration`,
 1 AS `status`,
 1 AS `worker`,
 1 AS `out_come`,
 1 AS `description`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_Id` varchar(50) NOT NULL,
  `First_Name` varchar(50) DEFAULT NULL,
  `Sur_Name` varchar(45) DEFAULT '',
  `Last_Name` varchar(45) DEFAULT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `Role_Id` int(11) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `isDisabled` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`),
  UNIQUE KEY `User_Id_UNIQUE` (`User_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vbrain_audit`
--

DROP TABLE IF EXISTS `vbrain_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_audit` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AUDIT_TYPE` varchar(20) DEFAULT NULL,
  `AUDIT_TYPE_INSTANCE_ID` varchar(20) DEFAULT NULL,
  `DESCRIPTION` varchar(200) DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `UPDATED_BY` varchar(50) DEFAULT NULL,
  `UPDATED_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vbrain_bot`
--

DROP TABLE IF EXISTS `vbrain_bot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_bot` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BOT_KEY` varchar(50) NOT NULL,
  `BOT_PROVIDER` varchar(50) DEFAULT NULL,
  `IP_ADDRESS` varchar(20) NOT NULL,
  `API_URL` varchar(200) DEFAULT NULL,
  `STATUS` varchar(20) NOT NULL,
  `REGISTRATION_DATE` datetime DEFAULT NULL,
  `DESCRIPTION` varchar(400) DEFAULT NULL,
  `LAST_PING_DATE` datetime DEFAULT NULL,
  `LAST_PING_STATUS` varchar(20) NOT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `UPDATED_BY` varchar(50) DEFAULT NULL,
  `UPDATED_DATE` datetime DEFAULT NULL,
  `GEO_ID` int(11) DEFAULT NULL,
  `PROCESS_ID` int(11) DEFAULT NULL,
  `TRANSACTIONS` int(11) DEFAULT '0',
  `TYPE` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `vbrain_bot_geo_id_idx` (`GEO_ID`),
  KEY `vbrain_bot_process_id_idx` (`PROCESS_ID`),
  CONSTRAINT `vbrain_bot_geo_id` FOREIGN KEY (`GEO_ID`) REFERENCES `vbrain_geo` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `vbrain_bot_process_id` FOREIGN KEY (`PROCESS_ID`) REFERENCES `vbrain_process` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vbrain_bot_config`
--

DROP TABLE IF EXISTS `vbrain_bot_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_bot_config` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BOT_ID` int(11) NOT NULL,
  `CONFIG_PARAM` varchar(10) DEFAULT NULL,
  `CONFIG_VALUE` varchar(50) DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `UPDATED_BY` varchar(50) DEFAULT NULL,
  `UPDATED_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `BOT_ID` (`BOT_ID`),
  CONSTRAINT `vbrain_bot_config_ibfk_1` FOREIGN KEY (`BOT_ID`) REFERENCES `vbrain_bot` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vbrain_bot_geo_mapping`
--

DROP TABLE IF EXISTS `vbrain_bot_geo_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_bot_geo_mapping` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BOT_ID` int(11) DEFAULT NULL,
  `PROCESS_ID` int(11) DEFAULT NULL,
  `GEO_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `vbrain_gio2_idx` (`GEO_ID`),
  KEY `vbrain_bot2_idx` (`BOT_ID`),
  KEY `vbrain_process2_idx` (`PROCESS_ID`),
  CONSTRAINT `vbrain_bot2` FOREIGN KEY (`BOT_ID`) REFERENCES `vbrain_bot` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `vbrain_gio2` FOREIGN KEY (`GEO_ID`) REFERENCES `vbrain_geo` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `vbrain_process2` FOREIGN KEY (`PROCESS_ID`) REFERENCES `vbrain_process` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vbrain_business_app`
--

DROP TABLE IF EXISTS `vbrain_business_app`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_business_app` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BUSINESS_APP_NAME` varchar(100) DEFAULT NULL,
  `DESCRIPTION` varchar(200) DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `UPDATED_BY` varchar(50) DEFAULT NULL,
  `UPDATED_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vbrain_geo`
--

DROP TABLE IF EXISTS `vbrain_geo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_geo` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GEOGRAPHY` varchar(45) DEFAULT NULL,
  `REGION` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vbrain_incidents`
--

DROP TABLE IF EXISTS `vbrain_incidents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_incidents` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TRANSACTION_ID` int(11) NOT NULL,
  `BOT_ID` int(11) NOT NULL,
  `TICKET_ID` varchar(20) NOT NULL,
  `STATUS` varchar(45) DEFAULT NULL,
  `DESCRIPTION` varchar(200) DEFAULT NULL,
  `CLOSED_BY` varchar(50) DEFAULT NULL,
  `CLOSING_DATE` datetime DEFAULT NULL,
  `CLOSING_COMMETNS` varchar(200) DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `UPDATED_BY` varchar(50) DEFAULT NULL,
  `UPDATED_DATE` datetime DEFAULT NULL,
  `TRACKING_ID` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3005 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vbrain_process`
--

DROP TABLE IF EXISTS `vbrain_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_process` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `WORKER` varchar(50) NOT NULL,
  `BUSINESS_APP_ID` int(11) NOT NULL,
  `PROCESS_NAME` varchar(100) DEFAULT NULL,
  `DESCRIPTION` varchar(200) DEFAULT NULL,
  `FUNCTION` int(11) DEFAULT NULL,
  `EFFORT_SAVED` varchar(10) NOT NULL,
  `PARENT_PROCESS_ID` int(11) NOT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `UPDATED_BY` varchar(50) DEFAULT NULL,
  `UPDATED_DATE` datetime DEFAULT NULL,
  `SLA` int(11) DEFAULT '0',
  `SEQUENCE` int(11) DEFAULT NULL,
  `GEO_ID` int(11) DEFAULT NULL,
  `IS_BOT_TYPE` int(11) DEFAULT NULL,
  `IS_HUMAN_TYPE` int(11) DEFAULT NULL,
  `IS_STP_TYPE` int(11) DEFAULT NULL,
  `BOT_EFFORT` int(11) DEFAULT NULL,
  `HUMAN_EFFORT` int(11) DEFAULT NULL,
  `STP_EFFORT` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vbrain_sla`
--

DROP TABLE IF EXISTS `vbrain_sla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_sla` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PROCESS_ID` int(11) DEFAULT NULL,
  `WORKER` varchar(45) DEFAULT NULL,
  `SLA` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vbrain_transaction`
--

DROP TABLE IF EXISTS `vbrain_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_transaction` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BOT_ID` int(11) DEFAULT '0',
  `BUSINESS_APP_NAME` varchar(50) DEFAULT NULL,
  `WORKER` varchar(50) DEFAULT NULL,
  `STATUS` varchar(50) DEFAULT NULL,
  `START_TIME` datetime DEFAULT NULL,
  `END_TIME` datetime DEFAULT NULL,
  `DURATION` varchar(10) DEFAULT NULL,
  `OUT_COME` varchar(50) DEFAULT NULL,
  `EXCEPTION_TYPE` varchar(200) DEFAULT NULL,
  `DESCRIPTION` varchar(200) DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `CREATED_DATE` varchar(50) DEFAULT NULL,
  `TRACKING_ID` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Final view structure for view `group_bot_view`
--

/*!50001 DROP VIEW IF EXISTS `group_bot_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `group_bot_view` AS select `b`.`ID` AS `id`,`b`.`Bot_Key` AS `botKey`,`b`.`Provider` AS `provider`,`b`.`Description` AS `description`,`b`.`Process_Id` AS `processId`,`b`.`status` AS `status`,`g`.`Name` AS `processName` from (`bot` `b` join `groups` `g`) where ((`g`.`ID` = `b`.`Process_Id`) and (`b`.`isDisabled` = '0')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `group_incidents_view`
--

/*!50001 DROP VIEW IF EXISTS `group_incidents_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `group_incidents_view` AS select `vi`.`TICKET_ID` AS `ticket_id`,`vi`.`STATUS` AS `status`,`vt`.`ID` AS `transaction_id`,(case when (`vt`.`WORKER_TYPE` = 'BOT') then (select `bot`.`Process_Id` from `bot` where ((`bot`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`Process_Id` from `human_worker` where ((`human_worker`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'HUMAN'))) end) AS `process_id`,(case when (`vt`.`WORKER_TYPE` = 'BOT') then (select `groups`.`Name` from `groups` where (`groups`.`ID` = (select `bot`.`Process_Id` from `bot` where ((`bot`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'BOT'))))) else (select `groups`.`Name` from `groups` where (`groups`.`ID` = (select `human_worker`.`Process_Id` from `human_worker` where ((`human_worker`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'HUMAN'))))) end) AS `process_name`,`vt`.`START_TIME` AS `start_time`,`vt`.`END_TIME` AS `end_time`,`vt`.`COUNTRY` AS `country` from (`vbrain_incidents` `vi` join `transactions` `vt`) where (`vt`.`ID` = `vi`.`TRANSACTION_ID`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `group_sla_view`
--

/*!50001 DROP VIEW IF EXISTS `group_sla_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `group_sla_view` AS select `vt`.`ID` AS `transaction_id`,(case when (`vt`.`WORKER_TYPE` = 'BOT') then (select `bot`.`avgEfforts` from `bot` where ((`bot`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`avgEfforts` from `human_worker` where ((`human_worker`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'HUMAN'))) end) AS `sla`,(case when (`vt`.`WORKER_TYPE` = 'BOT') then (select `bot`.`Process_Id` from `bot` where ((`bot`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`Process_Id` from `human_worker` where ((`human_worker`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'HUMAN'))) end) AS `process_id`,(case when (`vt`.`WORKER_TYPE` = 'BOT') then (select `groups`.`Name` from `groups` where (`groups`.`ID` = (select `bot`.`Process_Id` from `bot` where ((`bot`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'BOT'))))) else (select `groups`.`Name` from `groups` where (`groups`.`ID` = (select `human_worker`.`Process_Id` from `human_worker` where ((`human_worker`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'HUMAN'))))) end) AS `process_name`,(case when (`vt`.`WORKER_TYPE` = 'BOT') then (select `bot`.`isDisabled` from `bot` where ((`bot`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`isDisabled` from `human_worker` where ((`human_worker`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'HUMAN'))) end) AS `worker_status`,`vt`.`START_TIME` AS `start_time`,`vt`.`END_TIME` AS `end_time`,`vt`.`COUNTRY` AS `country`,timestampdiff(MINUTE,`vt`.`START_TIME`,`vt`.`END_TIME`) AS `Duration`,`vt`.`WORKER_TYPE` AS `worker`,`vt`.`WORKER_ID` AS `worker_id` from `transactions` `vt` where (`vt`.`STATUS` = '0') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `group_transaction_view`
--

/*!50001 DROP VIEW IF EXISTS `group_transaction_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `group_transaction_view` AS select `transactions`.`ID` AS `transaction_id`,(case when (`transactions`.`WORKER_TYPE` = 'BOT') then (select `bot`.`Bot_Key` from `bot` where ((`bot`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`Worker_Id` from `human_worker` where ((`human_worker`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'HUMAN'))) end) AS `worker_id`,(case when (`transactions`.`WORKER_TYPE` = 'BOT') then (select `bot`.`isDisabled` from `bot` where ((`bot`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`isDisabled` from `human_worker` where ((`human_worker`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'HUMAN'))) end) AS `worker_status`,(case when (`transactions`.`WORKER_TYPE` = 'BOT') then (select `bot`.`Process_Id` from `bot` where ((`bot`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`Process_Id` from `human_worker` where ((`human_worker`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'HUMAN'))) end) AS `process_id`,(case when (`transactions`.`WORKER_TYPE` = 'BOT') then (select `groups`.`Name` from `groups` where (`groups`.`ID` = (select `bot`.`Process_Id` from `bot` where ((`bot`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'BOT'))))) else (select `groups`.`Name` from `groups` where (`groups`.`ID` = (select `human_worker`.`Process_Id` from `human_worker` where ((`human_worker`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'HUMAN'))))) end) AS `process_name`,`transactions`.`START_TIME` AS `start_time`,`transactions`.`END_TIME` AS `end_time`,timestampdiff(MINUTE,`transactions`.`START_TIME`,`transactions`.`END_TIME`) AS `duration`,(select `bot`.`avgEffortsSaved` from `bot` where ((`bot`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'BOT'))) AS `efforts_saved`,`transactions`.`STATUS` AS `status`,`transactions`.`WORKER_TYPE` AS `worker_type`,`transactions`.`OUT_COME` AS `out_come`,`transactions`.`DESCRIPTION` AS `description`,`transactions`.`TRACKING_ID` AS `tracking_id`,`transactions`.`COUNTRY` AS `country`,`transactions`.`B_FUNCTION` AS `function` from `transactions` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `incidents_view`
--

/*!50001 DROP VIEW IF EXISTS `incidents_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `incidents_view` AS select `vi`.`TICKET_ID` AS `ticket_id`,`vi`.`STATUS` AS `status`,`vi`.`DESCRIPTION` AS `description`,`vp`.`ID` AS `process_id`,`vp`.`PROCESS_NAME` AS `process_name`,`vp`.`SLA` AS `SLA`,`vp`.`EFFORT_SAVED` AS `effort_saved`,`vp`.`SEQUENCE` AS `sequence`,`vg`.`GEOGRAPHY` AS `geography`,`vg`.`REGION` AS `region`,`vt`.`START_TIME` AS `start_time`,`vt`.`END_TIME` AS `end_time`,timestampdiff(MINUTE,`vt`.`START_TIME`,`vt`.`END_TIME`) AS `Duration`,`vt`.`WORKER` AS `worker` from ((((`vbrain_incidents` `vi` join `vbrain_process` `vp`) join `vbrain_transaction` `vt`) join `vbrain_geo` `vg`) join `vbrain_bot` `vb`) where ((`vb`.`ID` = `vt`.`BOT_ID`) and (`vb`.`PROCESS_ID` = `vp`.`ID`) and (`vg`.`ID` = `vb`.`GEO_ID`) and (`vt`.`ID` = `vi`.`TRANSACTION_ID`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `sla_view`
--

/*!50001 DROP VIEW IF EXISTS `sla_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `sla_view` AS select `vs`.`SLA` AS `sla`,`vp`.`PROCESS_NAME` AS `process_name`,`vp`.`ID` AS `process_id`,`vp`.`EFFORT_SAVED` AS `effort_saved`,`vp`.`SEQUENCE` AS `sequence`,`vg`.`GEOGRAPHY` AS `geography`,`vg`.`REGION` AS `region`,`vt`.`START_TIME` AS `start_time`,`vt`.`END_TIME` AS `end_time`,timestampdiff(MINUTE,`vt`.`START_TIME`,`vt`.`END_TIME`) AS `Duration`,`vt`.`WORKER` AS `worker` from ((((`vbrain_sla` `vs` join `vbrain_process` `vp`) join `vbrain_transaction` `vt`) join `vbrain_geo` `vg`) join `vbrain_bot` `vb`) where ((`vb`.`ID` = `vt`.`BOT_ID`) and (`vb`.`PROCESS_ID` = `vp`.`ID`) and (`vg`.`ID` = `vb`.`GEO_ID`) and (`vs`.`PROCESS_ID` = `vb`.`PROCESS_ID`)) group by `vt`.`ID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `transation_view`
--

/*!50001 DROP VIEW IF EXISTS `transation_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `transation_view` AS select `vb`.`BOT_KEY` AS `bot_key`,`vp`.`ID` AS `process_id`,`vp`.`PROCESS_NAME` AS `process_name`,`vp`.`SLA` AS `SLA`,`vp`.`EFFORT_SAVED` AS `effort_saved`,`vp`.`SEQUENCE` AS `sequence`,`vg`.`GEOGRAPHY` AS `geography`,`vg`.`REGION` AS `region`,`vt`.`START_TIME` AS `start_time`,`vt`.`END_TIME` AS `end_time`,timestampdiff(MINUTE,`vt`.`START_TIME`,`vt`.`END_TIME`) AS `Duration`,`vt`.`STATUS` AS `status`,`vt`.`WORKER` AS `worker`,`vt`.`OUT_COME` AS `out_come`,`vt`.`DESCRIPTION` AS `description` from (((`vbrain_bot` `vb` join `vbrain_process` `vp`) join `vbrain_transaction` `vt`) join `vbrain_geo` `vg`) where ((`vb`.`ID` = `vt`.`BOT_ID`) and (`vb`.`PROCESS_ID` = `vp`.`ID`) and (`vg`.`ID` = `vb`.`GEO_ID`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-15  4:24:49
