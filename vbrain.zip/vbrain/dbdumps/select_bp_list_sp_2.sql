DROP PROCEDURE IF EXISTS vbrain.select_bp_list_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`select_bp_list_sp_2`(IN include_group_id INT(11))
BEGIN
	IF include_group_id IS NOT NULL OR include_group_id > 0 THEN
		SELECT id, display_name 
		FROM wf_business_process 
		WHERE mapped_datastores IS NOT NULL AND tracking_id_field IS NOT NULL AND error_msg_field IS NOT NULL
			AND (mapping_id IS NULL OR group_process_id = include_group_id) 
		ORDER BY display_name;
	ELSE 
		SELECT id, display_name 
		FROM wf_business_process 
		WHERE mapped_datastores IS NOT NULL AND tracking_id_field IS NOT NULL AND error_msg_field IS NOT NULL
			AND mapping_id IS NULL
		ORDER BY display_name;
	END IF;
END$$
DELIMITER ;
