ALTER TABLE `vbrain`.`transactions`
ADD `ERROR_TYPE` VARCHAR(400); 

ALTER TABLE `vbrain`.`transactions`
ADD `BP_UUID` VARCHAR(45);

ALTER TABLE `vbrain`.`wf_temp_transactions`
ADD `BP_UUID` VARCHAR(45);

ALTER TABLE `vbrain`.`transactions` 
ADD COLUMN `POSTGRES_UPDATED` TINYINT 0 AFTER `ERROR_TYPE`;

CREATE TABLE `exceptions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Lob` varchar(300) DEFAULT NULL,
  `Exception_Type` varchar(300) DEFAULT NULL,
  `Exception_Value` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `vbrain`.`transactions` 
ADD COLUMN `ERROR_CAT` INT(11) NULL AFTER `ERROR_TYPE`;

ALTER VIEW `group_transaction_view` AS select `transactions`.`ID` AS `transaction_id`,(case when (`transactions`.`WORKER_TYPE` = 'BOT') then (select `bot`.`Bot_Key` from `bot` where ((`bot`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`Worker_Id` from `human_worker` where ((`human_worker`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'HUMAN'))) end) AS `worker_id`,(case when (`transactions`.`WORKER_TYPE` = 'BOT') then (select `bot`.`isDisabled` from `bot` where ((`bot`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`isDisabled` from `human_worker` where ((`human_worker`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'HUMAN'))) end) AS `worker_status`,(case when (`transactions`.`WORKER_TYPE` = 'BOT') then (select `bot`.`Process_Id` from `bot` where ((`bot`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`Process_Id` from `human_worker` where ((`human_worker`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'HUMAN'))) end) AS `process_id`,(case when (`transactions`.`WORKER_TYPE` = 'BOT') then (select `groups`.`Name` from `groups` where (`groups`.`ID` = (select `bot`.`Process_Id` from `bot` where ((`bot`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'BOT'))))) else (select `groups`.`Name` from `groups` where (`groups`.`ID` = (select `human_worker`.`Process_Id` from `human_worker` where ((`human_worker`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'HUMAN'))))) end) AS `process_name`,`transactions`.`START_TIME` AS `start_time`,`transactions`.`END_TIME` AS `end_time`,timestampdiff(MINUTE,`transactions`.`START_TIME`,`transactions`.`END_TIME`) AS `duration`,(select `bot`.`avgEffortsSaved` from `bot` where ((`bot`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'BOT'))) AS `efforts_saved`,`transactions`.`STATUS` AS `status`,`transactions`.`WORKER_TYPE` AS `worker_type`,`transactions`.`OUT_COME` AS `out_come`,`transactions`.`DESCRIPTION` AS `description`,`transactions`.`TRACKING_ID` AS `tracking_id`,`transactions`.`COUNTRY` AS `country`,`transactions`.`B_FUNCTION` AS `function`,`transactions`.`ERROR_TYPE` AS `error_type`,`transactions`.`ERROR_CAT` AS `error_cat`,`transactions`.`BP_UUID` AS `bp_uuid` from `transactions`;
