DROP PROCEDURE IF EXISTS vbrain.update_bp_mapping_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`update_bp_mapping_sp`(IN p_bp_id INT(11), IN p_mapping_id BIGINT(20), IN p_group_process_id INT(11))
BEGIN
	UPDATE wf_business_process SET group_process_id = p_group_process_id, mapping_id = p_mapping_id WHERE id = p_bp_id;
END$$
DELIMITER ;
