DROP PROCEDURE IF EXISTS vbrain.add_wf_business_process_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`add_wf_business_process_sp_2`(IN p_display_name VARCHAR(100), IN p_mapped_datastores VARCHAR(500), 
    IN p_tracking_id_field VARCHAR(200), IN p_error_msg_field VARCHAR(200), 
    IN p_system_id_field VARCHAR(200), IN p_start_date_field VARCHAR(200), IN p_bp_uuid_field VARCHAR(200),
    IN p_start_date_postgre_format VARCHAR(50), IN p_start_date_convert_format VARCHAR(50), IN p_id_order_field varchar(200))
BEGIN
    DECLARE max_query_order INT(11) DEFAULT 0;
    DECLARE display_name_exists TINYINT(1) DEFAULT 0;

    SELECT COUNT(display_name)>0 INTO display_name_exists 
    FROM wf_business_process WHERE display_name = p_display_name;

    IF display_name_exists = 0 THEN
		IF p_bp_uuid_field = '' THEN
			SET p_bp_uuid_field = NULL;
		END IF;
		
		IF p_id_order_field = '' THEN
			SET p_id_order_field = NULL;
		END IF;
		
        SELECT MAX(query_order) INTO max_query_order FROM wf_business_process;
        
        INSERT INTO wf_business_process(display_name, mapped_datastores, tracking_id_field, error_msg_field, 
            system_id_field, start_date_field, bp_uuid_field, start_date_postgre_format, start_date_convert_format, query_order, id_order_field)
        VALUES(p_display_name, p_mapped_datastores, p_tracking_id_field, p_error_msg_field, 
            p_system_id_field, p_start_date_field, p_bp_uuid_field, p_start_date_postgre_format, p_start_date_convert_format, max_query_order+1, p_id_order_field);
        
        SELECT 'Business Process added successfully' AS message;
    ELSE
        SELECT 'Business Process already exists' AS message;
    END IF;
END$$
DELIMITER ;