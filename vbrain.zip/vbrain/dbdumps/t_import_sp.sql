DROP PROCEDURE IF EXISTS vbrain.t_import_sp;
    
DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `t_import_sp`()
BEGIN
        DECLARE lastupdated_wf_id BIGINT(20) DEFAULT 0;
        DECLARE max_submissionDate DATETIME DEFAULT NULL;
        DECLARE min_submissionDate DATETIME DEFAULT NULL;        
        DECLARE mappingIdList VARCHAR(2000) DEFAULT NULL;
        DECLARE w VARCHAR(5000) DEFAULT NULL;

        SET min_submissionDate = DATE_SUB(NOW(), INTERVAL 15 day);
        
        SELECT MAX(wf_id), MAX(dt) INTO lastupdated_wf_id, max_submissionDate FROM (SELECT MAX(wf_id) AS wf_id, MAX(END_TIME) AS dt FROM vbrain.wf_temp_transactions UNION ALL SELECT MAX(wf_id) AS wf_id, MAX(END_TIME) AS dt FROM vbrain.wf_temp_transactions_trash) AS t;

        IF max_submissionDate IS NULL THEN
            SET max_submissionDate = min_submissionDate;
        END IF;

        SELECT GROUP_CONCAT(bp.mapping_id SEPARATOR ',') INTO mappingIdList
        FROM business_process_view_2 bp
        WHERE bp.isDisabled = 0;

        IF IFNULL(lastupdated_wf_id,0) = 0 THEN
            SET w = CONCAT('AwsHit.id > (SELECT MAX(id) FROM wfdb.AwsHit WHERE submissionDate < \'',DATE(max_submissionDate),'\') AND (Run.status=\'COMPLETED\' OR Run.hasProcessingIssues = 1)');
        ELSE
            SET w = CONCAT('(', t_import_sub_func(min_submissionDate), ')', ' AND (Run.status=\'COMPLETED\' OR Run.hasProcessingIssues = 1)');
        END IF;

        IF mappingIdList IS NOT NULL THEN
            SET w = CONCAT(w, ' AND Run.campaignMap_id IN (',mappingIdList,')');
        END IF;

        DROP TEMPORARY TABLE IF EXISTS `vbrain`.`t_import_tmp`;

        CREATE TEMPORARY TABLE `vbrain`.`t_import_tmp` (
            QE varchar(1000),
            QT varchar(1)
        );

        INSERT INTO t_import_tmp(QE, QT) VALUES
        ('Run|title|TITLE','S'),
        ('Run|title|DESCRIPTION','S'),
        ('AwsHit|submissionDate|START_TIME','S'),
        ('Run|campaign_id|CAMPAIGN_ID','S'),
        ('Run|rootRunUUID|BP_UUID','S'),
        ('AwsHit|completionDate|END_TIME','S'),
        ('Run|hasProcessingIssues|STATUS','S'),
        ('AwsHit|id|wf_id','S'),
        ('Run','F'),
        ('AwsHit|run_id|=|Run|id','J'),
        (w,'W'),
        ('AwsHit|id|A','O'),
        ('5000','L'),
        ('wf_temp_transactions|ii','T');

        SELECT * FROM t_import_tmp;

        DROP TEMPORARY TABLE IF EXISTS `vbrain`.`t_import_tmp`;
END$$
DELIMITER ;