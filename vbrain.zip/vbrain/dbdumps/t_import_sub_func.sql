DROP FUNCTION IF EXISTS vbrain.t_import_sub_func;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` FUNCTION `t_import_sub_func`(p_max_submissionDate DATETIME) RETURNS varchar(5000) CHARSET latin1
BEGIN
    DECLARE v_cmp_id INT(11);
    DECLARE v_max_wf_id INT(11) DEFAULT 1;
    DECLARE v_max_wf_id_str VARCHAR(500) DEFAULT NULL;
    DECLARE finished INT(1) DEFAULT 0;
    DECLARE sub_str VARCHAR(5000) DEFAULT '';
    
    DECLARE t_cursor CURSOR FOR
        SELECT a.campaign_id, b.WF_ID FROM business_process_view_2 a LEFT OUTER JOIN (SELECT CAMPAIGN_ID, MAX(WF_ID) AS WF_ID FROM (SELECT CAMPAIGN_ID, MAX(WF_ID) AS WF_ID FROM wf_temp_transactions WHERE WF_ID IS NOT NULL GROUP BY CAMPAIGN_ID UNION ALL SELECT CAMPAIGN_ID, MAX(WF_ID) AS WF_ID FROM wf_temp_transactions_trash WHERE WF_ID IS NOT NULL GROUP BY CAMPAIGN_ID) T GROUP BY CAMPAIGN_ID) b ON a.campaign_id = b.CAMPAIGN_ID;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;

    OPEN t_cursor;

        get_t_data: LOOP
            FETCH t_cursor INTO v_cmp_id, v_max_wf_id;
            IF finished = 1 THEN
                LEAVE get_t_data;
            END IF;

            SET v_max_wf_id_str = CONCAT(v_max_wf_id);

            IF IFNULL(v_max_wf_id,0) = 0 THEN
                SET v_max_wf_id_str = CONCAT('(SELECT IFNULL(MAX(id),0) FROM wfdb.AwsHit WHERE submissionDate < \'',DATE(p_max_submissionDate),'\')');
            END IF;

            SET sub_str = CONCAT(sub_str, ' (AwsHit.id > ', v_max_wf_id_str , ' AND Run.campaign_id = ', v_cmp_id, ') OR');

        END LOOP get_t_data;

        CLOSE t_cursor;
    
        IF sub_str <> '' THEN
            SET sub_str = SUBSTRING(sub_str, 1, CHAR_LENGTH(sub_str) - 2);
        END IF;

        RETURN sub_str;
END$$
DELIMITER ;