DROP PROCEDURE IF EXISTS vbrain.wf_temp_datastore_massage_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `wf_temp_datastore_massage_sp`()
BEGIN
        DECLARE v_bp_id INT(11);
        DECLARE v_convert_format VARCHAR(50);

        DECLARE finished INT(1) DEFAULT 0;

        DECLARE datastore_cursor CURSOR FOR
                SELECT business_process_id, start_date_convert_format FROM business_process_view_2 WHERE isDisabled = 0;


        DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;

        OPEN datastore_cursor;

        update_datastore_fields: LOOP
                FETCH datastore_cursor INTO v_bp_id, v_convert_format;
                IF finished = 1 THEN
                        LEAVE update_datastore_fields;
                END IF;

                -- WARNING!! Make sure to follow below order.
                -- Update Start date field format before updating wf_id
            
                -- 1. Convert start date field format
                UPDATE wf_temp_datastore SET start_date = STR_TO_DATE(start_date, v_convert_format) WHERE wf_id = 0 AND business_process_id = v_bp_id;
                -- 2. Update wf_id
                UPDATE wf_temp_datastore SET wf_id = UNIX_TIMESTAMP(start_date)*100000 + system_id WHERE wf_id = 0 AND business_process_id = v_bp_id;

        END LOOP update_datastore_fields;

        CLOSE datastore_cursor;
		
		-- Setting processing time for records having end date
		UPDATE wf_temp_datastore SET process_time = (UNIX_TIMESTAMP(end_date) - UNIX_TIMESTAMP(start_date))*1000 WHERE end_date IS NOT NULL AND process_time IS NULL;

        -- Update error cat for wf_temp_datastore data
        UPDATE vbrain.wf_temp_datastore ds
        JOIN (SELECT bp.business_process_id, Exception_Type, Exception_Value
                  FROM vbrain.exceptions e
                  JOIN vbrain.business_process_view_2 bp ON bp.lob_id = e.Lob) te
        ON ds.business_process_id = te.business_process_id
        SET ds.ERROR_CAT = te.Exception_Type
        WHERE ds.ERROR_CAT IS NULL AND ds.error_msg LIKE concat('%', te.Exception_Value, '%');
        
        -- Update bp_uuid 
        CALL update_ds_bp_uuid_sp_3();
END$$
DELIMITER ;