create
or replace
view `business_process_view_2` as select
    `bp`.`id` as `business_process_id`,
    `bp`.`display_name` as `display_name`,
    `gp`.`Name` as `bp_group_name`,
    `cmp`.`bp_name` as `campaign_name`,
    `func`.`Name` as `function`,
    `lob`.`Name` as `lob`,
    `country`.`Name` as `country`,
    `region`.`Name` as `region`,
    `cmp`.`campaign_id` as `campaign_id`,
    `bp`.`mapping_id` as `mapping_id`,
    `gp`.`ID` as `bp_group_id`,
    `func`.`ID` as `function_id`,
    `lob`.`ID` as `lob_id`,
    `country`.`ID` as `country_id`,
    `region`.`ID` as `region_id`,
    `bp`.`mapped_datastores` as `mapped_datastores`,
    `bp`.`query_order` as `query_order`,
    `bp`.`start_date_convert_format` as `start_date_convert_format`,
    `bp`.`start_date_postgre_format` as `start_date_postgre_format`,
    `bp`.`tracking_id_field` as `tracking_id_field`,
    `bp`.`error_msg_field` as `error_msg_field`,
    `bp`.`system_id_field` as `system_id_field`,
    `bp`.`start_date_field` as `start_date_field`,
    `gp`.`isDisabled` as `isDisabled`
from
    `groups` `gp`
join `groups` `func` on
    `gp`.`Parent_Id` = `func`.`ID`
join `groups` `lob` on
    `func`.`Parent_Id` = `lob`.`ID`
join `groups` `country` on
    `lob`.`Parent_Id` = `country`.`ID`
join `groups` `region` on
    `country`.`Parent_Id` = `region`.`ID`
join `wf_business_process` `bp` on
    `gp`.`id` = `bp`.`group_process_id`
join `wf_campaign` `cmp` on
    `bp`.`mapping_id` = `cmp`.`mapping_id`

where
    `gp`.`Type` = 'process';

;
