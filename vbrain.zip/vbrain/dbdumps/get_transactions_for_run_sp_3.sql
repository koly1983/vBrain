DROP PROCEDURE IF EXISTS vbrain.get_transactions_for_run_sp_3;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`get_transactions_for_run_sp_3`(IN p_bp_uuid VARCHAR(200), IN p_group_by VARCHAR(30))
BEGIN
    DECLARE start_date_format VARCHAR(50) DEFAULT '%m/%d/%Y %H:%i:%s';

    IF p_group_by = 'daily' THEN
        SET start_date_format = '%m/%d/%Y %H:%i:%s';
    ELSEIF p_group_by = 'monthly' THEN
        SET start_date_format = '%M/%Y';
    ELSEIF p_group_by = 'yearly' THEN
        SET start_date_format = '%Y';
    END IF;
    
    SELECT DATE_FORMAT(t.start_time, start_date_format) AS transactionDate, 
           t.tracking_id AS tracking_id, t.status AS status, 
           t.process_id AS process_id, t.process_name AS process_name, 
           t.duration AS duration, t.efforts_saved AS efforts_saved, 
           t.error_type AS error_type, e.type AS error_cat
    FROM group_transaction_view t
    LEFT JOIN wf_exception_category e ON t.error_cat = e.id
    WHERE t.tracking_id IS NOT NULL 
        AND t.status = '0' 
        AND t.worker_status = '0'  
        AND t.bp_uuid=p_bp_uuid;
END$$
DELIMITER ;
