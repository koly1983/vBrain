DROP PROCEDURE IF EXISTS vbrain.delete_group_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`delete_group_sp_2`()
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
	    ROLLBACK;  
        RESIGNAL;  
    END;
    IF CHECK_CAN_DELETE_GROUP_2(group_id) = 1 THEN
	    SET autocommit = 0;
		
		START TRANSACTION;
	
		UPDATE wf_business_process SET group_process_id = NULL, mapping_id = NULL WHERE group_process_id = group_id;
		DELETE FROM groups WHERE ID = group_id; 
	
		COMMIT;
		
		SET autocommit = 1;
	END IF;
END$$
DELIMITER ;
