DROP PROCEDURE IF EXISTS vbrain.update_transactions_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`update_transactions_sp_2`()
BEGIN
    DECLARE v_start_date varchar(100);
    DECLARE v_bp_id varchar(100);
    DECLARE max_length INTEGER DEFAULT 0;
    DECLARE track_id_max_length INTEGER DEFAULT 0;
    DECLARE finished INTEGER DEFAULT 0;
    DECLARE datastore_cursor CURSOR FOR 
        SELECT DISTINCT start_date, business_process_id FROM wf_temp_datastore WHERE bp_uuid IS NULL AND transaction_id IS NULL ORDER BY start_date;
              
    -- declare NOT FOUND handler
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
 
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;  -- Rollback any changes made in the transaction
        RESIGNAL;  -- Resignal the error to the caller
    END;
   
    UPDATE wf_temp_datastore ds 
    JOIN (
        SELECT t.id AS trans_id, d.id as ds_id FROM
        (SELECT CONCAT(@row_number:=CASE WHEN @bp_uuid = bp_uuid THEN @row_number + 1 ELSE 1 END,':',@bp_uuid:=bp_uuid) as map_key, id FROM wf_temp_datastore WHERE bp_uuid IS NOT NULL ORDER BY bp_uuid, system_id) d
        JOIN
        (SELECT CONCAT(@row_number:=CASE WHEN @BP_UUID = BP_UUID THEN @row_number + 1 ELSE 1 END,':',@BP_UUID:=BP_UUID) as map_key, ID FROM wf_temp_transactions WHERE BP_UUID IS NOT NULL ORDER BY BP_UUID, wf_id) t
        ON t.map_key = d.map_key
    ) AS map
    ON map.ds_id = ds.ID
    SET ds.transaction_id = map.trans_id;

    OPEN datastore_cursor;
     
    -- Loop through different runs data and link transactions dump with datastore dump
    -- Update 'ds.transaction_id' (foreign key)
    get_datastore_data: LOOP
        FETCH datastore_cursor INTO v_start_date,v_bp_id;
        IF finished = 1 THEN 
            LEAVE get_datastore_data;
        END IF;
        UPDATE wf_temp_datastore ds 
        JOIN (
            SELECT t2.ID AS trans_id, t1.ID AS ds_id
            FROM (
                -- Select wf_temp_datastore rows with row numbers
                SELECT tds.ID, @curRow := @curRow + 1 AS row_number
                FROM wf_temp_datastore tds
                JOIN
                    (SELECT @curRow := 0) r -- Row numbers
                WHERE tds.start_date = v_start_date AND tds.business_process_id = v_bp_id ORDER BY tds.system_id
            ) t1
            JOIN (
                -- Select ids from temp transactions with row numbers
                SELECT tt.ID, @curRow2 := @curRow2 + 1 AS row_number
                FROM wf_temp_transactions tt
                JOIN
                    (SELECT @curRow2 := 0) r -- Row numbers
                JOIN business_process_view_2 bp 
                    ON tt.campaign_id = bp.campaign_id 
                WHERE tt.END_TIME > v_start_date 
                    AND bp.business_process_id = v_bp_id 
                ORDER BY tt.END_TIME
            ) t2 ON t1.row_number = t2.row_number
        ) AS temp
        ON temp.ds_id = ds.ID
        SET ds.transaction_id = temp.trans_id;
    END LOOP get_datastore_data;

    CLOSE datastore_cursor;

    SELECT CHARACTER_MAXIMUM_LENGTH INTO max_length
    FROM information_schema.columns
    WHERE table_schema = 'vbrain' AND   
        table_name = 'transactions' AND
        COLUMN_NAME = 'ERROR_TYPE';

    SELECT CHARACTER_MAXIMUM_LENGTH INTO track_id_max_length
    FROM information_schema.columns
    WHERE table_schema = 'vbrain' AND   
        table_name = 'transactions' AND
        COLUMN_NAME = 'TRACKING_ID';

    -- Select from the dumps, groups, bot in temporary in mamory table
    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`tmp`;
    CREATE TEMPORARY TABLE `vbrain`.`tmp` engine=memory AS        
    SELECT tt.ID AS transaction_id,
           b.ID AS botid,
           tt.STATUS AS status,
           tt.START_TIME AS hit_submissionDate, 
           IF(ds.process_time IS NOT NULL, FROM_UNIXTIME(UNIX_TIMESTAMP(tt.START_TIME) + ds.process_time/1000), tt.END_TIME) AS hit_completionDate,
           IF(tt.STATUS = 1, 'Unkown Error', '') AS exception_type,
           tt.DESCRIPTION AS stepTitle,
           bp.country AS country, 
           tt.BP_UUID AS bp_instance_uuid,
           bp.function AS function,
           ds.error_cat AS error_cat,
           ds.error_msg AS error_msg,
           ds.tracking_id AS tracking_id,
           'BOT' AS WORKER_TYPE,
           0 AS OUT_COME,
           'vBrain' AS CREATED_BY
    FROM business_process_view_2 bp 
    JOIN bot b ON bp.bp_group_id = b.Process_Id
    INNER JOIN wf_temp_transactions tt ON tt.campaign_id = bp.campaign_id
    JOIN wf_temp_datastore ds ON ds.transaction_id = tt.ID
    WHERE b.ID > 0 AND b.isDisabled = 0
    LIMIT 2000;

    INSERT INTO `vbrain`.`tmp`
    SELECT tt.ID AS transaction_id,
           b.ID AS botid,
           tt.STATUS AS status,
           tt.START_TIME AS hit_submissionDate, 
           tt.END_TIME AS hit_completionDate,
           IF(tt.STATUS = 1, 'Unkown Error', '') AS exception_type,
           tt.DESCRIPTION AS stepTitle,
           bp.country AS country, 
           tt.BP_UUID AS bp_instance_uuid,
           bp.function AS function,
           1 AS error_cat,
           'This task has processing issues.' AS error_msg,
           '-' AS tracking_id,
           'BOT' AS WORKER_TYPE,
           0 AS OUT_COME,
           'vBrain' AS CREATED_BY
    FROM business_process_view_2 bp 
    JOIN bot b ON bp.bp_group_id = b.Process_Id
    INNER JOIN wf_temp_transactions tt ON tt.campaign_id = bp.campaign_id
    WHERE b.ID > 0 AND b.isDisabled = 0 
    AND tt.END_TIME IS NULL AND tt.STATUS = 1;


    SET autocommit = 0;

    -- Start SQL transaction
    START TRANSACTION;
    -- Promote to transactions from in memory temporary table
    INSERT INTO transactions (WORKER_ID,STATUS,START_TIME,END_TIME,EXCEPTION_TYPE,DESCRIPTION,COUNTRY,BP_UUID,B_FUNCTION,ERROR_CAT, ERROR_TYPE,TRACKING_ID,WORKER_TYPE,OUT_COME,CREATED_BY)
    SELECT botid, status, hit_submissionDate, hit_completionDate, exception_type,stepTitle, country, bp_instance_uuid, function,error_cat,SUBSTRING(error_msg, 1, max_length), SUBSTRING(tracking_id, 1, track_id_max_length), WORKER_TYPE, OUT_COME, CREATED_BY
    FROM `vbrain`.`tmp`;
    
    -- Delete (Move to trash) successfully promoted (moved to transactions table) rows 
    -- from temp tables (wf_temp_transactions, wf_temp_datastore)
    INSERT INTO wf_temp_transactions_trash (ID, STATUS, TITLE, BP_NAME, START_TIME, END_TIME, DESCRIPTION, BP_UUID, campaign_id, WF_ID) 
        SELECT ID, STATUS, TITLE, BP_NAME, START_TIME, END_TIME, DESCRIPTION, BP_UUID, campaign_id, WF_ID FROM wf_temp_transactions 
        WHERE ID IN (SELECT transaction_id FROM tmp);
    
    INSERT INTO wf_temp_datastore_trash (ID, name, transaction_id, error_cat, start_date, system_id, error_msg, tracking_id, business_process_id, wf_id, bp_uuid, end_date, process_time) 
        SELECT ID, name, transaction_id, error_cat, start_date, system_id, error_msg, tracking_id, business_process_id, wf_id, bp_uuid, end_date, process_time FROM wf_temp_datastore 
        WHERE transaction_id IN (SELECT transaction_id FROM tmp);
    
    DELETE FROM wf_temp_datastore WHERE transaction_id IN (SELECT transaction_id FROM tmp);
    DELETE FROM wf_temp_transactions WHERE ID IN (SELECT transaction_id FROM tmp);
    
    COMMIT;
    -- End SQL transaction 
    SET autocommit = 1;

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`tmp`;
END$$
DELIMITER ;