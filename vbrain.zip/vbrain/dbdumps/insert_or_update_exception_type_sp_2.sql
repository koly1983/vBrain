DROP PROCEDURE IF EXISTS vbrain.insert_or_update_exception_type_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`insert_or_update_exception_type_sp_2`(IN p_exception_id INT(11), IN p_lob_id INT(11), IN p_exception_category_id INT(11), IN p_exception_str VARCHAR(500))
BEGIN
	
	IF p_exception_id IS NULL THEN
		INSERT INTO exceptions (Lob, Exception_Type, Exception_Value) 
		VALUES (p_lob_id, p_exception_category_id, p_exception_str);
	ELSE
		UPDATE exceptions SET Lob = p_lob_id, Exception_Type = p_exception_category_id, Exception_Value = p_exception_str
		WHERE ID = p_exception_id;
	END IF;
	
	UPDATE vbrain.transactions t
	JOIN (SELECT bp.BOT_ID, Exception_Type, Exception_Value
		  FROM vbrain.exceptions e 
		  JOIN vbrain.business_process_bot_view_2 bp ON bp.lob_id = e.Lob) te 
	ON t.WORKER_ID = te.BOT_ID 
	SET t.ERROR_CAT = te.Exception_Type
	WHERE t.ERROR_CAT IS NULL AND t.ERROR_TYPE LIKE concat('%', te.Exception_Value, '%');
	
	UPDATE vbrain.wf_temp_datastore ds
	JOIN (SELECT bp.business_process_id, Exception_Type, Exception_Value
		  FROM vbrain.exceptions e 
		  JOIN vbrain.business_process_view_2 bp ON bp.lob_id = e.Lob) te 
	ON ds.business_process_id = te.business_process_id 
	SET ds.ERROR_CAT = te.Exception_Type
	WHERE ds.ERROR_CAT IS NULL AND ds.error_msg LIKE concat('%', te.Exception_Value, '%');

END$$
DELIMITER ;
