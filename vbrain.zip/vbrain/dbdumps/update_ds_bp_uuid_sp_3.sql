DROP PROCEDURE IF EXISTS vbrain.update_ds_bp_uuid_sp_3;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`update_ds_bp_uuid_sp_3`()
BEGIN
    -- Update bp_uuid from wf_bp_run
    UPDATE wf_temp_datastore ds JOIN 
    (SELECT r.bp_uuid AS bp_uuid, tds.id AS tds_id FROM wf_bp_run r JOIN wf_temp_datastore tds ON tds.business_process_id = r.business_process_id WHERE tds.start_date >= (r.start_time-INTERVAL 1 SECOND) AND tds.start_date < r.end_time) run
    ON ds.id = run.tds_id 
    SET ds.bp_uuid = run.bp_uuid 
    WHERE ds.bp_uuid IS NULL AND ds.business_process_id IN (15, 16, 17, 18, 20, 21);
        
    -- Getting baseline for each bp
    DROP TEMPORARY TABLE IF EXISTS tmp_t_massage;
    CREATE TEMPORARY TABLE tmp_t_massage engine=memory AS        
    SELECT t.business_process_id AS bp_id, MIN(t.start_time) AS t_min_start_time 
    FROM wf_bp_run t 
    JOIN(
        SELECT business_process_id, MIN(start_date) AS min_start_date 
        FROM wf_temp_datastore 
        WHERE bp_uuid IS NULL 
        GROUP BY business_process_id
    ) d ON d.business_process_id = t.business_process_id 
    WHERE t.start_time > d.min_start_date 
    GROUP BY t.business_process_id;

    DROP TEMPORARY TABLE IF EXISTS tmp_d_massage;
    CREATE TEMPORARY TABLE tmp_d_massage engine=memory AS 
    SELECT d.business_process_id AS bp_id, MIN(d.start_date) AS d_min_start_date 
    FROM wf_temp_datastore d 
    JOIN (
        SELECT business_process_id, MIN(t.start_time) AS min_start_time 
        FROM wf_temp_transactions t 
        JOIN business_process_view_2 bp ON bp.campaign_id = t.campaign_id 
        GROUP BY bp.business_process_id
    ) t ON d.business_process_id = t.business_process_id 
    WHERE d.bp_uuid IS NULL AND d.start_date > t.min_start_time 
    GROUP BY d.business_process_id;
    
    -- Update bp_uuid in datastore
    SET @bp_id_d = 0;
    SET @bp_id_t = 0;
    
    UPDATE wf_temp_datastore ds 
    JOIN (
        SELECT d.id as ds_id, t.id AS trans_id, t.BP_UUID as bp_uuid 
        FROM (            
            SELECT CONCAT(@row_number_d:=CASE WHEN @bp_id_d = business_process_id THEN @row_number_d + 1 ELSE 1 END,':',@bp_id_d:= business_process_id) AS map_key, id
            FROM (
                SELECT d.business_process_id, d.id 
                FROM wf_temp_datastore d
                JOIN tmp_t_massage t_md ON t_md.bp_id = d.business_process_id
                WHERE d.bp_uuid IS NULL AND d.start_date >= (t_md.t_min_start_time - INTERVAL 1 SECOND)
                ORDER BY d.business_process_id, d.start_date, d.system_id
            ) ds
        ) d
        JOIN (
            SELECT CONCAT(@row_number_t:=CASE WHEN @bp_id_t = business_process_id THEN @row_number_t + 1 ELSE 1 END,':',@bp_id_t:= business_process_id) AS map_key, ID, BP_UUID 
            FROM (
                SELECT bp.business_process_id, t.ID, t.BP_UUID 
                FROM wf_temp_transactions t
                JOIN business_process_view_2 bp ON t.campaign_id = bp.campaign_id 
                JOIN tmp_d_massage d_md ON d_md.bp_id = bp.business_process_id
                WHERE t.campaign_id IS NOT NULL AND t.start_time IS NOT NULL AND t.start_time > d_md.d_min_start_date 
                ORDER BY t.campaign_id, t.start_time, t.wf_id
            ) ts
        ) t
        ON t.map_key = d.map_key
    ) AS map
    ON map.ds_id = ds.ID
    SET ds.bp_uuid = map.bp_uuid; 
    
    DROP TEMPORARY TABLE IF EXISTS tmp_t_massage;
    DROP TEMPORARY TABLE IF EXISTS tmp_d_massage;
END$$
DELIMITER ;    
