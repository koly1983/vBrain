-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.6.44-log


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema nodestatus
--

CREATE DATABASE IF NOT EXISTS nodestatus;
USE nodestatus;

--
-- Definition of table `capabilities`
--

DROP TABLE IF EXISTS `capabilities`;
CREATE TABLE `capabilities` (
  `capability_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `nodes_node_id` int(11) NOT NULL,
  PRIMARY KEY (`capability_id`),
  KEY `fk_capabilities_nodes1_idx` (`nodes_node_id`),
  CONSTRAINT `fk_capabilities_nodes1` FOREIGN KEY (`nodes_node_id`) REFERENCES `nodes` (`node_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `capabilities`
--

/*!40000 ALTER TABLE `capabilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `capabilities` ENABLE KEYS */;


--
-- Definition of table `email`
--

DROP TABLE IF EXISTS `email`;
CREATE TABLE `email` (
  `email_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `to` varchar(65) DEFAULT NULL,
  `cc` varchar(65) DEFAULT NULL,
  PRIMARY KEY (`email_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `email`
--

/*!40000 ALTER TABLE `email` DISABLE KEYS */;
INSERT INTO `email` (`email_id`,`to`,`cc`) VALUES 
 (1,'lasanda.lihindipita@bmo.com','SURESHCUMAR.JEEGATHEESWARAN@bmo.com');
/*!40000 ALTER TABLE `email` ENABLE KEYS */;


--
-- Definition of table `email_status`
--

DROP TABLE IF EXISTS `email_status`;
CREATE TABLE `email_status` (
  `id_email_status` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_email_status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `email_status`
--

/*!40000 ALTER TABLE `email_status` DISABLE KEYS */;
INSERT INTO `email_status` (`id_email_status`,`status`) VALUES 
 (2,1);
/*!40000 ALTER TABLE `email_status` ENABLE KEYS */;


--
-- Definition of table `hubs`
--

DROP TABLE IF EXISTS `hubs`;
CREATE TABLE `hubs` (
  `hub_id` int(11) NOT NULL AUTO_INCREMENT,
  `hub_name` varchar(45) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `servers_server_id` int(11) NOT NULL,
  `status_id_status` int(11) NOT NULL,
  `email_state` tinyint(1) NOT NULL,
  PRIMARY KEY (`hub_id`),
  KEY `fk_hubs_servers_idx` (`servers_server_id`),
  KEY `fk_hubs_status1_idx` (`status_id_status`),
  CONSTRAINT `fk_hubs_servers` FOREIGN KEY (`servers_server_id`) REFERENCES `servers` (`server_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_hubs_status1` FOREIGN KEY (`status_id_status`) REFERENCES `status` (`id_status`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hubs`
--

/*!40000 ALTER TABLE `hubs` DISABLE KEYS */;
INSERT INTO `hubs` (`hub_id`,`hub_name`,`url`,`servers_server_id`,`status_id_status`,`email_state`) VALUES 
 (1,'rpa06hub1','http://wfiabccwprrpa06:10444/grid/console',1,3,1),
 (2,'rpa09hub3','http://wfiabccwprrpa09:10447/grid/console',2,3,1),
 (3,'rpa09hub2','http://wfiabccwprrpa09:10446/grid/console',2,9,0),
 (4,'rpa05hub3','http://wfiabccwprrpa05:10447/grid/console',3,3,1),
 (5,'rpa05hub1','http://wfiabccwprrpa05:10444/grid/console',3,4,0),
 (8,'rpa09hub1','http://wfiabccwprrpa09:10444/grid/console',2,8,0),
 (9,'rpa03hub3','http://wfiabccwprrpa03:10447/grid/console',4,3,1),
 (10,'rpa03hub2','http://wfiabccwprrpa03:10446/grid/console',4,3,1);
/*!40000 ALTER TABLE `hubs` ENABLE KEYS */;


--
-- Definition of table `nodes`
--

DROP TABLE IF EXISTS `nodes`;
CREATE TABLE `nodes` (
  `node_id` int(11) NOT NULL AUTO_INCREMENT,
  `node_name` varchar(65) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `hubs_hub_id` int(11) NOT NULL,
  `node_status_id_status` int(11) NOT NULL,
  PRIMARY KEY (`node_id`),
  KEY `fk_nodes_hubs1_idx` (`hubs_hub_id`),
  KEY `fk_nodes_node_status1_idx` (`node_status_id_status`),
  CONSTRAINT `fk_nodes_hubs1` FOREIGN KEY (`hubs_hub_id`) REFERENCES `hubs` (`hub_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_nodes_node_status1` FOREIGN KEY (`node_status_id_status`) REFERENCES `status` (`id_status`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nodes`
--

/*!40000 ALTER TABLE `nodes` DISABLE KEYS */;
INSERT INTO `nodes` (`node_id`,`node_name`,`url`,`hubs_hub_id`,`node_status_id_status`) VALUES 
 (1,'hub1node5','http://wfiabccwprrpa06:5004',1,1),
 (4,'hub1node4','http://wfiabccwprrpa06:5003',1,1),
 (5,'hub1node1','http://wfiabccwprrpa06:5000',1,1),
 (6,'hub1node2','http://wfiabccwprrpa06:5001',1,1),
 (10,'hub1node3','http://wfiabccwprrpa06:5002',1,1),
 (11,'hub3node3','http://wfiabccwprrpa05:5012',4,1),
 (12,'hub3node2','http://wfiabccwprrpa05:5011',4,1),
 (13,'hub3node4','http://wfiabccwprrpa05:5013',4,1),
 (14,'hub3node1','http://wfiabccwprrpa05:5010',4,1),
 (15,'hub1node3','http://wfiabccwprrpa05:5002',5,2),
 (16,'hub2node2','http://wfiabccwprrpa05:5006',5,2),
 (17,'hub1node2','http://wfiabccwprrpa05:5001',5,2),
 (18,'hub1node4','http://wfiabccwprrpa05:5003',5,2),
 (19,'hub2node1','http://wfiabccwprrpa05:5005',5,2),
 (20,'hub1node1','http://wfiabccwprrpa05:5000',5,2),
 (21,'hub2node3','http://wfiabccwprrpa05:5007',5,2),
 (22,'hub1node5','http://wfiabccwprrpa05:5004',5,2),
 (23,'hub3node5','http://wfiabccwprrpa09:5014',2,1),
 (24,'hub3node1','http://wfiabccwprrpa09:5010',2,1),
 (25,'hub3node3','http://wfiabccwprrpa09:5012',2,1),
 (26,'hub3node4','http://wfiabccwprrpa09:5013',2,1),
 (27,'hub3node2','http://wfiabccwprrpa09:5011',2,1),
 (28,'hub2node3','http://wfiabccwprrpa09:5007',3,1),
 (29,'hub2node5','http://wfiabccwprrpa09:5009',3,1),
 (30,'hub2node1','http://wfiabccwprrpa09:5005',3,1),
 (31,'hub2node2','http://wfiabccwprrpa09:5006',3,1),
 (32,'hub2node4','http://wfiabccwprrpa09:5008',3,1),
 (50,'hub1node2','http://wfiabccwprrpa09:5001',8,1),
 (51,'hub1node3','http://wfiabccwprrpa09:5002',8,1),
 (52,'hub1node5','http://wfiabccwprrpa09:5004',8,1),
 (53,'hub3node4','http://wfiabccwprrpa09:5013',8,1),
 (54,'hub3node1','http://wfiabccwprrpa09:5010',8,1),
 (55,'hub3node5','http://wfiabccwprrpa09:5014',8,1),
 (56,'hub3node3','http://wfiabccwprrpa09:5012',8,1),
 (57,'hub3node2','http://wfiabccwprrpa09:5011',8,1),
 (58,'hub2node5','http://wfiabccwprrpa03:5009',9,1),
 (59,'hub3node4','http://wfiabccwprrpa03:5013',9,1),
 (60,'hub3node2','http://wfiabccwprrpa03:5011',9,1),
 (61,'hub2node4','http://wfiabccwprrpa03:5008',9,1),
 (62,'hub3node3','http://wfiabccwprrpa03:5012',9,1),
 (63,'hub3node5','http://wfiabccwprrpa03:5014',9,1),
 (64,'hub3node1','http://wfiabccwprrpa03:5010',9,1),
 (65,'hub1node3','http://wfiabccwprrpa03:5002',9,1),
 (66,'hub1node4','http://wfiabccwprrpa03:5003',9,1),
 (67,'hub2node3','http://wfiabccwprrpa03:5007',9,1),
 (68,'hub2node1','http://wfiabccwprrpa03:5005',9,1),
 (69,'hub1node5','http://wfiabccwprrpa03:5004',9,1),
 (70,'hub1node1','http://wfiabccwprrpa03:5000',9,1),
 (71,'hub2node2','http://wfiabccwprrpa03:5006',9,1),
 (72,'hub1node2','http://wfiabccwprrpa03:5001',9,1),
 (73,'hub2node1','http://wfiabccwprrpa03:5005',10,1),
 (74,'hub2node2','http://wfiabccwprrpa03:5006',10,1);
/*!40000 ALTER TABLE `nodes` ENABLE KEYS */;


--
-- Definition of table `ocr_data`
--

DROP TABLE IF EXISTS `ocr_data`;
CREATE TABLE `ocr_data` (
  `data_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `queued` int(10) unsigned NOT NULL,
  `in_progress` int(10) unsigned NOT NULL,
  `timestamp` datetime NOT NULL,
  `completed` int(10) unsigned NOT NULL,
  PRIMARY KEY (`data_id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ocr_data`
--

/*!40000 ALTER TABLE `ocr_data` DISABLE KEYS */;
INSERT INTO `ocr_data` (`data_id`,`queued`,`in_progress`,`timestamp`,`completed`) VALUES 
 (38,0,0,'2019-06-18 15:10:05',210),
 (39,0,0,'2019-06-18 15:20:02',210),
 (40,0,0,'2019-06-18 15:40:06',210),
 (41,0,0,'2019-06-18 16:40:06',349),
 (42,0,0,'2019-06-18 16:50:03',349),
 (43,0,0,'2019-06-19 16:30:07',658),
 (44,0,0,'2019-06-19 16:40:02',663),
 (45,0,0,'2019-06-19 16:50:07',663),
 (46,0,0,'2019-06-27 16:50:11',469),
 (47,0,0,'2019-06-27 17:00:03',484),
 (48,0,0,'2019-06-27 17:20:02',485),
 (49,0,0,'2019-06-27 17:30:03',485),
 (50,0,0,'2019-06-27 17:40:02',485),
 (51,0,0,'2019-06-27 17:50:02',485),
 (52,0,0,'2019-06-28 14:00:13',174),
 (53,0,0,'2019-07-04 13:20:21',0),
 (54,0,0,'2019-07-04 15:20:41',0),
 (55,0,0,'2019-07-04 15:30:16',0),
 (56,0,0,'2019-07-04 16:10:17',0),
 (57,0,0,'2019-07-04 16:20:11',0),
 (58,0,0,'2019-07-04 16:30:12',0),
 (59,0,0,'2019-07-04 16:40:11',0),
 (60,0,0,'2019-07-04 16:50:11',0),
 (61,0,0,'2019-07-04 17:00:12',0),
 (62,0,0,'2019-07-04 17:10:11',0),
 (63,0,0,'2019-07-04 17:20:13',0),
 (64,0,0,'2019-07-05 11:10:55',41),
 (65,0,0,'2019-07-05 12:10:44',90),
 (66,0,0,'2019-07-05 12:20:11',91),
 (67,0,0,'2019-07-05 13:40:39',151),
 (68,0,0,'2019-07-05 13:50:12',159),
 (69,0,0,'2019-07-05 15:20:37',227),
 (70,0,0,'2019-07-05 15:40:39',227),
 (71,0,0,'2019-07-05 15:50:12',227),
 (72,0,0,'2019-07-05 16:00:40',236),
 (73,0,1,'2019-07-05 16:10:15',246),
 (74,0,0,'2019-07-05 17:10:42',308),
 (75,0,0,'2019-07-05 17:30:43',308),
 (76,0,0,'2019-07-05 17:50:47',308),
 (77,0,0,'2019-07-05 18:00:13',308);
/*!40000 ALTER TABLE `ocr_data` ENABLE KEYS */;


--
-- Definition of table `ocr_properties`
--

DROP TABLE IF EXISTS `ocr_properties`;
CREATE TABLE `ocr_properties` (
  `id_prop` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `max_jobs` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_prop`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ocr_properties`
--

/*!40000 ALTER TABLE `ocr_properties` DISABLE KEYS */;
INSERT INTO `ocr_properties` (`id_prop`,`max_jobs`) VALUES 
 (1,2);
/*!40000 ALTER TABLE `ocr_properties` ENABLE KEYS */;


--
-- Definition of table `servers`
--

DROP TABLE IF EXISTS `servers`;
CREATE TABLE `servers` (
  `server_id` int(11) NOT NULL AUTO_INCREMENT,
  `server_name` varchar(65) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`server_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `servers`
--

/*!40000 ALTER TABLE `servers` DISABLE KEYS */;
INSERT INTO `servers` (`server_id`,`server_name`,`url`) VALUES 
 (1,'wfiabccwprrpa06','http://wfiabccwprrpa06'),
 (2,'wfiabccwprrpa09','http://wfiabccwprrpa09'),
 (3,'wfiabccwprrpa05','http://wfiabccwprrpa05'),
 (4,'wfiabccwprrpa03','http://wfiabccwprrpa03');
/*!40000 ALTER TABLE `servers` ENABLE KEYS */;


--
-- Definition of table `status`
--

DROP TABLE IF EXISTS `status`;
CREATE TABLE `status` (
  `id_status` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_status`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

/*!40000 ALTER TABLE `status` DISABLE KEYS */;
INSERT INTO `status` (`id_status`,`status`) VALUES 
 (1,'ACTIVE'),
 (2,'INACTIVE'),
 (3,'HEALTHY'),
 (4,'WEAK'),
 (5,'OPERATIONAL'),
 (6,'OUTAGE'),
 (7,'NOSTATUS'),
 (8,'UPGRADED'),
 (9,'QUEUED');
/*!40000 ALTER TABLE `status` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
