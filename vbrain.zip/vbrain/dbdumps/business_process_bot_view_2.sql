create
or replace
view `business_process_bot_view_2` as select
    `bp`.`business_process_id` as `business_process_id`,
    `bp`.`display_name` as `display_name`,
    `bp`.`bp_group_name` as `bp_group_name`,
    `bp`.`campaign_name` as `campaign_name`,
    `bp`.`function` as `function`,
    `bp`.`lob` as `lob`,
    `bp`.`country` as `country`,
    `bp`.`region` as `region`,
    `bp`.`campaign_id` as `campaign_id`,
    `bp`.`mapping_id` as `mapping_id`,
    `bp`.`bp_group_id` as `bp_group_id`,
    `bp`.`function_id` as `function_id`,
    `bp`.`lob_id` as `lob_id`,
    `bp`.`country_id` as `country_id`,
    `bp`.`region_id` as `region_id`,
    `bp`.`mapped_datastores` as `mapped_datastores`,
    `bp`.`query_order` as `query_order`,
    `bp`.`start_date_convert_format` as `start_date_convert_format`,
    `bp`.`start_date_postgre_format` as `start_date_postgre_format`,
    `bp`.`tracking_id_field` as `tracking_id_field`,
    `bp`.`error_msg_field` as `error_msg_field`,
    `bp`.`system_id_field` as `system_id_field`,
    `bp`.`start_date_field` as `start_date_field`,
    `bp`.`isDisabled` as `isDisabled`,
    `b`.`ID` as `BOT_ID`,
    `b`.`isDisabled` as `BOT_DISABLED`
from
    `business_process_view_2` `bp`
join `bot` `b` on
    `b`.`Process_Id` = `bp`.`bp_group_id`;
