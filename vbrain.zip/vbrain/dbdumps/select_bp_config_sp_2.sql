DROP PROCEDURE IF EXISTS vbrain.select_bp_config_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`select_bp_config_sp_2`(IN group_id INT(11))
BEGIN
	IF group_id IS NOT NULL THEN
		SELECT business_process_id AS bp_id, bp_group_id AS group_id, campaign_id, mapping_id 
		FROM business_process_view_2 
		WHERE bp_group_id = group_id;
	ELSE
		SELECT NULL AS bp_id, NULL AS group_id, NULL AS campaign_id, NULL AS mapping_id LIMIT 0; 
	END IF;
END$$
DELIMITER ;
