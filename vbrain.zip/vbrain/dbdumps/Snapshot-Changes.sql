CREATE TABLE IF NOT EXISTS vbrain.wf_snapshot (
    id INT(11) NOT NULL AUTO_INCREMENT,
    wf_id BIGINT(20) NOT NULL,
    campaign_id BIGINT(20) NOT NULL,
    task_name VARCHAR(128) NULL,
    total_records INT(11) NOT NULL,
    records_processed INT(11) NOT NULL,
    bp_uuid VARCHAR(45) NULL,
    start_time DATETIME NOT NULL,
    snapshot_time DATETIME NOT NULL,
    CONSTRAINT wf_snapshot_pk PRIMARY KEY (id)
)
ENGINE=InnoDB
DEFAULT CHARSET=latin1
COLLATE=latin1_swedish_ci;

-- ss_import_sp_2
DROP PROCEDURE IF EXISTS vbrain.ss_import_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`ss_import_sp_2`()
BEGIN
    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`ss_import_tmp`;

    CREATE TEMPORARY TABLE `vbrain`.`ss_import_tmp` (
        QE varchar(1000),
        QT varchar(1)
    ); 

    INSERT INTO ss_import_tmp(QE, QT) VALUES 
    ('|id|wf_id','S'),
    ('|campaign_id|campaign_id','S'),
    ('|title|task_name','S'),
    ('|recordCount|total_records','S'),
    ('|totalAssignmentCount|records_processed','S'),
    ('|rootRunUUID|bp_uuid','S'),
    ('|startDate|start_time','S'),
    (CONCAT('|\'',NOW(),'\'|snapshot_time'),'S'),
    ('Run','F'),
    ('status = \'MACHINE_PROCESSING\'','W'),
    ('wf_snapshot|ii','T');
    
    SELECT * FROM ss_import_tmp;

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`ss_import_tmp`;
END$$
DELIMITER ;


-- import_details_sp
DROP PROCEDURE IF EXISTS vbrain.import_details_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `import_details_sp`()
BEGIN
    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`import_details_tmp`;

    CREATE TEMPORARY TABLE `vbrain`.`import_details_tmp` (
        entity varchar(1),
        import varchar(100),
        importParamValues varchar(100),
        post varchar(100),
        postParamValues varchar(100)
    );

    INSERT INTO import_details_tmp(entity, import, importParamValues, post, postParamValues) VALUES
    ('T','t_import_sp',NULL,NULL,NULL),
    ('T','bp_run_import_sp_2',NULL,'bp_run_massage_sp_2',NULL),
    ('D','ds_import_sp',NULL,'wf_temp_datastore_massage_sp',NULL),
    ('C','c_import_sp_2',NULL,NULL,NULL),
    ('S','ss_import_sp_2',NULL,NULL,NULL);
    
    SELECT * FROM import_details_tmp;

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`import_details_tmp`;
END$$
DELIMITER ;


-- select_current_snapshot_sp_2
DROP PROCEDURE IF EXISTS vbrain.select_current_snapshot_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`select_current_snapshot_sp_2`()
BEGIN
    SELECT c.bp_name, s.task_name, s.total_records, s.records_processed, s.bp_uuid, s.start_time, s.snapshot_time 
    FROM wf_snapshot s 
    JOIN (
        SELECT DISTINCT campaign_id, bp_name FROM wf_campaign
    ) c ON c.campaign_id = s.campaign_id 
    WHERE s.snapshot_time = (SELECT MAX(snapshot_time) FROM wf_snapshot);
END$$
DELIMITER ;


-- ----------------------
-- updates for SLA
-- ----------------------
-- update_transactions_sp_2
DROP PROCEDURE IF EXISTS vbrain.update_transactions_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`update_transactions_sp_2`()
BEGIN
    DECLARE v_start_date varchar(100);
    DECLARE v_bp_id varchar(100);
    DECLARE max_length INTEGER DEFAULT 0;
    DECLARE track_id_max_length INTEGER DEFAULT 0;
    DECLARE finished INTEGER DEFAULT 0;
    DECLARE datastore_cursor CURSOR FOR 
        SELECT DISTINCT start_date, business_process_id FROM wf_temp_datastore WHERE bp_uuid IS NULL AND transaction_id IS NULL ORDER BY start_date;
              
    -- declare NOT FOUND handler
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
 
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;  -- Rollback any changes made in the transaction
        RESIGNAL;  -- Resignal the error to the caller
    END;
   
    UPDATE wf_temp_datastore ds 
    JOIN (
        SELECT t.id AS trans_id, d.id as ds_id FROM
        (SELECT CONCAT(@row_number:=CASE WHEN @bp_uuid = bp_uuid THEN @row_number + 1 ELSE 1 END,':',@bp_uuid:=bp_uuid) as map_key, id FROM wf_temp_datastore WHERE bp_uuid IS NOT NULL ORDER BY bp_uuid, system_id) d
        JOIN
        (SELECT CONCAT(@row_number:=CASE WHEN @BP_UUID = BP_UUID THEN @row_number + 1 ELSE 1 END,':',@BP_UUID:=BP_UUID) as map_key, ID FROM wf_temp_transactions WHERE BP_UUID IS NOT NULL ORDER BY BP_UUID, wf_id) t
        ON t.map_key = d.map_key
    ) AS map
    ON map.ds_id = ds.ID
    SET ds.transaction_id = map.trans_id;

    OPEN datastore_cursor;
     
    -- Loop through different runs data and link transactions dump with datastore dump
    -- Update 'ds.transaction_id' (foreign key)
    get_datastore_data: LOOP
        FETCH datastore_cursor INTO v_start_date,v_bp_id;
        IF finished = 1 THEN 
            LEAVE get_datastore_data;
        END IF;
        UPDATE wf_temp_datastore ds 
        JOIN (
            SELECT t2.ID AS trans_id, t1.ID AS ds_id
            FROM (
                -- Select wf_temp_datastore rows with row numbers
                SELECT tds.ID, @curRow := @curRow + 1 AS row_number
                FROM wf_temp_datastore tds
                JOIN
                    (SELECT @curRow := 0) r -- Row numbers
                WHERE tds.start_date = v_start_date AND tds.business_process_id = v_bp_id ORDER BY tds.system_id
            ) t1
            JOIN (
                -- Select ids from temp transactions with row numbers
                SELECT tt.ID, @curRow2 := @curRow2 + 1 AS row_number
                FROM wf_temp_transactions tt
                JOIN
                    (SELECT @curRow2 := 0) r -- Row numbers
                JOIN business_process_view_2 bp 
                    ON tt.campaign_id = bp.campaign_id 
                WHERE tt.END_TIME > v_start_date 
                    AND bp.business_process_id = v_bp_id 
                ORDER BY tt.END_TIME
            ) t2 ON t1.row_number = t2.row_number
        ) AS temp
        ON temp.ds_id = ds.ID
        SET ds.transaction_id = temp.trans_id;
    END LOOP get_datastore_data;

    CLOSE datastore_cursor;

    SELECT CHARACTER_MAXIMUM_LENGTH INTO max_length
    FROM information_schema.columns
    WHERE table_schema = 'vbrain' AND   
        table_name = 'transactions' AND
        COLUMN_NAME = 'ERROR_TYPE';

    SELECT CHARACTER_MAXIMUM_LENGTH INTO track_id_max_length
    FROM information_schema.columns
    WHERE table_schema = 'vbrain' AND   
        table_name = 'transactions' AND
        COLUMN_NAME = 'TRACKING_ID';

    -- Select from the dumps, groups, bot in temporary in mamory table
    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`tmp`;
    CREATE TEMPORARY TABLE `vbrain`.`tmp` engine=memory AS        
    SELECT tt.ID AS transaction_id,
           b.ID AS botid,
           tt.STATUS AS status,
           tt.START_TIME AS hit_submissionDate, 
           IF(ds.process_time IS NOT NULL, FROM_UNIXTIME(UNIX_TIMESTAMP(tt.START_TIME) + ds.process_time/1000), tt.END_TIME) AS hit_completionDate,
           IF(tt.STATUS = 1, 'Unkown Error', '') AS exception_type,
           tt.DESCRIPTION AS stepTitle,
           bp.country AS country, 
           tt.BP_UUID AS bp_instance_uuid,
           bp.function AS function,
           ds.error_cat AS error_cat,
           ds.error_msg AS error_msg,
           ds.tracking_id AS tracking_id,
           'BOT' AS WORKER_TYPE,
           0 AS OUT_COME,
           'vBrain' AS CREATED_BY
    FROM business_process_view_2 bp 
    JOIN bot b ON bp.bp_group_id = b.Process_Id
    INNER JOIN wf_temp_transactions tt ON tt.campaign_id = bp.campaign_id
    JOIN wf_temp_datastore ds ON ds.transaction_id = tt.ID
    WHERE b.ID > 0 AND b.isDisabled = 0
    LIMIT 2000;

    INSERT INTO `vbrain`.`tmp`
    SELECT tt.ID AS transaction_id,
           b.ID AS botid,
           tt.STATUS AS status,
           tt.START_TIME AS hit_submissionDate, 
           tt.END_TIME AS hit_completionDate,
           IF(tt.STATUS = 1, 'Unkown Error', '') AS exception_type,
           tt.DESCRIPTION AS stepTitle,
           bp.country AS country, 
           tt.BP_UUID AS bp_instance_uuid,
           bp.function AS function,
           1 AS error_cat,
           'This task has processing issues.' AS error_msg,
           '-' AS tracking_id,
           'BOT' AS WORKER_TYPE,
           0 AS OUT_COME,
           'vBrain' AS CREATED_BY
    FROM business_process_view_2 bp 
    JOIN bot b ON bp.bp_group_id = b.Process_Id
    INNER JOIN wf_temp_transactions tt ON tt.campaign_id = bp.campaign_id
    WHERE b.ID > 0 AND b.isDisabled = 0 
    AND tt.END_TIME IS NULL AND tt.STATUS = 1;


    SET autocommit = 0;

    -- Start SQL transaction
    START TRANSACTION;
    -- Promote to transactions from in memory temporary table
    INSERT INTO transactions (WORKER_ID,STATUS,START_TIME,END_TIME,EXCEPTION_TYPE,DESCRIPTION,COUNTRY,BP_UUID,B_FUNCTION,ERROR_CAT, ERROR_TYPE,TRACKING_ID,WORKER_TYPE,OUT_COME,CREATED_BY)
    SELECT botid, status, hit_submissionDate, hit_completionDate, exception_type,stepTitle, country, bp_instance_uuid, function,error_cat,SUBSTRING(error_msg, 1, max_length), SUBSTRING(tracking_id, 1, track_id_max_length), WORKER_TYPE, OUT_COME, CREATED_BY
    FROM `vbrain`.`tmp`;
    
    -- Delete (Move to trash) successfully promoted (moved to transactions table) rows 
    -- from temp tables (wf_temp_transactions, wf_temp_datastore)
    INSERT INTO wf_temp_transactions_trash (ID, STATUS, TITLE, BP_NAME, START_TIME, END_TIME, DESCRIPTION, BP_UUID, campaign_id, WF_ID) 
        SELECT ID, STATUS, TITLE, BP_NAME, START_TIME, END_TIME, DESCRIPTION, BP_UUID, campaign_id, WF_ID FROM wf_temp_transactions 
        WHERE ID IN (SELECT transaction_id FROM tmp);
    
    INSERT INTO wf_temp_datastore_trash (ID, name, transaction_id, error_cat, start_date, system_id, error_msg, tracking_id, business_process_id, wf_id, bp_uuid, end_date, process_time) 
        SELECT ID, name, transaction_id, error_cat, start_date, system_id, error_msg, tracking_id, business_process_id, wf_id, bp_uuid, end_date, process_time FROM wf_temp_datastore 
        WHERE transaction_id IN (SELECT transaction_id FROM tmp);
    
    DELETE FROM wf_temp_datastore WHERE transaction_id IN (SELECT transaction_id FROM tmp);
    DELETE FROM wf_temp_transactions WHERE ID IN (SELECT transaction_id FROM tmp);
    
    COMMIT;
    -- End SQL transaction 
    SET autocommit = 1;

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`tmp`;
END$$
DELIMITER ;

-- wf_temp_datastore_massage_sp
DROP PROCEDURE IF EXISTS vbrain.wf_temp_datastore_massage_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `wf_temp_datastore_massage_sp`()
BEGIN
        DECLARE v_bp_id INT(11);
        DECLARE v_convert_format VARCHAR(50);

        DECLARE finished INT(1) DEFAULT 0;

        DECLARE datastore_cursor CURSOR FOR
                SELECT business_process_id, start_date_convert_format FROM business_process_view_2 WHERE isDisabled = 0;


        DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;

        OPEN datastore_cursor;

        update_datastore_fields: LOOP
                FETCH datastore_cursor INTO v_bp_id, v_convert_format;
                IF finished = 1 THEN
                        LEAVE update_datastore_fields;
                END IF;

                -- WARNING!! Make sure to follow below order.
                -- Update Start date field format before updating wf_id
            
                -- 1. Convert start date field format
                UPDATE wf_temp_datastore SET start_date = STR_TO_DATE(start_date, v_convert_format) WHERE wf_id = 0 AND business_process_id = v_bp_id;
                -- 2. Update wf_id
                UPDATE wf_temp_datastore SET wf_id = UNIX_TIMESTAMP(start_date)*100000 + system_id WHERE wf_id = 0 AND business_process_id = v_bp_id;

        END LOOP update_datastore_fields;

        CLOSE datastore_cursor;
        
        -- Setting processing time for records having end date
        UPDATE wf_temp_datastore SET process_time = (UNIX_TIMESTAMP(end_date) - UNIX_TIMESTAMP(start_date))*1000 WHERE end_date IS NOT NULL AND process_time IS NULL;

        -- Update error cat for wf_temp_datastore data
        UPDATE vbrain.wf_temp_datastore ds
        JOIN (SELECT bp.business_process_id, Exception_Type, Exception_Value
                  FROM vbrain.exceptions e
                  JOIN vbrain.business_process_view_2 bp ON bp.lob_id = e.Lob) te
        ON ds.business_process_id = te.business_process_id
        SET ds.ERROR_CAT = te.Exception_Type
        WHERE ds.ERROR_CAT IS NULL AND ds.error_msg LIKE concat('%', te.Exception_Value, '%');
        
        -- Update bp_uuid 
        CALL update_ds_bp_uuid_sp_3();
END$$
DELIMITER ;


-- ----------------------
-- Fixing campaign import
-- ----------------------
CREATE TABLE IF NOT EXISTS wf_campaign_temp LIKE wf_campaign;

-- c_import_sp_2
DROP PROCEDURE IF EXISTS vbrain.c_import_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`c_import_sp_2`()
BEGIN
    DECLARE last_updated_date VARCHAR(50);
    DECLARE w VARCHAR(5000) DEFAULT NULL;

    SELECT LEAST(IFNULL(MAX(bp_lastmodified), FROM_UNIXTIME(0)), IFNULL(MAX(step_lastmodified), FROM_UNIXTIME(0))) INTO last_updated_date FROM wf_campaign;
    
    SET w = CONCAT('s.lastModified > \'',last_updated_date,'\' OR bp.lastModified > \'',last_updated_date, '\'');

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`c_import_tmp`;

    CREATE TEMPORARY TABLE `vbrain`.`c_import_tmp` (
        QE varchar(1000),
        QT varchar(1)
    ); 

    INSERT INTO c_import_tmp(QE, QT) VALUES 
    ('cm|id|mapping_id','S'),
    ('cm|deleted|deleted','S'),
    ('cm|stepIndex|step_index','S'),
    ('bp|id|campaign_id','S'),
    ('bp|title|bp_name','S'),
    ('bp|lastModified|bp_lastmodified','S'),
    ('s|id|step_id','S'),
    ('s|title|step_title','S'),
    ('s|lastModified|step_lastmodified','S'),
    ('CampaignMap cm','F'),
    ('Campaign s|id|=|cm|campaign','J'),
    ('Campaign bp|id|=|cm|parent','J'),
    (w,'W'),
    ('bp|lastModified|A','O'),
    ('s|lastModified|A','O'),
    ('100','L'),
    ('wf_campaign_temp|ii','T');
    
    SELECT * FROM c_import_tmp;

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`c_import_tmp`;
END$$
DELIMITER ;


-- wf_campaign_massage_sp
DROP PROCEDURE IF EXISTS vbrain.wf_campaign_massage_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`wf_campaign_massage_sp`()
BEGIN
    INSERT INTO wf_campaign (mapping_id,campaign_id,step_id,
        bp_name,step_title,deleted,
        step_index,bp_lastmodified,step_lastmodified)
    SELECT mapping_id,campaign_id,step_id,
        bp_name,step_title,deleted,
        step_index,bp_lastmodified,step_lastmodified 
    FROM wf_campaign_temp t
    ON DUPLICATE KEY UPDATE 
        bp_name=t.bp_name, step_title=t.step_title, 
        deleted=t.deleted, step_index=t.step_index,
        bp_lastmodified=t.bp_lastmodified, step_lastmodified=t.step_lastmodified;

    DELETE FROM wf_campaign_temp;
END$$
DELIMITER ;



-- import_details_sp
DROP PROCEDURE IF EXISTS vbrain.import_details_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `import_details_sp`()
BEGIN
    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`import_details_tmp`;

    CREATE TEMPORARY TABLE `vbrain`.`import_details_tmp` (
        entity varchar(1),
        import varchar(100),
        importParamValues varchar(100),
        post varchar(100),
        postParamValues varchar(100)
    );

    INSERT INTO import_details_tmp(entity, import, importParamValues, post, postParamValues) VALUES
    ('T','t_import_sp',NULL,NULL,NULL),
    ('T','bp_run_import_sp_2',NULL,'bp_run_massage_sp_2',NULL),
    ('D','ds_import_sp',NULL,'wf_temp_datastore_massage_sp',NULL),
    ('C','c_import_sp_2',NULL,'wf_campaign_massage_sp',NULL),
    ('S','ss_import_sp_2',NULL,NULL,NULL);
    
    SELECT * FROM import_details_tmp;

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`import_details_tmp`;
END$$
DELIMITER ;

-- ----------------------
-- WF 8.2 support
-- ----------------------

-- 8 new tables
CREATE TABLE IF NOT EXISTS 82_wf_bp_run LIKE wf_bp_run;
CREATE TABLE IF NOT EXISTS 82_wf_business_process LIKE wf_business_process;
CREATE TABLE IF NOT EXISTS 82_wf_campaign LIKE wf_campaign;
CREATE TABLE IF NOT EXISTS 82_wf_campaign_temp LIKE wf_campaign_temp;
CREATE TABLE IF NOT EXISTS 82_wf_temp_datastore LIKE wf_temp_datastore;
CREATE TABLE IF NOT EXISTS 82_wf_temp_datastore_trash LIKE wf_temp_datastore_trash;
CREATE TABLE IF NOT EXISTS 82_wf_temp_transactions LIKE wf_temp_transactions;
CREATE TABLE IF NOT EXISTS 82_wf_temp_transactions_trash LIKE wf_temp_transactions_trash;

-- 82_import_details_sp
DROP PROCEDURE IF EXISTS vbrain.82_import_details_sp;

DELIMITER $$
$$
CREATE PROCEDURE vbrain.82_import_details_sp()
BEGIN
    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`82_import_details_sp`;

    CREATE TEMPORARY TABLE `vbrain`.`82_import_details_tmp` (
        entity varchar(1),
        import varchar(100),
        importParamValues varchar(100),
        post varchar(100),
        postParamValues varchar(100)
    );
    
    INSERT INTO 82_import_details_tmp(entity, import, importParamValues, post, postParamValues) VALUES
    ('T','82_t_import_sp',NULL,NULL,NULL),
    ('T','82_bp_run_import_sp_2',NULL,'82_bp_run_massage_sp_2',NULL),
    ('D','82_ds_import_sp',NULL,'82_wf_temp_datastore_massage_sp',NULL),
    ('C','82_c_import_sp_2',NULL,'82_wf_campaign_massage_sp',NULL);
    
    SELECT * FROM 82_import_details_tmp;

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`82_import_details_tmp`;
END$$
DELIMITER ;

-- 82_t_import_sp
DROP PROCEDURE IF EXISTS vbrain.`82_t_import_sp`;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`82_t_import_sp`()
BEGIN
    DECLARE lastupdated_wf_id BIGINT(20) DEFAULT 0;
    DECLARE max_submissionDate DATETIME DEFAULT NULL;
    DECLARE min_submissionDate DATETIME DEFAULT NULL;        
    DECLARE mappingIdList VARCHAR(2000) DEFAULT NULL;
    DECLARE w VARCHAR(5000) DEFAULT NULL;

    SET min_submissionDate = DATE_SUB(NOW(), INTERVAL 15 day);
    
    SELECT MAX(wf_id), MAX(dt) INTO lastupdated_wf_id, max_submissionDate FROM (SELECT MAX(wf_id) AS wf_id, MAX(END_TIME) AS dt FROM vbrain.82_wf_temp_transactions UNION ALL SELECT MAX(wf_id) AS wf_id, MAX(END_TIME) AS dt FROM vbrain.82_wf_temp_transactions_trash) AS t;

    IF max_submissionDate IS NULL THEN
        SET max_submissionDate = min_submissionDate;
    END IF;

    SELECT GROUP_CONCAT(bp.mapping_id SEPARATOR ',') INTO mappingIdList
    FROM 82_wf_business_process bp JOIN groups g ON g.id = bp.group_process_id
    WHERE g.isDisabled = 0;

   	IF mappingIdList IS NOT NULL THEN
	    IF IFNULL(lastupdated_wf_id,0) = 0 THEN
	        SET w = CONCAT('AwsHit.id > (SELECT MAX(id) FROM wfdb.AwsHit WHERE submissionDate < \'',DATE(max_submissionDate),'\') AND (Run.status=\'COMPLETED\' OR Run.hasProcessingIssues = 1)');
	    ELSE
	        SET w = CONCAT('(', 82_t_import_sub_func(min_submissionDate), ')', ' AND (Run.status=\'COMPLETED\' OR Run.hasProcessingIssues = 1)');
	    END IF;
    
        SET w = CONCAT(w, ' AND Run.campaignMap_id IN (',mappingIdList,')');

	    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`82_t_import_tmp`;
	
	    CREATE TEMPORARY TABLE `vbrain`.`82_t_import_tmp` (
	        QE varchar(1000),
	        QT varchar(1)
	    );
	
	    INSERT INTO 82_t_import_tmp(QE, QT) VALUES
	    ('Run|title|TITLE','S'),
	    ('Run|title|DESCRIPTION','S'),
	    ('AwsHit|submissionDate|START_TIME','S'),
	    ('Run|campaign_id|CAMPAIGN_ID','S'),
	    ('Run|rootRunUUID|BP_UUID','S'),
	    ('AwsHit|completionDate|END_TIME','S'),
	    ('Run|hasProcessingIssues|STATUS','S'),
	    ('AwsHit|id|wf_id','S'),
	    ('Run','F'),
	    ('AwsHit|run_id|=|Run|id','J'),
	    (w,'W'),
	    ('AwsHit|id|A','O'),
	    ('5000','L'),
	    ('82_wf_temp_transactions|ii','T');
	
	    SELECT * FROM 82_t_import_tmp;
	
	    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`82_t_import_tmp`;
   	END IF;
END$$
DELIMITER ;


-- 82_t_import_sub_func
DROP FUNCTION IF EXISTS vbrain.`82_t_import_sub_func`;

DELIMITER $$
$$
CREATE FUNCTION vbrain.`82_t_import_sub_func`(p_max_submissionDate DATETIME) RETURNS varchar(5000) CHARSET latin1
BEGIN
    DECLARE v_cmp_id INT(11);
    DECLARE v_max_wf_id INT(11) DEFAULT 1;
    DECLARE v_max_wf_id_str VARCHAR(500) DEFAULT NULL;
    DECLARE finished INT(1) DEFAULT 0;
    DECLARE sub_str VARCHAR(5000) DEFAULT '';
    
    DECLARE t_cursor CURSOR FOR
        SELECT c.campaign_id, b.WF_ID FROM 82_wf_business_process bp JOIN 82_wf_campaign c ON c.mapping_id = bp.mapping_id LEFT OUTER JOIN (SELECT CAMPAIGN_ID, MAX(WF_ID) AS WF_ID FROM (SELECT CAMPAIGN_ID, MAX(WF_ID) AS WF_ID FROM 82_wf_temp_transactions WHERE WF_ID IS NOT NULL GROUP BY CAMPAIGN_ID UNION ALL SELECT CAMPAIGN_ID, MAX(WF_ID) AS WF_ID FROM 82_wf_temp_transactions_trash WHERE WF_ID IS NOT NULL GROUP BY CAMPAIGN_ID) T GROUP BY CAMPAIGN_ID) b ON c.campaign_id = b.CAMPAIGN_ID;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;

    OPEN t_cursor;

    get_t_data: LOOP
        FETCH t_cursor INTO v_cmp_id, v_max_wf_id;
        IF finished = 1 THEN
            LEAVE get_t_data;
        END IF;

        SET v_max_wf_id_str = CONCAT(v_max_wf_id);

        IF IFNULL(v_max_wf_id,0) = 0 THEN
            SET v_max_wf_id_str = CONCAT('(SELECT IFNULL(MAX(id),0) FROM wfdb.AwsHit WHERE submissionDate < \'',DATE(p_max_submissionDate),'\')');
        END IF;

        SET sub_str = CONCAT(sub_str, ' (AwsHit.id > ', v_max_wf_id_str , ' AND Run.campaign_id = ', v_cmp_id, ') OR');

    END LOOP get_t_data;

    CLOSE t_cursor;

    IF sub_str <> '' THEN
        SET sub_str = SUBSTRING(sub_str, 1, CHAR_LENGTH(sub_str) - 2);
    END IF;

    RETURN sub_str;
END$$
DELIMITER ;


-- 82_bp_run_import_sp_2
DROP PROCEDURE IF EXISTS vbrain.`82_bp_run_import_sp_2`;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`82_bp_run_import_sp_2`()
BEGIN
	DECLARE v_max_wf_id BIGINT(20) DEFAULT 0;
    DECLARE min_start_date DATETIME DEFAULT NULL;
    DECLARE campaignIdList VARCHAR(2000) DEFAULT NULL;
    DECLARE w VARCHAR(5000) DEFAULT NULL;

    SELECT MAX(max_wf_id) INTO v_max_wf_id FROM 82_wf_bp_run;
    
    SET min_start_date = DATE_SUB(NOW(), INTERVAL 50 day);

    SELECT GROUP_CONCAT(c.campaign_id SEPARATOR ',') INTO campaignIdList
    FROM 82_wf_business_process bp 
	JOIN groups g ON g.id = bp.group_process_id
	JOIN 82_wf_campaign c ON c.mapping_id = bp.mapping_id
    WHERE g.isDisabled = 0;

   	IF campaignIdList IS NOT NULL THEN
	    IF IFNULL(v_max_wf_id,0) = 0 THEN
	        SET w = CONCAT('startDate > \'',DATE(min_start_date),'\'');
	    ELSE
	        SET w = CONCAT('(', 82_bp_run_import_sub_func_2(), ')');
	    END IF;

        SET w = CONCAT(w, ' AND campaign_id IN (',campaignIdList,') GROUP BY rootRunUUID');
	
	    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`82_bp_run_import_tmp`;
	
	    CREATE TEMPORARY TABLE `vbrain`.`82_bp_run_import_tmp` (
	        QE varchar(1000),
	        QT varchar(1)
	    );
	
	    INSERT INTO 82_bp_run_import_tmp(QE, QT) VALUES
	    ('|campaign_id|campaign_id','S'),
	    ('|rootRunUUID|bp_uuid','S'),
	    ('|MIN(startDate)|start_time','S'),
	    ('|IFNULL(MAX(endDate),MAX(startDate))|end_time','S'),
	    ('|MAX(id)|max_wf_id','S'),
	    ('Run','F'),
	    (w,'W'),
	    ('|startDate|A','O'),
	    ('1000','L'),
	    ('82_wf_bp_run|i','T');
	
	    SELECT * FROM 82_bp_run_import_tmp;
	
	    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`82_bp_run_import_tmp`;
   	END IF;
END$$
DELIMITER ;


-- 82_bp_run_import_sub_func_2
DROP FUNCTION IF EXISTS vbrain.`82_bp_run_import_sub_func_2`;

DELIMITER $$
$$
CREATE FUNCTION vbrain.`82_bp_run_import_sub_func_2`() RETURNS varchar(5000) CHARSET latin1
BEGIN
    DECLARE v_cmp_id INT(11);
    DECLARE v_max_wf_id INT(11) DEFAULT 1;
    DECLARE v_max_wf_id_str VARCHAR(500) DEFAULT NULL;
    DECLARE finished INT(1) DEFAULT 0;
    DECLARE sub_str VARCHAR(5000) DEFAULT '';
    DECLARE min_start_date DATETIME DEFAULT NULL;

    DECLARE bp_run_cursor CURSOR FOR
        SELECT c.campaign_id, MAX(r.max_wf_id) FROM 82_wf_business_process bp JOIN 82_wf_campaign c ON c.mapping_id = bp.mapping_id LEFT JOIN 82_wf_bp_run r ON r.campaign_id = c.campaign_id GROUP BY c.campaign_id;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;

    SET min_start_date = DATE_SUB(NOW(), INTERVAL 50 day);

    OPEN bp_run_cursor;

    get_bp_run_data: LOOP
        FETCH bp_run_cursor INTO v_cmp_id, v_max_wf_id;
        IF finished = 1 THEN
            LEAVE get_bp_run_data;
        END IF;
        
        IF IFNULL(v_max_wf_id,0) = 0 THEN
            SET v_max_wf_id_str = CONCAT('startDate > \'',DATE(min_start_date),'\'');
        ELSE
            SET v_max_wf_id_str = CONCAT('id > ',v_max_wf_id);
        END IF;

        SET sub_str = CONCAT(sub_str, ' (', v_max_wf_id_str , ' AND campaign_id = ', v_cmp_id, ') OR');

    END LOOP get_bp_run_data;

    CLOSE bp_run_cursor;

    IF sub_str <> '' THEN
        SET sub_str = SUBSTRING(sub_str, 1, CHAR_LENGTH(sub_str) - 2);
    END IF;

    RETURN sub_str;
END$$
DELIMITER ;

-- 82_bp_run_massage_sp_2
DROP PROCEDURE IF EXISTS vbrain.`82_bp_run_massage_sp_2`;

DELIMITER $$
$$
CREATE PROCEDURE vbrain.`82_bp_run_massage_sp_2`()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;  
        RESIGNAL;  
    END;
    SET autocommit = 0;

    
    START TRANSACTION;
    
    DROP TEMPORARY TABLE IF EXISTS 82_bp_run_massage_tmp;
    CREATE TEMPORARY TABLE 82_bp_run_massage_tmp engine=memory AS
    SELECT business_process_id, campaign_id, bp_uuid, MIN(start_time) AS start_time, MAX(end_time) AS end_time, MAX(max_wf_id) AS max_wf_id FROM 82_wf_bp_run GROUP BY bp_uuid;
    
    DELETE FROM wf_bp_run;
    
    INSERT INTO 82_wf_bp_run(business_process_id,campaign_id,bp_uuid,start_time,end_time,max_wf_id) 
    SELECT business_process_id,campaign_id,bp_uuid,start_time,end_time,max_wf_id FROM 82_bp_run_massage_tmp;
    
    DROP TEMPORARY TABLE IF EXISTS 82_bp_run_massage_tmp;
    
    COMMIT;
    
    SET autocommit = 1;
    
    UPDATE 82_wf_bp_run r JOIN 82_wf_business_process bp JOIN 82_wf_campaign c ON c.mapping_id = bp.mapping_id SET r.business_process_id = bp.id WHERE r.business_process_id IS NULL;
    
END$$
DELIMITER ;


-- 82_ds_import_sp
DROP PROCEDURE IF EXISTS vbrain.`82_ds_import_sp`;

DELIMITER $$
$$
CREATE PROCEDURE vbrain.`82_ds_import_sp`()
BEGIN
    DECLARE v_bp_id INT(11);
    DECLARE v_counter INT(11) DEFAULT 1;
    DECLARE row_count INT(11);
     DECLARE finished INT(1) DEFAULT 0;

    DECLARE datastore_cursor CURSOR FOR 
           SELECT bp.id FROM 82_wf_business_process bp JOIN groups g ON g.id = bp.group_process_id WHERE g.isDisabled = 0;
       
       
     DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
       
       OPEN datastore_cursor;
    SELECT FOUND_ROWS() INTO row_count ;
   
    get_datastore_data: LOOP
         FETCH datastore_cursor INTO v_bp_id;
         IF finished = 1 THEN 
            LEAVE get_datastore_data;
        END IF;
    
        
        CALL 82_ds_import_sub_sp(v_bp_id, IF(v_counter = row_count, 1, 0));
        
        SET v_counter = v_counter + 1;
    
    END LOOP get_datastore_data;
 
     CLOSE datastore_cursor;
END$$
DELIMITER ;

-- 82_ds_import_sub_sp
DROP PROCEDURE IF EXISTS vbrain.`82_ds_import_sub_sp`;

DELIMITER $$
$$
CREATE PROCEDURE vbrain.`82_ds_import_sub_sp`(IN bp_id INT(11), IN include_limit TINYINT(1))
BEGIN
    DECLARE max_wf_id BIGINT(20) DEFAULT 0;
    
    DECLARE ds_display_name VARCHAR(100) DEFAULT NULL;
    DECLARE postgre_start_date_format VARCHAR(50);
    DECLARE ds_table_name VARCHAR(500);
    DECLARE field_tracking_id VARCHAR(200);
    DECLARE field_error_msg VARCHAR(200);
    DECLARE field_system_id VARCHAR(200);
    DECLARE field_start_date VARCHAR(200);
    DECLARE field_id_order VARCHAR(200);
    DECLARE field_bp_uuid VARCHAR(200);
    DECLARE field_end_date VARCHAR(200);
    DECLARE field_process_time VARCHAR(200);

    DECLARE front TEXT DEFAULT NULL;
    DECLARE frontlen INT DEFAULT NULL;
    DECLARE lp_str VARCHAR(1000);
    DECLARE lp_substr TEXT DEFAULT NULL;

    DECLARE w VARCHAR(5000) DEFAULT NULL;

    DECLARE max_wf_id_tds BIGINT(20) DEFAULT 0;
    DECLARE max_wf_id_tdst BIGINT(20) DEFAULT 0;

    DECLARE start_date_str VARCHAR(500);

    SELECT IFNULL(MAX(tds.wf_id),0) INTO max_wf_id_tds FROM 82_wf_temp_datastore tds WHERE tds.business_process_id = bp_id;
    SELECT IFNULL(MAX(tdst.wf_id),0) INTO max_wf_id_tdst FROM 82_wf_temp_datastore_trash tdst WHERE tdst.business_process_id = bp_id;
    SELECT GREATEST(max_wf_id_tds,max_wf_id_tdst) INTO max_wf_id;
    
    IF max_wf_id = 0 THEN
         SELECT IFNULL(UNIX_TIMESTAMP(MIN(start_time))*100000,0) INTO max_wf_id FROM 82_wf_temp_transactions WHERE campaign_id = (SELECT campaign_id FROM business_process_view_2 WHERE business_process_id = bp_id); 
    END IF;

    SELECT display_name, start_date_postgre_format, mapped_datastores, tracking_id_field, error_msg_field, system_id_field, start_date_field, id_order_field, bp_uuid_field, end_date_field, process_time_field
            INTO ds_display_name, postgre_start_date_format, ds_table_name, field_tracking_id, field_error_msg, field_system_id, field_start_date, field_id_order, field_bp_uuid, field_end_date, field_process_time
            FROM 82_wf_business_process bp WHERE id = bp_id;

    SELECT CONCAT('to_timestamp(',field_start_date,', \'',postgre_start_date_format,'\')') INTO start_date_str;
    SELECT CONCAT('(EXTRACT(EPOCH FROM ',start_date_str,')*100000+ CAST(',field_system_id,' AS BIGINT)) > ',max_wf_id) INTO w;
        
    SET w = CONCAT('(',w,') AND ',field_start_date,' IS NOT NULL');

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`82_d_import_tmp`;

    CREATE TEMPORARY TABLE `vbrain`.`82_d_import_tmp` (
            QE varchar(1000),
            QT varchar(1)
    );

    INSERT INTO 82_d_import_tmp(QE, QT) VALUES
    (CONCAT('|',IFNULL(field_tracking_id,'NULL'),'|tracking_id'),'S'),
    (CONCAT('|',IFNULL(field_error_msg,'NULL'),'|error_msg'),'S'),
    (CONCAT('|',IFNULL(field_system_id,'NULL'),'|system_id'),'S'),
    (CONCAT('|',IFNULL(field_start_date,'NULL'),'|start_date'),'S'),
    (CONCAT('|\'',ds_display_name,'\'|name'),'S'),
    (CONCAT('|',bp_id,'|business_process_id'),'S'),
    (CONCAT('|',IFNULL(field_bp_uuid,'NULL'),'|bp_uuid'),'S'),
    (CONCAT('|',IFNULL(field_end_date,'NULL'),'|end_date'),'S'),
    (CONCAT('|',IFNULL(field_process_time,'NULL'),'|process_time'),'S'),
    (ds_table_name,'F'),
    (w,'W');

    IF field_id_order IS NOT NULL THEN
        SET lp_str = field_id_order;

        iterator: LOOP
            IF LENGTH(TRIM(lp_str)) = 0 OR lp_str IS NULL THEN
                LEAVE iterator;
            END IF;
            SET front = SUBSTRING_INDEX(lp_str,'$$',1);
            SET frontlen = LENGTH(front);
            SET lp_substr = TRIM(front);

            INSERT INTO 82_d_import_tmp(QE, QT) VALUES
            (CONCAT('|',lp_substr,'|A'),'O');

            SET lp_str = INSERT(lp_str,1,frontlen + 2,'');
        END LOOP;
    END IF;

    INSERT INTO 82_d_import_tmp(QE, QT) VALUES
    ('1000','L'),
    ('82_wf_temp_datastore|ii','T');

    SELECT * FROM 82_d_import_tmp;

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`82_d_import_tmp`;
END$$
DELIMITER ;

-- 82_wf_temp_datastore_massage_sp
DROP PROCEDURE IF EXISTS vbrain.`82_wf_temp_datastore_massage_sp`;

DELIMITER $$
$$
CREATE PROCEDURE vbrain.`82_wf_temp_datastore_massage_sp`()
BEGIN
    DECLARE v_bp_id INT(11);
    DECLARE v_convert_format VARCHAR(50);

    DECLARE finished INT(1) DEFAULT 0;

    DECLARE datastore_cursor CURSOR FOR
        SELECT bp.id, bp.start_date_convert_format FROM 82_wf_business_process bp JOIN groups g ON g.id = bp.group_process_id WHERE g.isDisabled = 0;


    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;

    OPEN datastore_cursor;

    update_datastore_fields: LOOP
        FETCH datastore_cursor INTO v_bp_id, v_convert_format;
        IF finished = 1 THEN
                LEAVE update_datastore_fields;
        END IF;

        UPDATE 82_wf_temp_datastore SET start_date = STR_TO_DATE(start_date, v_convert_format) WHERE wf_id = 0 AND business_process_id = v_bp_id;
        
        UPDATE 82_wf_temp_datastore SET wf_id = UNIX_TIMESTAMP(start_date)*100000 + system_id WHERE wf_id = 0 AND business_process_id = v_bp_id;

    END LOOP update_datastore_fields;

    CLOSE datastore_cursor;
   
    UPDATE 82_wf_temp_datastore SET process_time = (UNIX_TIMESTAMP(end_date) - UNIX_TIMESTAMP(start_date))*1000 WHERE end_date IS NOT NULL AND process_time IS NULL;

    UPDATE 82_wf_temp_datastore ds
    JOIN (SELECT bp.id AS business_process_id, e.Exception_Type, e.Exception_Value
              FROM exceptions e
              JOIN groups func ON func.Parent_Id = e.Lob
              JOIN groups proc ON func.ID = proc.Parent_Id
              JOIN 82_wf_business_process bp ON bp.group_process_id = proc.ID) te
    ON ds.business_process_id = te.business_process_id
    SET ds.ERROR_CAT = te.Exception_Type
    WHERE ds.ERROR_CAT IS NULL AND ds.error_msg LIKE concat('%', te.Exception_Value, '%');
    
    
    CALL 82_update_ds_bp_uuid_sp_3();
END$$
DELIMITER ;

-- 82_update_ds_bp_uuid_sp_3
DROP PROCEDURE IF EXISTS vbrain.`82_update_ds_bp_uuid_sp_3`;

DELIMITER $$
$$
CREATE PROCEDURE vbrain.`82_update_ds_bp_uuid_sp_3`()
BEGIN
    UPDATE 82_wf_temp_datastore ds JOIN 
    (SELECT r.bp_uuid AS bp_uuid, tds.id AS tds_id FROM 82_wf_bp_run r JOIN 82_wf_temp_datastore tds ON tds.business_process_id = r.business_process_id WHERE tds.start_date >= (r.start_time-INTERVAL 1 SECOND) AND tds.start_date < r.end_time) run
    ON ds.id = run.tds_id 
    SET ds.bp_uuid = run.bp_uuid 
    WHERE ds.bp_uuid IS NULL AND ds.business_process_id IN (15, 16, 17, 18, 20, 21);
        
    
    DROP TEMPORARY TABLE IF EXISTS 82_tmp_t_massage;
    CREATE TEMPORARY TABLE 82_tmp_t_massage engine=memory AS        
    SELECT t.business_process_id AS bp_id, MIN(t.start_time) AS t_min_start_time 
    FROM 82_wf_bp_run t 
    JOIN(
        SELECT business_process_id, MIN(start_date) AS min_start_date 
        FROM 82_wf_temp_datastore 
        WHERE bp_uuid IS NULL 
        GROUP BY business_process_id
    ) d ON d.business_process_id = t.business_process_id 
    WHERE t.start_time > d.min_start_date 
    GROUP BY t.business_process_id;

    DROP TEMPORARY TABLE IF EXISTS 82_tmp_d_massage;
    CREATE TEMPORARY TABLE 82_tmp_d_massage engine=memory AS 
    SELECT d.business_process_id AS bp_id, MIN(d.start_date) AS d_min_start_date 
    FROM 82_wf_temp_datastore d 
    JOIN (
        SELECT bp.id AS business_process_id, MIN(t.start_time) AS min_start_time 
        FROM 82_wf_temp_transactions t 
        JOIN 82_wf_campaign c ON c.campaign_id = t.campaign_id
        JOIN 82_wf_business_process bp ON bp.mapping_id = c.mapping_id 
        GROUP BY bp.id
    ) t ON d.business_process_id = t.business_process_id 
    WHERE d.bp_uuid IS NULL AND d.start_date > t.min_start_time 
    GROUP BY d.business_process_id;
    
    
    SET @bp_id_d = 0;
    SET @bp_id_t = 0;
    
    UPDATE 82_wf_temp_datastore ds 
    JOIN (
        SELECT d.id as ds_id, t.id AS trans_id, t.BP_UUID as bp_uuid 
        FROM (            
            SELECT CONCAT(@row_number_d:=CASE WHEN @bp_id_d = business_process_id THEN @row_number_d + 1 ELSE 1 END,':',@bp_id_d:= business_process_id) AS map_key, id
            FROM (
                SELECT d.business_process_id, d.id 
                FROM 82_wf_temp_datastore d
                JOIN 82_tmp_t_massage t_md ON t_md.bp_id = d.business_process_id
                WHERE d.bp_uuid IS NULL AND d.start_date >= (t_md.t_min_start_time - INTERVAL 1 SECOND)
                ORDER BY d.business_process_id, d.start_date, d.system_id
            ) ds
        ) d
        JOIN (
            SELECT CONCAT(@row_number_t:=CASE WHEN @bp_id_t = business_process_id THEN @row_number_t + 1 ELSE 1 END,':',@bp_id_t:= business_process_id) AS map_key, ID, BP_UUID 
            FROM (
                SELECT bp.id AS business_process_id, t.ID, t.BP_UUID 
                FROM 82_wf_temp_transactions t
                JOIN 82_wf_campaign c ON c.campaign_id = t.campaign_id
                JOIN 82_wf_business_process bp ON bp.mapping_id = c.mapping_id 
                JOIN 82_tmp_d_massage d_md ON d_md.bp_id = bp.id
                WHERE t.campaign_id IS NOT NULL AND t.start_time IS NOT NULL AND t.start_time > d_md.d_min_start_date 
                ORDER BY t.campaign_id, t.start_time, t.wf_id
            ) ts
        ) t
        ON t.map_key = d.map_key
    ) AS map
    ON map.ds_id = ds.ID
    SET ds.bp_uuid = map.bp_uuid; 
    
    DROP TEMPORARY TABLE IF EXISTS 82_tmp_t_massage;
    DROP TEMPORARY TABLE IF EXISTS 82_tmp_d_massage;
END$$
DELIMITER ;

-- 82_c_import_sp_2
DROP PROCEDURE IF EXISTS vbrain.82_c_import_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`82_c_import_sp_2`()
BEGIN
    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`82_c_import_tmp`;

    CREATE TEMPORARY TABLE `vbrain`.`82_c_import_tmp` (
        QE varchar(1000),
        QT varchar(1)
    ); 

    INSERT INTO 82_c_import_tmp(QE, QT) VALUES 
    ('cm|id|mapping_id','S'),
    ('cm|deleted|deleted','S'),
    ('cm|stepIndex|step_index','S'),
    ('bp|id|campaign_id','S'),
    ('bp|title|bp_name','S'),
    ('bp|lastModified|bp_lastmodified','S'),
    ('s|id|step_id','S'),
    ('s|title|step_title','S'),
    ('s|lastModified|step_lastmodified','S'),
    ('CampaignMap cm','F'),
    ('Campaign s|id|=|cm|campaign','J'),
    ('Campaign bp|id|=|cm|parent','J'),
    ('bp.title LIKE \'%CM-TDR%\'','W'),
    ('bp|lastModified|A','O'),
    ('s|lastModified|A','O'),
    ('100','L'),
    ('82_wf_campaign_temp|ii','T');
    
    SELECT * FROM 82_c_import_tmp;

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`82_c_import_tmp`;
END$$
DELIMITER ;

-- 82_wf_campaign_massage_sp
DROP PROCEDURE IF EXISTS vbrain.82_wf_campaign_massage_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`82_wf_campaign_massage_sp`()
BEGIN
    INSERT INTO 82_wf_campaign (mapping_id,campaign_id,step_id,
        bp_name,step_title,deleted,
        step_index,bp_lastmodified,step_lastmodified)
    SELECT mapping_id,campaign_id,step_id,
        bp_name,step_title,deleted,
        step_index,bp_lastmodified,step_lastmodified 
    FROM 82_wf_campaign_temp t
    ON DUPLICATE KEY UPDATE 
        bp_name=t.bp_name, step_title=t.step_title, 
        deleted=t.deleted, step_index=t.step_index,
        bp_lastmodified=t.bp_lastmodified, step_lastmodified=t.step_lastmodified;

    DELETE FROM 82_wf_campaign_temp;
END$$
DELIMITER ;


-- 82_update_transactions_sp_2
DROP PROCEDURE IF EXISTS vbrain.`82_update_transactions_sp_2`;

DELIMITER $$
$$
CREATE PROCEDURE vbrain.`82_update_transactions_sp_2`()
BEGIN
    DECLARE v_start_date varchar(100);
    DECLARE v_bp_id varchar(100);
    DECLARE max_length INTEGER DEFAULT 0;
    DECLARE track_id_max_length INTEGER DEFAULT 0;
    DECLARE finished INTEGER DEFAULT 0;
    DECLARE datastore_cursor CURSOR FOR 
        SELECT DISTINCT start_date, business_process_id FROM 82_wf_temp_datastore WHERE bp_uuid IS NULL AND transaction_id IS NULL ORDER BY start_date;
              
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
 
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;  
        RESIGNAL;  
    END;
   
    UPDATE 82_wf_temp_datastore ds 
    JOIN (
        SELECT t.id AS trans_id, d.id as ds_id FROM
        (SELECT CONCAT(@row_number:=CASE WHEN @bp_uuid = bp_uuid THEN @row_number + 1 ELSE 1 END,':',@bp_uuid:=bp_uuid) as map_key, id FROM 82_wf_temp_datastore WHERE bp_uuid IS NOT NULL ORDER BY bp_uuid, system_id) d
        JOIN
        (SELECT CONCAT(@row_number:=CASE WHEN @BP_UUID = BP_UUID THEN @row_number + 1 ELSE 1 END,':',@BP_UUID:=BP_UUID) as map_key, ID FROM 82_wf_temp_transactions WHERE BP_UUID IS NOT NULL ORDER BY BP_UUID, wf_id) t
        ON t.map_key = d.map_key
    ) AS map
    ON map.ds_id = ds.ID
    SET ds.transaction_id = map.trans_id;

    OPEN datastore_cursor;
    
    get_datastore_data: LOOP
        FETCH datastore_cursor INTO v_start_date,v_bp_id;
        IF finished = 1 THEN 
            LEAVE get_datastore_data;
        END IF;
        UPDATE 82_wf_temp_datastore ds 
        JOIN (
            SELECT t2.ID AS trans_id, t1.ID AS ds_id
            FROM (
                
                SELECT tds.ID, @curRow := @curRow + 1 AS row_number
                FROM 82_wf_temp_datastore tds
                JOIN
                    (SELECT @curRow := 0) r 
                WHERE tds.start_date = v_start_date AND tds.business_process_id = v_bp_id ORDER BY tds.system_id
            ) t1
            JOIN (
                
                SELECT tt.ID, @curRow2 := @curRow2 + 1 AS row_number
                FROM 82_wf_temp_transactions tt
                JOIN
                    (SELECT @curRow2 := 0) r 
                JOIN 82_wf_campaign c ON c.campaign_id = tt.campaign_id
                JOIN 82_wf_business_process bp ON bp.mapping_id = c.mapping_id 
                WHERE tt.END_TIME > v_start_date 
                    AND bp.id = v_bp_id 
                ORDER BY tt.END_TIME
            ) t2 ON t1.row_number = t2.row_number
        ) AS temp
        ON temp.ds_id = ds.ID
        SET ds.transaction_id = temp.trans_id;
    END LOOP get_datastore_data;

    CLOSE datastore_cursor;

    SELECT CHARACTER_MAXIMUM_LENGTH INTO max_length
    FROM information_schema.columns
    WHERE table_schema = 'vbrain' AND   
        table_name = 'transactions' AND
        COLUMN_NAME = 'ERROR_TYPE';

    SELECT CHARACTER_MAXIMUM_LENGTH INTO track_id_max_length
    FROM information_schema.columns
    WHERE table_schema = 'vbrain' AND   
        table_name = 'transactions' AND
        COLUMN_NAME = 'TRACKING_ID';

    
    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`82_tmp`;
    CREATE TEMPORARY TABLE `vbrain`.`82_tmp` engine=memory AS        
    SELECT tt.ID AS transaction_id,
           b.ID AS botid,
           tt.STATUS AS status,
           tt.START_TIME AS hit_submissionDate, 
           IF(ds.process_time IS NOT NULL, FROM_UNIXTIME(UNIX_TIMESTAMP(tt.START_TIME) + ds.process_time/1000), tt.END_TIME) AS hit_completionDate,
           IF(tt.STATUS = 1, 'Unkown Error', '') AS exception_type,
           tt.DESCRIPTION AS stepTitle,
           country.Name AS country, 
           tt.BP_UUID AS bp_instance_uuid,
           func.Name AS function,
           ds.error_cat AS error_cat,
           ds.error_msg AS error_msg,
           ds.tracking_id AS tracking_id,
           'BOT' AS WORKER_TYPE,
           0 AS OUT_COME,
           'vBrain' AS CREATED_BY
    FROM 82_wf_business_process bp
    JOIN 82_wf_campaign c ON c.mapping_id = bp.mapping_id 
    JOIN groups proc ON proc.ID = bp.group_process_id
    JOIN groups func ON func.ID = proc.Parent_Id
    JOIN groups lob ON lob.ID = func.Parent_Id
    JOIN groups country ON country.ID = lob.Parent_Id
    JOIN bot b ON bp.group_process_id = b.Process_Id
    INNER JOIN 82_wf_temp_transactions tt ON tt.campaign_id = c.campaign_id
    JOIN 82_wf_temp_datastore ds ON ds.transaction_id = tt.ID
    WHERE b.ID > 0 AND b.isDisabled = 0
    LIMIT 2000;

    SET autocommit = 0;
    
    START TRANSACTION;
    
    INSERT INTO transactions (WORKER_ID,STATUS,START_TIME,END_TIME,EXCEPTION_TYPE,DESCRIPTION,COUNTRY,BP_UUID,B_FUNCTION,ERROR_CAT, ERROR_TYPE,TRACKING_ID,WORKER_TYPE,OUT_COME,CREATED_BY)
    SELECT botid, status, hit_submissionDate, hit_completionDate, exception_type,stepTitle, country, bp_instance_uuid, function,error_cat,SUBSTRING(error_msg, 1, max_length), SUBSTRING(tracking_id, 1, track_id_max_length), WORKER_TYPE, OUT_COME, CREATED_BY
    FROM `vbrain`.`82_tmp`;
    
    INSERT INTO 82_wf_temp_transactions_trash (ID, STATUS, TITLE, BP_NAME, START_TIME, END_TIME, DESCRIPTION, BP_UUID, campaign_id, WF_ID) 
        SELECT ID, STATUS, TITLE, BP_NAME, START_TIME, END_TIME, DESCRIPTION, BP_UUID, campaign_id, WF_ID FROM 82_wf_temp_transactions 
        WHERE ID IN (SELECT transaction_id FROM 82_tmp);
    
    INSERT INTO 82_wf_temp_datastore_trash (ID, name, transaction_id, error_cat, start_date, system_id, error_msg, tracking_id, business_process_id, wf_id, bp_uuid, end_date, process_time) 
        SELECT ID, name, transaction_id, error_cat, start_date, system_id, error_msg, tracking_id, business_process_id, wf_id, bp_uuid, end_date, process_time FROM 82_wf_temp_datastore 
        WHERE transaction_id IN (SELECT transaction_id FROM 82_tmp);
    
    DELETE FROM 82_wf_temp_datastore WHERE transaction_id IN (SELECT transaction_id FROM 82_tmp);
    DELETE FROM 82_wf_temp_transactions WHERE ID IN (SELECT transaction_id FROM 82_tmp);
    
    COMMIT;
    
    SET autocommit = 1;

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`82_tmp`;
END$$
DELIMITER ;



-- Update UI SPs
-- select_bp_list_sp_2
DROP PROCEDURE IF EXISTS vbrain.select_bp_list_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`select_bp_list_sp_2`(IN include_group_id INT(11))
BEGIN
	IF include_group_id IS NOT NULL OR include_group_id > 0 THEN
		(SELECT id, display_name, '8.4' AS wf_version 
		FROM wf_business_process 
		WHERE mapped_datastores IS NOT NULL AND tracking_id_field IS NOT NULL AND error_msg_field IS NOT NULL
			AND (mapping_id IS NULL OR group_process_id = include_group_id) 
		ORDER BY display_name)
		UNION ALL
		(SELECT id, display_name, '8.2' AS wf_version 
		FROM 82_wf_business_process 
		WHERE mapped_datastores IS NOT NULL AND tracking_id_field IS NOT NULL AND error_msg_field IS NOT NULL
			AND (mapping_id IS NULL OR group_process_id = include_group_id) 
		ORDER BY display_name);
	ELSE 
		(SELECT id, display_name, '8.4' AS wf_version 
		FROM wf_business_process 
		WHERE mapped_datastores IS NOT NULL AND tracking_id_field IS NOT NULL AND error_msg_field IS NOT NULL
			AND mapping_id IS NULL
		ORDER BY display_name)
		UNION ALL
		(SELECT id, display_name, '8.2' AS wf_version 
		FROM 82_wf_business_process 
		WHERE mapped_datastores IS NOT NULL AND tracking_id_field IS NOT NULL AND error_msg_field IS NOT NULL
			AND mapping_id IS NULL
		ORDER BY display_name);
	END IF;
END$$
DELIMITER ;

-- select_unmapped_campaigns_sp_2
DROP PROCEDURE IF EXISTS vbrain.select_unmapped_campaigns_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`select_unmapped_campaigns_sp_2`(IN include_group_id INT(11))
BEGIN
	IF include_group_id IS NOT NULL OR include_group_id > 0 THEN
		(SELECT c.campaign_id, c.step_id, MAX(c.mapping_id) as mapping_id, c.bp_name, c.step_title, c.step_index, c.bp_lastmodified, '8.4' AS wf_version
		FROM wf_campaign c 
		WHERE campaign_id NOT IN (
			SELECT c.campaign_id FROM wf_business_process bp JOIN wf_campaign c ON c.mapping_id = bp.mapping_id
			WHERE bp.group_process_id <> include_group_id) 
		GROUP BY c.campaign_id, c.step_id)
		UNION ALL
		(SELECT c.campaign_id, c.step_id, MAX(c.mapping_id) as mapping_id, c.bp_name, c.step_title, c.step_index, c.bp_lastmodified, '8.2' AS wf_version
		FROM 82_wf_campaign c 
		WHERE campaign_id NOT IN (
			SELECT c.campaign_id FROM 82_wf_business_process bp JOIN 82_wf_campaign c ON c.mapping_id = bp.mapping_id
			WHERE bp.group_process_id <> include_group_id) 
		GROUP BY c.campaign_id, c.step_id)
		ORDER BY bp_name, bp_lastmodified DESC;
	ELSE 
		(SELECT c.campaign_id, c.step_id, MAX(c.mapping_id) as mapping_id, c.bp_name, c.step_title, c.step_index, c.bp_lastmodified, '8.4' AS wf_version 
		FROM wf_campaign c 
		WHERE campaign_id NOT IN (SELECT c.campaign_id FROM wf_business_process bp JOIN wf_campaign c ON c.mapping_id = bp.mapping_id) 
		GROUP BY c.campaign_id, c.step_id)
		UNION ALL
		(SELECT c.campaign_id, c.step_id, MAX(c.mapping_id) as mapping_id, c.bp_name, c.step_title, c.step_index, c.bp_lastmodified, '8.2' AS wf_version 
		FROM 82_wf_campaign c 
		WHERE campaign_id NOT IN (SELECT c.campaign_id FROM 82_wf_business_process bp JOIN 82_wf_campaign c ON c.mapping_id = bp.mapping_id) 
		GROUP BY c.campaign_id, c.step_id)
		ORDER BY bp_name, bp_lastmodified DESC;
	END IF;

END$$
DELIMITER ;


-- select_bp_config_sp_2
DROP PROCEDURE IF EXISTS vbrain.select_bp_config_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`select_bp_config_sp_2`(IN group_id INT(11))
BEGIN
	IF group_id IS NOT NULL THEN
		IF EXISTS(SELECT TRUE FROM business_process_view_2 WHERE bp_group_id = group_id) THEN
			SELECT business_process_id AS bp_id, bp_group_id AS group_id, campaign_id, mapping_id 
			FROM business_process_view_2 
			WHERE bp_group_id = group_id;
		ELSE
			SELECT bp.id AS bp_id, bp.group_process_id AS group_id, c.campaign_id, bp.mapping_id 
			FROM 82_wf_business_process bp
			JOIN 82_wf_campaign c ON c.mapping_id = bp.mapping_id
			WHERE bp.group_process_id = group_id;
		END IF;
	ELSE
		SELECT NULL AS bp_id, NULL AS group_id, NULL AS campaign_id, NULL AS mapping_id LIMIT 0; 
	END IF;
END$$
DELIMITER ;


-- 82_update_bp_mapping_sp
DROP PROCEDURE IF EXISTS vbrain.`82_update_bp_mapping_sp`;

DELIMITER $$
$$
CREATE PROCEDURE vbrain.`82_update_bp_mapping_sp`(IN p_bp_id INT(11), IN p_mapping_id BIGINT(20), IN p_group_process_id INT(11))
BEGIN
	UPDATE 82_wf_business_process SET group_process_id = p_group_process_id, mapping_id = p_mapping_id WHERE id = p_bp_id;
END$$
DELIMITER ;


-- 82_add_wf_business_process_sp_2
DROP PROCEDURE IF EXISTS vbrain.`82_add_wf_business_process_sp_2`;

DELIMITER $$
$$
CREATE PROCEDURE vbrain.`82_add_wf_business_process_sp_2`(IN p_display_name VARCHAR(100), IN p_mapped_datastores VARCHAR(500), 
    IN p_tracking_id_field VARCHAR(200), IN p_error_msg_field VARCHAR(200), 
    IN p_system_id_field VARCHAR(200), IN p_start_date_field VARCHAR(200), IN p_bp_uuid_field VARCHAR(200),
	IN p_end_date_field VARCHAR(200), IN p_process_time_field VARCHAR(200),
    IN p_start_date_postgre_format VARCHAR(50), IN p_start_date_convert_format VARCHAR(50), IN p_id_order_field varchar(200))
BEGIN
	DECLARE max_query_order INT(11) DEFAULT 0;
    DECLARE display_name_exists TINYINT(1) DEFAULT 0;

    SELECT COUNT(display_name)>0 INTO display_name_exists 
    FROM 82_wf_business_process WHERE display_name = p_display_name;

    IF display_name_exists = 0 THEN
		
	    IF p_id_order_field IS NULL THEN
			SET p_id_order_field = CONCAT(p_start_date_field,'$$',p_system_id_field);
		END IF;
		
        SELECT MAX(query_order) INTO max_query_order FROM 82_wf_business_process;
        
        INSERT INTO 82_wf_business_process(display_name, mapped_datastores, tracking_id_field, error_msg_field, 
            system_id_field, start_date_field, bp_uuid_field, end_date_field, process_time_field, start_date_postgre_format, start_date_convert_format, query_order, id_order_field)
        VALUES(p_display_name, p_mapped_datastores, p_tracking_id_field, p_error_msg_field, 
            p_system_id_field, p_start_date_field, p_bp_uuid_field, p_end_date_field, p_process_time_field, p_start_date_postgre_format, p_start_date_convert_format, max_query_order+1, p_id_order_field);
        
        SELECT 'Business Process added successfully' AS message;
    ELSE
        SELECT 'Business Process already exists' AS message;
    END IF;
END$$
DELIMITER ;



