DROP FUNCTION IF EXISTS vbrain.split_str;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` FUNCTION `vbrain`.`split_str`( s VARCHAR(1024) , del CHAR(3) , i INT) RETURNS varchar(1024) CHARSET latin1
BEGIN
    DECLARE n INT; 
    
    SET n = (LENGTH(s) - LENGTH(REPLACE(s, del, '')))/LENGTH(del) + 1;
    IF i > n THEN
        RETURN NULL;
    ELSE
        RETURN SUBSTRING_INDEX(SUBSTRING_INDEX(s, del, i) , del , -1 );        
    END IF;
END$$
DELIMITER ;
