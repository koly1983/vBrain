create
or replace
view `business_process_view_2` as select
    `bp`.`id` as `business_process_id`,
    `bp`.`display_name` as `display_name`,
    `gp`.`Name` as `bp_group_name`,
    `cmp`.`bp_name` as `campaign_name`,
    `func`.`Name` as `function`,
    `lob`.`Name` as `lob`,
    `country`.`Name` as `country`,
    `region`.`Name` as `region`,
    `cmp`.`campaign_id` as `campaign_id`,
    `bp`.`mapping_id` as `mapping_id`,
    `gp`.`ID` as `bp_group_id`,
    `func`.`ID` as `function_id`,
    `lob`.`ID` as `lob_id`,
    `country`.`ID` as `country_id`,
    `region`.`ID` as `region_id`,
    `bp`.`mapped_datastores` as `mapped_datastores`,
    `bp`.`query_order` as `query_order`,
    `bp`.`start_date_convert_format` as `start_date_convert_format`,
    `bp`.`start_date_postgre_format` as `start_date_postgre_format`,
    `bp`.`tracking_id_field` as `tracking_id_field`,
    `bp`.`error_msg_field` as `error_msg_field`,
    `bp`.`system_id_field` as `system_id_field`,
    `bp`.`start_date_field` as `start_date_field`,
    `gp`.`isDisabled` as `isDisabled`
from
    `groups` `gp`
join `groups` `func` on
    `gp`.`Parent_Id` = `func`.`ID`
join `groups` `lob` on
    `func`.`Parent_Id` = `lob`.`ID`
join `groups` `country` on
    `lob`.`Parent_Id` = `country`.`ID`
join `groups` `region` on
    `country`.`Parent_Id` = `region`.`ID`
join `wf_business_process` `bp` on
    `gp`.`id` = `bp`.`group_process_id`
join `wf_campaign` `cmp` on
    `bp`.`mapping_id` = `cmp`.`mapping_id`

where
    `gp`.`Type` = 'process';

;


-- Creating functions
DROP FUNCTION IF EXISTS vbrain.split_str;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` FUNCTION `vbrain`.`split_str`( s VARCHAR(1024) , del CHAR(1) , i INT) RETURNS varchar(1024)
BEGIN
    DECLARE n INT;
    -- get max number of items
    SET n = LENGTH(s) - LENGTH(REPLACE(s, del, '')) + 1;
    IF i > n THEN
        RETURN NULL;
    ELSE
        RETURN SUBSTRING_INDEX(SUBSTRING_INDEX(s, del, i) , del , -1 );        
    END IF;
END$$
DELIMITER ;


DROP FUNCTION IF EXISTS vbrain.check_can_delete_group_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` FUNCTION `vbrain`.`check_can_delete_group_2`(id INT(11)) RETURNS tinyint(1)
    DETERMINISTIC
BEGIN
	 DECLARE gtype varchar(45);
	 DECLARE flag TINYINT(1) DEFAULT 0;
	 SELECT g.`Type` INTO gtype FROM groups g WHERE g.ID = id;
     IF gtype = 'process' THEN
         SELECT COUNT(*) = 0 INTO flag FROM 
			(SELECT 1 as exist FROM bot b WHERE Process_Id = id
			UNION ALL
			SELECT 1 as exist FROM transactions t WHERE t.WORKER_ID = (SELECT b.ID FROM bot b WHERE Process_Id = id LIMIT 1)
			UNION ALL
			SELECT 1 as exist FROM wf_temp_transactions tt WHERE tt.CAMPAIGN_ID = (SELECT bp.campaign_id FROM vbrain.business_process_view_2 bp
				WHERE bp.bp_group_id = id)
			UNION ALL
			SELECT 1 as exist FROM wf_temp_datastore td WHERE td.business_process_id = (SELECT bp.business_process_id FROM vbrain.business_process_view_2 bp
				WHERE bp.bp_group_id = id)) AS total;
	 ELSE 
	 	SELECT COUNT(*) = 0 INTO flag FROM groups g WHERE g.Parent_Id = id;
     END IF;
     RETURN flag;
 END$$
DELIMITER ;


-- Import stored procedures
DROP PROCEDURE IF EXISTS vbrain.import_details_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`import_details_sp`()
BEGIN
	DROP TEMPORARY TABLE IF EXISTS `vbrain`.`import_details_tmp`;

	CREATE TEMPORARY TABLE `vbrain`.`import_details_tmp` (
		entity varchar(1),
		import varchar(100),
		importParamValues varchar(100),
		post varchar(100),
		postParamValues varchar(100)
	); 

	INSERT INTO import_details_tmp(entity, import, importParamValues, post, postParamValues) VALUES 
	('T','t_import_sp',NULL,NULL,NULL),
	('D','ds_import_sp',NULL,'wf_temp_datastore_massage_sp',NULL);
	
	SELECT * FROM import_details_tmp;

	DROP TEMPORARY TABLE IF EXISTS `vbrain`.`import_details_tmp`;
END$$
DELIMITER ;


DROP PROCEDURE IF EXISTS vbrain.t_import_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`t_import_sp`()
BEGIN
	DECLARE lastupdated_wf_id BIGINT(20) DEFAULT 0;
	DECLARE mappingIdList VARCHAR(2000) DEFAULT NULL;
	DECLARE w VARCHAR(5000) DEFAULT NULL;

	SELECT GREATEST(MAX(IFNULL(tt.wf_id,0)),MAX(IFNULL(ttt.wf_id,0))) INTO lastupdated_wf_id 
	FROM vbrain.wf_temp_transactions tt, vbrain.wf_temp_transactions_trash ttt;
	
	SELECT GROUP_CONCAT(bp.mapping_id SEPARATOR ',') INTO mappingIdList
	FROM business_process_view_2 bp 
	WHERE bp.isDisabled = 0;

	SET w = CONCAT('AwsHit.id > ', IFNULL(lastupdated_wf_id,0), ' AND (Run.status=\'COMPLETED\' OR Run.hasProcessingIssues = 1)');
	IF mappingIdList IS NOT NULL THEN
		SET w = CONCAT(w, ' AND Run.campaignMap_id IN (',mappingIdList,')');
	END IF;
	
	DROP TEMPORARY TABLE IF EXISTS `vbrain`.`t_import_tmp`;

	CREATE TEMPORARY TABLE `vbrain`.`t_import_tmp` (
		QE varchar(1000),
		QT varchar(1)
	); 

	INSERT INTO t_import_tmp(QE, QT) VALUES 
	('Run|title|TITLE','S'),
	('Run|title|DESCRIPTION','S'),
	('AwsHit|submissionDate|START_TIME','S'),
	('Run|campaign_id|CAMPAIGN_ID','S'),
	('Run|rootRunUUID|BP_UUID','S'),
	('AwsHit|completionDate|END_TIME','S'),
	('Run|hasProcessingIssues|STATUS','S'),
	('AwsHit|id|wf_id','S'),
	('Run','F'),
	('AwsHit|run_id|=|Run|id','J'),
	(w,'W'),
	('AwsHit|id|A','O'),
	('100','L'),
	('wf_temp_transactions|ii','T');
	
	SELECT * FROM t_import_tmp;

	DROP TEMPORARY TABLE IF EXISTS `vbrain`.`t_import_tmp`;
END$$
DELIMITER ;


DROP PROCEDURE IF EXISTS vbrain.ds_import_sub_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`ds_import_sub_sp`(IN bp_id INT(11), IN include_limit TINYINT(1))
BEGIN
	DECLARE max_wf_id BIGINT(20) DEFAULT 0;

	DECLARE ds_display_name VARCHAR(100) DEFAULT NULL;
	DECLARE postgre_start_date_format VARCHAR(50);
	DECLARE ds_table_name VARCHAR(500);
	DECLARE field_tracking_id VARCHAR(200);
	DECLARE field_error_msg VARCHAR(200);
	DECLARE field_system_id VARCHAR(200);
	DECLARE field_start_date VARCHAR(200);
	
	DECLARE w VARCHAR(5000) DEFAULT NULL;

	DECLARE max_wf_id_tds BIGINT(20) DEFAULT 0;
	DECLARE max_wf_id_tdst BIGINT(20) DEFAULT 0;

	DECLARE start_date_str VARCHAR(500);
		
	SELECT IFNULL(MAX(tds.wf_id),0) INTO max_wf_id_tds FROM wf_temp_datastore tds WHERE tds.business_process_id = bp_id;
	SELECT IFNULL(MAX(tdst.wf_id),0) INTO max_wf_id_tdst FROM wf_temp_datastore_trash tdst WHERE tdst.business_process_id = bp_id;
	SELECT GREATEST(max_wf_id_tds,max_wf_id_tdst) INTO max_wf_id;

	SELECT display_name, start_date_postgre_format, mapped_datastores, tracking_id_field, error_msg_field, system_id_field, start_date_field
		INTO ds_display_name, postgre_start_date_format, ds_table_name, field_tracking_id, field_error_msg, field_system_id, field_start_date
		FROM wf_business_process bp WHERE id = bp_id;

	SELECT CONCAT('to_timestamp(',field_start_date,', \'',postgre_start_date_format,'\')') INTO start_date_str;
	SELECT CONCAT('EXTRACT(EPOCH FROM ',start_date_str,')*100000+ CAST(',field_system_id,' AS DOUBLE PRECISION) > ',max_wf_id) INTO w;
	
	DROP TEMPORARY TABLE IF EXISTS `vbrain`.`d_import_tmp`;

	CREATE TEMPORARY TABLE `vbrain`.`d_import_tmp` (
		QE varchar(1000),
		QT varchar(1)
	); 

	INSERT INTO d_import_tmp(QE, QT) VALUES 
	(CONCAT('|',IFNULL(field_tracking_id,'NULL'),'|tracking_id'),'S'),
	(CONCAT('|',IFNULL(field_error_msg,'NULL'),'|error_msg'),'S'),
	(CONCAT('|',IFNULL(field_system_id,'NULL'),'|system_id'),'S'),
	(CONCAT('|',IFNULL(field_start_date,'NULL'),'|start_date'),'S'),
	(CONCAT('|\'',ds_display_name,'\'|name'),'S'),
	(CONCAT('|',bp_id,'|business_process_id'),'S'),
	(ds_table_name,'F'),
	(w,'W');

	IF include_limit = 1 THEN
		INSERT INTO d_import_tmp(QE, QT) VALUES 
		('100','L');
	END IF;

	INSERT INTO d_import_tmp(QE, QT) VALUES 
	('wf_temp_datastore|ii','T');
	
	SELECT * FROM d_import_tmp;

	DROP TEMPORARY TABLE IF EXISTS `vbrain`.`d_import_tmp`;
END$$
DELIMITER ;




DROP PROCEDURE IF EXISTS vbrain.ds_import_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`ds_import_sp`()
BEGIN
	DECLARE v_bp_id INT(11);
	DECLARE v_counter INT(11) DEFAULT 1;
	DECLARE row_count INT(11);
 	DECLARE finished INT(1) DEFAULT 0;

	DECLARE datastore_cursor CURSOR FOR 
   		SELECT business_process_id FROM business_process_view_2 WHERE isDisabled = 0;
   	
   	-- declare NOT FOUND handler
 	DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
   	
   	OPEN datastore_cursor;
    SELECT FOUND_ROWS() INTO row_count ;
   
    get_datastore_data: LOOP
 		FETCH datastore_cursor INTO v_bp_id;
	 	IF finished = 1 THEN 
			LEAVE get_datastore_data;
		END IF;
	
		-- Add limit to last query elements only
		CALL ds_import_sub_sp(v_bp_id, IF(v_counter = row_count, 1, 0));
		
		SET v_counter = v_counter + 1;
	
	END LOOP get_datastore_data;
 
 	CLOSE datastore_cursor;
END$$
DELIMITER ;



DROP PROCEDURE IF EXISTS vbrain.wf_temp_datastore_massage_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`wf_temp_datastore_massage_sp`()
BEGIN
	DECLARE v_bp_id INT(11);
	DECLARE v_convert_format VARCHAR(50);

	DECLARE finished INT(1) DEFAULT 0;

	DECLARE datastore_cursor CURSOR FOR 
   		SELECT business_process_id, start_date_convert_format FROM business_process_view_2 WHERE isDisabled = 0;
   	
   	-- declare NOT FOUND handler
 	DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
   	
   	OPEN datastore_cursor;
   
    update_datastore_fields: LOOP
 		FETCH datastore_cursor INTO v_bp_id, v_convert_format;
	 	IF finished = 1 THEN 
			LEAVE update_datastore_fields;
		END IF;

		-- WARNING!! Make sure to follow below order.
		-- Update Start date field format before updating wf_id
	
		-- 1. Convert start date field format
		UPDATE wf_temp_datastore SET start_date = STR_TO_DATE(start_date, v_convert_format) WHERE wf_id = 0 AND business_process_id = v_bp_id;
		-- 2. Update wf_id
		UPDATE wf_temp_datastore SET wf_id = UNIX_TIMESTAMP(start_date)*100000 + system_id WHERE wf_id = 0 AND business_process_id = v_bp_id;

	END LOOP update_datastore_fields;
 
 	CLOSE datastore_cursor;

	-- Update error cat for wf_temp_datastore data
 	UPDATE vbrain.wf_temp_datastore ds
	JOIN (SELECT bp.business_process_id, Exception_Type, Exception_Value
		  FROM vbrain.exceptions e 
		  JOIN vbrain.business_process_view_2 bp ON bp.lob_id = e.Lob) te 
	ON ds.business_process_id = te.business_process_id 
	SET ds.ERROR_CAT = te.Exception_Type
	WHERE ds.ERROR_CAT IS NULL AND ds.error_msg LIKE concat('%', te.Exception_Value, '%');
END$$
DELIMITER ;


DROP PROCEDURE IF EXISTS vbrain.update_transactions_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`update_transactions_sp_2`()
BEGIN
	DECLARE v_start_date varchar(100);
    DECLARE v_bp_id varchar(100);
   	DECLARE max_length INTEGER DEFAULT 0;
    DECLARE finished INTEGER DEFAULT 0;
   
    DECLARE datastore_cursor CURSOR FOR 
   		SELECT DISTINCT start_date, business_process_id FROM wf_temp_datastore WHERE transaction_id IS NULL ORDER BY start_date;
      	
   	-- declare NOT FOUND handler
 	DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
 
 	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
	    ROLLBACK;  -- Rollback any changes made in the transaction
        RESIGNAL;  -- Resignal the error to the caller
    END;
   
 	OPEN datastore_cursor;
 	
 	-- Loop through different runs data and link transactions dump with datastore dump
 	-- Update 'ds.transaction_id' (foreign key)
 	get_datastore_data: LOOP
 		FETCH datastore_cursor INTO v_start_date,v_bp_id;
	 	IF finished = 1 THEN 
			LEAVE get_datastore_data;
		END IF;
 		UPDATE wf_temp_datastore ds 
			JOIN (
				SELECT t2.ID AS trans_id, t1.ID AS ds_id
				FROM (
					-- Select wf_temp_datastore rows with row numbers
					SELECT tds.ID, @curRow := @curRow + 1 AS row_number
				      FROM wf_temp_datastore tds
				         JOIN
				         	(SELECT @curRow := 0) r -- Row numbers
				         WHERE tds.start_date = v_start_date AND tds.business_process_id = v_bp_id ORDER BY tds.system_id) t1
				JOIN (
					-- Select ids from temp transactions with row numbers
				 	SELECT tt.ID, @curRow2 := @curRow2 + 1 AS row_number
				      FROM wf_temp_transactions tt
				         JOIN
				         	(SELECT @curRow2 := 0) r -- Row numbers
				      JOIN business_process_view_2 bp 
						 ON tt.campaign_id = bp.campaign_id 
					  WHERE tt.END_TIME > v_start_date 
						 AND bp.business_process_id = v_bp_id 
					  ORDER BY tt.END_TIME
				) t2 ON t1.row_number = t2.row_number
			) AS temp
			ON temp.ds_id = ds.ID
			SET ds.transaction_id = temp.trans_id;
 	END LOOP get_datastore_data;
 
 	CLOSE datastore_cursor;

	SELECT CHARACTER_MAXIMUM_LENGTH INTO max_length
	FROM information_schema.columns
	WHERE table_schema = 'vbrain' AND   
	      table_name = 'transactions' AND
	      COLUMN_NAME = 'ERROR_TYPE';

	-- Select from the dumps, groups, bot in temporary in mamory table
	DROP TEMPORARY TABLE IF EXISTS `vbrain`.`tmp`;
	CREATE TEMPORARY TABLE `vbrain`.`tmp` engine=memory AS	
	SELECT tt.ID AS transaction_id,
		   b.ID AS botid,
		   tt.STATUS AS status,
		   tt.START_TIME AS hit_submissionDate, 
		   tt.END_TIME AS hit_completionDate,
		   IF(tt.STATUS = 1, 'Unkown Error', '') AS exception_type,
		   tt.DESCRIPTION AS stepTitle,
		   bp.country AS country, 
		   tt.BP_UUID AS bp_instance_uuid,
		   bp.function AS function,
		   ds.error_cat AS error_cat,
		   ds.error_msg AS error_msg,
		   ds.tracking_id AS tracking_id,
		   'BOT' AS WORKER_TYPE,
		   0 AS OUT_COME,
		   'vBrain' AS CREATED_BY
		FROM business_process_view_2 bp 
		JOIN bot b ON bp.bp_group_id = b.Process_Id
		INNER JOIN wf_temp_transactions tt ON tt.campaign_id = bp.campaign_id
		JOIN wf_temp_datastore ds ON ds.transaction_id = tt.ID
		WHERE b.ID > 0 AND b.isDisabled = 0;
   
	SET autocommit = 0;

	-- Start SQL transaction
	START TRANSACTION;
	-- Promote to transactions from in memory temporary table
 	INSERT INTO transactions (WORKER_ID,STATUS,
				START_TIME,END_TIME,EXCEPTION_TYPE,DESCRIPTION,COUNTRY,BP_UUID,B_FUNCTION,
				ERROR_CAT, ERROR_TYPE,TRACKING_ID,WORKER_TYPE,OUT_COME,CREATED_BY)
 	SELECT botid, status, hit_submissionDate, hit_completionDate, exception_type,
		   stepTitle, country, bp_instance_uuid, function, error_cat,
		   SUBSTRING(error_msg, 1, max_length), tracking_id, WORKER_TYPE, OUT_COME, CREATED_BY
		FROM `vbrain`.`tmp`;
	
	-- Delete (Move to trash) successfully promoted (moved to transactions table) rows 
	-- from temp tables (wf_temp_transactions, wf_temp_datastore)
	INSERT INTO wf_temp_transactions_trash (ID, STATUS, TITLE, BP_NAME, START_TIME, END_TIME, DESCRIPTION, BP_UUID, campaign_id, WF_ID) 
		SELECT ID, STATUS, TITLE, BP_NAME, START_TIME, END_TIME, DESCRIPTION, BP_UUID, campaign_id, WF_ID FROM wf_temp_transactions 
		WHERE ID IN (SELECT transaction_id FROM tmp);
	
	INSERT INTO wf_temp_datastore_trash (ID, name, transaction_id, error_cat, start_date, system_id, error_msg, tracking_id, business_process_id, wf_id) 
		SELECT ID, name, transaction_id, error_cat, start_date, system_id, error_msg, tracking_id, business_process_id, wf_id FROM wf_temp_datastore 
		WHERE transaction_id IN (SELECT transaction_id FROM tmp);
	
	DELETE FROM wf_temp_datastore WHERE transaction_id IN (SELECT transaction_id FROM tmp);
	DELETE FROM wf_temp_transactions WHERE ID IN (SELECT transaction_id FROM tmp);
	
	COMMIT;
	-- End SQL transaction 
	SET autocommit = 1;

	DROP TEMPORARY TABLE IF EXISTS `vbrain`.`tmp`;
END$$
DELIMITER ;


-- UI stored procedures
DROP PROCEDURE IF EXISTS vbrain.select_bp_list_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`select_bp_list_sp_2`(IN include_group_id INT(11))
BEGIN
	IF include_group_id IS NOT NULL OR include_group_id > 0 THEN
		SELECT id, display_name 
		FROM wf_business_process 
		WHERE mapped_datastores IS NOT NULL AND tracking_id_field IS NOT NULL AND error_msg_field IS NOT NULL
			AND (mapping_id IS NULL OR group_process_id = include_group_id) 
		ORDER BY display_name;
	ELSE 
		SELECT id, display_name 
		FROM wf_business_process 
		WHERE mapped_datastores IS NOT NULL AND tracking_id_field IS NOT NULL AND error_msg_field IS NOT NULL
			AND mapping_id IS NULL
		ORDER BY display_name;
	END IF;
END$$
DELIMITER ;


DROP PROCEDURE IF EXISTS vbrain.select_unmapped_campaigns_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`select_unmapped_campaigns_sp_2`(IN include_group_id INT(11))
BEGIN
	IF include_group_id IS NOT NULL OR include_group_id > 0 THEN
		SELECT c.campaign_id, c.step_id, MAX(c.mapping_id) as mapping_id, c.bp_name, c.step_title, c.step_index 
		FROM wf_campaign c 
		WHERE campaign_id NOT IN (
			SELECT c.campaign_id FROM wf_business_process bp JOIN wf_campaign c ON c.mapping_id = bp.mapping_id
			WHERE bp.group_process_id <> include_group_id) 
		GROUP BY c.campaign_id, c.step_id
		ORDER BY c.bp_name, c.bp_lastmodified DESC;
	ELSE 
		SELECT c.campaign_id, c.step_id, MAX(c.mapping_id) as mapping_id, c.bp_name, c.step_title, c.step_index 
		FROM wf_campaign c 
		WHERE campaign_id NOT IN (SELECT c.campaign_id FROM wf_business_process bp JOIN wf_campaign c ON c.mapping_id = bp.mapping_id) 
		GROUP BY c.campaign_id, c.step_id
		ORDER BY c.bp_name, c.bp_lastmodified DESC;
	END IF;

END$$
DELIMITER ;


DROP PROCEDURE IF EXISTS vbrain.select_bp_config_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`select_bp_config_sp_2`(IN group_id INT(11))
BEGIN
	IF group_id IS NOT NULL THEN
		SELECT business_process_id AS bp_id, bp_group_id AS group_id, campaign_id, mapping_id 
		FROM business_process_view_2 
		WHERE bp_group_id = group_id;
	ELSE
		SELECT NULL AS bp_id, NULL AS group_id, NULL AS campaign_id, NULL AS mapping_id LIMIT 0; 
	END IF;
END$$
DELIMITER ;



DROP PROCEDURE IF EXISTS vbrain.update_bp_mapping_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`update_bp_mapping_sp`(IN p_bp_id INT(11), IN p_mapping_id BIGINT(20), IN p_group_process_id INT(11))
BEGIN
	UPDATE wf_business_process SET group_process_id = p_group_process_id, mapping_id = p_mapping_id WHERE id = p_bp_id;
END$$
DELIMITER ;



DROP PROCEDURE IF EXISTS vbrain.delete_group_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`delete_group_sp_2`()
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
	    ROLLBACK;  
        RESIGNAL;  
    END;
    IF CHECK_CAN_DELETE_GROUP_2(group_id) = 1 THEN
	    SET autocommit = 0;
		
		START TRANSACTION;
	
		UPDATE wf_business_process SET group_process_id = NULL, mapping_id = NULL WHERE group_process_id = group_id;
		DELETE FROM groups WHERE ID = group_id; 
	
		COMMIT;
		
		SET autocommit = 1;
	END IF;
END$$
DELIMITER ;



