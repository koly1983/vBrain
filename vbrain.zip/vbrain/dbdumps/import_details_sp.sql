DROP PROCEDURE IF EXISTS vbrain.import_details_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `import_details_sp`()
BEGIN
    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`import_details_tmp`;

    CREATE TEMPORARY TABLE `vbrain`.`import_details_tmp` (
        entity varchar(1),
        import varchar(100),
        importParamValues varchar(100),
        post varchar(100),
        postParamValues varchar(100)
    );

    INSERT INTO import_details_tmp(entity, import, importParamValues, post, postParamValues) VALUES
    ('T','t_import_sp',NULL,NULL,NULL),
    ('T','bp_run_import_sp_2',NULL,'bp_run_massage_sp_2',NULL),
    ('D','ds_import_sp',NULL,'wf_temp_datastore_massage_sp',NULL),
    ('C','c_import_sp_2',NULL,NULL,NULL);
    
    SELECT * FROM import_details_tmp;

    DROP TEMPORARY TABLE IF EXISTS `vbrain`.`import_details_tmp`;
END$$
DELIMITER ;