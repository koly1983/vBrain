DROP PROCEDURE IF EXISTS `vbrain`.`update_lastrecord_datastore_sp`;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`update_lastrecord_datastore_sp`()
BEGIN
	DECLARE max_time BIGINT;
	
	SELECT MAX(UNIX_TIMESTAMP(start_date)*100000 + system_id) INTO max_time
			FROM wf_temp_datastore;

	IF max_time > (SELECT LASTRECORD_TIMESTAMP_DATASTORE FROM wf_configuration) THEN
		UPDATE wf_configuration SET LASTRECORD_TIMESTAMP_DATASTORE = max_time;
	END IF;
END$$
DELIMITER ;