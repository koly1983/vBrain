DROP PROCEDURE IF EXISTS vbrain.c_import_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`c_import_sp_2`()
BEGIN
	DECLARE bp_last_updated_date VARCHAR(50);
	DECLARE s_last_updated_date VARCHAR(50);
	DECLARE w VARCHAR(5000) DEFAULT NULL;

	SELECT IFNULL(MAX(bp_lastmodified), FROM_UNIXTIME(0)), IFNULL(MAX(step_lastmodified), FROM_UNIXTIME(0)) INTO bp_last_updated_date, s_last_updated_date FROM wf_campaign;
	
	SET w = CONCAT('s.lastModified > \'',s_last_updated_date,'\' OR bp.lastModified > \'',bp_last_updated_date, '\'');

	DROP TEMPORARY TABLE IF EXISTS `vbrain`.`c_import_tmp`;

	CREATE TEMPORARY TABLE `vbrain`.`c_import_tmp` (
		QE varchar(1000),
		QT varchar(1)
	); 

	INSERT INTO c_import_tmp(QE, QT) VALUES 
	('cm|id|mapping_id','S'),
	('cm|deleted|deleted','S'),
	('cm|stepIndex|step_index','S'),
	('bp|id|campaign_id','S'),
	('bp|title|bp_name','S'),
	('bp|lastModified|bp_lastmodified','S'),
	('s|id|step_id','S'),
	('s|title|step_title','S'),
	('s|lastModified|step_lastmodified','S'),
	('CampaignMap cm','F'),
	('Campaign s|id|=|cm|campaign','J'),
	('Campaign bp|id|=|cm|parent','J'),
	(w,'W'),
	('bp|lastModified|A','O'),
	('s|lastModified|A','O'),
	('100','L'),
	('wf_campaign|ii','T');
	
	SELECT * FROM c_import_tmp;

	DROP TEMPORARY TABLE IF EXISTS `vbrain`.`c_import_tmp`;
END$$
DELIMITER ;
