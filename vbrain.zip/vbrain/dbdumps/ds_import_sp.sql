DROP PROCEDURE IF EXISTS vbrain.ds_import_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`ds_import_sp`()
BEGIN
	DECLARE v_bp_id INT(11);
	DECLARE v_counter INT(11) DEFAULT 1;
	DECLARE row_count INT(11);
 	DECLARE finished INT(1) DEFAULT 0;

	DECLARE datastore_cursor CURSOR FOR 
   		SELECT business_process_id FROM business_process_view_2 WHERE isDisabled = 0;
   	
   	-- declare NOT FOUND handler
 	DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
   	
   	OPEN datastore_cursor;
    SELECT FOUND_ROWS() INTO row_count ;
   
    get_datastore_data: LOOP
 		FETCH datastore_cursor INTO v_bp_id;
	 	IF finished = 1 THEN 
			LEAVE get_datastore_data;
		END IF;
	
		-- Add limit to last query elements only
		CALL ds_import_sub_sp(v_bp_id, IF(v_counter = row_count, 1, 0));
		
		SET v_counter = v_counter + 1;
	
	END LOOP get_datastore_data;
 
 	CLOSE datastore_cursor;
END$$
DELIMITER ;
