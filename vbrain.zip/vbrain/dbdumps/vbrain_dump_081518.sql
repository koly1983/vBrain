-- MySQL dump 10.13  Distrib 5.7.23, for Linux (x86_64)
--
-- Host: localhost    Database: vbrain
-- ------------------------------------------------------
-- Server version	5.7.23-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bot`
--

DROP TABLE IF EXISTS `bot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bot` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Bot_Key` varchar(45) DEFAULT NULL,
  `Provider` varchar(45) DEFAULT NULL,
  `Host_Name` varchar(45) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `Process_Id` int(11) DEFAULT NULL,
  `isDisabled` int(11) DEFAULT '0',
  `avgEfforts` varchar(45) DEFAULT NULL,
  `avgCost` varchar(45) DEFAULT NULL,
  `cycleTime` varchar(45) DEFAULT NULL,
  `noOftransactions` varchar(45) DEFAULT NULL,
  `status` varchar(2) DEFAULT '0',
  `avgEffortsSaved` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot`
--

LOCK TABLES `bot` WRITE;
/*!40000 ALTER TABLE `bot` DISABLE KEYS */;
INSERT INTO `bot` VALUES (1,'BOT1','Pega Robotics','121.70.88.210','Pega Robotics Bot',42,1,'5','50','10','700','0','10'),(2,'BOT2','AA','121.11.22.33','AA Bot',42,1,'5','55','10','900','1','10'),(3,'BOT3','BP','122.12.344.120','BluePrism BOT',43,1,'5','50','10','800','1','10'),(4,'BOT4','Blue Prism','122.305.200','BP Bot for AD Claim',43,1,'6','40','10','400','1','12'),(5,'BOT5','Automation Anywhere','12.11.2.33','Automation Anywhere Bot',51,1,'6','50','10','700','1','10'),(6,'BOT6','Open Span','11.22.33.444','Open Span BOT',50,1,'6','50','10','500','0','10'),(7,'BOT7','Open Span','102.33.405.67','Open Span Bot for OCR',44,1,'5','50','5','600','0','10'),(9,'BOT8','Pega Robotics','205.33.25.46','Bot for Create FNOL',54,0,'5','50','5','1','1','10'),(10,'BOT9','Blue Prism','10.20,165.204','FNOL BOT for Comm Claims',56,0,'100','60','20','5','0','80'),(11,'BOT10','Blue Prism','10.20.160.95','App Ingestion BOT',57,0,'100','60','20','20','0','65'),(12,'BOT11','WorkFusion','172.56.236.26','WorkFusion bot',69,0,'5','40','30','1','1','45'),(13,'BOT12','Workfusion','34.162.45.57','Cards Issurance Bot',212,0,'20','20','324','0','0','15'),(14,'BOT13','Workfusion v2','57.42.125.55','KYC Verification',282,0,'23','56','3432','344','1','15'),(15,'BOT14','Pega Bot v4','251.34.125.67','Pega Bot v4',214,0,'54','54','22','1','1','22'),(16,'BOT15','Workfusion v3','76.34.22.113','Workfusion v3',312,0,'34','43','34','33','1','23'),(17,'BOT16','WorkFusion Bot','181.168.9.1','WF Bot',336,0,'10','1000','10','10','1','10'),(18,'BOT17','CIBC','14.25.67.23','Test Bot',54,0,'6','260','10','500','1','6'),(19,'BOT18','workfusion','127.0.0.1','KYC_BOT1',311,0,'2','10','5','1','1','5'),(20,'BOT19','WF','test','1',246,0,'1','1','1','1','0','1');
/*!40000 ALTER TABLE `bot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `functions`
--

DROP TABLE IF EXISTS `functions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `functions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Category` varchar(100) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `functions`
--

LOCK TABLES `functions` WRITE;
/*!40000 ALTER TABLE `functions` DISABLE KEYS */;
INSERT INTO `functions` VALUES (1,'Group Management','CreateGroup'),(2,'Group Management','ModifyGroup'),(3,'Group Management','DisableGroup'),(4,'Worker Management','AssignWrokers'),(6,'Process Management','DisableWorkers'),(7,'Worker Management','CreateUser'),(8,'User Management','ModifyUser'),(9,'User Management','DisableUser'),(10,'Worker Management','ViewWorkers'),(11,'User Management','ViewUser'),(12,'Privilege Management','ViewPrivilege');
/*!40000 ALTER TABLE `functions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `group_bot_view`
--

DROP TABLE IF EXISTS `group_bot_view`;
/*!50001 DROP VIEW IF EXISTS `group_bot_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `group_bot_view` AS SELECT 
 1 AS `id`,
 1 AS `botKey`,
 1 AS `provider`,
 1 AS `description`,
 1 AS `processId`,
 1 AS `status`,
 1 AS `processName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `group_incidents_view`
--

DROP TABLE IF EXISTS `group_incidents_view`;
/*!50001 DROP VIEW IF EXISTS `group_incidents_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `group_incidents_view` AS SELECT 
 1 AS `ticket_id`,
 1 AS `status`,
 1 AS `transaction_id`,
 1 AS `process_id`,
 1 AS `process_name`,
 1 AS `start_time`,
 1 AS `end_time`,
 1 AS `country`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `group_sla_view`
--

DROP TABLE IF EXISTS `group_sla_view`;
/*!50001 DROP VIEW IF EXISTS `group_sla_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `group_sla_view` AS SELECT 
 1 AS `transaction_id`,
 1 AS `sla`,
 1 AS `process_id`,
 1 AS `process_name`,
 1 AS `worker_status`,
 1 AS `start_time`,
 1 AS `end_time`,
 1 AS `country`,
 1 AS `Duration`,
 1 AS `worker`,
 1 AS `worker_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `group_transaction_view`
--

DROP TABLE IF EXISTS `group_transaction_view`;
/*!50001 DROP VIEW IF EXISTS `group_transaction_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `group_transaction_view` AS SELECT 
 1 AS `transaction_id`,
 1 AS `worker_id`,
 1 AS `worker_status`,
 1 AS `process_id`,
 1 AS `process_name`,
 1 AS `start_time`,
 1 AS `end_time`,
 1 AS `duration`,
 1 AS `efforts_saved`,
 1 AS `status`,
 1 AS `worker_type`,
 1 AS `out_come`,
 1 AS `description`,
 1 AS `tracking_id`,
 1 AS `country`,
 1 AS `function`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `group_users`
--

DROP TABLE IF EXISTS `group_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Group_Id` int(11) DEFAULT NULL,
  `User_Id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_users`
--

LOCK TABLES `group_users` WRITE;
/*!40000 ALTER TABLE `group_users` DISABLE KEYS */;
INSERT INTO `group_users` VALUES (2,2,1),(8,3,5),(10,34,3),(13,45,3),(14,44,1),(19,1,1),(23,4,3),(27,38,3),(28,38,4),(29,43,3),(30,43,4),(33,4,6),(34,4,7),(35,4,8),(36,54,1);
/*!40000 ALTER TABLE `group_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Description` varchar(300) DEFAULT NULL,
  `Type` varchar(45) DEFAULT NULL,
  `Parent_Id` int(11) DEFAULT NULL,
  `Parent_Group_Id` int(11) DEFAULT NULL,
  `isDisabled` int(11) DEFAULT '0',
  `Created_By` varchar(45) DEFAULT NULL,
  `Created_Date` timestamp NULL DEFAULT NULL,
  `Updated_By` varchar(45) DEFAULT NULL,
  `Updated_Date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=338 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,'Americas','Americas Geog','geo',0,0,0,NULL,NULL,NULL,NULL),(2,'North America','Region','region',1,1,0,NULL,NULL,NULL,NULL),(3,'USA','Country','country',2,1,0,NULL,NULL,NULL,NULL),(4,'APAC','APAC Geo','geo',0,0,0,NULL,NULL,NULL,NULL),(5,'Personal Auto','Personal Auto LOB for North America','lob',3,1,0,NULL,NULL,NULL,NULL),(6,'Europe','Europe Geo','geo',0,0,0,NULL,NULL,NULL,NULL),(7,'Latin America','Region','region',1,1,0,NULL,NULL,NULL,NULL),(8,'UK','Region','region',6,6,0,NULL,NULL,NULL,NULL),(9,'Continental Europe','Region','region',6,6,0,NULL,NULL,NULL,NULL),(10,'Nordics','Region','region',6,6,0,NULL,NULL,NULL,NULL),(11,'South Asia','Region','region',4,4,0,NULL,NULL,NULL,NULL),(12,'South-east Asia','Region','region',4,4,0,NULL,NULL,NULL,NULL),(13,'Canada','Country','country',2,1,0,NULL,NULL,NULL,NULL),(14,'Mexico','Country','country',2,1,0,NULL,NULL,NULL,NULL),(15,'Brazil','Country','country',7,1,0,NULL,NULL,NULL,NULL),(16,'Argentina','Country','country',7,1,0,NULL,NULL,NULL,NULL),(17,'England','Country','country',8,6,0,NULL,NULL,NULL,NULL),(18,'Scotland','Country','country',8,6,0,NULL,NULL,NULL,NULL),(19,'Singapore','Country','country',12,4,0,NULL,NULL,NULL,NULL),(20,'India','Country','country',11,4,0,NULL,NULL,NULL,NULL),(21,'Retail Banking','LOB group','lob',3,0,0,NULL,NULL,NULL,NULL),(22,'Retail Banking','LOB group','lob',13,0,0,NULL,NULL,NULL,NULL),(23,'Retail Banking','LOB group','lob',17,0,0,NULL,NULL,NULL,NULL),(24,'Retail Banking','LOB group','lob',20,0,0,NULL,NULL,NULL,NULL),(25,'Capital Markets','CB LOB group','lob',3,0,0,NULL,NULL,NULL,NULL),(26,'Capital Markets','CB LOB group','lob',13,0,0,NULL,NULL,NULL,NULL),(27,'Capital Markets','CB LOB group','lob',17,0,0,NULL,NULL,NULL,NULL),(28,'Capital Markets','CB LOB group','lob',19,0,0,NULL,NULL,NULL,NULL),(29,'Commercial Banks','CB2 LOB group','lob',3,0,0,NULL,NULL,NULL,NULL),(30,'Commercial Banks','CB2 LOB group','lob',13,0,0,NULL,NULL,NULL,NULL),(31,'Commercial Banks','CB2 LOB group','lob',17,0,0,NULL,NULL,NULL,NULL),(32,'Commercial Banks','CB2 LOB group','lob',20,0,0,NULL,NULL,NULL,NULL),(34,'Underwriting','Process under Underwriting function','function',5,0,0,NULL,NULL,NULL,NULL),(41,'Claims','Process under Personal Auto','function',5,0,0,NULL,NULL,NULL,NULL),(43,'Adjudicate Claim','Process under Claims function','process',41,0,0,NULL,NULL,NULL,NULL),(44,'OCR','Process of Underwriting','process',34,0,0,NULL,NULL,NULL,NULL),(45,'Middle East Region','Region','region',4,4,0,NULL,NULL,NULL,NULL),(46,'Approve Claim','Process under Claims Group','process',41,0,0,NULL,NULL,NULL,NULL),(47,'UK','Country','country',45,0,0,NULL,NULL,NULL,NULL),(48,'Personal Auto','Personal Auto Lob for UK','lob',47,0,0,NULL,NULL,NULL,NULL),(49,'Claims','Function','function',48,0,0,NULL,NULL,NULL,NULL),(51,'Adjudicate Claim','Process','process',49,0,0,NULL,NULL,NULL,NULL),(52,'Approve Claim','Process','process',49,0,0,NULL,NULL,NULL,NULL),(54,'Create FNOL','Process of Claims function','process',41,0,0,NULL,NULL,NULL,NULL),(100,'Wealth Management','CB3 LOB group','lob',3,0,0,NULL,NULL,NULL,NULL),(101,'Wealth Management','CB3 LOB group','lob',13,0,0,NULL,NULL,NULL,NULL),(102,'Wealth Management','CB3 LOB group','lob',17,0,0,NULL,NULL,NULL,NULL),(103,'Wealth Management','CB3 LOB group','lob',19,0,0,NULL,NULL,NULL,NULL),(104,'Wealth Management','CB3 LOB group','lob',20,0,0,NULL,NULL,NULL,NULL),(111,'Cards','Cards','function',21,0,0,NULL,NULL,NULL,NULL),(112,'Cards','Cards','function',22,0,0,NULL,NULL,NULL,NULL),(113,'Cards','Cards','function',23,0,0,NULL,NULL,NULL,NULL),(114,'Cards','Cards','function',24,0,0,NULL,NULL,NULL,NULL),(121,'Mortgage','Mortgage','function',21,0,0,NULL,NULL,NULL,NULL),(122,'Mortgage','Mortgage','function',22,0,0,NULL,NULL,NULL,NULL),(123,'Mortgage','Mortgage','function',23,0,0,NULL,NULL,NULL,NULL),(124,'Mortgage','Mortgage','function',24,0,0,NULL,NULL,NULL,NULL),(131,'Payments','Payments','function',21,0,0,NULL,NULL,NULL,NULL),(132,'Payments','Payments','function',22,0,0,NULL,NULL,NULL,NULL),(133,'Payments','Payments','function',23,0,0,NULL,NULL,NULL,NULL),(134,'Payments','Payments','function',24,0,0,NULL,NULL,NULL,NULL),(141,'Front Office','Front Office','function',25,0,0,NULL,NULL,NULL,NULL),(142,'Front Office','Front Office','function',26,0,0,NULL,NULL,NULL,NULL),(143,'Front Office','Front Office','function',27,0,0,NULL,NULL,NULL,NULL),(144,'Front Office','Front Office','function',28,0,0,NULL,NULL,NULL,NULL),(145,'Back Office','Back Office','function',25,0,0,NULL,NULL,NULL,NULL),(146,'Back Office','Back Office','function',26,0,0,NULL,NULL,NULL,NULL),(147,'Back Office','Back Office','function',27,0,0,NULL,NULL,NULL,NULL),(148,'Back Office','Back Office','function',28,0,0,NULL,NULL,NULL,NULL),(149,'Middle Office','Middle Office','function',25,0,0,NULL,NULL,NULL,NULL),(150,'Middle Office','Middle Office','function',26,0,0,NULL,NULL,NULL,NULL),(151,'Middle Office','Middle Office','function',27,0,0,NULL,NULL,NULL,NULL),(152,'Middle Office','Middle Office','function',28,0,0,NULL,NULL,NULL,NULL),(160,'Cash Management','Cash Management','function',29,0,0,NULL,NULL,NULL,NULL),(161,'Cash Management','Cash Management','function',30,0,0,NULL,NULL,NULL,NULL),(162,'Cash Management','Cash Management','function',31,0,0,NULL,NULL,NULL,NULL),(163,'Cash Management','Cash Management','function',32,0,0,NULL,NULL,NULL,NULL),(164,'Trade Finance','Trade Finance','function',29,0,0,NULL,NULL,NULL,NULL),(165,'Trade Finance','Trade Finance','function',30,0,0,NULL,NULL,NULL,NULL),(166,'Trade Finance','Trade Finance','function',31,0,0,NULL,NULL,NULL,NULL),(167,'Trade Finance','Trade Finance','function',32,0,0,NULL,NULL,NULL,NULL),(170,'Advisory Services','Advisory Services','function',100,0,0,NULL,NULL,NULL,NULL),(171,'Advisory Services','Advisory Services','function',101,0,0,NULL,NULL,NULL,NULL),(172,'Advisory Services','Advisory Services','function',102,0,0,NULL,NULL,NULL,NULL),(173,'Advisory Services','Advisory Services','function',103,0,0,NULL,NULL,NULL,NULL),(174,'Advisory Services','Advisory Services','function',104,0,0,NULL,NULL,NULL,NULL),(180,'Execution Services','Execution Services','function',100,0,0,NULL,NULL,NULL,NULL),(181,'Execution Services','Execution Services','function',101,0,0,NULL,NULL,NULL,NULL),(182,'Execution Services','Execution Services','function',102,0,0,NULL,NULL,NULL,NULL),(183,'Execution Services','Execution Services','function',103,0,0,NULL,NULL,NULL,NULL),(184,'Execution Services','Execution Services','function',104,0,0,NULL,NULL,NULL,NULL),(211,'Cards Issuance','Cards Issuance','process',111,0,0,NULL,NULL,NULL,NULL),(212,'Cards Issuance','Cards Issuance','process',112,0,0,NULL,NULL,NULL,NULL),(213,'Cards Issuance','Cards Issuance','process',113,0,0,NULL,NULL,NULL,NULL),(214,'Cards Issuance','Cards Issuance','process',114,0,0,NULL,NULL,NULL,NULL),(221,'Documents Processing','Documents Processing','process',121,0,0,NULL,NULL,NULL,NULL),(222,'Documents Processing','Documents Processing','process',122,0,0,NULL,NULL,NULL,NULL),(223,'Documents Processing','Documents Processing','process',123,0,0,NULL,NULL,NULL,NULL),(224,'Documents Processing','Documents Processing','process',124,0,0,NULL,NULL,NULL,NULL),(231,'Payment Repairs','Payment Repairs','process',131,0,0,NULL,NULL,NULL,NULL),(232,'Payment Repairs','Payment Repairs','process',132,0,0,NULL,NULL,NULL,NULL),(233,'Payment Repairs','Payment Repairs','process',133,0,0,NULL,NULL,NULL,NULL),(234,'Payment Repairs','Payment Repairs','process',134,0,0,NULL,NULL,NULL,NULL),(241,'Reconciliation','Reconciliation','process',141,0,0,NULL,NULL,NULL,NULL),(242,'Reconciliation','Reconciliation','process',142,0,0,NULL,NULL,NULL,NULL),(243,'Reconciliation','Reconciliation','process',143,0,0,NULL,NULL,NULL,NULL),(244,'Reconciliation','Reconciliation','process',144,0,0,NULL,NULL,NULL,NULL),(245,'Reconciliation','Reconciliation','process',145,0,0,NULL,NULL,NULL,NULL),(246,'Reconciliation','Reconciliation','process',146,0,0,NULL,NULL,NULL,NULL),(247,'Reconciliation','Reconciliation','process',147,0,0,NULL,NULL,NULL,NULL),(248,'Reconciliation','Reconciliation','process',147,0,0,NULL,NULL,NULL,NULL),(251,'SSI Setup','SSI Setup','process',149,0,0,NULL,NULL,NULL,NULL),(252,'SSI Setup','SSI Setup','process',150,0,0,NULL,NULL,NULL,NULL),(253,'SSI Setup','SSI Setup','process',151,0,0,NULL,NULL,NULL,NULL),(254,'SSI Setup','SSI Setup','process',152,0,0,NULL,NULL,NULL,NULL),(255,'Margin Call processing','Margin Call processing','process',149,0,0,NULL,NULL,NULL,NULL),(256,'Margin Call processing','Margin Call processing','process',150,0,0,NULL,NULL,NULL,NULL),(257,'Margin Call processing','Margin Call processing','process',151,0,0,NULL,NULL,NULL,NULL),(258,'Margin Call processing','Margin Call processing','process',152,0,0,NULL,NULL,NULL,NULL),(261,'KYC Verification','KYC Verification','process',160,0,0,NULL,NULL,NULL,NULL),(262,'KYC Verification','KYC Verification','process',161,0,0,NULL,NULL,NULL,NULL),(263,'KYC Verification','KYC Verification','process',162,0,0,NULL,NULL,NULL,NULL),(264,'KYC Verification','KYC Verification','process',163,0,0,NULL,NULL,NULL,NULL),(265,'Cheque processing','Cheque processing','process',160,0,0,NULL,NULL,NULL,NULL),(266,'Cheque processing','Cheque processing','process',161,0,0,NULL,NULL,NULL,NULL),(267,'Cheque processing','Cheque processing','process',162,0,0,NULL,NULL,NULL,NULL),(268,'Cheque processing','Cheque processing','process',163,0,0,NULL,NULL,NULL,NULL),(271,'Import LC processing','Import LC processing','process',164,0,0,NULL,NULL,NULL,NULL),(272,'Import LC processing','Import LC processing','process',165,0,0,NULL,NULL,NULL,NULL),(273,'Import LC processing','Import LC processing','process',166,0,0,NULL,NULL,NULL,NULL),(274,'Import LC processing','Import LC processing','process',167,0,0,NULL,NULL,NULL,NULL),(275,'Document Capture','Document Capture','process',164,0,0,NULL,NULL,NULL,NULL),(276,'Document Capture','Document Capture','process',165,0,0,NULL,NULL,NULL,NULL),(277,'Document Capture','Document Capture','process',166,0,0,NULL,NULL,NULL,NULL),(278,'Document Capture','Document Capture','process',167,0,0,NULL,NULL,NULL,NULL),(280,'SSI Setup','SSI Setup','process',174,0,0,NULL,NULL,NULL,NULL),(281,'KYC Verificaton','KYC Verificaton','process',170,0,0,NULL,NULL,NULL,NULL),(282,'KYC Verificaton','KYC Verificaton','process',171,0,0,NULL,NULL,NULL,NULL),(283,'KYC Verificaton','KYC Verificaton','process',172,0,0,NULL,NULL,NULL,NULL),(284,'KYC Verificaton','KYC Verificaton','process',173,0,0,NULL,NULL,NULL,NULL),(285,'KYC Verificaton','KYC Verificaton','process',174,0,0,NULL,NULL,NULL,NULL),(286,'SSI Setup','SSI Setup','process',170,0,0,NULL,NULL,NULL,NULL),(287,'SSI Setup','SSI Setup','process',171,0,0,NULL,NULL,NULL,NULL),(288,'SSI Setup','SSI Setup','process',172,0,0,NULL,NULL,NULL,NULL),(289,'SSI Setup','SSI Setup','process',173,0,0,NULL,NULL,NULL,NULL),(291,'Reconciliation','Reconciliation','process',180,0,0,NULL,NULL,NULL,NULL),(292,'Reconciliation','Reconciliation','process',181,0,0,NULL,NULL,NULL,NULL),(293,'Reconciliation','Reconciliation','process',182,0,0,NULL,NULL,NULL,NULL),(294,'Reconciliation','Reconciliation','process',183,0,0,NULL,NULL,NULL,NULL),(295,'Reconciliation','Reconciliation','process',184,0,0,NULL,NULL,NULL,NULL),(311,'KYC Check','KYC Check','process',111,0,0,NULL,NULL,NULL,NULL),(312,'KYC Check','KYC Check','process',112,0,0,NULL,NULL,NULL,NULL),(313,'KYC Check','KYC Check','process',113,0,0,NULL,NULL,NULL,NULL),(314,'KYC Check','KYC Check','process',114,0,0,NULL,NULL,NULL,NULL),(331,'Reconciliation','Reconciliation','process',131,0,0,NULL,NULL,NULL,NULL),(332,'Reconciliation','Reconciliation','process',132,0,0,NULL,NULL,NULL,NULL),(333,'Reconciliation','Reconciliation','process',133,0,0,NULL,NULL,NULL,NULL),(334,'Reconciliation','Reconciliation','process',134,0,0,NULL,NULL,NULL,NULL),(336,'Fraud Check','Fraud Check','process',114,0,0,NULL,NULL,NULL,NULL),(337,'Fraud','Tracking fraud activity','process',111,0,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups_old`
--

DROP TABLE IF EXISTS `groups_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups_old` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Description` varchar(300) DEFAULT NULL,
  `Type` varchar(45) DEFAULT NULL,
  `Parent_Id` int(11) DEFAULT NULL,
  `Parent_Group_Id` int(11) DEFAULT NULL,
  `isDisabled` int(11) DEFAULT '0',
  `Created_By` varchar(45) DEFAULT NULL,
  `Created_Date` timestamp NULL DEFAULT NULL,
  `Updated_By` varchar(45) DEFAULT NULL,
  `Updated_Date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups_old`
--

LOCK TABLES `groups_old` WRITE;
/*!40000 ALTER TABLE `groups_old` DISABLE KEYS */;
INSERT INTO `groups_old` VALUES (1,'Americas','Americas Geog','geo',0,0,0,NULL,NULL,NULL,NULL),(2,'North America','Region','region',1,1,0,NULL,NULL,NULL,NULL),(3,'US','Country','country',2,1,0,NULL,NULL,NULL,NULL),(4,'EMEA','EMEA Geo','geo',0,0,0,NULL,NULL,NULL,NULL),(5,'Personal Auto','Personal Auto LOB for North America','lob',3,1,0,NULL,NULL,NULL,NULL),(34,'Underwriting','Process under Underwriting function','function',5,0,0,NULL,NULL,NULL,NULL),(38,'APAC','Geo Root','geo',0,0,1,NULL,NULL,NULL,NULL),(41,'Claims','Process under Personal Auto','function',5,0,0,NULL,NULL,NULL,NULL),(43,'Adjudicate Claim','Process under Claims function','process',41,0,0,NULL,NULL,NULL,NULL),(44,'OCR','Process of Underwriting','process',34,0,0,NULL,NULL,NULL,NULL),(45,'Middle East Region','Region','region',4,4,0,NULL,NULL,NULL,NULL),(46,'Approve Claim','Process under Claims Group','process',41,0,0,NULL,NULL,NULL,NULL),(47,'UK','Country','country',45,0,0,NULL,NULL,NULL,NULL),(48,'Personal Auto','Personal Auto Lob for UK','lob',47,0,0,NULL,NULL,NULL,NULL),(49,'Claims','Function','function',48,0,0,NULL,NULL,NULL,NULL),(51,'Adjudicate Claim','Process','process',49,0,0,NULL,NULL,NULL,NULL),(52,'Approve Claim','Process','process',49,0,0,NULL,NULL,NULL,NULL),(54,'Create FNOL','Process of Claims function','process',41,0,0,NULL,NULL,NULL,NULL),(55,'Commercial Auto','Commercial Auto','lob',3,0,0,NULL,NULL,NULL,NULL),(56,'Comm Claims','Comm Claims','process',55,0,1,NULL,NULL,NULL,NULL),(57,'Comm UND','Commercial Underwriting','process',55,0,0,NULL,NULL,NULL,NULL),(58,'Comm SandD','Sales and Distribution','process',55,0,0,NULL,NULL,NULL,NULL),(59,'Canada','Canada','geo',0,0,1,NULL,NULL,NULL,NULL),(60,'India','India','geo',0,0,1,NULL,NULL,NULL,NULL),(61,'IN-India','India','country',0,0,1,NULL,NULL,NULL,NULL),(62,'Ontario','Ontario province','region',59,0,1,NULL,NULL,NULL,NULL),(63,'Canada','','country',2,0,0,NULL,NULL,NULL,NULL),(64,'WorldWide','world wide org','geo',0,0,0,NULL,NULL,NULL,NULL),(65,'South America','','region',64,0,0,NULL,NULL,NULL,NULL),(66,'Columbia','','country',65,0,0,NULL,NULL,NULL,NULL),(67,'Banking','','lob',66,0,0,NULL,NULL,NULL,NULL),(68,'Loans','','function',67,0,0,NULL,NULL,NULL,NULL),(69,'Mortgage','','process',68,0,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `groups_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `human_worker`
--

DROP TABLE IF EXISTS `human_worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `human_worker` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Worker_Id` varchar(45) DEFAULT NULL,
  `Name` varchar(60) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `Process_Id` int(11) DEFAULT NULL,
  `isDisabled` int(11) DEFAULT '0',
  `avgEfforts` varchar(45) DEFAULT NULL,
  `avgCost` varchar(45) DEFAULT NULL,
  `cycleTime` varchar(45) DEFAULT NULL,
  `noOftransactions` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `human_worker`
--

LOCK TABLES `human_worker` WRITE;
/*!40000 ALTER TABLE `human_worker` DISABLE KEYS */;
INSERT INTO `human_worker` VALUES (1,'Fathima','Fathima Hussian','Human worker',42,0,'15','null','30','50'),(2,'Suresh','Suresh','Human Worker for Create FNOL',42,0,'15','null','30','30'),(4,'Harish','Harish Krishna','Human worker',46,1,'15','','30','30'),(5,'Venkat','Venkat Krish','Human worker for AJ',43,1,'15','','25','21'),(6,'Suresh1','Suresh Mani','Human Worker for AC',43,1,'15','','35','28'),(7,'Fathima1','Fathi','Beh',43,1,'15','null','30','50'),(8,'Rohit','Rohit','Human',43,0,'15','null','30','50'),(9,'Rajan','RajRajan','Human Worker',43,0,'15','null','30','54'),(10,'jith','Jithin','Human worker',43,0,'15','null','30','25'),(12,'jith9','Jithin','Human worker',43,0,'15','null','30','25'),(13,'jith1','Jithin','Human worker',43,0,'15','null','30','25'),(14,'jith2','Jithin','Human worker',43,0,'15','null','30','25'),(15,'jith3','Jithin','Human worker',43,0,'15','null','30','25'),(16,'jith4','Jithin','Human worker',43,0,'15','null','30','25'),(17,'jith5','Jithin','Human worker',43,0,'15','null','30','25'),(18,'jith6','Jithin','Human worker',43,0,'15','null','30','25'),(19,'jith7','Jithin','Human worker',43,0,'15','null','30','25'),(20,'jith8','Jithin','Human worker',43,0,'15','null','30','25'),(21,'jith9','Jithin','Human worker',42,1,'15','null','30','25'),(22,'jith1','Jithin1','Human worker1',42,1,'15','null','30','25'),(23,'Fatima','Fatima John','Human Worker',51,0,'15','','30','40'),(24,'PegaClaims-0102','Pega Claims','Pega claims processing platform',69,0,'5','','240','260');
/*!40000 ALTER TABLE `human_worker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `incidents_view`
--

DROP TABLE IF EXISTS `incidents_view`;
/*!50001 DROP VIEW IF EXISTS `incidents_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `incidents_view` AS SELECT 
 1 AS `ticket_id`,
 1 AS `status`,
 1 AS `description`,
 1 AS `process_id`,
 1 AS `process_name`,
 1 AS `SLA`,
 1 AS `effort_saved`,
 1 AS `sequence`,
 1 AS `geography`,
 1 AS `region`,
 1 AS `start_time`,
 1 AS `end_time`,
 1 AS `Duration`,
 1 AS `worker`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `privilage`
--

DROP TABLE IF EXISTS `privilage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privilage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Function_Id` int(11) DEFAULT NULL,
  `Role_Id` int(11) DEFAULT NULL,
  `access` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `privilage`
--

LOCK TABLES `privilage` WRITE;
/*!40000 ALTER TABLE `privilage` DISABLE KEYS */;
INSERT INTO `privilage` VALUES (1,1,1,1),(3,3,1,1),(4,4,1,1),(6,6,1,1),(7,7,1,1),(9,9,1,1),(10,1,2,0),(12,3,2,0),(13,4,2,1),(15,6,2,1),(16,7,2,0),(18,9,2,0),(19,1,3,0),(21,3,3,0),(22,4,3,0),(24,6,3,1),(25,7,3,0),(27,9,3,0),(28,10,3,1),(29,10,2,1),(30,10,1,1),(31,11,1,1),(32,11,2,0),(33,11,3,0),(34,12,1,1),(35,12,2,0),(36,12,3,0),(52,1,5,1),(53,2,5,1),(54,3,5,1),(55,4,5,1),(56,6,5,1),(57,7,5,1),(58,8,5,1),(59,9,5,1),(60,10,5,1),(61,11,5,1),(62,12,5,1);
/*!40000 ALTER TABLE `privilage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `isDisabled` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'Administrator','Administrator',0),(2,'Operations Manager','Operations Manager',0),(3,'Operations Supervisor','Operations Supervisor',0),(5,'Super Admin',NULL,1);
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequence_temp`
--

DROP TABLE IF EXISTS `sequence_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequence_temp` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Process_Name` varchar(100) DEFAULT NULL,
  `sequence` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequence_temp`
--

LOCK TABLES `sequence_temp` WRITE;
/*!40000 ALTER TABLE `sequence_temp` DISABLE KEYS */;
INSERT INTO `sequence_temp` VALUES (1,'Create FNOL',1),(2,'Adjudicate Claim',2),(3,'Approve Claim',3),(4,'Cards Issuance',4),(5,'Document Capture',5),(6,'KYC Verification',6),(7,'Reconciliation',7),(8,'SSI Setup',8),(9,'Margin Call processing',9),(10,'Margin Call processing',10),(11,'KYC Check',11),(12,'Cheque processing',12);
/*!40000 ALTER TABLE `sequence_temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `sla_view`
--

DROP TABLE IF EXISTS `sla_view`;
/*!50001 DROP VIEW IF EXISTS `sla_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `sla_view` AS SELECT 
 1 AS `sla`,
 1 AS `process_name`,
 1 AS `process_id`,
 1 AS `effort_saved`,
 1 AS `sequence`,
 1 AS `geography`,
 1 AS `region`,
 1 AS `start_time`,
 1 AS `end_time`,
 1 AS `Duration`,
 1 AS `worker`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `WORKER_ID` int(11) DEFAULT '0',
  `WORKER_TYPE` varchar(50) DEFAULT NULL,
  `STATUS` varchar(50) DEFAULT NULL,
  `START_TIME` datetime DEFAULT NULL,
  `END_TIME` datetime DEFAULT NULL,
  `DURATION` varchar(10) DEFAULT NULL,
  `OUT_COME` varchar(50) DEFAULT NULL,
  `EXCEPTION_TYPE` varchar(200) DEFAULT NULL,
  `DESCRIPTION` varchar(400) DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `CREATED_DATE` varchar(50) DEFAULT NULL,
  `TRACKING_ID` varchar(45) DEFAULT NULL,
  `COUNTRY` varchar(100) DEFAULT NULL,
  `B_FUNCTION` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3205 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,1,'BOT','0','2017-05-01 12:00:02','2017-05-01 12:02:44','10','','','description','BOT',NULL,NULL,'US','Claims'),(2,1,'BOT','0','2017-05-01 15:00:02','2017-05-01 15:02:24','10','','','description','BOT',NULL,NULL,'US','Claims'),(3,2,'BOT','0','2017-05-02 12:15:02','2017-05-02 12:17:16','5','','','description','BOT',NULL,NULL,'US','Claims'),(4,2,'BOT','0','2017-05-02 15:10:02','2017-05-02 15:11:41','5','','','description','BOT',NULL,NULL,'US','Claims'),(5,2,'BOT','0','2017-05-02 16:00:02','2017-05-02 16:02:31','5','','','description','BOT',NULL,NULL,'US','Claims'),(6,2,'BOT','0','2017-05-02 17:00:02','2017-05-02 17:01:11','5','','','description','BOT',NULL,NULL,'US','Claims'),(7,1,'BOT','0','2017-05-03 12:30:44','2017-05-03 12:32:09','','','','description','BOT','',NULL,'US','Claims'),(13,1,'HUMAN','0','2017-05-04 12:03:09','2017-05-04 12:35:12','','','','description','Fatima','',NULL,'US','Claims'),(14,1,'BOT','0','2017-05-05 12:30:44','2017-05-05 12:32:44',NULL,NULL,NULL,NULL,'BOT',NULL,NULL,'US','Claims'),(15,3,'BOT','0','2017-05-06 15:00:02','2017-05-06 15:02:44',NULL,'','','description','CSRBOT',NULL,NULL,'US','Claims'),(16,3,'BOT','0','2017-05-06 22:01:32','2017-05-06 22:03:12',NULL,'','','description','CSRBOT',NULL,NULL,'US','Claims'),(17,3,'BOT','0','2017-05-07 15:00:02','2017-05-07 15:02:44',NULL,'','','description','CSRBOT',NULL,NULL,'US','Claims'),(18,3,'BOT','0','2017-05-07 22:01:32','2017-05-07 22:03:12',NULL,'','','description','CSRBOT',NULL,NULL,'US','Claims'),(19,3,'BOT','0','2017-05-11 21:46:52','2017-05-11 21:49:02',NULL,'Claim File is created successfully.','','CF-510is completed &amp; FNOL-1472 is created','CSRBOT',NULL,NULL,'US','Claims'),(21,3,'BOT','0','2017-05-18 15:30:21','2017-05-18 15:45:14',NULL,NULL,NULL,'OCR Created','CSRBOT',NULL,NULL,'US','Claims'),(22,3,'BOT','0','2017-05-19 18:30:41','2017-05-19 18:35:49',NULL,'Claim File is created successfully.','null','is completed &  is created','OCRBOT',NULL,'OCR-20170519183041','US','Claims'),(23,3,'BOT','0','2017-05-20 18:30:41','2017-05-20 18:35:49',NULL,'Claim File is created successfully.','','is completed &  is created','OCRBOT',NULL,'OCR-20170520183041','US','Claims'),(24,3,'BOT','0','2017-05-19 23:50:18','2017-05-19 23:51:33',NULL,'CSV files are created successfully.','','OCR service completed.','OCRBOT',NULL,'Ref # 20170519235018','US','Claims'),(26,1,'BOT','1','2017-06-14 23:42:18','2017-06-14 23:50:33',NULL,'Backend System Down','OU','Backend System Down','OCRBOT',NULL,'Ref#1027061450','US','Claims'),(27,1,'BOT','1','2017-06-15 09:10:12','2017-06-15 09:20:08',NULL,'Backend System Down','OU','Backend System Down','OCRBOT',NULL,'Ref#1027061509','US','Claims'),(32,1,'BOT','1','2017-06-20 10:25:12','2017-06-20 10:30:08',NULL,'Backend System Down','OU','Backend System Down','OCRBOT',NULL,'Ref#1027061514','US','Claims'),(33,1,'BOT','1','2017-06-20 10:40:12','2017-06-20 10:45:08',NULL,'Backend System Down','OU','Backend System Down','OCRBOT',NULL,'Ref#1027061515','US','Claims'),(34,9,'BOT','1','2017-06-20 11:40:12','2017-06-20 11:45:08',NULL,'Backend System Down','OU','Backend System Down','OCRBOT',NULL,'Ref#1027061516','US','Claims'),(35,9,'BOT','1','2017-06-20 11:45:12','2017-06-20 11:50:08',NULL,'Backend System Down','OU','Backend System Down','OCRBOT',NULL,'Ref#1027061517','US','Claims'),(36,9,'BOT','1','2017-06-21 11:45:12','2017-06-21 11:50:08',NULL,'Backend System Down','OU','Backend System Down','OCRBOT',NULL,'Ref#1027061518','US','Claims'),(37,9,'BOT','1','2017-06-21 11:50:12','2017-06-21 11:55:08',NULL,'Backend System Down','OU','Backend System Down','OCRBOT',NULL,'Ref#1027061519','US','Claims'),(38,1,'HUMAN','0','2017-07-02 15:00:02','2017-07-02 15:30:44',NULL,NULL,'','FNOL Created','Fatima',NULL,'FNOL-801-20170702151044','US','Claims'),(39,1,'HUMAN','0','2017-07-02 16:00:02','2017-07-02 16:32:44',NULL,NULL,'','FNOL Created','Fatima',NULL,'FNOL-801-20170702151044','US','Claims'),(40,4,'BOT','0','2017-11-30 08:00:02','2017-11-30 08:05:44',NULL,'','','Mailed Quote Successful','',NULL,'AC-100-20170904121044','US','Claims'),(41,4,'BOT','0','2017-11-30 08:30:02','2017-11-30 08:35:44',NULL,'','','Mailed Quote Successful','',NULL,'AC-100-20171130121044','US','Claims'),(42,1,'BOT','0','2017-11-30 11:21:03','2017-11-30 11:22:37',NULL,'Claim created successfully.','','Create FNOL Success','FNOLBOT',NULL,'Ref # ','US','Claims'),(43,1,'BOT','0','2017-11-30 11:21:03','2017-11-30 11:22:37',NULL,'Claim created successfully.','','Create FNOL Success','FNOLBOT',NULL,'Ref # ','US','Claims'),(44,1,'BOT','0','2017-11-30 11:41:15','2017-11-30 11:42:52',NULL,'Claim created successfully.','','Create FNOL Success','FNOLBOT',NULL,'Ref # ','US','Claims'),(45,4,'BOT','0','2017-11-30 11:30:02','2017-11-30 11:35:44',NULL,'','','Mailed Quote Successful','',NULL,'AC-100-20171130121044','US','Claims'),(46,4,'BOT','0','2017-11-30 11:35:02','2017-11-30 11:40:44',NULL,'','','Mailed Quote Successful','',NULL,'AC-100-20171130121044','US','Claims'),(47,4,'BOT','0','2017-11-30 11:40:02','2017-11-30 11:44:44',NULL,'','','Mailed Quote Successful','',NULL,'AC-100-20171130401044','US','Claims'),(48,1,'BOT','0','2017-11-30 12:30:59','2017-11-30 12:33:42',NULL,'Claim created successfully.','','Create FNOL Success','FNOLBOT',NULL,'Ref # ','US','Claims'),(49,5,'BOT','0','2017-10-28 10:40:02','2017-10-28 10:44:44',NULL,'','','Create FNOL Success','',NULL,'FNOL-100-20171028104002','UK','Claims'),(50,5,'BOT','0','2017-10-28 10:45:02','2017-10-28 10:50:44',NULL,'','','Create FNOL Success','',NULL,'FNOL-100-20171028104502','UK','Claims'),(51,5,'BOT','0','2017-10-28 10:50:02','2017-10-28 10:55:44',NULL,'','','Create FNOL Success','',NULL,'FNOL-100-20171028105002','UK','Claims'),(52,5,'BOT','0','2017-10-28 10:55:02','2017-10-28 10:59:44',NULL,'','','Create FNOL Success','',NULL,'FNOL-100-20171028105502','UK','Claims'),(53,1,'BOT','0','2017-11-30 13:00:02','2017-11-30 13:05:32',NULL,'Claim created successfully.','','Create FNOL Success','FNOLBOT',NULL,'FNOL- 20171130130532','US','Claims'),(54,1,'BOT','0','2017-11-30 14:16:40','2017-11-30 14:18:15',NULL,'Claim created successfully.','','Create FNOL Success','FNOLBOT',NULL,'AC-101-20170704153444','US','Claims'),(55,1,'BOT','0','2017-11-30 15:05:34','2017-11-30 15:07:28',NULL,'Claim created successfully.','','Create FNOL Success','FNOLBOT',NULL,'FNOL- 20171130150728','US','Claims'),(57,8,'HUMAN','0','2017-07-04 13:00:02','2017-07-04 13:31:02',NULL,NULL,NULL,'Adjudicate Claim Created','Rohit',NULL,'AC-100-20170704133244','US','Claims'),(58,8,'HUMAN','0','2017-07-04 15:00:02','2017-07-04 15:34:02',NULL,NULL,NULL,'Adjudicate Claim Created','Rohit',NULL,'AC-101-20170704153444','US','Claims'),(59,6,'BOT','0','2017-10-25 12:00:02','2017-10-25 12:35:02',NULL,'Claim created successfully.',NULL,'Create FNOL Success',NULL,NULL,'AC-101-20171025123234','UK','Claims'),(60,6,'BOT','0','2017-10-25 13:00:02','2017-10-25 13:35:02',NULL,'Claim created successfully.',NULL,'Create FNOL Success',NULL,NULL,'AC-101-20171025133234','UK','Claims'),(61,6,'BOT','0','2017-10-25 14:00:02','2017-10-25 14:35:02',NULL,'Claim created successfully.',NULL,'Create FNOL Success',NULL,NULL,'AC-101-20171025143234','UK','Claims'),(62,6,'BOT','0','2017-10-25 15:00:02','2017-10-25 15:35:02',NULL,'Claim created successfully.',NULL,'Create FNOL Success',NULL,NULL,'AC-101-20171025153234','UK','Claims'),(63,6,'BOT','0','2017-10-25 16:00:02','2017-10-25 16:35:02',NULL,'Claim created successfully.',NULL,'Create FNOL Success',NULL,NULL,'AC-101-20171025163234','UK','Claims'),(64,1,'BOT','0','2017-12-11 12:38:27','2017-12-11 12:41:18',NULL,'Claim created successfully.','','Create FNOL Success','FNOLBOT',NULL,'FNOL- 20171211124118','US','Claims'),(65,5,'BOT','0','2017-12-11 10:45:02','2017-12-11 10:50:44',NULL,'','','Adjudicate Claim Success','',NULL,'AC-100-20171211104502','UK','Claims'),(66,5,'BOT','0','2017-12-10 10:45:02','2017-12-10 10:50:44',NULL,'','','Adjudicate Claim Success','',NULL,'AC-100-20171211004502','UK','Claims'),(67,9,'BOT','0','2017-12-14 16:01:29','2017-12-14 16:05:18',NULL,'Claim File is created successfully.','','FNOL20171214160518 - CreateFNOL success','FNOLBOT',NULL,'FNOL20171214160518','US','Claims'),(68,9,'BOT','0','2017-12-15 10:01:29','2017-12-15 10:05:18',NULL,'Claim File is created successfully.',NULL,'FNOL20171215150518 - CreateFNOL success','FNOLBOT',NULL,'FNOL20171215150518','US','Claims'),(69,9,'BOT','0','2017-12-15 11:01:29','2017-12-15 11:05:18',NULL,'Claim File is created successfully.',NULL,'FNOL20171215160518 - CreateFNOL success','FNOLBOT',NULL,'FNOL20171215160518','US','Claims'),(70,9,'BOT','0','2017-12-15 12:10:29','2017-12-15 12:15:18',NULL,'Claim File is created successfully.',NULL,'FNOL20171215161018 - CreateFNOL success','FNOLBOT',NULL,'FNOL20171215161018','US','Claims'),(71,9,'BOT','0','2017-12-15 13:16:29','2017-12-15 13:21:18',NULL,'Claim File is created successfully.',NULL,'FNOL20171215162118 - CreateFNOL success',NULL,NULL,'FNOL20171215162118 ','US','Claims'),(72,9,'BOT','0','2018-01-19 13:21:08','2018-01-19 13:29:33',NULL,'Exception during FNOL creation','RA','Exception has been thrown by the target of an invocation.','FNOLBOT',NULL,'FNOL20180119132933-CreateFNOLfailed','US','Claims'),(1000,13,'BOT','0','2018-01-12 15:03:04','2018-01-12 15:03:14','10','','','successful issued card ending #1234','BOT',NULL,NULL,'Canada','Cards'),(1001,13,'BOT','0','2018-01-12 15:25:04','2018-01-12 15:25:24','20','','','successful issued card ending #3456','BOT',NULL,NULL,'Canada','Cards'),(1002,13,'BOT','0','2018-01-16 16:25:04','2018-01-16 16:25:16','12','','','successful issued card ending #5631','BOT',NULL,NULL,'Canada','Cards'),(1003,13,'BOT','0','2018-02-15 10:21:04','2018-02-15 10:28:16','7','','','successful issued card ending #5631','BOT',NULL,NULL,'Canada','Cards'),(1020,16,'BOT','0','2018-01-12 16:03:04','2018-01-12 16:03:14','10','','','KYC check done on card ending #5630','BOT',NULL,NULL,'Canada','Cards'),(1021,16,'BOT','0','2018-01-12 16:25:04','2018-01-12 16:25:24','20','','','KYC check done on card ending #5631','BOT',NULL,NULL,'Canada','Cards'),(1022,16,'BOT','0','2018-01-16 17:25:04','2018-01-16 17:25:16','12','','','KYC check done on card ending #5632','BOT',NULL,NULL,'Canada','Cards'),(1023,16,'BOT','0','2018-02-15 20:21:04','2018-02-15 20:28:16','7','','','KYC check done on card ending #5633','BOT',NULL,NULL,'Canada','Cards'),(1200,13,'BOT','1','2017-06-14 23:42:18','2017-06-14 23:50:33',NULL,'Network Level-2 Router Outage','OU','Network Level-2 Router Outage','BOT',NULL,'Ref#1027061450','Canada','Cards'),(1201,13,'BOT','1','2017-07-15 23:42:18','2017-07-15 23:50:33',NULL,'Insufficient fund','OU','Insufficient fund','BOT',NULL,'Ref#1027061450','Canada','Cards'),(1202,13,'BOT','1','2017-08-10 23:42:18','2017-08-15 23:50:33',NULL,'Insufficient fund','OU','Insufficient fund','BOT',NULL,'Ref#1027061567','Canada','Cards'),(1203,13,'BOT','1','2017-06-14 23:42:18','2017-06-14 23:50:33',NULL,'Backend System Down','OU','Backend System Down','BOT',NULL,'Ref#1027061450','Canada','Cards'),(2000,14,'BOT','0','2018-03-12 12:03:04','2018-03-12 12:03:14','10','','','Verified user John B','BOT',NULL,NULL,'Canada','Cards'),(2001,14,'BOT','0','2018-03-12 12:25:04','2018-03-12 12:25:24','20','','','Verified user Sam X','BOT',NULL,NULL,'Canada','Cards'),(2002,14,'BOT','0','2018-04-16 13:25:04','2018-04-16 13:25:16','12','','','Verified user Francois G','BOT',NULL,NULL,'Canada','Cards'),(2003,14,'BOT','0','2018-05-15 15:21:04','2018-05-15 15:28:16','7','','','Verification paused on Martin Miller','BOT',NULL,NULL,'Canada','Cards'),(2004,14,'BOT','0','2018-06-21 17:21:14','2018-06-21 17:28:26','7','','','Verification paused on Jimmy F','BOT',NULL,NULL,'Canada','Cards'),(2200,14,'BOT','1','2017-06-14 23:42:18','2017-06-14 23:50:33',NULL,'Network connection timeout','OU','Network connection timeout','BOT',NULL,'Ref#1027061451','Canada','Cards'),(2201,14,'BOT','1','2017-07-15 23:42:18','2017-07-15 23:50:33',NULL,'Incomplete credentials','OU','Incomplete credentials','BOT',NULL,'Ref#1027061452','Canada','Cards'),(2202,14,'BOT','1','2017-08-10 23:42:18','2017-08-15 23:50:33',NULL,'High probability of fraudulence','OU','High probability of fraudulence','BOT',NULL,'Ref#1027062567','Canada','Cards'),(2203,14,'BOT','1','2017-06-14 23:42:18','2017-06-14 23:50:33',NULL,'Backend System Down','OU','Backend System Down','BOT',NULL,'Ref#1027061456','Canada','Cards'),(3000,15,'BOT','0','2018-01-22 15:03:04','2018-01-22 15:03:14','10','','','successful issued card ending #1234','BOT',NULL,NULL,'India','Cards'),(3001,15,'BOT','0','2018-01-22 15:25:04','2018-01-22 15:25:24','20','','','successful issued card ending #3456','BOT',NULL,NULL,'India','Cards'),(3002,15,'BOT','0','2018-01-06 16:25:04','2018-01-06 16:25:16','12','','','successful issued card ending #6633','BOT',NULL,NULL,'India','Cards'),(3003,15,'BOT','0','2018-04-15 10:21:04','2018-04-15 10:28:16','7','','','successful issued card ending #7854','BOT',NULL,NULL,'India','Cards'),(3004,15,'BOT','0','2018-04-16 10:21:04','2018-04-16 10:30:16','9','','','successful issued card ending #3453','BOT',NULL,NULL,'India','Cards'),(3005,15,'BOT','0','2018-04-26 11:21:04','2018-04-26 11:32:16','11','','','successful issued card ending #1236','BOT',NULL,NULL,'India','Cards'),(3200,15,'BOT','1','2018-02-10 23:42:18','2018-02-10 23:50:33',NULL,'Database transaction timeout','OU','Database transaction timeout','BOT',NULL,'Ref#1027061450','India','Cards'),(3201,15,'BOT','1','2018-02-25 23:42:18','2018-02-25 23:50:33',NULL,'Insufficient fund','OU','Insufficient fund','BOT',NULL,'Ref#1027061450','India','Cards'),(3202,15,'BOT','1','2018-03-11 23:42:18','2018-03-11 23:50:33',NULL,'Password not meeting requirements','OU','Password not meeting requirements','BOT',NULL,'Ref#1027061567','India','Cards'),(3203,15,'BOT','1','2018-03-28 23:42:18','2018-03-28 23:50:33',NULL,'Backend System Down','OU','Backend System Down','BOT',NULL,'Ref#1027061450','India','Cards'),(3204,15,'BOT','1','2018-04-20 23:42:18','2018-04-20 23:50:33',NULL,'Backup restore failed','OU','Backup restore failed','BOT',NULL,'Ref#1027061455','India','Cards');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `transation_view`
--

DROP TABLE IF EXISTS `transation_view`;
/*!50001 DROP VIEW IF EXISTS `transation_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `transation_view` AS SELECT 
 1 AS `bot_key`,
 1 AS `process_id`,
 1 AS `process_name`,
 1 AS `SLA`,
 1 AS `effort_saved`,
 1 AS `sequence`,
 1 AS `geography`,
 1 AS `region`,
 1 AS `start_time`,
 1 AS `end_time`,
 1 AS `Duration`,
 1 AS `status`,
 1 AS `worker`,
 1 AS `out_come`,
 1 AS `description`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_Id` varchar(50) NOT NULL,
  `First_Name` varchar(50) DEFAULT NULL,
  `Sur_Name` varchar(45) DEFAULT '',
  `Last_Name` varchar(45) DEFAULT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `Role_Id` int(11) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `isDisabled` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`),
  UNIQUE KEY `User_Id_UNIQUE` (`User_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Walter','Walter','St','Steve','welcome01',1,NULL,0),(2,'Roger','Roger','','Federer','welcome01',1,NULL,0),(3,'John','John','G','Smith','welcome01',2,NULL,0),(4,'James','James','Ft','Norman','welcome01',2,NULL,0),(5,'Samual','Samuel','M','Philips','welcome01',1,NULL,0),(6,'psamual','Pradeep','M','Samual','welcome01',3,NULL,1),(7,'Rajanselvam','Rajan','M','Selvam','welcome01',5,NULL,0),(8,'Gayathri','Gayathri','P','Selvam','welcome01',1,NULL,0),(9,'Divya','Divya','P','Prabha','welcome01',2,NULL,1),(11,'Ved','Ved','','Narayan','welcome01',1,NULL,0),(12,'Laknath','Laknath','','Ranasinghe','welcome01',1,NULL,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vbrain_audit`
--

DROP TABLE IF EXISTS `vbrain_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_audit` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AUDIT_TYPE` varchar(20) DEFAULT NULL,
  `AUDIT_TYPE_INSTANCE_ID` varchar(20) DEFAULT NULL,
  `DESCRIPTION` varchar(200) DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `UPDATED_BY` varchar(50) DEFAULT NULL,
  `UPDATED_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vbrain_audit`
--

LOCK TABLES `vbrain_audit` WRITE;
/*!40000 ALTER TABLE `vbrain_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `vbrain_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vbrain_bot`
--

DROP TABLE IF EXISTS `vbrain_bot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_bot` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BOT_KEY` varchar(50) NOT NULL,
  `BOT_PROVIDER` varchar(50) DEFAULT NULL,
  `IP_ADDRESS` varchar(20) NOT NULL,
  `API_URL` varchar(200) DEFAULT NULL,
  `STATUS` varchar(20) NOT NULL,
  `REGISTRATION_DATE` datetime DEFAULT NULL,
  `DESCRIPTION` varchar(400) DEFAULT NULL,
  `LAST_PING_DATE` datetime DEFAULT NULL,
  `LAST_PING_STATUS` varchar(20) NOT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `UPDATED_BY` varchar(50) DEFAULT NULL,
  `UPDATED_DATE` datetime DEFAULT NULL,
  `GEO_ID` int(11) DEFAULT NULL,
  `PROCESS_ID` int(11) DEFAULT NULL,
  `TRANSACTIONS` int(11) DEFAULT '0',
  `TYPE` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `vbrain_bot_geo_id_idx` (`GEO_ID`),
  KEY `vbrain_bot_process_id_idx` (`PROCESS_ID`),
  CONSTRAINT `vbrain_bot_geo_id` FOREIGN KEY (`GEO_ID`) REFERENCES `vbrain_geo` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `vbrain_bot_process_id` FOREIGN KEY (`PROCESS_ID`) REFERENCES `vbrain_process` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vbrain_bot`
--

LOCK TABLES `vbrain_bot` WRITE;
/*!40000 ALTER TABLE `vbrain_bot` DISABLE KEYS */;
INSERT INTO `vbrain_bot` VALUES (1,'BOTFNOL1','OPEN SPAN','0.0.0.0',NULL,'0',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,1,1,0,'BOT'),(2,'BOTFNOL2','OPEN SPAN','0.0.0.0',NULL,'1',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,2,1,0,'BOT'),(3,'BOTFNOL3','OPEN SPAN','0.0.0.0',NULL,'1',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,3,1,0,'BOT'),(4,'BOTFNOL4','OPEN SPAN','0.0.0.0',NULL,'1',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,4,1,0,'BOT'),(7,'BOTACLAIM1','OPEN SPAN','0.0.0.0',NULL,'1',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,1,2,0,'BOT'),(8,'BOTACLAIM2','OPEN SPAN','0.0.0.0',NULL,'1',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,2,2,0,'BOT'),(9,'BOTACLAIM3','OPEN SPAN','0.0.0.0',NULL,'1',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,3,2,0,'BOT'),(10,'BOTACLAIM4','OPEN SPAN','0.0.0.0',NULL,'1',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,4,2,0,'BOT'),(11,'BOT1234','OPEN SPAN','0.0.0.0',NULL,'1',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,1,1,0,'BOT'),(12,'USER1',NULL,'0.0.0.0',NULL,'1',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,1,3,0,'HUMAN'),(13,'BOTOCR1','OPEN SPAN','0.0.0.0',NULL,'1',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,1,4,0,'BOT'),(14,'USER2',NULL,'0.0.0.0',NULL,'1',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,1,4,0,'HUMAN'),(15,'USERFNOL',NULL,'0.0.0.0',NULL,'1',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,1,1,0,'HUMAN'),(16,'Sruthi',NULL,'0.0.0.0',NULL,'1',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,1,1,0,'Human');
/*!40000 ALTER TABLE `vbrain_bot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vbrain_bot_config`
--

DROP TABLE IF EXISTS `vbrain_bot_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_bot_config` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BOT_ID` int(11) NOT NULL,
  `CONFIG_PARAM` varchar(10) DEFAULT NULL,
  `CONFIG_VALUE` varchar(50) DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `UPDATED_BY` varchar(50) DEFAULT NULL,
  `UPDATED_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `BOT_ID` (`BOT_ID`),
  CONSTRAINT `vbrain_bot_config_ibfk_1` FOREIGN KEY (`BOT_ID`) REFERENCES `vbrain_bot` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vbrain_bot_config`
--

LOCK TABLES `vbrain_bot_config` WRITE;
/*!40000 ALTER TABLE `vbrain_bot_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `vbrain_bot_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vbrain_bot_geo_mapping`
--

DROP TABLE IF EXISTS `vbrain_bot_geo_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_bot_geo_mapping` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BOT_ID` int(11) DEFAULT NULL,
  `PROCESS_ID` int(11) DEFAULT NULL,
  `GEO_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `vbrain_gio2_idx` (`GEO_ID`),
  KEY `vbrain_bot2_idx` (`BOT_ID`),
  KEY `vbrain_process2_idx` (`PROCESS_ID`),
  CONSTRAINT `vbrain_bot2` FOREIGN KEY (`BOT_ID`) REFERENCES `vbrain_bot` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `vbrain_gio2` FOREIGN KEY (`GEO_ID`) REFERENCES `vbrain_geo` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `vbrain_process2` FOREIGN KEY (`PROCESS_ID`) REFERENCES `vbrain_process` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vbrain_bot_geo_mapping`
--

LOCK TABLES `vbrain_bot_geo_mapping` WRITE;
/*!40000 ALTER TABLE `vbrain_bot_geo_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `vbrain_bot_geo_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vbrain_business_app`
--

DROP TABLE IF EXISTS `vbrain_business_app`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_business_app` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BUSINESS_APP_NAME` varchar(100) DEFAULT NULL,
  `DESCRIPTION` varchar(200) DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `UPDATED_BY` varchar(50) DEFAULT NULL,
  `UPDATED_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vbrain_business_app`
--

LOCK TABLES `vbrain_business_app` WRITE;
/*!40000 ALTER TABLE `vbrain_business_app` DISABLE KEYS */;
INSERT INTO `vbrain_business_app` VALUES (1,'vClaim','Claim Application',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `vbrain_business_app` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vbrain_geo`
--

DROP TABLE IF EXISTS `vbrain_geo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_geo` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GEOGRAPHY` varchar(45) DEFAULT NULL,
  `REGION` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vbrain_geo`
--

LOCK TABLES `vbrain_geo` WRITE;
/*!40000 ALTER TABLE `vbrain_geo` DISABLE KEYS */;
INSERT INTO `vbrain_geo` VALUES (1,'US','NAM'),(2,'UK','EMEA'),(3,'Canada','APAC'),(4,'Singapore','APAC');
/*!40000 ALTER TABLE `vbrain_geo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vbrain_incidents`
--

DROP TABLE IF EXISTS `vbrain_incidents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_incidents` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TRANSACTION_ID` int(11) NOT NULL,
  `BOT_ID` int(11) NOT NULL,
  `TICKET_ID` varchar(20) NOT NULL,
  `STATUS` varchar(45) DEFAULT NULL,
  `DESCRIPTION` varchar(200) DEFAULT NULL,
  `CLOSED_BY` varchar(50) DEFAULT NULL,
  `CLOSING_DATE` datetime DEFAULT NULL,
  `CLOSING_COMMETNS` varchar(200) DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `UPDATED_BY` varchar(50) DEFAULT NULL,
  `UPDATED_DATE` datetime DEFAULT NULL,
  `TRACKING_ID` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3005 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vbrain_incidents`
--

LOCK TABLES `vbrain_incidents` WRITE;
/*!40000 ALTER TABLE `vbrain_incidents` DISABLE KEYS */;
INSERT INTO `vbrain_incidents` VALUES (9,34,9,'TK0020','1','Ticket Raised',NULL,NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),(10,35,9,'TK0021','0','Closed','Gayathri',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),(11,36,9,'TK0022','1','Ticket Raised',NULL,NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),(12,37,9,'TK0023','1','Ticket Raised',NULL,NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),(1000,1200,13,'TK-01000','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),(1001,1201,13,'TK-01001','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),(1002,1202,13,'TK-01002','1','Ticket Closed (Issue Resolved)','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),(1003,1203,13,'TK-01003','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),(2000,2200,14,'TK-02000','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),(2001,2201,14,'TK-02001','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),(2002,2202,14,'TK-02002','0','Ticket Closed (Issue Resolved)','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),(2003,2203,14,'TK-02003','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),(3000,3200,15,'TK-03000','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),(3001,3201,15,'TK-03001','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),(3002,3202,15,'TK-03002','0','Ticket Closed (Issue Resolved)','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),(3003,3203,15,'TK-03003','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL),(3004,3204,15,'TK-03004','1','Ticket Raised','Suresh Mani',NULL,NULL,'Suresh Mani',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `vbrain_incidents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vbrain_process`
--

DROP TABLE IF EXISTS `vbrain_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_process` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `WORKER` varchar(50) NOT NULL,
  `BUSINESS_APP_ID` int(11) NOT NULL,
  `PROCESS_NAME` varchar(100) DEFAULT NULL,
  `DESCRIPTION` varchar(200) DEFAULT NULL,
  `FUNCTION` int(11) DEFAULT NULL,
  `EFFORT_SAVED` varchar(10) NOT NULL,
  `PARENT_PROCESS_ID` int(11) NOT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `UPDATED_BY` varchar(50) DEFAULT NULL,
  `UPDATED_DATE` datetime DEFAULT NULL,
  `SLA` int(11) DEFAULT '0',
  `SEQUENCE` int(11) DEFAULT NULL,
  `GEO_ID` int(11) DEFAULT NULL,
  `IS_BOT_TYPE` int(11) DEFAULT NULL,
  `IS_HUMAN_TYPE` int(11) DEFAULT NULL,
  `IS_STP_TYPE` int(11) DEFAULT NULL,
  `BOT_EFFORT` int(11) DEFAULT NULL,
  `HUMAN_EFFORT` int(11) DEFAULT NULL,
  `STP_EFFORT` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vbrain_process`
--

LOCK TABLES `vbrain_process` WRITE;
/*!40000 ALTER TABLE `vbrain_process` DISABLE KEYS */;
INSERT INTO `vbrain_process` VALUES (1,'BOT',1,'Create FNOL','Create FNOL',1,'10',0,NULL,NULL,NULL,NULL,5,2,1,1,1,NULL,10,0,0),(2,'BOT',1,'Adjudicate Claim','Adjudicate Claim',1,'10',0,NULL,NULL,NULL,NULL,6,3,1,1,1,NULL,10,0,0),(3,'HUMAN',1,'Approve Claim','Approve Claim',1,'0',0,NULL,NULL,NULL,NULL,4320,4,1,0,1,NULL,0,0,0),(4,'BOT',1,'OCR','OCR',1,'480',0,NULL,NULL,NULL,NULL,480,1,1,1,0,NULL,120,0,0);
/*!40000 ALTER TABLE `vbrain_process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vbrain_sla`
--

DROP TABLE IF EXISTS `vbrain_sla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_sla` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PROCESS_ID` int(11) DEFAULT NULL,
  `WORKER` varchar(45) DEFAULT NULL,
  `SLA` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vbrain_sla`
--

LOCK TABLES `vbrain_sla` WRITE;
/*!40000 ALTER TABLE `vbrain_sla` DISABLE KEYS */;
INSERT INTO `vbrain_sla` VALUES (1,1,'BOT',10),(2,2,'Human',480),(3,3,'BOT',10),(4,4,'BOT',5);
/*!40000 ALTER TABLE `vbrain_sla` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vbrain_transaction`
--

DROP TABLE IF EXISTS `vbrain_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vbrain_transaction` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BOT_ID` int(11) DEFAULT '0',
  `BUSINESS_APP_NAME` varchar(50) DEFAULT NULL,
  `WORKER` varchar(50) DEFAULT NULL,
  `STATUS` varchar(50) DEFAULT NULL,
  `START_TIME` datetime DEFAULT NULL,
  `END_TIME` datetime DEFAULT NULL,
  `DURATION` varchar(10) DEFAULT NULL,
  `OUT_COME` varchar(50) DEFAULT NULL,
  `EXCEPTION_TYPE` varchar(200) DEFAULT NULL,
  `DESCRIPTION` varchar(200) DEFAULT NULL,
  `CREATED_BY` varchar(50) DEFAULT NULL,
  `CREATED_DATE` varchar(50) DEFAULT NULL,
  `TRACKING_ID` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vbrain_transaction`
--

LOCK TABLES `vbrain_transaction` WRITE;
/*!40000 ALTER TABLE `vbrain_transaction` DISABLE KEYS */;
INSERT INTO `vbrain_transaction` VALUES (1,1,NULL,'BOT','0','2017-05-01 12:00:02','2017-05-01 12:02:44','10','','','description','BOT',NULL,NULL),(2,1,NULL,'BOT','0','2017-05-01 15:00:02','2017-05-01 15:02:24','10','','','description','BOT',NULL,NULL),(3,2,NULL,'BOT','0','2017-05-02 12:15:02','2017-05-02 12:17:16','5','','','description','BOT',NULL,NULL),(4,2,NULL,'BOT','0','2017-05-02 15:10:02','2017-05-02 15:11:41','5','','','description','BOT',NULL,NULL),(5,2,NULL,'BOT','0','2017-05-02 16:00:02','2017-05-02 16:02:31','5','','','description','BOT',NULL,NULL),(6,2,NULL,'BOT','0','2017-05-02 17:00:02','2017-05-02 17:01:11','5','','','description','BOT',NULL,NULL),(7,1,'','BOT','0','2017-05-03 12:30:44','2017-05-03 12:32:09','','','','description','BOT','',NULL),(13,12,'','HUMAN','0','2017-05-04 12:03:09','2017-05-04 13:05:12','','','','description','User1','',NULL),(14,1,NULL,'BOT','0','2017-05-05 12:30:44','2017-05-05 12:32:44',NULL,NULL,NULL,NULL,'BOT',NULL,NULL),(15,7,NULL,'BOT','0','2017-05-06 15:00:02','2017-05-06 15:02:44',NULL,'','','description','CSRBOT',NULL,NULL),(16,7,NULL,'BOT','0','2017-05-06 22:01:32','2017-05-06 22:03:12',NULL,'','','description','CSRBOT',NULL,NULL),(17,7,NULL,'BOT','0','2017-05-07 15:00:02','2017-05-07 15:02:44',NULL,'','','description','CSRBOT',NULL,NULL),(18,7,NULL,'BOT','0','2017-05-07 22:01:32','2017-05-07 22:03:12',NULL,'','','description','CSRBOT',NULL,NULL),(19,11,NULL,'BOT','0','2017-05-11 21:46:52','2017-05-11 21:49:02',NULL,'Claim File is created successfully.','','CF-510is completed &amp; FNOL-1472 is created','CSRBOT',NULL,NULL),(21,13,NULL,'BOT','0','2017-05-18 15:30:21','2017-05-18 15:45:14',NULL,NULL,NULL,'OCR Created','CSRBOT',NULL,NULL),(22,13,NULL,'BOT','0','2017-05-19 18:30:41','2017-05-19 18:30:49',NULL,'Claim File is created successfully.','null','is completed &  is created','OCRBOT',NULL,'OCR-20170519183041'),(23,13,NULL,'BOT','0','2017-05-20 18:30:41','2017-05-20 18:30:49',NULL,'Claim File is created successfully.','','is completed &  is created','OCRBOT',NULL,'OCR-20170520183041'),(24,13,NULL,'BOT','0','2017-05-19 23:50:18','2017-05-19 23:51:33',NULL,'CSV files are created successfully.','','OCR service completed.','OCRBOT',NULL,'Ref # 20170519235018'),(25,15,NULL,'HUMAN','0','2017-05-19 23:40:18','2017-05-19 23:50:33',NULL,NULL,NULL,NULL,'UserFnol',NULL,NULL),(26,1,NULL,'BOT','1','2017-06-14 23:42:18','2017-06-14 23:50:33',NULL,'Backend System Down','OU','Backend System Down','OCRBOT',NULL,'Ref#1027061450'),(27,1,NULL,'BOT','1','2017-06-15 09:10:12','2017-06-15 09:20:08',NULL,'Backend System Down','OU','Backend System Down','OCRBOT',NULL,'Ref#1027061509'),(32,8,NULL,'BOT','1','2017-06-20 10:25:12','2017-06-20 10:30:08',NULL,'Backend System Down','OU','Backend System Down','OCRBOT',NULL,'Ref#1027061514'),(33,8,NULL,'BOT','1','2017-06-20 10:40:12','2017-06-20 10:45:08',NULL,'Backend System Down','OU','Backend System Down','OCRBOT',NULL,'Ref#1027061515'),(34,9,NULL,'BOT','1','2017-06-20 11:40:12','2017-06-20 11:45:08',NULL,'Backend System Down','OU','Backend System Down','OCRBOT',NULL,'Ref#1027061516'),(35,9,NULL,'BOT','1','2017-06-20 11:45:12','2017-06-20 11:50:08',NULL,'Backend System Down','OU','Backend System Down','OCRBOT',NULL,'Ref#1027061517'),(36,10,NULL,'BOT','1','2017-06-21 11:45:12','2017-06-21 11:50:08',NULL,'Backend System Down','OU','Backend System Down','OCRBOT',NULL,'Ref#1027061518'),(37,10,NULL,'BOT','1','2017-06-21 11:50:12','2017-06-21 11:55:08',NULL,'Backend System Down','OU','Backend System Down','OCRBOT',NULL,'Ref#1027061519'),(38,16,'vClaims','HUMAN','0','2017-07-02 15:00:02','2017-07-02 15:10:44',NULL,NULL,'','FNOL Created',NULL,NULL,'FNOL-801-20170702151044'),(39,16,'vClaims','HUMAN','0','2017-07-02 16:00:02','2017-07-02 16:10:44',NULL,NULL,'','FNOL Created','Sruthi',NULL,'FNOL-801-20170702151044');
/*!40000 ALTER TABLE `vbrain_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `group_bot_view`
--

/*!50001 DROP VIEW IF EXISTS `group_bot_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `group_bot_view` AS select `b`.`ID` AS `id`,`b`.`Bot_Key` AS `botKey`,`b`.`Provider` AS `provider`,`b`.`Description` AS `description`,`b`.`Process_Id` AS `processId`,`b`.`status` AS `status`,`g`.`Name` AS `processName` from (`bot` `b` join `groups` `g`) where ((`g`.`ID` = `b`.`Process_Id`) and (`b`.`isDisabled` = '0')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `group_incidents_view`
--

/*!50001 DROP VIEW IF EXISTS `group_incidents_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `group_incidents_view` AS select `vi`.`TICKET_ID` AS `ticket_id`,`vi`.`STATUS` AS `status`,`vt`.`ID` AS `transaction_id`,(case when (`vt`.`WORKER_TYPE` = 'BOT') then (select `bot`.`Process_Id` from `bot` where ((`bot`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`Process_Id` from `human_worker` where ((`human_worker`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'HUMAN'))) end) AS `process_id`,(case when (`vt`.`WORKER_TYPE` = 'BOT') then (select `groups`.`Name` from `groups` where (`groups`.`ID` = (select `bot`.`Process_Id` from `bot` where ((`bot`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'BOT'))))) else (select `groups`.`Name` from `groups` where (`groups`.`ID` = (select `human_worker`.`Process_Id` from `human_worker` where ((`human_worker`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'HUMAN'))))) end) AS `process_name`,`vt`.`START_TIME` AS `start_time`,`vt`.`END_TIME` AS `end_time`,`vt`.`COUNTRY` AS `country` from (`vbrain_incidents` `vi` join `transactions` `vt`) where (`vt`.`ID` = `vi`.`TRANSACTION_ID`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `group_sla_view`
--

/*!50001 DROP VIEW IF EXISTS `group_sla_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `group_sla_view` AS select `vt`.`ID` AS `transaction_id`,(case when (`vt`.`WORKER_TYPE` = 'BOT') then (select `bot`.`avgEfforts` from `bot` where ((`bot`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`avgEfforts` from `human_worker` where ((`human_worker`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'HUMAN'))) end) AS `sla`,(case when (`vt`.`WORKER_TYPE` = 'BOT') then (select `bot`.`Process_Id` from `bot` where ((`bot`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`Process_Id` from `human_worker` where ((`human_worker`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'HUMAN'))) end) AS `process_id`,(case when (`vt`.`WORKER_TYPE` = 'BOT') then (select `groups`.`Name` from `groups` where (`groups`.`ID` = (select `bot`.`Process_Id` from `bot` where ((`bot`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'BOT'))))) else (select `groups`.`Name` from `groups` where (`groups`.`ID` = (select `human_worker`.`Process_Id` from `human_worker` where ((`human_worker`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'HUMAN'))))) end) AS `process_name`,(case when (`vt`.`WORKER_TYPE` = 'BOT') then (select `bot`.`isDisabled` from `bot` where ((`bot`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`isDisabled` from `human_worker` where ((`human_worker`.`ID` = `vt`.`WORKER_ID`) and (`vt`.`WORKER_TYPE` = 'HUMAN'))) end) AS `worker_status`,`vt`.`START_TIME` AS `start_time`,`vt`.`END_TIME` AS `end_time`,`vt`.`COUNTRY` AS `country`,timestampdiff(MINUTE,`vt`.`START_TIME`,`vt`.`END_TIME`) AS `Duration`,`vt`.`WORKER_TYPE` AS `worker`,`vt`.`WORKER_ID` AS `worker_id` from `transactions` `vt` where (`vt`.`STATUS` = '0') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `group_transaction_view`
--

/*!50001 DROP VIEW IF EXISTS `group_transaction_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `group_transaction_view` AS select `transactions`.`ID` AS `transaction_id`,(case when (`transactions`.`WORKER_TYPE` = 'BOT') then (select `bot`.`Bot_Key` from `bot` where ((`bot`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`Worker_Id` from `human_worker` where ((`human_worker`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'HUMAN'))) end) AS `worker_id`,(case when (`transactions`.`WORKER_TYPE` = 'BOT') then (select `bot`.`isDisabled` from `bot` where ((`bot`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`isDisabled` from `human_worker` where ((`human_worker`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'HUMAN'))) end) AS `worker_status`,(case when (`transactions`.`WORKER_TYPE` = 'BOT') then (select `bot`.`Process_Id` from `bot` where ((`bot`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'BOT'))) else (select `human_worker`.`Process_Id` from `human_worker` where ((`human_worker`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'HUMAN'))) end) AS `process_id`,(case when (`transactions`.`WORKER_TYPE` = 'BOT') then (select `groups`.`Name` from `groups` where (`groups`.`ID` = (select `bot`.`Process_Id` from `bot` where ((`bot`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'BOT'))))) else (select `groups`.`Name` from `groups` where (`groups`.`ID` = (select `human_worker`.`Process_Id` from `human_worker` where ((`human_worker`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'HUMAN'))))) end) AS `process_name`,`transactions`.`START_TIME` AS `start_time`,`transactions`.`END_TIME` AS `end_time`,timestampdiff(MINUTE,`transactions`.`START_TIME`,`transactions`.`END_TIME`) AS `duration`,(select `bot`.`avgEffortsSaved` from `bot` where ((`bot`.`ID` = `transactions`.`WORKER_ID`) and (`transactions`.`WORKER_TYPE` = 'BOT'))) AS `efforts_saved`,`transactions`.`STATUS` AS `status`,`transactions`.`WORKER_TYPE` AS `worker_type`,`transactions`.`OUT_COME` AS `out_come`,`transactions`.`DESCRIPTION` AS `description`,`transactions`.`TRACKING_ID` AS `tracking_id`,`transactions`.`COUNTRY` AS `country`,`transactions`.`B_FUNCTION` AS `function` from `transactions` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `incidents_view`
--

/*!50001 DROP VIEW IF EXISTS `incidents_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `incidents_view` AS select `vi`.`TICKET_ID` AS `ticket_id`,`vi`.`STATUS` AS `status`,`vi`.`DESCRIPTION` AS `description`,`vp`.`ID` AS `process_id`,`vp`.`PROCESS_NAME` AS `process_name`,`vp`.`SLA` AS `SLA`,`vp`.`EFFORT_SAVED` AS `effort_saved`,`vp`.`SEQUENCE` AS `sequence`,`vg`.`GEOGRAPHY` AS `geography`,`vg`.`REGION` AS `region`,`vt`.`START_TIME` AS `start_time`,`vt`.`END_TIME` AS `end_time`,timestampdiff(MINUTE,`vt`.`START_TIME`,`vt`.`END_TIME`) AS `Duration`,`vt`.`WORKER` AS `worker` from ((((`vbrain_incidents` `vi` join `vbrain_process` `vp`) join `vbrain_transaction` `vt`) join `vbrain_geo` `vg`) join `vbrain_bot` `vb`) where ((`vb`.`ID` = `vt`.`BOT_ID`) and (`vb`.`PROCESS_ID` = `vp`.`ID`) and (`vg`.`ID` = `vb`.`GEO_ID`) and (`vt`.`ID` = `vi`.`TRANSACTION_ID`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `sla_view`
--

/*!50001 DROP VIEW IF EXISTS `sla_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `sla_view` AS select `vs`.`SLA` AS `sla`,`vp`.`PROCESS_NAME` AS `process_name`,`vp`.`ID` AS `process_id`,`vp`.`EFFORT_SAVED` AS `effort_saved`,`vp`.`SEQUENCE` AS `sequence`,`vg`.`GEOGRAPHY` AS `geography`,`vg`.`REGION` AS `region`,`vt`.`START_TIME` AS `start_time`,`vt`.`END_TIME` AS `end_time`,timestampdiff(MINUTE,`vt`.`START_TIME`,`vt`.`END_TIME`) AS `Duration`,`vt`.`WORKER` AS `worker` from ((((`vbrain_sla` `vs` join `vbrain_process` `vp`) join `vbrain_transaction` `vt`) join `vbrain_geo` `vg`) join `vbrain_bot` `vb`) where ((`vb`.`ID` = `vt`.`BOT_ID`) and (`vb`.`PROCESS_ID` = `vp`.`ID`) and (`vg`.`ID` = `vb`.`GEO_ID`) and (`vs`.`PROCESS_ID` = `vb`.`PROCESS_ID`)) group by `vt`.`ID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `transation_view`
--

/*!50001 DROP VIEW IF EXISTS `transation_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `transation_view` AS select `vb`.`BOT_KEY` AS `bot_key`,`vp`.`ID` AS `process_id`,`vp`.`PROCESS_NAME` AS `process_name`,`vp`.`SLA` AS `SLA`,`vp`.`EFFORT_SAVED` AS `effort_saved`,`vp`.`SEQUENCE` AS `sequence`,`vg`.`GEOGRAPHY` AS `geography`,`vg`.`REGION` AS `region`,`vt`.`START_TIME` AS `start_time`,`vt`.`END_TIME` AS `end_time`,timestampdiff(MINUTE,`vt`.`START_TIME`,`vt`.`END_TIME`) AS `Duration`,`vt`.`STATUS` AS `status`,`vt`.`WORKER` AS `worker`,`vt`.`OUT_COME` AS `out_come`,`vt`.`DESCRIPTION` AS `description` from (((`vbrain_bot` `vb` join `vbrain_process` `vp`) join `vbrain_transaction` `vt`) join `vbrain_geo` `vg`) where ((`vb`.`ID` = `vt`.`BOT_ID`) and (`vb`.`PROCESS_ID` = `vp`.`ID`) and (`vg`.`ID` = `vb`.`GEO_ID`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-16  3:22:36
