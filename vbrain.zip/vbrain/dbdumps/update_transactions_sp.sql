DROP PROCEDURE IF EXISTS vbrain.update_transactions_sp;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `vbrain`.`update_transactions_sp`()
BEGIN
	
    DECLARE v_start_date varchar(100);
    DECLARE v_name varchar(100);
   	DECLARE max_length INTEGER DEFAULT 0;
    DECLARE finished INTEGER DEFAULT 0;
   
    DECLARE datastore_cursor CURSOR FOR 
   		SELECT DISTINCT start_date, name FROM wf_temp_datastore WHERE transaction_id IS NULL ORDER BY start_date;
      	
   	-- declare NOT FOUND handler
 	DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
 
 	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
	    ROLLBACK;  -- Rollback any changes made in the transaction
        RESIGNAL;  -- Resignal the error to the caller
    END;
   
 	OPEN datastore_cursor;
 	
 	-- Loop through different runs data and link transactions dump with datastore dump
 	-- Update 'ds.transaction_id' (foreign key)
 	get_datastore_data: LOOP
 		FETCH datastore_cursor INTO v_start_date,v_name;
	 	IF finished = 1 THEN 
			LEAVE get_datastore_data;
		END IF;
 		UPDATE wf_temp_datastore ds 
			JOIN (
				SELECT t2.ID AS trans_id, t1.ID AS ds_id
				FROM (
					-- Select wf_temp_datastore rows with row numbers
					SELECT tds.ID, @curRow := @curRow + 1 AS row_number
				      FROM wf_temp_datastore tds
				         JOIN
				         	(SELECT @curRow := 0) r -- Row numbers
				         WHERE tds.start_date = v_start_date AND tds.name = v_name ORDER BY tds.system_id) t1
				JOIN (
					-- Select ids from temp transactions with row numbers
				 	SELECT tt.ID, @curRow2 := @curRow2 + 1 AS row_number
				      FROM wf_temp_transactions tt
				         JOIN
				         	(SELECT @curRow2 := 0) r -- Row numbers
				      JOIN wf_bp_mapping m 
						 ON tt.campaign_id = m.campaign_id 
					  WHERE tt.END_TIME > v_start_date 
						 AND m.datastore_name = v_name 
					  ORDER BY tt.END_TIME
				) t2 ON t1.row_number = t2.row_number
			) AS temp
			ON temp.ds_id = ds.ID
			SET ds.transaction_id = temp.trans_id;
 	END LOOP get_datastore_data;
 
 	CLOSE datastore_cursor;

 	-- Update error cat for wf_temp_datastore data
 	UPDATE vbrain.wf_temp_datastore ds
	JOIN (
		SELECT
			ds.ID ID,
			e.Exception_type e_type
		FROM vbrain.wf_temp_datastore ds
		JOIN vbrain.exceptions e ON
			ds.error_msg LIKE concat('%', e.Exception_Value, '%')
		JOIN vbrain.business_process_view bp ON
			bp.lob_id = e.Lob
		WHERE
			bp.datastore_name = ds.name) te 
		ON ds.ID = te.ID 
	SET ds.ERROR_CAT = te.e_type
	WHERE ds.ERROR_CAT IS NULL;
 
	SELECT CHARACTER_MAXIMUM_LENGTH INTO max_length
	FROM information_schema.columns
	WHERE table_schema = 'vbrain' AND   
	      table_name = 'transactions' AND
	      COLUMN_NAME = 'ERROR_TYPE';

	-- Select from the dumps, groups, bot in temporary in mamory table
	DROP TEMPORARY TABLE IF EXISTS `vbrain`.`tmp`;
	CREATE TEMPORARY TABLE `vbrain`.`tmp` engine=memory AS	
	SELECT tt.ID AS transaction_id,
		   b.ID AS botid,
		   tt.STATUS AS status,
		   tt.START_TIME AS hit_submissionDate, 
		   tt.END_TIME AS hit_completionDate,
		   IF(tt.STATUS = 1, 'Unkown Error', '') AS exception_type,
		   tt.DESCRIPTION AS stepTitle,
		   bp.country AS country, 
		   tt.BP_UUID AS bp_instance_uuid,
		   bp.function AS function,
		   ds.error_cat AS error_cat,
		   ds.error_msg AS error_msg,
		   ds.tracking_id AS tracking_id,
		   'BOT' AS WORKER_TYPE,
		   0 AS OUT_COME,
		   'vBrain' AS CREATED_BY
		FROM business_process_view bp 
		JOIN bot b ON bp.process_id = b.Process_Id
		INNER JOIN wf_temp_transactions tt ON tt.campaign_id = bp.campaign_id
		JOIN wf_temp_datastore ds ON ds.transaction_id = tt.ID
		WHERE b.ID > 0 AND b.isDisabled = 0;
   
	SET autocommit = 0;

	-- Start SQL transaction
	START TRANSACTION;
	-- Promote to transactions from in memory temporary table
 	INSERT INTO transactions (WORKER_ID,STATUS,
				START_TIME,END_TIME,EXCEPTION_TYPE,DESCRIPTION,COUNTRY,BP_UUID,B_FUNCTION,
				ERROR_CAT, ERROR_TYPE,TRACKING_ID,WORKER_TYPE,OUT_COME,CREATED_BY)
 	SELECT botid, status, hit_submissionDate, hit_completionDate, exception_type,
		   stepTitle, country, bp_instance_uuid, function, error_cat,
		   SUBSTRING(error_msg, 1, max_length), tracking_id, WORKER_TYPE, OUT_COME, CREATED_BY
		FROM `vbrain`.`tmp`;
	
	-- Delete (Move to trash) successfully promoted (moved to transactions table) rows 
	-- from temp tables (wf_temp_transactions, wf_temp_datastore)
	INSERT INTO wf_temp_transactions_trash (ID, STATUS, TITLE, BP_NAME, START_TIME, END_TIME, DESCRIPTION, BP_UUID, campaign_id) 
		SELECT ID, STATUS, TITLE, BP_NAME, START_TIME, END_TIME, DESCRIPTION, BP_UUID, campaign_id FROM wf_temp_transactions 
		WHERE ID IN (SELECT transaction_id FROM tmp);
	
	INSERT INTO wf_temp_datastore_trash (ID, name, transaction_id, error_cat, start_date, system_id, error_msg, tracking_id) 
		SELECT ID, name, transaction_id, error_cat, start_date, system_id, error_msg, tracking_id FROM wf_temp_datastore 
		WHERE transaction_id IN (SELECT transaction_id FROM tmp);
	
	DELETE FROM wf_temp_datastore WHERE transaction_id IN (SELECT transaction_id FROM tmp);
	DELETE FROM wf_temp_transactions WHERE ID IN (SELECT transaction_id FROM tmp);
	
	COMMIT;
	-- End SQL transaction 
	SET autocommit = 1;

	DROP TEMPORARY TABLE IF EXISTS `vbrain`.`tmp`;
 
END$$
DELIMITER ;
