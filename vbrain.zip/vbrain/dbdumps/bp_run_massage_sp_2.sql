DROP PROCEDURE IF EXISTS vbrain.bp_run_massage_sp_2;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `bp_run_massage_sp_2`()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;  -- Rollback any changes made in the transaction
        RESIGNAL;  -- Resignal the error to the caller
    END;
    SET autocommit = 0;

    -- Start SQL transaction
    START TRANSACTION;
    
    DROP TEMPORARY TABLE IF EXISTS bp_run_massage_tmp;
    CREATE TEMPORARY TABLE bp_run_massage_tmp engine=memory AS
    SELECT business_process_id, campaign_id, bp_uuid, MIN(start_time) AS start_time, MAX(end_time) AS end_time, MAX(max_wf_id) AS max_wf_id FROM wf_bp_run GROUP BY bp_uuid;
    
    DELETE FROM wf_bp_run;
    
    INSERT INTO wf_bp_run(business_process_id,campaign_id,bp_uuid,start_time,end_time,max_wf_id) 
    SELECT business_process_id,campaign_id,bp_uuid,start_time,end_time,max_wf_id FROM bp_run_massage_tmp;
    
    DROP TEMPORARY TABLE IF EXISTS bp_run_massage_tmp;
    
    COMMIT;
    -- End SQL transaction 
    SET autocommit = 1;
	
	UPDATE wf_bp_run r JOIN business_process_view_2 bp ON bp.campaign_id = r.campaign_id SET r.business_process_id = bp.business_process_id WHERE r.business_process_id IS NULL;
    
END$$
DELIMITER ;