CREATE TABLE `wf_business_process` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display_name` varchar(100) NOT NULL,
  `mapped_datastores` varchar(500) DEFAULT NULL,
  `query_order` int(11) NOT NULL,
  `start_date_convert_format` varchar(50) DEFAULT NULL,
  `start_date_postgre_format` varchar(50) DEFAULT NULL,
  `tracking_id_field` varchar(200) DEFAULT NULL,
  `error_msg_field` varchar(200) DEFAULT NULL,
  `system_id_field` varchar(200) DEFAULT NULL,
  `start_date_field` varchar(200) DEFAULT NULL,
  `group_process_id` int(11) DEFAULT NULL,
  `mapping_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wf_business_process_groups_fk` (`group_process_id`),
  KEY `wf_business_process_wf_campaign_fk` (`mapping_id`),
  CONSTRAINT `wf_business_process_groups_fk` FOREIGN KEY (`group_process_id`) REFERENCES `groups` (`ID`),
  CONSTRAINT `wf_business_process_wf_campaign_fk` FOREIGN KEY (`mapping_id`) REFERENCES `wf_campaign` (`mapping_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1

INSERT INTO vbrain.wf_business_process (display_name,mapped_datastores,query_order,start_date_convert_format,start_date_postgre_format,tracking_id_field,error_msg_field,system_id_field,start_date_field,group_process_id,mapping_id) VALUES 
('TPS-XIM','ds_ds_tps_run_statistics',1,'%a %b %d %H:%i:%s UTC %Y','Dy Mon DD HH24:MI:SS "UTC" YYYY','ir_id','error_msg','ds_ds_tps_run_statistics_id','start_date',NULL,NULL)
,('TPS-ACH','ds_ds_tps_ach_run_statistics',2,'%a %b %d %H:%i:%s UTC %Y','Dy Mon DD HH24:MI:SS "UTC" YYYY','ir_id','error_msg','ds_ds_tps_ach_run_statistics_id','start_date',NULL,NULL)
,('TPS-DE','ds_ds_tps_de_run_statistics',3,'%a %b %d %H:%i:%s UTC %Y','Dy Mon DD HH24:MI:SS "UTC" YYYY','ir_id','error_msg','ds_ds_tps_de_run_statistics_id','start_date',NULL,NULL)
,('IAM WebIR Access Setup','ds_iam_webir_email_report',4,'%a %b %d %H:%i:%s UTC %Y','Dy Mon DD HH24:MI:SS "UTC" YYYY','request_id','COALESCE(NULLIF(error_msg,''''), comments)','ds_iam_webir_email_report_id','start_date',NULL,NULL)
,('IAM RSAVIA WebIR Delete','ds_iam_webir_rsavia_email_report',5,'%a %b %d %H:%i:%s UTC %Y','Dy Mon DD HH24:MI:SS "UTC" YYYY','CONCAT(account_name,''_'',ds_iam_webir_rsavia_email_report_id)','COALESCE(NULLIF(error_msg,''''), comments)','ds_iam_webir_rsavia_email_report_id','start_date',NULL,NULL)
,('FIN-S4-HANA','ds_ds_fin_s4_hana_bot_status',6,'%Y%m%d-%H:%i:%s','YYYYMMDD-HH24:MI:SS.MS','run_uuid','exception_message','ds_ds_fin_s4_hana_bot_status_id','datetime',NULL,NULL)
,('PC-CL Part 2','ds_ds_pccl_run_statistics',7,'%a %b %d %H:%i:%s UTC %Y','Dy Mon DD HH24:MI:SS "UTC" YYYY','rmc','error_msg','ds_ds_pccl_run_statistics_id','start_date',NULL,NULL)
,('USBL-USLC Finalize','"ds_USBL_USLC_Exception"',8,'%Y%m%d-%H:%i:%s','YYYYMMDD-HH24:MI:SS.MS','tr_id','error_message','"ds_USBL_USLC_Exception_id"','timestamp',NULL,NULL)
,('USPB-MODI Imaging','ds_uspb_modi_run r|ds_uspb_modi_exception e|r.run_id,e.run_id',9,'%Y-%m-%d %H:%i:%s','YYYY-MM-DD HH24:MI:SS.MS +0000','r.run_id','e.message_txt','r.ds_uspb_modi_run_id','r.started_dttm',NULL,NULL);

-- Altering temp transactions tables
ALTER TABLE vbrain.wf_temp_transactions ADD WF_ID BIGINT(20) NULL;
ALTER TABLE vbrain.wf_temp_transactions ADD CONSTRAINT wf_temp_transactions_un UNIQUE KEY (WF_ID);

ALTER TABLE vbrain.wf_temp_transactions_trash ADD WF_ID BIGINT(20) NULL;
ALTER TABLE vbrain.wf_temp_transactions_trash ADD INSERT_OR_UPDATED_ON TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL;

-- Altering temp datastore tables
ALTER TABLE vbrain.wf_temp_datastore ADD business_process_id INT(11) NOT NULL;
UPDATE wf_temp_datastore td JOIN wf_business_process bp ON bp.display_name = td.name SET td.business_process_id = bp.id;
-- Adding wf_id field and updating the value for existing records
ALTER TABLE vbrain.wf_temp_datastore ADD wf_id BIGINT(20) NOT NULL;
UPDATE wf_temp_datastore SET wf_id = (UNIX_TIMESTAMP(substring(start_date,1,19))*100000 + system_id);

ALTER TABLE vbrain.wf_temp_datastore_trash ADD business_process_id INT(11) NOT NULL;
UPDATE wf_temp_datastore_trash tdt JOIN wf_business_process bp ON bp.display_name = tdt.name SET tdt.business_process_id = bp.id;

ALTER TABLE vbrain.wf_temp_datastore_trash ADD wf_id BIGINT(20) NOT NULL;
UPDATE wf_temp_datastore_trash SET wf_id = (UNIX_TIMESTAMP(substring(start_date,1,19))*100000 + system_id);

ALTER TABLE vbrain.wf_temp_datastore_trash ADD insert_or_updated_on DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL;


-- Take utmost care. PLEASE. --- Also check SP for name column
-- ALTER TABLE wf_temp_datastore DROP COLUMN name;
-- ALTER TABLE wf_temp_datastore_trash DROP COLUMN name;


