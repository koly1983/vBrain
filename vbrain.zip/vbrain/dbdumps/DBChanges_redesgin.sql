CREATE TABLE IF NOT EXISTS `vbrain`.`wf_temp_datastore` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `tracking_id` varchar(100) DEFAULT NULL,
  `error_msg` varchar(4000) DEFAULT NULL,
  `system_id` int(11) DEFAULT NULL,
  `start_date` varchar(100) DEFAULT NULL,
  `error_cat` int(11) DEFAULT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `wf_temp_datastore_uk` (`system_id`,`start_date`,`name`),
  KEY `wf_temp_datastore_wf_temp_transactions_fk` (`transaction_id`),
  CONSTRAINT `wf_temp_datastore_wf_temp_transactions_fk` FOREIGN KEY (`transaction_id`) REFERENCES `wf_temp_transactions` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `vbrain`.`wf_temp_datastore_trash` (
  `tracking_id` varchar(100) DEFAULT NULL,
  `error_msg` varchar(4000) DEFAULT NULL,
  `system_id` int(11) DEFAULT NULL,
  `start_date` varchar(100) DEFAULT NULL,
  `error_cat` int(11) DEFAULT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `vbrain`.`wf_temp_transactions_trash` (
  `ID` int(11) NOT NULL,
  `STATUS` varchar(50) DEFAULT NULL,
  `TITLE` varchar(250) DEFAULT NULL,
  `BP_NAME` varchar(250) DEFAULT NULL,
  `START_TIME` datetime DEFAULT NULL,
  `END_TIME` datetime DEFAULT NULL,
  `DESCRIPTION` varchar(400) DEFAULT NULL,
  `BP_UUID` varchar(45) DEFAULT NULL,
  `campaign_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE vbrain.wf_temp_transactions ADD CAMPAIGN_ID INT(11) NULL;

ALTER TABLE vbrain.wf_configuration ADD LASTRECORD_TIMESTAMP_DATASTORE BIGINT NULL;

CREATE TABLE `wf_bp_mapping` (
  `process_id` int(11) NOT NULL,
  `campaign_id` int(11) DEFAULT NULL,
  `datastore_name` varchar(100) DEFAULT NULL,
  `mapping_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`process_id`),
  KEY `wf_bp_mapping_groups_fk` (`process_id`),
  KEY `wf_bp_mapping_wf_campaign_fk` (`mapping_id`),
  CONSTRAINT `wf_bp_mapping_groups_fk` FOREIGN KEY (`process_id`) REFERENCES `groups` (`ID`),
  CONSTRAINT `wf_bp_mapping_wf_campaign_fk` FOREIGN KEY (`mapping_id`) REFERENCES `wf_campaign` (`mapping_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1

create
or replace
view `business_process_view` as select
    `bp`.`ID` as `process_id`,
    `bp`.`Name` as `process_name`,
    `func`.`Name` as `function`,
    `lob`.`ID` as `lob_id`,
    `lob`.`Name` as `lob`,
    `country`.`Name` as `country`,
    `mp`.`datastore_name` as `datastore_name`,
    `mp`.`campaign_id` as `campaign_id`
from
    ((((`groups` `bp`
join `groups` `func` on
    ((`bp`.`Parent_Id` = `func`.`ID`)))
join `groups` `lob` on
    ((`func`.`Parent_Id` = `lob`.`ID`)))
join `groups` `country` on
    ((`lob`.`Parent_Id` = `country`.`ID`)))
join `wf_bp_mapping` `mp` on
    ((`bp`.`ID` = `mp`.`process_id`)))
where
    (`bp`.`Type` = 'process');
	
-- Step 2 Changes
-- ALTER TABLE vbrain.wf_bp_mapping ADD mapping_id int(11) NULL;
-- ALTER TABLE vbrain.wf_bp_mapping ADD CONSTRAINT wf_bp_mapping_un UNIQUE KEY (process_id);

CREATE TABLE IF NOT EXISTS `vbrain`.`wf_campaign` (
	MAPPING_ID BIGINT(20) NOT NULL,
	CAMPAIGN_ID BIGINT(20) NULL,
	STEP_ID BIGINT(20) NULL,
	BP_NAME varchar(128) NULL,
	STEP_TITLE varchar(128) NULL,
	DELETED INT(11) NULL,
	STEP_INDEX INT(11) NULL,
	BP_LASTMODIFIED DATETIME NULL,
	STEP_LASTMODIFIED DATETIME NULL,
	CONSTRAINT wf_campaign_pk PRIMARY KEY (MAPPING_ID)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `vbrain`.`wf_configuration` ADD LASTRECORD_TIMESTAMP_CAMPAIGN DATETIME NULL;

-- Step 3 Changes
-- ALTER TABLE vbrain.wf_bp_mapping MODIFY COLUMN mapping_id BIGINT(20) NULL;
-- ALTER TABLE vbrain.wf_bp_mapping ADD CONSTRAINT wf_bp_mapping_wf_campaign_fk FOREIGN KEY (mapping_id) REFERENCES vbrain.wf_campaign(mapping_id);
-- ALTER TABLE vbrain.wf_bp_mapping DROP KEY wf_bp_mapping_un;
-- ALTER TABLE vbrain.wf_bp_mapping ADD PRIMARY KEY(process_id);
