package com.vbrain.adapter.impl;

import java.sql.Connection;
import java.util.List;
import java.util.Properties;

import com.vbrain.adapter.TPSAdapter;
import com.vbrain.common.util.ReadProperties;
import com.vbrain.dao.VbrainDBAdapter;
import com.vbrain.dao.WFDBAdapter;
import com.vbrain.dao.impl.VbrainDBAdapterImpl;
import com.vbrain.dao.impl.WFDBAdapterImpl;

/**
 * TPS adapter class used as adapter between WF Postgre database and Vbrain DB 
 * for TPS Project
 * @author VISWANATHV
 * @since 12/26/2018
 */
public class TPSAdapterImpl implements TPSAdapter {

    /**
     * Updating Vbrain database 
     */
    public void updateVbrainData(Connection connObjVb, Connection connObjPostgres, long lastrecordtime) {
        try {
            System.out.println(" Update Tps Data");
            ReadProperties properties = new ReadProperties();
            Properties prop = properties.loadProperties("adapter.properties");
            if(prop != null){
                String selectQuery = prop.getProperty("psql.select.run.statistics");
                
                WFDBAdapter wfdbAdapter = new WFDBAdapterImpl();
                List<String[]> wfTPSData = wfdbAdapter.getDataFromTable(selectQuery, buildParameters(String.valueOf(lastrecordtime)), connObjPostgres);
                
                if(wfTPSData != null && !wfTPSData.isEmpty()) {
	                VbrainDBAdapter vbrainAdapter = new VbrainDBAdapterImpl();
	
	                String insertQuery = prop.getProperty("vbrain.insert.datastore");               
	                vbrainAdapter.insertData(wfTPSData, insertQuery, connObjVb);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * Method used to build parameters
     * @param param with comma separated values 
     * @return String array with parameters
     */
    @Override
    public String[] buildParameters(String param) {
        String[] parameters = null;
        if(param != null)
            parameters = param.split(";");
        return parameters;
    }
    

}
