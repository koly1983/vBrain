/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vbrain.adapter.impl;

import com.vbrain.adapter.CommonDbAdapter;
import com.vbrain.bpsynchronizer.DbTypes;
import com.vbrain.hibernate.IContainData;
import com.vbrain.hibernate.PoolManager;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author llihind
 */
public class CommonDbAdapterImpl implements CommonDbAdapter {

    private Session session;

    public CommonDbAdapterImpl() {
        try {
            session = PoolManager.getSessionFactory().getCurrentSession();
        } catch (HibernateException e) {
            if (e.getMessage().contains("No CurrentSessionContext configured")) {
                session = PoolManager.getSessionFactory().openSession();
            } else {
                throw new HibernateException(e);
            }
        }
    }
    
    public CommonDbAdapterImpl(String sessionType) {
        if (sessionType.equals(DbTypes.ACCESS.toString())) {
            System.out.println("Access Session Factory Created");
            try {
                session = PoolManager.getAccessSessionFactory().getCurrentSession();
            } catch (HibernateException e) {
                if (e.getMessage().contains("No CurrentSessionContext configured")) {
                    session = PoolManager.getAccessSessionFactory().openSession();
                } else {
                    throw new HibernateException(e);
                }
            }
        } else {
            System.out.println("SQL Session Factory Created");
            try {
                session = PoolManager.getSqlSessionFactory().getCurrentSession();
            } catch (HibernateException e) {
                if (e.getMessage().contains("No CurrentSessionContext configured")) {
                    session = PoolManager.getSqlSessionFactory().openSession();
                } else {
                    throw new HibernateException(e);
                }
            }
        }
    }

    @Override
    public void insertDataToTable(IContainData data) throws Exception {
        try {
            Transaction tx = getSession().beginTransaction();

            getSession().save(data);
            tx.commit();
        } catch (Exception e) {
            throw new Exception("Inserting data failed with : " + e);
        } finally {
            getSession().clear();
        }
    }

    @Override
    public void updateDataOnTable(IContainData data) throws Exception {
        try {
            Transaction tx = getSession().beginTransaction();

            getSession().update(data);
            tx.commit();

        } catch (Exception e) {
            throw new Exception("Updating data failed with : " + e);
        } finally {
            getSession().clear();
        }

    }

    @Override
    public List readDataListfromTable(Class table, Map restrictions) throws Exception {
        try {
            Criteria criteria = getSession().createCriteria(table);
            Iterator entries = restrictions.entrySet().iterator();
            while (entries.hasNext()) {
                Map.Entry entry = (Map.Entry) entries.next();

                criteria.add(Restrictions.eq((String) entry.getKey(), entry.getValue()));
            }

            List data = criteria.list();

            return data;
        } catch (HibernateException e) {
            throw new Exception("Reading data list from table failed with : " + e);
        }
    }

    @Override
    public List readDataListFiltredByDateRange(Class table, Date startDate, Date endDate) throws Exception {
        try {
            Criteria criteria = getSession().createCriteria(table);

            criteria.add(Restrictions.ge("startDate", startDate));
            criteria.add(Restrictions.lt("startDate", endDate));

            List data = criteria.list();

            return data;
        } catch (HibernateException e) {
            throw new Exception("Reading filtered data list from table failed with : " + e);
        }
    }

    @Override
    public List readUniqueDataListfromTable(Class table, Map restrictions, String targetColumn) throws Exception {
        try {
            Criteria criteria = getSession().createCriteria(table);
            criteria.setProjection(Projections.distinct(Projections.property(targetColumn)));
            Iterator entries = restrictions.entrySet().iterator();
            while (entries.hasNext()) {
                Map.Entry entry = (Map.Entry) entries.next();

                criteria.add(Restrictions.eq((String) entry.getKey(), entry.getValue()));
            }

            List data = criteria.list();

            return data;
        } catch (HibernateException e) {
            throw new Exception("Reading data list from table failed with : " + e);
        }

    }

    @Override
    public IContainData readDataObjfromTable(Class table, Map restrictions) throws Exception {
        try {
            Criteria criteria = getSession().createCriteria(table);
            Iterator entries = restrictions.entrySet().iterator();
            while (entries.hasNext()) {
                Map.Entry entry = (Map.Entry) entries.next();
                
                criteria.add(Restrictions.eq((String) entry.getKey(), entry.getValue()));
            }

            IContainData data = (IContainData) criteria.uniqueResult();

            return data;
        } catch (HibernateException e) {
            throw new Exception("Reading data object from table failed with : " + e);
        }
    }

    @Override
    public void clearTable(Class table) throws Exception {
        try {

            Transaction tx = getSession().beginTransaction();

            String queryStr = "delete from " + table.getName();
            Query query = getSession().createQuery(queryStr);

            query.executeUpdate();
            tx.commit();
        } catch (Exception e) {
            throw new Exception("Deleting All Rows Failed With : " + e);
        } finally {
            getSession().clear();
        }

    }

    @Override
    public List<Object[]> getDataUsingQuery(String query) throws Exception {
        try {
            SQLQuery queryEx = getSession().createSQLQuery(query);
            List<Object[]> rows = queryEx.list();

            return rows;
        } catch (Exception e) {
            throw new Exception("Select Query Execution Failed With : " + e);
        }
    }

    @Override
    public List<Object> getDataObjsUsingQuery(String query) throws Exception {
        try {
            SQLQuery queryEx = getSession().createSQLQuery(query);
            List<Object> rows = queryEx.list();

            return rows;
        } catch (Exception e) {
            throw new Exception("Select Query Execution Failed With : " + e);
        }
    }

    @Override
    public void deleteDataOnTable(IContainData data) throws Exception {
        try {
            Transaction tx = getSession().beginTransaction();

            getSession().delete(data);
            tx.commit();

        } catch (Exception e) {
            throw new Exception("Deleting data failed with : " + e);
        } finally {
            getSession().clear();
        }
    }

    /**
     * @return the session
     */
    @Override
    public Session getSession() {
        return session;
    }

}
