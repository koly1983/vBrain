/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vbrain.adapter;

import java.util.Date;
import java.util.List;
import java.util.Map;
import org.hibernate.Session;

import com.vbrain.hibernate.IContainData;

/**
 *
 * @author llihind
 */
public interface CommonDbAdapter {
    
    public void insertDataToTable(IContainData data) throws Exception;
    public void updateDataOnTable(IContainData data) throws Exception;
    public void deleteDataOnTable(IContainData data) throws Exception;
    public List readDataListfromTable(Class table, Map restrictions) throws Exception;
    public List readDataListFiltredByDateRange(Class table, Date startDate, Date endDate) throws Exception;
    public List readUniqueDataListfromTable(Class table, Map restrictions, String targetColumn) throws Exception;
    public IContainData readDataObjfromTable(Class table, Map restrictions) throws Exception;
    public void clearTable(Class table) throws Exception;
    public List<Object []> getDataUsingQuery(String query) throws Exception;
    public List<Object> getDataObjsUsingQuery(String query) throws Exception;
    public Session getSession();
    
    
}
