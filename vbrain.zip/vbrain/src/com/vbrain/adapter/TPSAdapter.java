package com.vbrain.adapter;

import java.sql.Connection;

public interface TPSAdapter {
    public void updateVbrainData(Connection connObjVb, Connection connObjPostgres, long lastrecordtime);
    public String[] buildParameters(String param);
}