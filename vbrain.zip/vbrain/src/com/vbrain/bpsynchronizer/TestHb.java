/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vbrain.bpsynchronizer;

import com.vbrain.dao.DbSynchronizer;
import com.vbrain.dao.impl.DbSynchronizerImpl;
import com.vbrain.hibernate.sql.model.Run;
import java.util.List;

/**
 *
 * @author llihind
 */
public class TestHb {

    public static void main(String[] args) {
        try {
            DbSynchronizer synchronizer = new DbSynchronizerImpl();
            List<Run> runsList = synchronizer.getFilteredRunListByDateRange();

            synchronizer.syncDatabases(runsList);
            synchronizer.reverseSyncDatabases(runsList);

            System.out.println("DONE");
        } catch (Exception e) {
               e.printStackTrace();
        }
    }
}
