package com.vbrain.dao;

import java.util.List;

import com.vbrain.common.io.Data;

public interface IncidentsDao {

	/*List<Data> getIncidentsData(String startDate, String endDate, String workStep, String groupBy);
	List<Data> getIncidentsWorkstepwise(String startDate, String endDate, String groupBy);
	List<Data> getIncidentsRegionwise(String startDate, String endDate, String groupBy);*/
	
	List<Data> getIncidents(String startDate, String endDate, String function);
    List<Data> getIncidentList(String processName, String startDate, String endDate);
}
