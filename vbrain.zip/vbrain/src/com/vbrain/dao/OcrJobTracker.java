/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vbrain.dao;

import com.vbrain.nodemonitor.model.OcrSummary;

/**
 *
 * @author llihind
 */
public interface OcrJobTracker {
    public OcrSummary readOcrSummary(String url) throws Exception;
    public void handleOcrStatus(OcrSummary ocrSummary) throws Exception;
    public void handleOcrLicenseStatus(String url, int threshold) throws Exception;
    public void cleanUpOcrData() throws Exception;
    public void finalizeSynchronizer();
}
