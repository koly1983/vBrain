package com.vbrain.dao;

import java.util.List;

import com.vbrain.common.io.Data;
import com.vbrain.common.io.Group;

public interface GroupDao {

	/*List<Data> getIncidentsData(String startDate, String endDate, String workStep, String groupBy);
	List<Data> getIncidentsWorkstepwise(String startDate, String endDate, String groupBy);
	List<Data> getIncidentsRegionwise(String startDate, String endDate, String groupBy);*/
	
	public Data getGroups();
	
	public Data getUsers(String groupId); 
	
	public Data getGroupUsers(String groupId); 
	
	public int deleteGroupUser(String userId, String groupId);
	
	public int addGroup(Group group);
	
	public int updateGroup(Group group);
	
	public int disableGroup(String groupId, String isDisabled);
	
	public List<Data> getGroupNames(String type);
}
