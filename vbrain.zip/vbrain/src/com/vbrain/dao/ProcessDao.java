package com.vbrain.dao;

import java.util.List;

import com.vbrain.common.io.Bot;
import com.vbrain.common.io.Data;
import com.vbrain.common.io.Human;
import com.vbrain.common.io.RequestMessage;

public interface ProcessDao {
	/**
	 * 
	 * @param function
	 * @param geo
	 * @param businessApp
	 * @return
	 */
	List<Data> getProcess(String function, String geo, String businessApp);
	
	/**
	 * Get All processes
	 * @return
	 */
	Data getAllProcess();
	
	/**
	 * 
	 * @param processId
	 * @return
	 */
	Data getProcess(String processId);
	
	/**
	 * 
	 * @param requestMessage
	 * @return
	 */
	int insertProcess(RequestMessage requestMessage);
	
	/**
	 * 
	 * @param requestMessage
	 * @return
	 */
	int updateProcess(RequestMessage requestMessage);
	
	
	Data getBots(String processId);
	
	String addBot(Bot bot);
	int editBot(Bot bot);
	int disableBot(Bot bot);
	
	Data getHumans(String processId);
	
	int addHuman(Human human);
	int editHuman(Human human);
	int disableHuman(Human human);
	
	
	Data getProcesses();
	
}
