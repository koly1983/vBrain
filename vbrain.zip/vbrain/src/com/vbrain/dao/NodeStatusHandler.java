/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vbrain.dao;

import com.vbrain.adapter.CommonDbAdapter;
import com.vbrain.hibernate.model.Hubs;
import com.vbrain.hibernate.model.Nodes;
import java.util.List;



/**
 *
 * @author llihind
 */
public interface NodeStatusHandler {
    
    public boolean updateNodeStatus(Nodes node,String status);
    public String getNodeStatus(String node,String hub);
    public void handleNodeStatus(String hub) throws Exception;
    public List<Nodes> getNodesList(String hub);
    public List<Hubs> getHubsList();
    public CommonDbAdapter getDbAdapter();
    public void finalizeHandler();
}
