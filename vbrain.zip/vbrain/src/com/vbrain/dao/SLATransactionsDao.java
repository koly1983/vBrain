package com.vbrain.dao;

import java.util.List;

import com.vbrain.common.io.Data;

public interface SLATransactionsDao {
	
	List<Data> getSLAListWorkstepWise(String startDate, String endDate, String function);
	 List<Data> getSLAListRegionWise(String startDate, String endDate, String processName);
	 boolean invokeTriggerBotService(String botKey, boolean statusFlag);
	 List<Data> getSLAListByStatusAndFunction(String startDate, String endDate, String status, String function);
	 List<Data> getSLAListByStatus(String startDate, String endDate, String processName, String status);
	 List<Data> getSLAListByRegion(String startDate, String endDate, String region, String status, String groupBy, String function);

}
