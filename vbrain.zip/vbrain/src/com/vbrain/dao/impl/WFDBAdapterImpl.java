package com.vbrain.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.vbrain.common.exception.AdapterException;
import com.vbrain.dao.WFDBAdapter;
import com.vbrain.db.connection.PostgresDbManager;
import com.vbrain.db.connection.VBrainDbManager;

public class WFDBAdapterImpl implements WFDBAdapter {
	
    /**
     * Used to Retrieve Data from database and load the data to String array and return as list.
     * @query query retrieved from Properties file and passed as parameter
     * @parameters Array of parameters used to set for prepared statement
     * @parameters PostGress DB Connection
     * @return List with the data fetch from resultSet
     */
    public List<String[]> getDataFromTable(String query, String[] parameters, Connection connObjPostgres) {
        List<String[]> result = new ArrayList<String[]>();
        
        PreparedStatement readData = null;
        ResultSet resultSet = null;
        try{
            if(connObjPostgres == null) {
                throw new AdapterException("Postgres Connection not found ");
            }
            
            if(query == null || query.isEmpty()) {
                throw new AdapterException("Invalid Query: " + query);
            }
            System.out.println("WFDBAdapterImpl : getDataFromTable : Select Query: " + query);
            
            readData = connObjPostgres.prepareStatement(query, ResultSet.TYPE_SCROLL_SENSITIVE,  ResultSet.CONCUR_UPDATABLE);
            int parameterIndex = 1;
            if( parameters != null && parameters.length > 0) {
                for(String parameter : parameters) {
                    readData.setString(parameterIndex++, parameter);
                }
            }
            resultSet = readData.executeQuery();
            resultSet.last();
            //int resultSetLength = resultSet.getRow();
            resultSet.beforeFirst();
            String rows[] = null;
            int rowIndex = 0 , resultSetIndex = 1;
            while(resultSet.next()){
                int columnCount = resultSet.getMetaData().getColumnCount();
                rows = new String[columnCount];
                for(int count = 0 ; count < columnCount ; count++) {
                    rows[rowIndex++] = resultSet.getString(resultSetIndex++);
                }
                result.add(rows);
                rows = null;resultSetIndex = 1;rowIndex = 0;
            }
        } catch(Exception ex){
            ex.printStackTrace();
        } finally {
            try{
                
                if (readData != null) {
                    readData.close();
                }
                if (resultSet != null) {
                    resultSet.close();
                }
            }
            catch(Exception e){
                e.printStackTrace();
                return null;
            }
        }
        return result;
    }

}
