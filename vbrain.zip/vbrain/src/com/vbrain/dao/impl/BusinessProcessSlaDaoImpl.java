package com.vbrain.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import com.vbrain.common.io.BusinessProcessSla;
import com.vbrain.common.io.Exception;
import com.vbrain.dao.BusinessProcessSlaDao;

public class BusinessProcessSlaDaoImpl extends ConnectionDaoImpl implements BusinessProcessSlaDao{

	public int configureSla(BusinessProcessSla sla) {
		Connection mysqlConn = null;
		PreparedStatement st = null;
		int result = 0;
		try {

			if (sla != null) {

				mysqlConn = getMySqlConnection();

				StringBuffer updateQuery = new StringBuffer();
				updateQuery.append("{CALL insert_or_update_business_process_sla_sp(?,?,?,?)}");

				st = mysqlConn.prepareStatement(updateQuery.toString());
				st.setNull(1, Types.INTEGER);
				st.setInt(2, Integer.valueOf(sla.getbpId()));
				st.setInt(3, Integer.valueOf(sla.getSlaTime()));
				st.setString(4, sla.getEmailAddress());
				st.executeUpdate();
				result = 1;

				System.out.println("Add business_process_sla result :::::::::: " + result);
			}

		} catch (java.lang.Exception e) {
			e.printStackTrace();
			result = 0;
		} finally {
			boolean closedResources = closeResources(mysqlConn, st, null);
			if (!closedResources) {
				result = 0;
			}
		}

		return result;
	}
	
	public int updateSlaConfiguration(BusinessProcessSla sla) {
		Connection mysqlConn = null;
		PreparedStatement st = null;
		int result = 0;
		try {

			if (sla != null) {

				mysqlConn = getMySqlConnection();

				StringBuffer updateQuery = new StringBuffer();
				updateQuery.append("{CALL insert_or_update_business_process_sla_sp(?,?,?,?)}");

				st = mysqlConn.prepareStatement(updateQuery.toString());
				st.setInt(1, Integer.valueOf(sla.getId()));
				st.setInt(2, Integer.valueOf(sla.getbpId()));
				st.setInt(3, Integer.valueOf(sla.getSlaTime()));
				st.setString(4, sla.getEmailAddress());
				st.executeUpdate();
				result = 1;

				System.out.println("update business_process_sla result :::::::::: " + result);
			}

		} catch (java.lang.Exception e) {
			e.printStackTrace();
			result = 0;
		} finally {
			boolean closedResources = closeResources(mysqlConn, st, null);
			if (!closedResources) {
				result = 0;
			}
		}

		return result;
	}
	
	@Override
	public int deleteSlaConfiguration(String businessProcessId) {
		Connection mysqlConn = null;
		Statement st = null;
		ResultSet rs = null;
		int result = 0;
		try {
			mysqlConn = getMySqlConnection();
			StringBuffer deleteQuery = new StringBuffer();
			deleteQuery.append("DELETE FROM wf_business_process_sla_time WHERE Business_Process_Id = ").append(businessProcessId);
			System.out.println("Dlete Query is"+deleteQuery);
			st = mysqlConn.createStatement();
			result = st.executeUpdate(deleteQuery.toString());
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources(mysqlConn, st, rs);
		} 
		return result;
	}
	
	
	public List<BusinessProcessSla> getBusinessProcessSlaList() {
		Connection mysqlConn = null;
		Statement st = null;
		ResultSet rs = null;
		List<BusinessProcessSla> businessProcessSlaList = new ArrayList<>();
		try {
			mysqlConn = getMySqlConnection();
			StringBuffer getQuery = new StringBuffer();
			getQuery.append("SELECT s.ID as ID, s.Business_Process_Id as BUSINESS_PROCESS_ID, s.Sla_Time_In_Minutes as SLA_TIME_IN_MINUTES, ");
			getQuery.append("s.Email_Address as EMAIL_ADDRESS, b.campaign_name as CAMPAIGN_NAME ");
			getQuery.append("FROM wf_business_process_sla_time s ");
			getQuery.append("JOIN business_process_view_2 b ON s.Business_Process_Id = b. business_process_id");
			System.out.println("Query String is"+getQuery.toString());
			
			st = mysqlConn.createStatement();
			rs = st.executeQuery(getQuery.toString());
			
			while(rs.next()){
				BusinessProcessSla businessProcessSla = new BusinessProcessSla();
				businessProcessSla.setId(rs.getString("ID"));
				businessProcessSla.setbpId(rs.getString("BUSINESS_PROCESS_ID"));
				businessProcessSla.setBpName(rs.getString("CAMPAIGN_NAME"));
				businessProcessSla.setSlaTime(rs.getString("SLA_TIME_IN_MINUTES"));
				businessProcessSla.setEmailAddress(rs.getString("EMAIL_ADDRESS"));
				
				businessProcessSlaList.add(businessProcessSla);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources(mysqlConn, st, rs);
		} 
		return businessProcessSlaList;
	}
}
