package com.vbrain.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.vbrain.common.io.Data;
import com.vbrain.common.io.Incident;
import com.vbrain.common.io.RequestMessage;
import com.vbrain.dao.IncidentsDao;

public class IncidentsDaoImpl extends ConnectionDaoImpl implements IncidentsDao{

	
	 public List<Data> getIncidentsWorkstepwise(String startDate, String endDate,String workstep, String groupBy){
	    	Connection mysqlConn = null;
	        Statement st = null;
	        //Data data = null;
	        List<Data> dataList = null;
	        ResultSet rs = null;
	    	try{
	    		String mode = "";
	    		if(groupBy.equalsIgnoreCase("Daily")){
	    			 mode = "%m/%d/%Y";
	    		}
	    		else if(groupBy.equalsIgnoreCase("Monthly")){
	   			 	mode = "%M/%Y";
	    		}
	    		else if(groupBy.equalsIgnoreCase("Yearly")){
	   			 	mode = "%Y";
	    		}
/*
	    		String sql = 	"SELECT  count(vb.TICKET_ID) count, vb.status, vp.process_name "+
	    						"FROM vbrain_incidents vb, vbrain_transaction vp "+
	    						"where vb.TRANSACTION_ID = vp.ID AND vp.START_TIME >= STR_TO_DATE('"+startDate+"', '%m/%d/%Y') and vp.END_TIME <=  STR_TO_DATE('"+endDate+"', '%m/%d/%Y')"+ 
	    						"group by vb.status, vp.process_name "+ 
	    						"order by vb.TRANSACTION_ID";*/
	    		//String sql="SELECT * from vbrain_incidents";

	    		String sql = 	"SELECT  DATE_FORMAT(vp.START_TIME, '"+mode+"') AS transactionDate, count(vb.TICKET_ID) count, vb.status, "+
	    						"vp.process_name "+
						" FROM vbrain_incidents vb, vbrain_transaction vp "+
						" where vb.TRANSACTION_ID = vp.ID AND vp.START_TIME >= STR_TO_DATE('"+startDate+"', '%m/%d/%Y') and vp.END_TIME <=  STR_TO_DATE('"+endDate+"', '%m/%d/%Y') "+ 
						" group by transactionDate, vb.status, vp.process_name "+ 
						" order by transactionDate,vb.TRANSACTION_ID";
	    		mysqlConn = getMySqlConnection();
	    		st = mysqlConn.createStatement();
	    		rs = st.executeQuery(sql);
	    		//System.out.println("Incidents dataList.size() :::::::: "+dataList.size());

	    	}
	    	catch(Exception e){
	    		e.printStackTrace();
	    	}
	    	finally {
	    		closeResources(mysqlConn, st, rs);
	        } 

	    	return dataList;
	    }
	 
	 /**
	  * 
	  * @param trackingId
	  * @return
	  */
	 private int isNewIncedents(String trackingId){
			Connection mysqlConn = null;
			Statement st = null;
			ResultSet rs = null;
			try{

				String sql = 	"select * from vbrain_incidents "+
								" where tracking_id = '"+trackingId+"' ";
				
				mysqlConn = getMySqlConnection();
	    		st = mysqlConn.createStatement();
	    		rs = st.executeQuery(sql);
	    		
	    		
	    		if(rs.next()){
	    			return 0;
	    		}
	    		else {
	    			return 1;
	    		}
			
			}
			catch(Exception e){
				e.printStackTrace();
				return 2;
			}
			finally {
				boolean closedResources = closeResources(mysqlConn, st, rs);
				if(!closedResources) {
            		return 2;
            	}
			} 
		}
	 
	 
	 
	 
	 /**
		 * 
		 * @param requestMessage
		 * @return
		 */
		public int createIncidents(RequestMessage requestMessage, TransactionDaoImpl transDao){
			// Connection oracleConn = null;
			Connection mysqlConn = null;
			Statement st = null;
			int result = 0;
			try {
				if(requestMessage.getRequestData().getIncidents().size() > 0){
					List<Incident> incidentList =  requestMessage.getRequestData().getIncidents();
					String tQuery = "";
					mysqlConn = getMySqlConnection();
					System.out.println("incidentList.size() =" + incidentList.size());
					System.out.println("workerType:::::::::::: "+requestMessage.getRequestHeader().getWorkerType());
					System.out.println("workerId:::::::::::: "+requestMessage.getRequestHeader().getWorkerId());
					for(int i=0; i<incidentList.size(); i++){

						Incident incidents = incidentList.get(i);
						System.out.println("incidents.getTrackingId()  =" + incidents.getTrackingId());
						System.out.println("incidents.getTicketNo() =" + incidents.getTicketNo());
						System.out.println("incidents.getStatus() =" + incidents.getStatus());
						System.out.println("incidents.getCreatedBy() =" + incidents.getCreatedBy());
						System.out.println("incidents.getCreatedDate() =" + incidents.getCreatedDate());
						System.out.println("incidents.getClosedBy() =" + incidents.getClosedBy());
						System.out.println("incidents.getClosedDate() =" + incidents.getClosedDate());
						System.out.println("incidents.getDescription() =" + incidents.getDescription());
						int chkFlag = isNewIncedents(incidents.getTrackingId());
						if(chkFlag == 1){
							List<Integer> txn_ids = transDao.getTransactionIds(incidents.getTrackingId());
							int transaction_id = 0;
							if (txn_ids != null && txn_ids.size() > 0) {
								transaction_id = txn_ids.get(0);
							}
							List<Integer> worker_ids = transDao.getWorkerIds(incidents.getTrackingId());
							int worker_id = 0;
							if (worker_ids != null && worker_ids.size() > 0) {
								worker_id = worker_ids.get(0);
							}
							tQuery = "INSERT INTO vbrain_incidents "+
									"(TICKET_ID, STATUS, DESCRIPTION, CREATED_BY, CREATED_DATE, TRACKING_ID, TRANSACTION_ID, BOT_ID ) "+
									"VALUES (" +
									" '"+incidents.getTicketNo()+"', " +
									" '"+incidents.getStatus()+"', "+
									" '"+incidents.getDescription()+"',"+
									" '"+incidents.getCreatedBy()+"', "+
									" '"+Timestamp.valueOf(incidents.getCreatedDate())+"', "+
									" '"+incidents.getTrackingId()+"', " +
									" "+transaction_id+"," +
									" "+worker_id+" )";
							System.out.println("tQuery ::::::: "+tQuery);
							st = mysqlConn.createStatement();
							result = result + st.executeUpdate(tQuery);

						}
						else if(chkFlag == 0){
							tQuery = "UPDATE vbrain_incidents "+
									" SET STATUS = '"+incidents.getStatus()+"', "+
									" DESCRIPTION = '"+incidents.getDescription()+"', "+
									" CLOSED_BY = '"+incidents.getClosedBy()+"',  "+
									" CLOSING_DATE = '"+Timestamp.valueOf(incidents.getClosedDate())+"' " +
									" WHERE TICKET_ID = '"+incidents.getTicketNo()+"'   ";
							
							System.out.println("tQuery ::::::: "+tQuery);
							st = mysqlConn.createStatement();
							result = result + st.executeUpdate(tQuery);
						}
						else {
							result = 0;
						}

						System.out.println("result :::::::::: "+result);
					}
				}

			} 
			catch (Exception e) {
				// handle the exception
				e.printStackTrace();
				result = 0;
				//System.exit(1);
			} 
			finally {
				// release database resources
				boolean closedResources = closeResources(mysqlConn, st, null);
				if(!closedResources) {
            		result = 0;
            	}
			}

			return result;
		}

	/**
	 * 
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<Data> getIncidentList(String processName, String startDate, String endDate) {
		Connection mysqlConn = null;
		Statement st = null;
		Data data = null;
		
		List<Data> recordList =null;
	
		ResultSet rs = null;
		try{

			String sql=	" select g.ticket_id as ticket_id, i.DESCRIPTION as ticket_desc, t.DESCRIPTION as transaction_desc, g.status as status, " +
			            " g.transaction_id as transaction_id, g.start_time as start_time, g.end_time as end_time "+
						" from group_incidents_view g join vbrain_incidents i on g.ticket_id = i.ticket_id "+
			            " join transactions t on t.id = g.transaction_id " +
						" where g.process_name = '" + processName +"' and g.start_time >= STR_TO_DATE('"+startDate+
						"', '%m/%d/%Y') and g.END_TIME <=  DATE_ADD( STR_TO_DATE('"+
						endDate+"', '%m/%d/%Y'), INTERVAL 1 DAY) order by g.start_time desc";
			System.out.println(sql);
			mysqlConn = getMySqlConnection();
    		st = mysqlConn.createStatement();
    		rs = st.executeQuery(sql);
    		recordList = new ArrayList<Data>();
    		int i = 1;
    		while(rs.next()){
    			data = new Data();
				data.setIndex(i++);
    			data.setTicketID(rs.getString("ticket_id"));
    			System.out.println("ticket_id="+rs.getString("ticket_id"));
    			
    			data.setTicketDesc(rs.getString("ticket_desc"));
    			System.out.println("ticket_desc="+rs.getString("ticket_desc"));

    			data.setStatus(rs.getString("status"));
    			if (data.getStatus().equals("0")) {
    				data.setStatus("closed");
    			} else {
    				data.setStatus("open");
    			}
    			System.out.println("status=" + rs.getString("status"));

    			data.setTransactionID(rs.getString("transaction_id"));
    			System.out.println("transaction_id="+rs.getString("transaction_id"));

    			data.setTransactionDesc(rs.getString("transaction_desc"));
    			System.out.println("transaction_desc="+rs.getString("transaction_desc"));

    			data.setStartTime(rs.getString("start_time"));
    			System.out.println("start_time="+rs.getString("start_time"));
    			
    			data.setEndTime(rs.getString("end_time"));
    			System.out.println("end_time="+rs.getString("end_time"));
    			
    			recordList.add(data);
    		}
			System.out.println("getIncidentList(): dataList.size() :::::::: "+recordList.size());
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			closeResources(mysqlConn, st, rs);
		} 
		return recordList;
	}
	
	/**
	 * 
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<Data> getIncidents(String startDate, String endDate, String function){
		Connection mysqlConn = null;
		Statement st = null;
		Data data = null;
		
		List<Data> recordList =null;
	
		ResultSet rs = null;
		try{

			String sql;
			if (function == null || function.isEmpty()) {
				sql =" select count(*) TICKET_COUNT, g.status, g.process_name, sum( case when g.status='0' then 1 else 0 end ) as closed, "+
						" sum( case when g.status='1' then 1 else 0 end ) as OPEN "+
						" from group_incidents_view g join transactions t on g.transaction_id = t.id"+
						" where g.process_id = (select id from groups where isDisabled = '0'  and id = process_id ) and g.START_TIME >= STR_TO_DATE('"+startDate+"', '%m/%d/%Y') and g.END_TIME <=  DATE_ADD( STR_TO_DATE('"+endDate+"', '%m/%d/%Y'), INTERVAL 1 DAY) "+
						" group by g.process_name order by g.process_id";
			} else {
				sql =" select count(*) TICKET_COUNT, g.status, g.process_name, sum( case when g.status='0' then 1 else 0 end ) as closed, "+
						" sum( case when g.status='1' then 1 else 0 end ) as OPEN "+
						" from group_incidents_view g join transactions t on g.transaction_id = t.id"+
						" where t.b_function = '" + function + "' and g.process_id = (select id from groups where isDisabled = '0'  and id = process_id ) and g.START_TIME >= STR_TO_DATE('"+startDate+"', '%m/%d/%Y') and g.END_TIME <=  DATE_ADD( STR_TO_DATE('"+endDate+"', '%m/%d/%Y'), INTERVAL 1 DAY) "+
						" group by g.process_name order by g.process_id";
			}
			
			System.out.println(sql);
			mysqlConn = getMySqlConnection();
    		st = mysqlConn.createStatement();
    		rs = st.executeQuery(sql);
    		recordList = new ArrayList<Data>();
    		
    		while(rs.next()){
    			data = new Data();

    			data.setTotalIncidents(Long.parseLong(rs.getString("TICKET_COUNT")));
    			System.out.println("tckt count"+rs.getString("TICKET_COUNT"));
    			
    			data.setProcessName(rs.getString("PROCESS_NAME"));
    			//data.setStatus(rs.getString("status"));
    			data.setTicketsClosed(rs.getLong("closed"));
    			data.setTicketsOpen(rs.getLong("open"));
    			
    			System.out.println("Process name"+rs.getString("PROCESS_NAME")); 
    			
    			recordList.add(data);

    		}

			System.out.println("dataList.size() :::::::: "+recordList.size());
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			closeResources(mysqlConn, st, rs);
		} 

		return recordList;
	}
	
	/**
	 * 
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<Data> getIncidentListRegionWise(String processName, String startDate, String endDate) {
		Connection mysqlConn = null;
		Statement st = null;
		Data data = null;
		
		List<Data> recordList =null;
	
		ResultSet rs = null;
		try{

			String sql=	" select ticket_id, status, transaction_id, start_time, end_time"+
						" from group_incidents_view "+
						" where process_name = '" + processName +"' and start_time >= STR_TO_DATE('"+startDate+
						"', '%m/%d/%Y') and END_TIME <=  DATE_ADD( STR_TO_DATE('"+
						endDate+"', '%m/%d/%Y'), INTERVAL 1 DAY) order by start_time";
			System.out.println(sql);
			mysqlConn = getMySqlConnection();
    		st = mysqlConn.createStatement();
    		rs = st.executeQuery(sql);
    		recordList = new ArrayList<Data>();
    		int i =1;
    		while(rs.next()){
    			data = new Data();
				data.setIndex(i++);
    			data.setTicketID(rs.getString("ticket_id"));
    			System.out.println("ticket_id="+rs.getString("ticket_id"));
    			
    			data.setTicketDesc(rs.getString("ticket_desc"));
    			System.out.println("ticket_desc="+rs.getString("ticket_desc"));

    			data.setStatus(rs.getString("status"));
    			if (data.getStatus().equals("0")) {
    				data.setStatus("closed");
    			} else {
    				data.setStatus("open");
    			}
    			System.out.println("status=" + rs.getString("status"));

    			data.setTransactionID(rs.getString("transaction_id"));
    			System.out.println("transaction_id="+rs.getString("transaction_id"));

    			data.setTransactionDesc(rs.getString("transaction_desc"));
    			System.out.println("transaction_desc="+rs.getString("transaction_desc"));

    			data.setStartTime(rs.getString("start_time"));
    			System.out.println("start_time="+rs.getString("start_time"));
    			
    			data.setEndTime(rs.getString("end_time"));
    			System.out.println("end_time="+rs.getString("end_time"));
    			
    			recordList.add(data);
    		}
			System.out.println("getIncidentList(): dataList.size() :::::::: "+recordList.size());
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			closeResources(mysqlConn, st, rs);
		} 
		return recordList;
	}

	/**
	 * 
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<Data> getIncidentsRegionwise(String startDate, String endDate,String mode, String function){
		Connection mysqlConn = null;
		Statement st = null;
		Data data = null;
		List<Data> dataList = null;
		ResultSet rs = null;
		try{

			String sql = "select count(*) totalIncidents, vi.process_Name, vi.country, vt.worker_type, (select sequence from sequence_temp where process_name = vi.process_name) as sequence " + 
			        " from group_incidents_view vi join group_transaction_view vt on vi.transaction_id = vt.transaction_id" +
					" where vt.status = '0' and vt.worker_status = '0' and vi.process_id = (select id from groups where isDisabled = '0'  and id = vi.process_id ) and " +
			        " and vi.START_TIME >= STR_TO_DATE('"+startDate+"', '%m/%d/%Y') and " + 
					" vi.END_TIME <=  DATE_ADD( STR_TO_DATE('"+endDate+"', '%m/%d/%Y'), INTERVAL 1 DAY) " +
					" group by vi.process_Name, vi.country, vt.worker_type order by sequence, vi.country, vt.worker_type";
			
			System.out.println("sql ::::::::::: "+sql);

			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);
			dataList = new ArrayList<Data>();
			int i = 0;

			String processName = "";
			Data transData = null;
			List<Data> transList = new ArrayList<Data>();
			while(rs.next()){
				transData = new Data();

				if(i > 0 && !processName.equalsIgnoreCase(rs.getString("process_Name"))){
					data = new Data();
					data.setProcessName(processName);
					data.setTransactionList(transList);
					dataList.add(data);
					transList = new ArrayList<Data>();

				}

				processName = rs.getString("process_Name");
				i++;

				transData.setTotalIncidents( rs.getLong("totalIncidents") );
				transData.setRegion(rs.getString("country"));
				transData.setWorker(rs.getString("worker_type"));
				
				
				System.out.println(" Worker Type :::::::: ----- > "+rs.getString("worker_type"));
				
				transList.add(transData);

				if(rs.isLast()){
					data = new Data();
					data.setProcessName(processName);
					data.setTransactionList(transList);
					dataList.add(data);
				}

			}
			System.out.println("getIncidentsRegionwise(): dataList.size() *************** "+dataList.size());

		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			closeResources(mysqlConn, st, rs);
		} 

		return dataList;
	}

	public List<Data> old_getIncidentsRegionwise(String startDate, String endDate,String mode, String function){
		Connection mysqlConn = null;
		Statement st = null;
		Data data = null;
		
		List<Data> recordList =null;
	
		ResultSet rs = null;
		try{

			String sql;
			if (function == null || function.isEmpty()) {
				sql = "select count(*) Total_incidents, country, process_name, sum( case when status='0' then 1 else 0 end ) as closed,sum( case when status='1' then 1 else 0 end ) as OPEN "+
					" from group_incidents_view "+
					" where  process_id = (select id from groups where isDisabled = '0'  and id = process_id ) and START_TIME >= STR_TO_DATE('"+startDate+"', '%m/%d/%Y') and END_TIME <=  DATE_ADD( STR_TO_DATE('"+endDate+"', '%m/%d/%Y'), INTERVAL 1 DAY) "+
					"  group by country, process_name";
			} else {
				sql = "select count(*) Total_incidents, country, process_name, sum( case when status='0' then 1 else 0 end ) as closed,sum( case when status='1' then 1 else 0 end ) as OPEN "+
						" from group_incidents_view "+
						" where  process_id = (select id from groups where isDisabled = '0'  and id = process_id ) and START_TIME >= STR_TO_DATE('"+startDate+"', '%m/%d/%Y') and END_TIME <=  DATE_ADD( STR_TO_DATE('"+endDate+"', '%m/%d/%Y'), INTERVAL 1 DAY) "+
						"  group by country, process_name";
			}
			System.out.println(sql);
			mysqlConn = getMySqlConnection();
    		st = mysqlConn.createStatement();
    		rs = st.executeQuery(sql);
    		recordList = new ArrayList<Data>();
    		while(rs.next()){
    			data = new Data();

    			data.setTotalIncidents(Long.parseLong(rs.getString("Total_incidents")));
    			System.out.println("tckt count"+rs.getString("Total_incidents"));
    			
    			data.setProcessName(rs.getString("process_name"));
    			data.setCountry("country");
    			data.setTicketsClosed(rs.getLong("closed"));
    			data.setTicketsOpen(rs.getLong("open"));
    			
    			//System.out.println("Process name"+rs.getString("PROCESS_NAME")); 
    			recordList.add(data);
    		}

			System.out.println("getIncidentsRegionwise(): dataList.size() :::::::: "+recordList.size());
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			closeResources(mysqlConn, st, rs);
		} 

		return recordList;
	}


}
