package com.vbrain.dao.impl;

public class DbTableField {
	private String name;

	public DbTableField(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}
