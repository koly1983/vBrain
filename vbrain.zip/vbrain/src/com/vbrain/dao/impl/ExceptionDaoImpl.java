package com.vbrain.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import com.vbrain.common.io.Exception;
import com.vbrain.dao.ExceptionDao;

public class ExceptionDaoImpl extends ConnectionDaoImpl implements ExceptionDao {

	/*@Override
	public int addException(Exception exception) {

		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		try {

			if (exception != null) {

				System.out.println("exception.getLob()             =" + exception.getLob());
				System.out.println("exception.getExceptionType()   =" + exception.getExceptionType());
				System.out.println("exception.getExceptionValue()  =" + exception.getExceptionValue());

				// int isDuplicateGroup = isDuplicateGroup(group.getName(),
				// group.getParentId());

				// if(isDuplicateGroup == 0){
				mysqlConn = getMySqlConnection();

				StringBuffer insertQuery = new StringBuffer();
				insertQuery.append("INSERT INTO exceptions (Lob, Exception_Type, Exception_Value) VALUES (");
				insertQuery.append(" '").append(exception.getLob()).append("',");
				insertQuery.append(" '").append(exception.getExceptionType()).append("',");
				insertQuery.append(" '").append(exception.getExceptionValue()).append("'");
				insertQuery.append(")");

				System.out.println("tQuery ::::::: " + insertQuery.toString());

				st = mysqlConn.createStatement();

				result = st.executeUpdate(insertQuery.toString());

				System.out.println("Add Exception result :::::::::: " + result);

				// }
				// else if(isDuplicateGroup == 1){
				// return 2; //Group already exist
				// }
				// else if(isDuplicateGroup == 2){
				// return 3; //technical error
				// }
			}

		} catch (java.lang.Exception e) {
			e.printStackTrace();
			result = 0;
		} finally {
			boolean closedResources = closeResources(mysqlConn, st, null);
			if (!closedResources) {
				result = 0;
			}
		}

		return result;
	}*/
	
	@Override
	public int addException(Exception exception) {

		Connection mysqlConn = null;
		PreparedStatement st = null;
		int result = 0;
		try {

			if (exception != null) {

				// int isDuplicateGroup = isDuplicateGroup(group.getName(),
				// group.getParentId());

				// if(isDuplicateGroup == 0){
				mysqlConn = getMySqlConnection();

				StringBuffer updateQuery = new StringBuffer();
				updateQuery.append("{CALL insert_or_update_exception_type_sp_2(?,?,?,?,?)}");


				st = mysqlConn.prepareStatement(updateQuery.toString());
				st.setNull(1, Types.INTEGER);
				st.setInt(2, Integer.valueOf(exception.getLob()));
				st.setInt(3, Integer.valueOf(exception.getExceptionType()));
				st.setString(4, exception.getExceptionValue());
				st.setInt(5, exception.getFullMatchValue().trim().equals("Equals") ? 1 : 0);
				st.executeUpdate();
				result = 1;

				System.out.println("Add Exception result :::::::::: " + result);

				// }
				// else if(isDuplicateGroup == 1){
				// return 2; //Group already exist
				// }
				// else if(isDuplicateGroup == 2){
				// return 3; //technical error
				// }
			}

		} catch (java.lang.Exception e) {
			e.printStackTrace();
			result = 0;
		} finally {
			boolean closedResources = closeResources(mysqlConn, st, null);
			if (!closedResources) {
				result = 0;
			}
		}

		return result;
	}

	@Override
	public List<Exception> getExceptions() {
		return getExceptionsByLob(null);
	}

	@Override
	public List<Exception> getExceptionsByLob(String lobId) {
		Connection mysqlConn = null;
		Statement st = null;
		ResultSet rs = null;
		List<Exception> exceptionsList = new ArrayList<>();
		try {
			mysqlConn = getMySqlConnection();
			StringBuffer getQuery = new StringBuffer();
			getQuery.append("SELECT e.ID ID, e.Lob LOB_ID,e.Exception_Type Exception_Type, e.Exception_Value Exception_Value, e.Exception_Msg Exception_Msg ");
//			getQuery.append("e.Exception_Type Exception_Type, e.Exception_Value Exception_Value ");
			getQuery.append("FROM exceptions e ");
//			getQuery.append("JOIN groups g ON e.Lob = g.ID");
//			if(lobId != null && !lobId.isEmpty()) {
//				getQuery.append(" WHERE e.Lob =");
//				getQuery.append("'").append(lobId).append("'");
//			}
			System.out.println("Query String is"+getQuery.toString());
			
			st = mysqlConn.createStatement();
			rs = st.executeQuery(getQuery.toString());
			
			while(rs.next()){
				Exception exception = new Exception();
				exception.setId(rs.getString("ID"));
				exception.setLob(rs.getString("LOB_ID"));
			//	exception.setLobName(rs.getString("LOB_NAME"));
				exception.setExceptionType(rs.getString("Exception_Type"));
				exception.setExceptionValue(rs.getString("Exception_Value"));
				exception.setFullMatchValue(rs.getInt("Exception_Msg") == 1 ? "Equals" : "Contains");
				
				exceptionsList.add(exception);
			}
			System.out.println("Exceptions List is " +exceptionsList);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources(mysqlConn, st, rs);
		} 
		return exceptionsList;
	}

	@Override
	public int deleteException(String exceptionId) {
		Connection mysqlConn = null;
		Statement st = null;
		ResultSet rs = null;
		int result = 0;
		try {
			mysqlConn = getMySqlConnection();
			StringBuffer deleteQuery = new StringBuffer();
			deleteQuery.append("DELETE FROM exceptions WHERE ID = ").append(exceptionId);
			st = mysqlConn.createStatement();
			result = st.executeUpdate(deleteQuery.toString());
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources(mysqlConn, st, rs);
		} 
		return result;
	}

	/*@Override
	public int updateException(com.vbrain.common.io.Exception exception) {
		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		try {

			if (exception != null) {

				System.out.println("exception.getLob()             =" + exception.getLob());
				System.out.println("exception.getExceptionType()   =" + exception.getExceptionType());
				System.out.println("exception.getExceptionValue()  =" + exception.getExceptionValue());

				mysqlConn = getMySqlConnection();

				StringBuffer updateQuery = new StringBuffer();
				updateQuery.append("UPDATE exceptions SET ");
				updateQuery.append("Lob='").append(exception.getLob()).append("', ");
				updateQuery.append("Exception_Type='").append(exception.getExceptionType()).append("', ");
				updateQuery.append("Exception_Value='").append(exception.getExceptionValue()).append("' ");
				updateQuery.append("WHERE ID=").append(exception.getId());

				System.out.println("tQuery ::::::: " + updateQuery.toString());

				st = mysqlConn.createStatement();

				result = st.executeUpdate(updateQuery.toString());

				System.out.println("Update Exception result :::::::::: " + result);

			}

		} catch (java.lang.Exception e) {
			e.printStackTrace();
			result = 0;
		} finally {
			boolean closedResources = closeResources(mysqlConn, st, null);
			if (!closedResources) {
				result = 0;
			}
		}

		return result;
	}*/
	
	@Override
	public int updateException(com.vbrain.common.io.Exception exception) {
		Connection mysqlConn = null;
		PreparedStatement st = null;
		int result = 0;
		try {

			if (exception != null) {

				mysqlConn = getMySqlConnection();

				StringBuffer updateQuery = new StringBuffer();
				updateQuery.append("{CALL insert_or_update_exception_type_sp_2(?,?,?,?,?)}");

				System.out.println("tQuery ::::::: " + updateQuery.toString());

				st = mysqlConn.prepareStatement(updateQuery.toString());
				st.setInt(1, Integer.valueOf(exception.getId()));
				st.setInt(2, Integer.valueOf(exception.getLob()));
				st.setInt(3, Integer.valueOf(exception.getExceptionType()));
				st.setString(4, exception.getExceptionValue());
				st.setInt(5, exception.getFullMatchValue().trim().equals("Equals") ? 1 : 0);
				st.executeUpdate();
				result = 1;

				System.out.println("Update Exception result :::::::::: " + result);

			}

		} catch (java.lang.Exception e) {
			e.printStackTrace();
			result = 0;
		} finally {
			boolean closedResources = closeResources(mysqlConn, st, null);
			if (!closedResources) {
				result = 0;
			}
		}

		return result;
	}

}
