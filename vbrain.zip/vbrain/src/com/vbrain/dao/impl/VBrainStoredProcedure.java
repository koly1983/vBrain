package com.vbrain.dao.impl;

import java.sql.ResultSet;
import java.util.List;

import com.vbrain.dao.impl.ImportImpl.DbConnectionType;

public class VBrainStoredProcedure extends DbStoredProcedure {

	private DbConnection _conn;
	private ResultSet _rs;
	
	private DbConnection getConnection() {
		if(_conn == null) {
			_conn = new DbConnection(DbConnectionType.VBRAIN);
		}
		
		return _conn;
	}
	
	public VBrainStoredProcedure(String name, List<String> params) {
		super(name, params, false);
		execute();
	}
	
	public VBrainStoredProcedure(String name, List<String> params, boolean returnsData) {
		super(name, params, returnsData);
		execute();
	}
	
	public VBrainStoredProcedure(String name, String param) {
		super(name, param, false);
		execute();
	}
	
	public VBrainStoredProcedure(String name, String param, boolean returnsData) {
		super(name, param, returnsData);
		execute();
	}

	private void execute() {
		if(!returnsData) {
			execute(getConnection());
			close();
			return;
		}
		
		_rs = executeQuery(getConnection(), true);
//		try {
//			if(!_rs.next()){
//				close();
//				return;
//			}
//			_rs.beforeFirst();
//		} catch (SQLException e) {
//			close();
//		}
	}
	
	public ResultSet getResultSet() {
//		return executeQuery(getConnection(), true);
		return _rs;
	}
	
	public void close() {
		getConnection().closeResultSet(_rs, true);
		getConnection().closeConnection();
	}
	
	public static void execute(String name, List<String> params) {
		new VBrainStoredProcedure(name, params);
	}
}
