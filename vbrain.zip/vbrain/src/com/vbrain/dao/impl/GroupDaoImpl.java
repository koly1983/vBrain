package com.vbrain.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.vbrain.common.io.Campaign;
import com.vbrain.common.io.Data;
import com.vbrain.common.io.Group;
import com.vbrain.common.io.RequestMessage;
import com.vbrain.common.io.CampaignMapping;
import com.vbrain.common.io.Transactions;
import com.vbrain.common.io.User;
import com.vbrain.dao.GroupDao;

public class GroupDaoImpl extends ConnectionDaoImpl implements GroupDao{

    private static List<Group> allGroups = null;
    
    /**
     * @return the allGroups
     */
    private static List<Group> getAllGroups() {
        return allGroups;
    }

    /**
     * @param allGroups the allGroups to set
     */
    private static void setAllGroups(List<Group> allGroups) {
        GroupDaoImpl.allGroups = allGroups;
    }
    
    /**
     * Get group names of the specified type
     */
    public List<Data> getGroupNames(String type) {
        Connection mysqlConn = null;
        Statement st = null;
        Data data = null;
        
        List<Data> recordList =null;
    
        ResultSet rs = null;
        try{

            String sql= " select ID, Name from groups where type ='" + type + "' and isDisabled = 0";
            System.out.println(sql);
            mysqlConn = getMySqlConnection();
            st = mysqlConn.createStatement();
            rs = st.executeQuery(sql);
            recordList = new ArrayList<Data>();
            
            while(rs.next()){
                data = new Data();
                data.setGroupName(rs.getString("Name"));
                data.setGroupID(rs.getLong("ID"));
                System.out.println("name="+rs.getString("Name"));
                System.out.println("ID="+rs.getLong("ID"));
                
                recordList.add(data);
            }
            System.out.println("getGroupNames(): dataList.size() :::::::: "+recordList.size());
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            closeResources(mysqlConn, st, rs);
        } 
        return recordList;
        
    }
    
    /**
     * Get function names of the specified type
     */
    public List<Data> getFunctionNames(String type, long id) {
        Connection mysqlConn = null;
        Statement st = null;
        Data data = null;
        
        List<Data> recordList =null;
    
        ResultSet rs = null;
        try{

            String sql= " select ID, Name from groups where type ='" + type + "' and Parent_Id='" + id + "' and isDisabled = 0";
            System.out.println(sql);
            mysqlConn = getMySqlConnection();
            st = mysqlConn.createStatement();
            rs = st.executeQuery(sql);
            recordList = new ArrayList<Data>();
            
            while(rs.next()){
                data = new Data();
                data.setGroupName(rs.getString("Name"));
                data.setGroupID(rs.getLong("ID"));
                System.out.println("name="+rs.getString("Name"));
                System.out.println("ID="+rs.getLong("ID"));
                
                recordList.add(data);
            }
            System.out.println("getFunctionNames(): dataList.size() :::::::: "+recordList.size());
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            closeResources(mysqlConn, st, rs);
        } 
        return recordList;
        
    }
    
    public Data getUnusedCampaignsData(long includeGroupId) {
        Connection mysqlConn = null;
        PreparedStatement st = null;
        Data data = new Data();
        
    
        ResultSet rs = null;
        try{

        	StringBuilder query = new StringBuilder();
        	query.append("{CALL select_unmapped_campaigns_sp_2(?)}");
        	
            System.out.println(query.toString());
            mysqlConn = getMySqlConnection();
            st = mysqlConn.prepareStatement(query.toString());
            st.setLong(1, includeGroupId);
            rs = st.executeQuery();
            
            Map<String, Campaign> campaignsMap = new LinkedHashMap<>();
            Campaign campaign = null;
            CampaignMapping mapping = null;
            while(rs.next()){
            	String campaignId = rs.getString("campaign_id");
            	campaign = campaignsMap.get(campaignId);
            	if(campaign == null) {
            		campaign = new Campaign();
            		campaign.setId(campaignId);
            		campaign.setTitle(rs.getString("bp_name"));
            		campaign.setWfVersion(rs.getString("wf_version"));
            		campaignsMap.put(campaign.getId(), campaign);
            	}
            	mapping = new CampaignMapping();
            	mapping.setStepId(rs.getString("step_id"));
            	mapping.setStepTitle(rs.getString("step_title"));
            	mapping.setMappingId(rs.getString("mapping_id"));
            	mapping.setStepIndex(rs.getString("step_index"));
            	campaign.getMappings().add(mapping);
            }
            
            List<Campaign> campaigns = new ArrayList<>();
            campaigns.addAll(campaignsMap.values());
            System.out.println("getFunctionNames(): dataList.size() :::::::: "+campaigns.size());
            
            data.setCampaigns(campaigns);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            closeResources(mysqlConn, st, rs);
        } 
        return data;
        
    }
    
    public List<Data> getUnmappedBpList_2(long includeGroupId) {
        Connection mysqlConn = null;
        PreparedStatement st = null;
        List<Data> bpList = new ArrayList<>();
    
        ResultSet rs = null;
        try{

        	StringBuilder query = new StringBuilder();
        	query.append("{CALL select_bp_list_sp_2(?)}");
        	
        	System.out.println(query.toString());
            mysqlConn = getMySqlConnection();
            st = mysqlConn.prepareStatement(query.toString());
            st.setLong(1, includeGroupId);
            rs = st.executeQuery();
            
            while(rs.next()){
            	Data data = new Data();
            	data.setProcessId(rs.getString("id"));
            	data.setProcessName(rs.getString("display_name"));
            	data.setWfVersion(rs.getString("wf_version"));
            	bpList.add(data);
            }
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            closeResources(mysqlConn, st, rs);
        } 
        return bpList;
        
    }

    public Data getGroups(){
            Connection mysqlConn = null;
            Statement st = null;
            //Data data = null;
            Data data = null;
            ResultSet rs = null;
            try{
                

                //String sql =  "SELECT * FROM groups where isDisabled = '0' order by parent_id desc";
                String sql =    "SELECT * FROM groups order by parent_id desc";
                mysqlConn = getMySqlConnection();
                st = mysqlConn.createStatement();
                rs = st.executeQuery(sql);
                List<Group> groups = new ArrayList<Group>();
                Group group = null;
                String groupIds = "";
                
                while(rs.next()){
                    group = new Group();
                    
                    group.setId(rs.getString("id"));
                    group.setName(rs.getString("name"));
                    group.setDescription(rs.getString("description"));
                    group.setType(rs.getString("type"));
                    group.setParentId(rs.getString("parent_id"));
                    group.setParentGroupId(rs.getString("Parent_Group_Id"));
                    group.setNodes(new ArrayList<Group>());
                    
                    if("0".equals(rs.getString("isDisabled"))){
                        group.setIsDisabled("enabled");
                        group.setIconStyle("remove");
                        
                        
                    }
                    else {
                        group.setIsDisabled("disabled");
                        group.setIconStyle("ok");
                        
                    }
                    
                    
                    groupIds = groupIds + rs.getString("id") + ",";
                    
                    groups.add(group);
                }
                
                
                String[] groupIdList = groupIds.split(",");
                
                for(int cnt=0; cnt<groupIdList.length; cnt++){
                    
                    String id = groupIdList[cnt];
                    System.out.println("Group Id for group list::::::::::: "+id);
                    
                    Group sourceObj = null;
                    int  sourceIndex = 0;
                    for(int i=0; i<groups.size(); i++){
                        
                        String groupId = groups.get(i).getId();
                        if(id.equalsIgnoreCase(groupId)){
                        
                            System.out.println("Id::::::::::: "+groups.get(i).getId());
                            System.out.println("Parent Id:::: "+groups.get(i).getParentId());
                            System.out.println("Name::::::::: "+groups.get(i).getName());
                            
                            sourceObj = groups.get(i);
                            sourceIndex = i;
                        }
                    }   
                    
                    String sourceParentId = sourceObj.getParentId();
                    
                    //Parent(top node) Group check
                    if(0 != Integer.parseInt(sourceParentId)){
                        
                        for(int i=0; i<groups.size(); i++){
                            
                            String groupId = groups.get(i).getId();
                            if(sourceParentId.equalsIgnoreCase(groupId)){
                            
                                System.out.println("Destination Id::::::::::: "+groups.get(i).getId());
                                System.out.println("Destination Parent Id:::: "+groups.get(i).getParentId());
                                System.out.println("Destination Name::::::::: "+groups.get(i).getName());
                                
                                groups.get(i).getNodes().add(sourceObj);
                                
                            }
                        }   
                    
                        //Remove source element from group list
                        System.out.println("Removing Source Node ["+sourceIndex+"] ");
                        groups.remove(sourceIndex);
                    }
                    
                }
                
                data = new Data();
                data.setGroups(groups);
                
                System.out.println("Final Group Size ::::::::::::: "+groups.size());
                for(int i=0; i<groups.size(); i++){
                    
                    System.out.println("Final Group ID ::::::::::::: "+groups.get(i).getId());
                    System.out.println("Final Group - Child Group Length ::::: "+groups.get(i).getNodes().size());
                }   
                
            }
            catch(Exception e){
                e.printStackTrace();
            }
            finally {
            	closeResources(mysqlConn, st, rs);
            } 

            return data;
        }
     
        
        private int isDuplicateGroup(String groupName, String parentId){
            Connection mysqlConn = null;
            Statement st = null;
            ResultSet rs = null;
            
            
            try{
                
                String sql =    "SELECT * FROM groups where name = '"+groupName+"'and parent_id = '"+parentId+"' ";
                mysqlConn = getMySqlConnection();
                st = mysqlConn.createStatement();
                rs = st.executeQuery(sql);
                
                if(rs.next()){
                    return 1;
                }
                else {
                    return 0;
                }
                
            }
            catch(Exception e){
                e.printStackTrace();
                return 2;
            }
            finally {
            	boolean closedResources = closeResources(mysqlConn, st, rs);
            	if(!closedResources) {
            		return 2;
            	}
            } 

            
        }
        
        private int isDuplicateGroupUser(String groupId, String userId){
            Connection mysqlConn = null;
            Statement st = null;
            ResultSet rs = null;
            
            
            try{
                
                String sql =    "SELECT * FROM group_users where group_id = '"+groupId+"'and user_id = '"+userId+"' ";
                mysqlConn = getMySqlConnection();
                st = mysqlConn.createStatement();
                rs = st.executeQuery(sql);
                
                if(rs.next()){
                    return 1;
                }
                else {
                    return 0;
                }
                
            }
            catch(Exception e){
                e.printStackTrace();
                return 2;
            }
            finally {
            	boolean closedResources = closeResources(mysqlConn, st, rs);
            	if(!closedResources) {
            		return 2;
            	}
            } 

            
        }
     
     public int addGroup(Group group){

            // Connection oracleConn = null;
            Connection mysqlConn = null;
            Statement st = null;
            int result = 0;
            //ResultSet rs = null;
            try {

                if(group != null ){
                    
                
                    String tQuery = "";

                    System.out.println("group.getName()          =" + group.getName());
                    System.out.println("group.getDescription()   =" + group.getDescription());
                    System.out.println("group.getType()          =" + group.getType());
                    System.out.println("group.getParentId()      =" + group.getParentId());
                    System.out.println("group.getParentGroupId() =" + group.getParentGroupId());
                    
                    int isDuplicateGroup = isDuplicateGroup(group.getName(), group.getParentId());
                    
                    if(isDuplicateGroup == 0){
                        mysqlConn = getMySqlConnection();

                        tQuery = "INSERT INTO groups "+
                                "(Name, Description, Type, Parent_Id, Parent_Group_Id, isDisabled ) "+
                                "VALUES (" +
                                " '"+group.getName()+"', "+
                                " '"+group.getDescription()+"', "+
                                " '"+group.getType()+"', "+
                                " '"+group.getParentId()+"', "+
                                " '"+group.getParentGroupId()+"'," +
                                " '0' )";
                        
                        System.out.println("tQuery ::::::: "+tQuery);

                        st = mysqlConn.createStatement();

                        result = st.executeUpdate(tQuery);

                        System.out.println("Add Group result :::::::::: "+result);
                        
                        if (group.getType() != null && group.getType().equalsIgnoreCase("process")) {
                        	CampaignMapping campaignMapping = group.getCampaignMapping();
                        	
                        	tQuery = "INSERT INTO wf_bp_mapping (process_id, datastore_name, campaign_id, mapping_id)"
                        			+ " VALUES(LAST_INSERT_ID(),'"+group.getDatastoreName()+"','"+campaignMapping.getCampaignId()+"','"+campaignMapping.getMappingId()+"')"
                        			+ " ON DUPLICATE KEY UPDATE datastore_name = datastore_name ";
                        	
                        	System.out.println("Insert into bp mapping ::::::: "+tQuery);
                        	result = st.executeUpdate(tQuery);
                        	
                            int max_id = -1;
                            st = mysqlConn.createStatement();
                            String max_id_query = "select max(sequence) from sequence_temp";
                            ResultSet rs = st.executeQuery(max_id_query);
                            if (rs != null && rs.next()) {
                                max_id = rs.getInt(1);
                            }
                            System.out.println("max id ..." + max_id);
                            if (max_id != -1) {
                                max_id ++;
                                String sql = "INSERT INTO sequence_temp (Process_Name, sequence) VALUES ('" +
                                        group.getName() + "'," + max_id + ")";
                                System.out.println("sql ::::::: "+sql);
                                result = st.executeUpdate(sql);
                                System.out.println("Add Sequence result :::::::::: "+result);
                            }
                        }
                    }
                    else if(isDuplicateGroup == 1){
                        return 2; //Group already exist
                    }
                    else if(isDuplicateGroup == 2){
                        return 3; //technical error
                    }
                }

            } 
            catch (Exception e) {
                // handle the exception
                e.printStackTrace();
                result = 0;
                //System.exit(1);
            } 
            finally {
                // release database resources
            	//oracleConn.close();
            	boolean closedResources = closeResources(mysqlConn, st, null);
            	if(!closedResources) {
            		result = 0;
            	}
            }

            return result;
        }

	public int addGroup_2(Group group) {

		// Connection oracleConn = null;
		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		// ResultSet rs = null;
		try {

			if (group != null) {
				String tQuery = "";

				System.out.println("group.getName()          =" + group.getName());
				System.out.println("group.getDescription()   =" + group.getDescription());
				System.out.println("group.getType()          =" + group.getType());
				System.out.println("group.getParentId()      =" + group.getParentId());
				System.out.println("group.getParentGroupId() =" + group.getParentGroupId());

				int isDuplicateGroup = isDuplicateGroup(group.getName(), group.getParentId());

				if (isDuplicateGroup == 0) {
					mysqlConn = getMySqlConnection();

					tQuery = "INSERT INTO groups "
							+ "(Name, Description, Type, Parent_Id, Parent_Group_Id, isDisabled ) " + "VALUES (" + " '"
							+ group.getName() + "', " + " '" + group.getDescription() + "', " + " '" + group.getType()
							+ "', " + " '" + group.getParentId() + "', " + " '" + group.getParentGroupId() + "',"
							+ " '0' )";

					System.out.println("tQuery ::::::: " + tQuery);

					st = mysqlConn.createStatement();

					result = st.executeUpdate(tQuery, Statement.RETURN_GENERATED_KEYS);

					System.out.println("Add Group result :::::::::: " + result);
					String groupId = null;
					ResultSet keys = st.getGeneratedKeys();
					if (keys.next()){
						groupId=keys.getString(1);
					}
					keys.close();

					if (group.getType() != null && group.getType().equalsIgnoreCase("process")) {
						int max_id = -1;
						st = mysqlConn.createStatement();
						String max_id_query = "select max(sequence) from sequence_temp";
						ResultSet rs = st.executeQuery(max_id_query);
						if (rs != null && rs.next()) {
							max_id = rs.getInt(1);
						}
						System.out.println("max id ..." + max_id);
						if (max_id != -1) {
							max_id++;
							String sql = "INSERT INTO sequence_temp (Process_Name, sequence) VALUES ('"
									+ group.getName() + "'," + max_id + ")";
							System.out.println("sql ::::::: " + sql);
							result = st.executeUpdate(sql);
							System.out.println("Add Sequence result :::::::::: " + result);
						}
						
						result = updateBpMapping(mysqlConn, groupId, group.getBpId(), group.getMappingId(), group.getWfVersion());
					}
				} else if (isDuplicateGroup == 1) {
					return 2; // Group already exist
				} else if (isDuplicateGroup == 2) {
					return 3; // technical error
				}
			}

		} catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			result = 0;
			// System.exit(1);
		} finally {
			// release database resources
			// oracleConn.close();
			boolean closedResources = closeResources(mysqlConn, st, null);
			if (!closedResources) {
				result = 0;
			}
		}

		return result;
	}
     
     private int updateBpMapping(Connection mysqlConn, String processId, String bpId, String mappingId, String wfVersion) {
    	 PreparedStatement st = null;
    	 int result = 0;
         ResultSet rs = null;
         try{

         	StringBuilder query = new StringBuilder();
         	if("8.2".equals(wfVersion)) {
         		query.append("{CALL 82_update_bp_mapping_sp(?,?,?)}");
         	} else {
         		query.append("{CALL update_bp_mapping_sp(?,?,?)}");
         	}
         	
         	System.out.println(query.toString());
             mysqlConn = getMySqlConnection();
             st = mysqlConn.prepareStatement(query.toString());
             st.setString(1, bpId);
             st.setString(2, mappingId);
        	 st.setString(3, processId);
             result = st.executeUpdate();
         }
         catch(Exception e){
             e.printStackTrace();
         }
         finally {
             closeResources(null, st, rs);
         } 
         return result;
     }
     
     public int updateGroup_2(Group group){

         // Connection oracleConn = null;
         Connection mysqlConn = null;
         Statement st = null;
         int result = 0;
         //ResultSet rs = null;
         try {

             if(group != null ){
                 
                 System.out.println("group.getName()          =" + group.getName());
                 System.out.println("group.getDescription()   =" + group.getDescription());
                 System.out.println("group.getType()          =" + group.getType());
                 System.out.println("group.getParentId()      =" + group.getParentId());
                 System.out.println("group.getParentGroupId() =" + group.getParentGroupId());
                 
                 //int isDuplicateGroup = isDuplicateGroup(group.getName(), group.getParentId());
                 
                 //if(isDuplicateGroup == 0){
                     mysqlConn = getMySqlConnection();

                     StringBuilder updateQuery = new StringBuilder();
                     updateQuery.append("UPDATE groups g SET ");
                     updateQuery.append("g.Name = '").append(group.getName()).append("', ");
                     updateQuery.append("g.Description = '").append(group.getDescription()).append("', ");
                     updateQuery.append("g.Type = '").append(group.getType()).append("', ");
                     updateQuery.append("g.Parent_Id = '").append(group.getParentId()).append("', ");
                     updateQuery.append("g.Parent_Group_Id = '").append(group.getParentGroupId()).append("' ");
                     updateQuery.append("WHERE g.ID ='").append(group.getId()).append("' ");
                     
                     System.out.println("Update groups Query ::::::: "+updateQuery.toString());

                     st = mysqlConn.createStatement();

                     result = result + st.executeUpdate(updateQuery.toString());
                     
                     result = updateBpMapping(mysqlConn, group.getId(), group.getBpId(), group.getMappingId(), group.getWfVersion());

                     System.out.println("Update groups result :::::::::: "+result);
                 //}
                 //else if(isDuplicateGroup == 1){
                     //return 2; //Group already exist
                 //}
                 //else if(isDuplicateGroup == 2){
                     //return 3; //technical error
                 //}
                     
             }

         } 
         catch (Exception e) {
             // handle the exception
             e.printStackTrace();
             result = 0;
             //System.exit(1);
         } 
         finally {
             // release database resources
         	//oracleConn.close();
         	boolean closedResources = closeResources(mysqlConn, st, null);
         	if(!closedResources) {
         		result = 0;
         	}
         }

         return result;
     }
     
     public int updateGroup(Group group){

            // Connection oracleConn = null;
            Connection mysqlConn = null;
            Statement st = null;
            int result = 0;
            //ResultSet rs = null;
            try {

                if(group != null ){
                    
                    System.out.println("group.getName()          =" + group.getName());
                    System.out.println("group.getDescription()   =" + group.getDescription());
                    System.out.println("group.getType()          =" + group.getType());
                    System.out.println("group.getParentId()      =" + group.getParentId());
                    System.out.println("group.getParentGroupId() =" + group.getParentGroupId());
                    
                    //int isDuplicateGroup = isDuplicateGroup(group.getName(), group.getParentId());
                    
                    //if(isDuplicateGroup == 0){
                        mysqlConn = getMySqlConnection();

                        StringBuilder updateQuery = new StringBuilder();
                        updateQuery.append("UPDATE groups g, wf_bp_mapping m SET ");
                        updateQuery.append("g.Name = '").append(group.getName()).append("', ");
                        updateQuery.append("g.Description = '").append(group.getDescription()).append("', ");
                        updateQuery.append("g.Type = '").append(group.getType()).append("', ");
                        updateQuery.append("g.Parent_Id = '").append(group.getParentId()).append("', ");
                        updateQuery.append("g.Parent_Group_Id = '").append(group.getParentGroupId()).append("', ");
                        
                        updateQuery.append("m.datastore_name = '").append(group.getDatastoreName()).append("', ");
                        updateQuery.append("m.campaign_id = '").append(group.getCampaignMapping().getCampaignId()).append("', ");
                        updateQuery.append("m.mapping_id = '").append(group.getCampaignMapping().getMappingId()).append("' ");
                        
                        updateQuery.append("WHERE g.ID ='").append(group.getId()).append("' ");
                        updateQuery.append("AND m.process_id ='").append(group.getId()).append("' ");
                        
                        System.out.println("Update groups Query ::::::: "+updateQuery.toString());

                        st = mysqlConn.createStatement();

                        result = result + st.executeUpdate(updateQuery.toString());

                        System.out.println("Update groups result :::::::::: "+result);
                    //}
                    //else if(isDuplicateGroup == 1){
                        //return 2; //Group already exist
                    //}
                    //else if(isDuplicateGroup == 2){
                        //return 3; //technical error
                    //}
                        
                }

            } 
            catch (Exception e) {
                // handle the exception
                e.printStackTrace();
                result = 0;
                //System.exit(1);
            } 
            finally {
                // release database resources
            	//oracleConn.close();
            	boolean closedResources = closeResources(mysqlConn, st, null);
            	if(!closedResources) {
            		result = 0;
            	}
            }

            return result;
        }
     
     public Data getCampaignMappings(String processId){ 
         Connection mysqlConn = null;
         Statement st = null;
         //Data data = null;
         Data data = null;
         ResultSet rs = null;
         try{
             

             StringBuilder query = new StringBuilder();
             query.append("SELECT c.campaign_id, c.step_id, MAX(c.mapping_id) as mapping_id, c.bp_name, c.step_title, c.step_index, ");
             query.append("m.datastore_name, c.mapping_id = m.mapping_id as selected FROM wf_campaign c ");
             query.append("JOIN wf_bp_mapping m ON c.campaign_id = m.campaign_id ");
             query.append("WHERE m.process_id = '").append(processId).append("' AND c.deleted = 0 ");
             query.append("GROUP BY c.campaign_id, c.step_id");
             System.out.println("\n\n"+query.toString()+"\n\n");
             mysqlConn = getMySqlConnection();
             st = mysqlConn.createStatement();
             rs = st.executeQuery(query.toString());
             Map<String, Campaign> campaignsMap = new HashMap<>();
             Campaign campaign = null;
             CampaignMapping mapping = null;
             CampaignMapping selectedMapping = null;
             while(rs.next()){
             	String campaignId = rs.getString("campaign_id");
             	campaign = campaignsMap.get(campaignId);
             	if(campaign == null) {
             		campaign = new Campaign();
             		campaign.setId(campaignId);
             		campaign.setTitle(rs.getString("bp_name"));
             		campaignsMap.put(campaign.getId(), campaign);
             	}
             	mapping = new CampaignMapping();
             	mapping.setStepId(rs.getString("step_id"));
             	mapping.setStepTitle(rs.getString("step_title"));
             	mapping.setMappingId(rs.getString("mapping_id"));
             	mapping.setStepIndex(rs.getString("step_index"));
             	mapping.setDatastoreName(rs.getString("datastore_name"));
             	if(rs.getBoolean("selected")) {
             		selectedMapping = mapping;
             	}
             	campaign.getMappings().add(mapping);
             }
             
             List<Campaign> campaigns = new ArrayList<>();
             campaigns.addAll(campaignsMap.values());
             
             
             data = new Data();
             data.setCampaigns(campaigns);  
             data.setCampaignMapping(selectedMapping);
             
         }
         catch(Exception e){
             e.printStackTrace();
         }
         finally {
         	closeResources(mysqlConn, st, rs);
         } 

         return data;
     }
     
     public Data getCampaignMappings_2(long processId){ 
    	 
    	 VBrainStoredProcedure proc = null;
         Data data = new Data();
         ResultSet rs = null;
         try{
             
        	 proc = new VBrainStoredProcedure("select_bp_config_sp_2", String.valueOf(processId), true);
        	 rs = proc.getResultSet();
        	 
             if(rs.next()){
            	 data.setGroupID(processId);
            	 data.setBpId(rs.getLong("bp_id"));
            	 data.setCampaignId(rs.getLong("campaign_id"));
            	 data.setMappingId(rs.getLong("mapping_id"));
            	 data.setWfVersion(rs.getString("wf_version"));
             }
             
         }
         catch(Exception e){
             e.printStackTrace();
         }
         finally {
        	 if(proc != null) {
        		 proc.close();
        	 }
         } 

         return data;
     }
     
     public boolean checkCanDeleteGroup(long groupId) {
    	 
    	 boolean canDelete = false;
         Connection mysqlConn = null;
         Statement st = null;
         //Data data = null;
         ResultSet rs = null;
         try{
             

             StringBuilder query = new StringBuilder();
             query.append("SELECT CHECK_CAN_DELETE_GROUP_2(").append(groupId).append(") AS can_delete");
             System.out.println("\n\n"+query.toString()+"\n\n");
             mysqlConn = getMySqlConnection();
             st = mysqlConn.createStatement();
             rs = st.executeQuery(query.toString());
             if(rs.next()){
            	 canDelete = rs.getBoolean("can_delete");
             }
             
         }
         catch(Exception e){
             e.printStackTrace();
         }
         finally {
         	closeResources(mysqlConn, st, rs);
         } 

         return canDelete;
     
    	 
     }
     
     public boolean deleteGroup(long groupId) {
    	 
    	 boolean deleted = false;
         Connection mysqlConn = null;
         PreparedStatement st = null;
         //Data data = null;
         try{
             

             StringBuilder query = new StringBuilder();
             query.append("{CALL delete_group_sp_2(?)}");
             System.out.println("\n\n"+query.toString()+"\n\n");
             mysqlConn = getMySqlConnection();
             st = mysqlConn.prepareStatement(query.toString());
             st.setInt(1, (int) groupId);
             st.executeUpdate();
             deleted = true;
             
         }
         catch(Exception e){
             e.printStackTrace();
         }
         finally {
         	closeResources(mysqlConn, st, null);
         } 

         return deleted;
     
    	 
     }
     
     private List<String> childGroups;
     
     
        
     /**
     * @return the childGroups
     */
    public List<String> getChildGroups() {
        return childGroups;
    }
    
    /**
     * @param childGroups the childGroups to set
     */
    public void setChildGroups(List<String> childGroups) {
        this.childGroups = childGroups;
    }

        
        public int disableGroup(String groupId, String isDisabled){
            int count = 0;
            try{
                
                System.out.println("Enter into disableGroup ------------> "+groupId + "|"+isDisabled);
                
                if(isDisabled.equalsIgnoreCase("1") ){
                
                    getGroupsById(groupId);
                    
                    List<String> groupList = new ArrayList<String>();
                    
                    groupList.add(groupId);
                    
                    setChildGroups(groupList);
                    int isNext = 0;
                    
                    while(isNext == 0){
                        System.out.println("getChildGroups().size() -----------> "+getChildGroups().size());
                        boolean isChild = false;
                        List<String> tempList = new ArrayList<String>();
                        for(int i=0; i<getChildGroups().size(); i++){
                        
                            StringBuffer childGroup = getChildGroups(getChildGroups().get(i));
                            
                            if(childGroup.toString().length() > 0){
                                String[] childGroups = childGroup.toString().split(",");
                                for(int j=0; j<childGroups.length; j++){
                                    if(childGroups[j].length() > 0){
                                        groupList.add(childGroups[j]); 
                                        
                                        tempList.add(childGroups[j]);
                                        
                                        isChild = true;
                                    }
                                }
                            }
                            
                        }
                        
                        if(isChild){
                            setChildGroups(null);
                            setChildGroups(tempList);
                        }
                        else{
                            isNext = 1;
                            tempList = null;
                        }
                        
                    }
                    
                    
                    System.out.println("groupList.size() --------------> "+groupList.size());
                    
                    for(int i=0; i<groupList.size(); i++){
                        
                        String childGroupId = groupList.get(i);
                        
                        System.out.println("childGroupId --------------> "+childGroupId);
                        
                        if(childGroupId.length()  > 0){
                            count = count + disableOrEnableGroup(childGroupId, isDisabled);
                        }
                    }
                    
                    setAllGroups(null);
                }
                else {
                    count = disableOrEnableGroup(groupId, isDisabled);
                }
                
            }
            catch(Exception e){
                e.printStackTrace();
            }
            
            return count;
            
        }
       
     
        /**
         * 
         * @param groupId
         * @return
         */
        private int disableOrEnableGroup(String groupId, String isDisabled){

            // Connection oracleConn = null;
            Connection mysqlConn = null;
            Statement st = null;
            int result = 0;
            //ResultSet rs = null;
            try {

                if(groupId != null && groupId.trim().length() > 0){
                    
                    
                    
                    
                    String tQuery = "";
                
                    mysqlConn = getMySqlConnection();

                    tQuery = "Update groups "+
                             "SET isDisabled = '"+isDisabled+"' "+
                            " WHERE ID ='"+groupId+"' ";
                    
                    System.out.println("Update groups Query ::::::: "+tQuery);

                    st = mysqlConn.createStatement();

                    result = result + st.executeUpdate(tQuery);

                    System.out.println("Disable group result :::::::::: "+result);
                }

            } 
            catch (Exception e) {
                // handle the exception
                e.printStackTrace();
                result = 0;
                //System.exit(1);
            } 
            finally {
                // release database resources
            	//oracleConn.close();
            	boolean closedResources = closeResources(mysqlConn, st, null);
            	if(!closedResources) {
            		result = 0;
            	}
            }

            return result;
        }
        
        
        public Data getGroupUsers(String groupId){ 
            Connection mysqlConn = null;
            Statement st = null;
            //Data data = null;
            Data data = null;
            ResultSet rs = null;
            try{
                

                String sql = "SELECT u.id id, u.user_id userId, u.first_name firstName, u.last_name lastName, r.name roleName, g.name groupName, gu.id groupId "+
                             " FROM group_users gu, users u, groups g, role r "+ 
                             " where gu.group_id = '"+groupId+"' and gu.group_id = g.id and gu.user_id = u.id and r.id = u.role_id and u.isDisabled = '0' and r.isDisabled = '0' ";
                mysqlConn = getMySqlConnection();
                st = mysqlConn.createStatement();
                rs = st.executeQuery(sql);
                List<User> users = new ArrayList<User>();
                
                
                User user = null;
                while(rs.next()){
                    user = new User();
                    
                    System.out.println("userId in get groupUsers method : "+rs.getString("userId"));
                    
                    user.setId(rs.getString("id"));
                    user.setFirstName(rs.getString("firstName"));
                    user.setLastName(rs.getString("lastName"));
                    user.setUserId(rs.getString("userId"));
                    user.setRole(rs.getString("roleName"));
                    
                    users.add(user);
                }
                
                Group group = new Group();
                group.setUsers(users); 
                
                data = new Data();
                data.setGroup(group);  
                
            }
            catch(Exception e){
                e.printStackTrace();
            }
            finally {
            	closeResources(mysqlConn, st, rs);
            } 

            return data;
        }
        
        
        public Data getUsers(String groupId){ 
            Connection mysqlConn = null;
            Statement st = null;
            //Data data = null;
            Data data = null;
            ResultSet rs = null;
            try{
                

                String sql = "SELECT u.id id, u.user_id userId, u.first_name firstName, u.last_name lastName, r.name roleName FROM users u, role r where r.id = u.role_id and u.isDisabled = '0' and r.isDisabled = '0' and u.id not in (select user_id from group_users where group_id = '"+groupId+"')";
                mysqlConn = getMySqlConnection();
                st = mysqlConn.createStatement();
                rs = st.executeQuery(sql);
                List<User> users = new ArrayList<User>();
                
                
                User user = null;
                while(rs.next()){
                    user = new User();
                    
                    System.out.println("userId in get groupUsers method : "+rs.getString("userId"));
                    
                    user.setId(rs.getString("id"));
                    user.setUserId(rs.getString("userId"));
                    user.setFirstName(rs.getString("firstName"));
                    user.setLastName(rs.getString("lastName"));
                    user.setRole(rs.getString("roleName"));
                    
                    users.add(user);
                }
                
                Group group = new Group();
                group.setUsers(users); 
                
                data = new Data();
                data.setGroup(group);  
                
            }
            catch(Exception e){
                e.printStackTrace();
            }
            finally {
            	closeResources(mysqlConn, st, rs);
            } 

            return data;
        }
        
        
        public int addGroupUser(String userId, String groupId){

            // Connection oracleConn = null;
            Connection mysqlConn = null;
            Statement st = null;
            int result = 0;
            //ResultSet rs = null;
            try {

                if(userId != null && groupId != null ){
                    
                
                    String tQuery = "";

                    System.out.println("userId    =" + userId);
                    System.out.println("groupId   =" + groupId);
                    
                    int isDuplicateGroup = isDuplicateGroupUser(groupId, userId);
                    
                    if(isDuplicateGroup == 0){
                        mysqlConn = getMySqlConnection();

                        tQuery = "INSERT INTO group_users "+
                                "(group_id, user_id ) "+
                                "VALUES (" +
                                " '"+groupId+"', "+
                                " '"+userId+"' )";
                        
                        System.out.println("tQuery ::::::: "+tQuery);

                        st = mysqlConn.createStatement();

                        result = st.executeUpdate(tQuery);

                        System.out.println("Add Group Users result :::::::::: "+result);
                    }
                    else if(isDuplicateGroup == 1){
                        return 2; //Group already exist
                    }
                    else if(isDuplicateGroup == 2){
                        return 3; //technical error
                    }
                }

            } 
            catch (Exception e) {
                // handle the exception
                e.printStackTrace();
                result = 0;
                //System.exit(1);
            } 
            finally {
                // release database resources
            	//oracleConn.close();
            	boolean closedResources = closeResources(mysqlConn, st, null);
            	if(!closedResources) {
            		result = 0;
            	}
            }

            return result;
        }
        
        
        public int deleteGroupUser(String userId, String groupId){

            // Connection oracleConn = null;
            Connection mysqlConn = null;
            Statement st = null;
            int result = 0;
            //ResultSet rs = null;
            try {

                if(userId != null && groupId != null ){
                    
                
                    String tQuery = "";

                    System.out.println("userId    =" + userId);
                    System.out.println("groupId   =" + groupId);
                    
                    
                    mysqlConn = getMySqlConnection();

                    tQuery = "DELETE from group_users "+
                            " where "+
                            " group_id = '"+groupId+"' and user_id = '"+userId+"' ";
                    
                    System.out.println("tQuery ::::::: "+tQuery);

                    st = mysqlConn.createStatement();

                    result = st.executeUpdate(tQuery);

                    System.out.println("Delete Group Users result :::::::::: "+result);
                }

            } 
            catch (Exception e) {
                // handle the exception
                e.printStackTrace();
                result = 0;
                //System.exit(1);
            } 
            finally {
                // release database resources
            	//oracleConn.close();
            	boolean closedResources = closeResources(mysqlConn, st, null);
            	if(!closedResources) {
            		result = 0;
            	}
            }

            return result;
        }
        
        private StringBuffer getChildGroups(String parentId){
            
            StringBuffer pathIfo = new StringBuffer();
            try{
                List<Group> groups = getAllGroups();
                
                
                for(int i=0; i<groups.size(); i++){
                    Group group = groups.get(i);
                    
                    if( parentId.equalsIgnoreCase(group.getParentId()) ){
                        pathIfo.append(group.getId() + ",");
                    }
                }
                
                
            }
            catch (Exception e){
                e.printStackTrace();
            }
            return pathIfo;
        }
        
        
        private void getGroupsById(String groupId){
            Connection mysqlConn = null;
            Statement st = null;
            //Data data = null;
            
            ResultSet rs = null;
            List<Group> groups = null;
            try{
                

                //String sql =  "SELECT * FROM groups where isDisabled = '0' order by parent_id desc";
                String sql =    "SELECT * FROM groups where id >= '"+groupId+"' order by id";
                System.out.println("sql : "+sql);
                
                mysqlConn = getMySqlConnection();
                st = mysqlConn.createStatement();
                rs = st.executeQuery(sql);
                groups = new ArrayList<Group>();
                Group group = null;
                
                while(rs.next()){
                    group = new Group();
                    
                    group.setId(rs.getString("id"));
                    group.setParentId(rs.getString("parent_id"));
                    /*
                    group.setName(rs.getString("name"));
                    group.setDescription(rs.getString("description"));
                    group.setType(rs.getString("type"));
                    */
                    
                    groups.add(group);
                }
                
                setAllGroups(groups);
                
                
            }
            catch(Exception e){
                e.printStackTrace();
            }
            finally {
            	closeResources(mysqlConn, st, rs);
            } 

            
        }
        
     
}
