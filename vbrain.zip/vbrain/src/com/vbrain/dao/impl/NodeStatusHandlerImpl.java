/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vbrain.dao.impl;

import com.vbrain.adapter.CommonDbAdapter;
import com.vbrain.adapter.impl.CommonDbAdapterImpl;
import com.vbrain.common.api.ApiManager;
import com.vbrain.common.util.ConfigNameExtractor;
import com.vbrain.common.util.Converters;
import com.vbrain.common.util.EmailManager;
import com.vbrain.common.util.WFEmail;
import com.vbrain.dao.NodeStatusHandler;
import com.vbrain.hibernate.model.Email;
import com.vbrain.hibernate.model.EmailStatus;
import com.vbrain.hibernate.model.Hubs;
import com.vbrain.hibernate.model.Status;
import com.vbrain.hibernate.model.Nodes;
import com.vbrain.nodemonitor.NodeStatusApiReader;
import com.vbrain.nodemonitor.model.Statuses;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author llihind
 */
public class NodeStatusHandlerImpl implements NodeStatusHandler {

    private CommonDbAdapter dbAdapter;

    public NodeStatusHandlerImpl() {
        dbAdapter = new CommonDbAdapterImpl();
    }

    @Override
    public boolean updateNodeStatus(Nodes node, String status) {
        try {

            //Retreave node status object
            HashMap subFilters = new HashMap();
            subFilters.put("status", status);
            Status statusToSet = (Status) dbAdapter.readDataObjfromTable(Status.class, subFilters);

            node.setStatus(statusToSet);

            dbAdapter.updateDataOnTable(node);
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    @Override
    public String getNodeStatus(String node, String hub) {
        //Setting Filters
        HashMap filters = new HashMap();
        filters.put("nodeName", node);

        try {
            Nodes filteredNode = (Nodes) dbAdapter.readDataObjfromTable(Nodes.class, filters);
            return filteredNode.getStatus().getStatus();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return Statuses.NOSTATUS.toString();
    }

    public Hubs getHub(String hub) {
        HashMap filters = new HashMap();
        Hubs currentHub = new Hubs();

        try {
            //Filtering current hub
            filters.put("hubName", hub);
            currentHub = (Hubs) dbAdapter.readDataObjfromTable(Hubs.class, filters);

            return currentHub;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return currentHub;
    }

    @Override
    public List<Nodes> getNodesList(String hub) {
        List<Nodes> nodesList = new ArrayList();
        //Map for filters
        HashMap<String, Hubs> filters = new HashMap();

        try {
            Hubs currentHub = getHub(hub);

            filters.put("hubs", currentHub);
            nodesList = dbAdapter.readDataListfromTable(Nodes.class, filters);
            return nodesList;

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return nodesList;
    }

    @Override
    public List<Hubs> getHubsList() {
        List<Hubs> hubsList = new ArrayList();

        try {

            hubsList = dbAdapter.readDataListfromTable(Hubs.class, Collections.emptyMap());
            return hubsList;

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return hubsList;
    }

    public boolean updateHubStatus(Hubs hub, String status) {
        try {

            //Retreave node status object
            HashMap subFilters = new HashMap();
            subFilters.put("status", status);
            Status statusToSet = (Status) dbAdapter.readDataObjfromTable(Status.class, subFilters);

            hub.setStatus(statusToSet);

            dbAdapter.updateDataOnTable(hub);
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    @Override
    public void handleNodeStatus(String hub) throws Exception {
        List<Nodes> nodeList = getNodesList(hub);
        boolean isAllNodesUp = true;

        Hubs currentHub = getHub(hub);
        int expectedNodeCount = nodeList.size();
        int returnedNodeCount = readNodeCount(currentHub.getUrl());

        //Updating status of nodes
        Vector availableNodes = readAvailableNodes(currentHub.getUrl());

        System.out.println("Available Nodes : " + availableNodes);
        for (Nodes node : nodeList) {
            if (!availableNodes.contains(node.getNodeName())) {
                isAllNodesUp = false;
                if (!updateNodeStatus(node, Statuses.INACTIVE.toString())) {
                    throw new Exception("Node status update failed");
                }

            } else {
                if (!updateNodeStatus(node, Statuses.ACTIVE.toString())) {
                    throw new Exception("Node status update failed");
                }
            }
        }

        //Updating status of hub
        if (expectedNodeCount < returnedNodeCount) {
            //Preparing and sending email out
            EmailStatus emailStatus = (EmailStatus) dbAdapter.readDataObjfromTable(EmailStatus.class, Collections.emptyMap());
            if (emailStatus.isStatus()) {
                if (currentHub.isEmailState()) {
                    Logger log = LoggerFactory.getLogger(NodeStatusHandlerImpl.class);
                    List<Email> emailClients = dbAdapter.readDataListfromTable(Email.class, Collections.emptyMap());
                    String[] to = Converters.converterEmailList("to", emailClients);
                    String[] cc = Converters.converterEmailList("cc", emailClients);
                    currentHub = getHub(hub);
                    nodeList = getNodesList(hub);
                    WFEmail email = new WFEmail(log, to, cc, "WARNING : Hub Upgrade Detected", EmailManager.getStatusEmailBody(nodeList, currentHub.getHubName(), currentHub.getServers().getServerName(), "Expected node count for this hub appears to be changed (Possible reason : hub upgrade...). Please check the indicated hub and resync.", "upgrade"), WFEmail.HIGH_IMPORTANCE);
                    email.sendHTML();
                }

                currentHub.setEmailState(false);
                dbAdapter.updateDataOnTable(currentHub);
            }

            if (!updateHubStatus(currentHub, Statuses.UPGRADED.toString())) {
                throw new Exception("Hub status update failed");
            }
        } else {
            if (isAllNodesUp) {
                if (readQueuedNodes(currentHub.getUrl())) {
                    //Preparing and sending email out
                    EmailStatus emailStatus = (EmailStatus) dbAdapter.readDataObjfromTable(EmailStatus.class, Collections.emptyMap());
                    if (emailStatus.isStatus()) {
                        if (currentHub.isEmailState()) {
                            Logger log = LoggerFactory.getLogger(NodeStatusHandlerImpl.class);
                            List<Email> emailClients = dbAdapter.readDataListfromTable(Email.class, Collections.emptyMap());
                            String[] to = Converters.converterEmailList("to", emailClients);
                            String[] cc = Converters.converterEmailList("cc", emailClients);
                            currentHub = getHub(hub);
                            nodeList = getNodesList(hub);
                            WFEmail email = new WFEmail(log, to, cc, "WARNING : Hub Queue Detected", EmailManager.getStatusEmailBody(nodeList, currentHub.getHubName(), currentHub.getServers().getServerName(), " Node monitor has detected potencial queue of requests in the hub.", "queue"), WFEmail.HIGH_IMPORTANCE);
                            email.sendHTML();
                        }

                        currentHub.setEmailState(false);
                        dbAdapter.updateDataOnTable(currentHub);
                    }
                    if (!updateHubStatus(currentHub, Statuses.QUEUED.toString())) {
                        throw new Exception("Hub status update failed");
                    }
                } else {
                    //Setting email state back to normal
                    currentHub.setEmailState(true);
                    dbAdapter.updateDataOnTable(currentHub);
                    
                    if (!updateHubStatus(currentHub, Statuses.HEALTHY.toString())) {
                        throw new Exception("Hub status update failed");
                    }
                }
            } else {
                currentHub = getHub(hub);

                //Preparing and sending email out
                EmailStatus emailStatus = (EmailStatus) dbAdapter.readDataObjfromTable(EmailStatus.class, Collections.emptyMap());
                if (emailStatus.isStatus()) {
                    if (currentHub.isEmailState()) {
                        Logger log = LoggerFactory.getLogger(NodeStatusHandlerImpl.class);
                        List<Email> emailClients = dbAdapter.readDataListfromTable(Email.class, Collections.emptyMap());
                        String[] to = Converters.converterEmailList("to", emailClients);
                        String[] cc = Converters.converterEmailList("cc", emailClients);
                        nodeList = getNodesList(hub);
                        WFEmail email = new WFEmail(log, to, cc, "WARNING : Hub Status Failure Detected", EmailManager.getStatusEmailBody(nodeList, currentHub.getHubName(), currentHub.getServers().getServerName()), WFEmail.HIGH_IMPORTANCE);
                        email.sendHTML();
                    }

                    currentHub.setEmailState(false);
                    dbAdapter.updateDataOnTable(currentHub);
                }

                if (!updateHubStatus(currentHub, Statuses.WEAK.toString())) {
                    throw new Exception("Hub status update failed");
                }
            }
        }

    }

    private int readNodeCount(String url) {
        ApiManager apiManager = new ApiManager(new NodeStatusApiReader());

        try {
            String output = apiManager.executeCall(url);

            Document doc = Jsoup.parse(output);

            Elements eles = doc.getElementsByClass("content");

            return eles.size();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return 0;
    }

    public Vector readAvailableNodes(String url) {
        Vector availableNodes = new Vector();

        ApiManager apiManager = new ApiManager(new NodeStatusApiReader());

        try {
            String output = apiManager.executeCall(url);

            Document doc = Jsoup.parse(output);

            Elements eles = doc.getElementsByClass("content");

            for (Element ele : eles) {
                String node = ConfigNameExtractor.compileNodeName(ele.select("p:contains(nodeConfig)").text());

                availableNodes.add(node);
            }
            return availableNodes;
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return availableNodes;
    }

    public List<com.vbrain.nodemonitor.model.Nodes> readNodeObjects(String url) {
        List<com.vbrain.nodemonitor.model.Nodes> availableNodes = new ArrayList();

        ApiManager apiManager = new ApiManager(new NodeStatusApiReader());

        try {
            String output = apiManager.executeCall(url);

            Document doc = Jsoup.parse(output);

            Elements eles = doc.getElementsByClass("content");

            for (Element ele : eles) {
                String nodeName = ConfigNameExtractor.compileNodeName(ele.select("p:contains(nodeConfig)").text());
                String nodeUrl = ConfigNameExtractor.compileServerUrl(url) + ConfigNameExtractor.compileLastPort(ele.select("p:contains(port)").text());

                com.vbrain.nodemonitor.model.Nodes node = new com.vbrain.nodemonitor.model.Nodes(nodeName, "", nodeUrl);

                availableNodes.add(node);
            }
            return availableNodes;
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return availableNodes;
    }

    public boolean readQueuedNodes(String url) {
        boolean isQueued = false;

        ApiManager apiManager = new ApiManager(new NodeStatusApiReader());

        try {
            String output = apiManager.executeCall(url);

            Document doc = Jsoup.parse(output);

            Elements eles = doc.select("div:contains(requests waiting for a slot)");

            if (!eles.isEmpty()) {
                isQueued = true;
            }

            return isQueued;
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return isQueued;
    }
    
    @Override
    public CommonDbAdapter getDbAdapter() {
		return dbAdapter;
	}

    @Override
    public void finalizeHandler() {
        dbAdapter.getSession().clear();
        dbAdapter.getSession().close();
    }

}
