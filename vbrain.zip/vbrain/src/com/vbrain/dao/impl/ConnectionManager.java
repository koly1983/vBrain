package com.vbrain.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.vbrain.adapter.TPSAdapter;
import com.vbrain.adapter.impl.TPSAdapterImpl;
import com.vbrain.common.util.SlaBreachNotifier;
import com.vbrain.dao.impl.ImportImpl.ImportEntity;
import com.vbrain.dao.impl.ImportImpl.WfVersion;
import com.vbrain.db.connection.PostgresDbManager;
import com.vbrain.db.connection.VBrainDbManager;
import com.vbrain.db.connection.WfDbManager;


public class ConnectionManager implements Job{

	private static boolean isRunning = false;

	public void updateDataBase() {
		if(isRunning) {
			return;
		}

		isRunning = true;

		ResultSet rsObj = null;
		ResultSet rsObjForCampaigns = null;

		Connection connObjVb = null;
		Connection connObjWf = null;
		Connection connObjPostgres = null;

		PreparedStatement pstmtObjForCampaignData = null;
		PreparedStatement pstmtObjFordatetime = null;
		PreparedStatement pstmtObjForinsert = null;

		PreparedStatement transactionDateSP = null;
		PreparedStatement datastoreDateSP = null;
		PreparedStatement promoteTransactionsSPobj = null;

		DateTime lastrecordtime = null;
		long lastrecordtime_datastore = 0L;

		WfDbManager wfmgr = new WfDbManager();
		VBrainDbManager vbrainmgr = new VBrainDbManager();
		PostgresDbManager postgressmgr = new PostgresDbManager();


		
		
		try {

			DataSource dataSourceVB = vbrainmgr.setUpPool();
			DataSource dataSourceWF = wfmgr.setUpPool();
			DataSource dataSourcePostgres = postgressmgr.setUpPool();

			// Performing Database Operation!
			System.out.println("\n=====Making A New Connection Object For Db Transaction=====\n");
			try {
				connObjVb = dataSourceVB.getConnection();
			} catch(Exception e) {
				System.out.println("Failed at dataSourceVB ");
			}

			// select last execution time from the vBrain- wf- config table
			pstmtObjFordatetime = selectLastRecordDatetime(connObjVb);
			rsObj = pstmtObjFordatetime.executeQuery();

			if (rsObj.next()) {
				lastrecordtime = convertToStandardTime(rsObj.getObject("LASTRECORD_TIMESTAMP").toString());

				lastrecordtime_datastore = rsObj.getLong("LASTRECORD_TIMESTAMP_DATASTORE");
			} else if (lastrecordtime == null) {
				lastrecordtime = DateTime.now();
			}

			List<String> mappingIdList = getEnabledBpMappings(connObjVb);

			try {
				connObjWf = dataSourceWF.getConnection();
			} catch(Exception e) {
				System.out.println("Failed at dataSourceWF ");
			}
			// Select Bp Related data from vbrain tables
			pstmtObjForCampaignData = selectCampaignData(connObjWf, lastrecordtime, mappingIdList);
			rsObjForCampaigns = pstmtObjForCampaignData.executeQuery();
			pstmtObjForinsert = insertTempTransactions(connObjVb);

			while (rsObjForCampaigns.next()) {
				pstmtObjForinsert = convertCompaignData(pstmtObjForinsert, rsObjForCampaigns);
				pstmtObjForinsert.addBatch();
			}

			pstmtObjForinsert.executeBatch();
			if (connObjWf != null) {
				connObjWf.close();
			}

			// Update the last updated date from temp transactions
			String transactionDateSPQuery = "{CALL update_lastrecord_transaction_sp()}";
			System.out.println("ConnectionManager : " + transactionDateSPQuery);
			transactionDateSP = connObjVb.prepareStatement(transactionDateSPQuery);
			transactionDateSP.executeUpdate();

			try {
				connObjPostgres = dataSourcePostgres.getConnection();
			} catch(Exception e) {
				System.out.println("Failed at dataSourcePostgres ");
			}
			// DB update for Transaction table for TPS process.
			TPSAdapter tpsAdapter = new TPSAdapterImpl();
			tpsAdapter.updateVbrainData(connObjVb, connObjPostgres, lastrecordtime_datastore);

			if (connObjPostgres != null) {
				connObjPostgres.close();
			}

			// Update the last updated date from temp datastore
			String datastoreDateSPQuery = "{CALL update_lastrecord_datastore_sp()}";
			System.out.println("ConnectionManager : " + datastoreDateSPQuery);
			datastoreDateSP = connObjVb.prepareStatement(datastoreDateSPQuery);
			datastoreDateSP.executeUpdate();

			// Map the temp transactions and temp datastore data and promote to transactions table
			String promoteTransactionsSP = "{CALL update_transactions_sp()}";
			System.out.println("ConnectionManager : " + promoteTransactionsSP);
			promoteTransactionsSPobj = connObjVb.prepareStatement(promoteTransactionsSP);
			promoteTransactionsSPobj.executeUpdate();

			System.out.println("\n=====Releasing Connection Object To Pool=====\n");

		} catch (Exception sqlException) {
			sqlException.printStackTrace();
		} finally {
			isRunning = false;
			try {		       
				// Closing ResultSet Object
				if (rsObj != null) {
					rsObj.close();
				}
				if (rsObjForCampaigns != null) {
					rsObjForCampaigns.close();
				}
				// Closing PreparedStatement Object
				if (pstmtObjForCampaignData != null) {
					pstmtObjForCampaignData.close();
				}
				if (pstmtObjFordatetime != null) {
					pstmtObjFordatetime.close();
				}
				if (pstmtObjForinsert != null) {
					pstmtObjForinsert.close();
				}
				if (transactionDateSP != null) {
					transactionDateSP.close();
				}
				if (datastoreDateSP != null) {
					datastoreDateSP.close();
				}
				if (promoteTransactionsSPobj != null) {
					promoteTransactionsSPobj.close();
				}
				// Closing Connection Object
				if (connObjWf != null) {
					connObjWf.close();
				}
				if (connObjVb != null) {
					connObjVb.close();
				}
				if (connObjPostgres != null) {
					connObjPostgres.close();
				}
			} catch (Exception sqlException) {
				sqlException.printStackTrace();
			}
		}

	}

	private List<String> getEnabledBpMappings(Connection connObjVb) {
		List<String> mappingList = new ArrayList<>();
		PreparedStatement pstmtObjForProcesses = null;

		ResultSet rsObjforProcesses = null;
		try {
			pstmtObjForProcesses = selectAllEnabledProcess(connObjVb);
			rsObjforProcesses = pstmtObjForProcesses.executeQuery();
			while (rsObjforProcesses.next()) {
				mappingList.add(rsObjforProcesses.getString("mapping_id"));
			}
		} catch (Exception sqlException) {
			sqlException.printStackTrace();
		} finally {
			try {
				// Closing ResultSet Object
				if (rsObjforProcesses != null) {
					rsObjforProcesses.close();
				}
				// Closing PreparedStatement Object
				if (pstmtObjForProcesses != null) {
					pstmtObjForProcesses.close();
				}
			} catch (Exception sqlException) {
				sqlException.printStackTrace();
			}
		}
		return mappingList;
	}


	private PreparedStatement selectAllEnabledProcess(Connection con) throws SQLException {
		String selectProcesses = "SELECT m.mapping_id as mapping_id FROM vbrain.wf_bp_mapping m"
				+ " JOIN vbrain.groups p ON m.process_id = p.id"
				+ " WHERE p.isDisabled = 0";
		System.out.println("ConnectionManager : " + selectProcesses);
		PreparedStatement insertObj = con.prepareStatement(selectProcesses);
		return insertObj;
	}

	private DateTime convertToStandardTime(String datetime) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		Date coverteddatewithseconds = formatter.parse(datetime);
		String converttosimpledateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(coverteddatewithseconds);
		DateTimeFormatter formatters = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
		DateTime converteddatetimeobj = formatters.parseDateTime(converttosimpledateformat);
		return converteddatetimeobj;
	}

	private PreparedStatement insertTempTransactions(Connection con) throws SQLException {
		String inserttemptranasactiondata = "INSERT INTO vbrain.wf_temp_transactions(" + "STATUS," + "TITLE,"
				+ "BP_NAME," + "START_TIME," + "END_TIME," + "DESCRIPTION ,"+ "BP_UUID,"+ "campaign_id)" + "VALUES(?,?,?,?,?,?,?,?)";
		System.out.println("ConnectionManager : " + inserttemptranasactiondata);
		PreparedStatement inserttempObj = con.prepareStatement(inserttemptranasactiondata);
		return inserttempObj;
	}

	private PreparedStatement selectLastRecordDatetime(Connection con) throws SQLException {
		String selecttimestamp = "SELECT IFNULL(LASTRECORD_TIMESTAMP, from_unixtime(0)) as LASTRECORD_TIMESTAMP, IFNULL(LASTRECORD_TIMESTAMP_DATASTORE, 0) as LASTRECORD_TIMESTAMP_DATASTORE FROM vbrain.wf_configuration";
		System.out.println("ConnectionManager : " + selecttimestamp);
		PreparedStatement insertObj = con.prepareStatement(selecttimestamp);
		return insertObj;
	}

	private PreparedStatement selectCampaignData(Connection con, DateTime lastrecordtime, List<String> mappingIdList) throws SQLException {
		String selectcampagindaata = "select r.title as stepTitle\r\n"
				+ ", ah.submissionDate as hit_submissionDate\r\n" + ", r.startDate as step_startDate\r\n"
				+ ", r.campaign_id as campaign_id\r\n"
				+ ", r.rootRunUUID as bp_instance_uuid\r\n" + ", ah.completionDate as hit_completionDate\r\n"
				+ ",r.hasProcessingIssues as status \r\n" + "from wfdb.Run r \r\n"
				+ "join AwsHit ah on ah.run_id = r.id\r\n" 
				+ "where  ah.submissionDate >'"
				+ lastrecordtime + "'\r\n" 
				+ "AND (r.status='COMPLETED' OR r.hasProcessingIssues = 1)\r\n";
		if(mappingIdList != null && !mappingIdList.isEmpty()) {
			selectcampagindaata = selectcampagindaata + " AND r.campaignMap_id IN (";
			selectcampagindaata = selectcampagindaata + String.join(",", mappingIdList);
			selectcampagindaata = selectcampagindaata + ") ";
		}
		selectcampagindaata = selectcampagindaata + "Order by ah.submissionDate";
		System.out.println("ConnectionManager : " + selectcampagindaata);
		PreparedStatement insertObj = con.prepareStatement(selectcampagindaata);
		return insertObj;
	}

	private PreparedStatement convertCompaignData(PreparedStatement insertObjforCampaign, ResultSet rsObjforCampaign)
			throws SQLException, ParseException {
		insertObjforCampaign.setString(1, rsObjforCampaign.getString("status"));
		insertObjforCampaign.setString(2, rsObjforCampaign.getString("stepTitle"));
		insertObjforCampaign.setString(3, null);//TODO: Need to change this
		insertObjforCampaign.setString(4, rsObjforCampaign.getString("hit_submissionDate"));
		insertObjforCampaign.setString(5, rsObjforCampaign.getString("hit_completionDate"));
		insertObjforCampaign.setString(6, rsObjforCampaign.getString("stepTitle"));
		insertObjforCampaign.setString(7, rsObjforCampaign.getString("bp_instance_uuid"));
		insertObjforCampaign.setString(8, rsObjforCampaign.getString("campaign_id"));

		return insertObjforCampaign;
	}

	/**
	 * Method triggered with scheduler.
	 * 
	 */
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		ConnectionManager connectionManager = new ConnectionManager();
		//connectionManager.updateDataBase();
		connectionManager.updateDataBase2();
	}

	public void updateDataBase2() {
		if (isRunning) {
			return;
		}

		isRunning = true;

		ImportImpl wfTrans = new ImportImpl(ImportEntity.TRANSACTION);
		wfTrans.execute();

		ImportImpl wfDatastore = new ImportImpl(ImportEntity.DATASTORE);
		wfDatastore.execute();

		VBrainStoredProcedure.execute("update_transactions_sp_2", null);

		// Import Snapshot of running BPs
		ImportImpl wfSnapshot = new ImportImpl(ImportEntity.SNAPSHOT);
		wfSnapshot.execute();

		// Importing data from 8.2 version
		try {
			ImportImpl wf82Trans = new ImportImpl(ImportEntity.TRANSACTION, WfVersion.WF82);
			wf82Trans.execute();

			ImportImpl wf82Datastore = new ImportImpl(ImportEntity.DATASTORE, WfVersion.WF82);
			wf82Datastore.execute();

			VBrainStoredProcedure.execute("82_update_transactions_sp_2", null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Importing data from 8.4 Prod 2
		try {
			ImportImpl wf84Prod2Trans = new ImportImpl(ImportEntity.TRANSACTION, WfVersion.WF84P2);
			wf84Prod2Trans.execute();

			ImportImpl wf84Prod2Datastore = new ImportImpl(ImportEntity.DATASTORE, WfVersion.WF84P2);
			wf84Prod2Datastore.execute();

			VBrainStoredProcedure.execute("84Prod2_update_transactions_sp_2", null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		VBrainStoredProcedure nacc = null;
		VBrainStoredProcedure rami = null;
		VBrainStoredProcedure email = null;

		try {
			String emailAddress= null;
			email = new VBrainStoredProcedure("email_address_getter",(String)null,true);
			ResultSet emailResults = email.getResultSet();
			if(emailResults.next()) {
				emailAddress = emailResults.getString("email_address");
				System.out.println("Notifying SLA Breached status to Email Address"+emailAddress);
			}
			
			nacc = new VBrainStoredProcedure("update_naccc_sla_breached_records", (String)null, true);
			ResultSet nacccSlaBreachedResults = nacc.getResultSet();
			System.out.println("Naccc Result set is "+nacccSlaBreachedResults);
			if(nacccSlaBreachedResults != null) {
				SlaBreachNotifier nacciNotifier = new SlaBreachNotifier(nacccSlaBreachedResults);
				nacciNotifier.notifyToSupportTeam(emailAddress);
			}
			
			rami = new VBrainStoredProcedure("update_rami_sla_breached_records", (String)null, true);
			ResultSet ramiSlaBreachedResults = rami.getResultSet();
			System.out.println(" Rami Result set is "+ramiSlaBreachedResults);
			if(ramiSlaBreachedResults != null) {
				SlaBreachNotifier ramiNotifier = new SlaBreachNotifier(ramiSlaBreachedResults);
				ramiNotifier.notifyToSupportTeam(emailAddress);
			}
		}
		catch(Exception ex) {
			System.out.println("Failed in SLA Breached transaction notifying process");
			ex.printStackTrace();
		} 
		finally {
			if(nacc != null) {
				nacc.close();
			}
			if(rami != null) {
				rami.close();
			}
			if(email != null) {
				email.close();
			}

		}

		isRunning = false;
	}
}