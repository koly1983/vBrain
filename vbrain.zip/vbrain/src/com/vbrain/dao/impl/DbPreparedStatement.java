package com.vbrain.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DbPreparedStatement {
	private PreparedStatement stmt = null;
	private boolean firstTime = true;

	public DbPreparedStatement(PreparedStatement stmt) {
		this.stmt = stmt;
		try {
			stmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
			stmt = null;
		}
	}
	
	public ResultSet nextResultSet() {
		if(stmt == null) 
			return null;
		
		try {
			boolean hasResults = false;
			if(firstTime) {
				firstTime = false;
				hasResults = true;
			} else {
				hasResults = stmt.getMoreResults();
			}
			
			return hasResults ? stmt.getResultSet() : null;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public void close() {
		try {
			if (stmt != null) {
				stmt.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
