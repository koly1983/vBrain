package com.vbrain.dao.impl;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.axis.utils.StringUtils;

public class DynamicQueryProcedure extends DbStoredProcedure{

	private String queryString; 
	
	private DbTable destTable;
	
	public DynamicQueryProcedure(String name, List<String> params) {
		super(name, params);
	}
	
	public DynamicQueryProcedure(String name, String param) {
		super(name, param);
	}
	
	public String getQueryString() {
		if(StringUtils.isEmpty(queryString)) 
			queryString = "SELECT NULL LIMIT 0";
		return queryString;
	}

	public DbTable getDestTable() {
		return destTable;
	}

	@Override
	public void execute(DbConnection conn) {
		ResultSet rsObjQE = null;
		List<String> pullQueries = new ArrayList<>();

		try {
			// Get query elements from db
			DbPreparedStatement stmt = conn.prepareStatement(getCallStatement());
			// Execute the CALL statement and expecting multiple result sets
			rsObjQE = stmt.nextResultSet();

			while (rsObjQE != null) {
				
				// Next ResultSet object
				String subQuery = getQuery(rsObjQE);
				if (subQuery != null) {
					pullQueries.add(subQuery);
				}
				
				conn.closeResultSet(rsObjQE, false);
				rsObjQE = stmt.nextResultSet();
			}
			stmt.close();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			conn.closeResultSet(rsObjQE, true);
		}

		if (!pullQueries.isEmpty()) {
			if(pullQueries.size() > 1) {
				queryString = pullQueries.stream().map(p -> "(" + p + ")").collect(Collectors.joining(" UNION ALL "));
			} else {
				queryString = pullQueries.get(0);
			}
		}
	}

	private String getQuery(ResultSet rsObjQE) {
		boolean validQuery = true;

		List<String> s = new ArrayList<>();
		String f = null;
		List<String> j = new ArrayList<>();
		List<String> lj = new ArrayList<>();
		List<String> rj = new ArrayList<>();
		String w = null;
		List<String> o = new ArrayList<>();
		String l = null;

		String destTableName = null;
		boolean ii = false;
		List<DbTableField> destFields = new ArrayList<>();

		try {
			while (rsObjQE.next()) {
				String t = rsObjQE.getString("QT");
				String e = rsObjQE.getString("QE");
				if(e == null) {
					continue;
				}
				String[] arr = e.split("\\|");

				if (t.equals("S")) {
					if (arr.length == 3) {
						if (!StringUtils.isEmpty(arr[0]))
							s.add(arr[0] + "." + arr[1] + " AS " + arr[2]);
						else
							s.add(arr[1] + " AS " + arr[2]);
						destFields.add(new DbTableField(arr[2]));
					}
				} else if (t.equals("F")) {
					if (arr.length > 0){
						f = arr[0];
						if(f.contains(" ")) {
							String[] tbl = f.split(" ");
							f = tbl[0] + " AS " + tbl[1];
						}
						int i = 1;
						while(arr.length > i + 1) {
							String[] condition = arr[i+1].split(",");
							String[] tbl = arr[i].split(" ");
							
							if(tbl.length != 2 || condition.length < 2) {
								f = null;
								j.clear();
								break;
							}
							String jt = "j";
							if(condition.length == 3) {
								jt = condition[2];
							}
							String jc = tbl[0] + " AS " + tbl[1] + " ON " + condition[0] + " = " + condition[1];
							
							if(jt.equals("j"))
								j.add(jc);
							else if(jt.equals("lj"))
								lj.add(jc);
							else if(jt.equals("rj"))
								rj.add(jc);
		
							i+=2;
						}
						
					}
				} else if (t.equals("J") || t.equals("LJ") || t.equals("RJ")) {
					if (arr.length == 5) {
						String op = arr[2];
						
						String jTbl = arr[0];
						String jA = arr[0];
						if(jTbl.contains(" ")) {
							String[] tbl = jTbl.split(" ");
							jTbl = tbl[0] + " AS " + tbl[1];
							jA = tbl[1];
						}
						
						String joinStmt = jTbl + " ON " + jA + "." + arr[1] + " " + op + " " + arr[3] + "." + arr[4];
						
						if (t.equals("J")) {
							j.add(joinStmt);
						} else if (t.equals("LJ")) {
							lj.add(joinStmt);
						} else if (t.equals("RJ")) {
							rj.add(joinStmt);
						}
					}
				} else if (t.equals("W")) {
					if (arr.length == 1)
						w = arr[0];
				} else if (t.equals("O")) {
					if (arr.length == 3) {
						String order = arr[2].equals("D") ? "DESC" : "";
						if (!StringUtils.isEmpty(arr[0]))
							o.add(arr[0] + "." + arr[1] + " " + order);
						else
							o.add(arr[1] + " " + order);
					}
				} else if (t.equals("L")) {
					if (arr.length == 1)
						l = arr[0];
				} else if (t.equals("T")) {
					if (arr.length >= 1) {
						destTableName = arr[0];
						if (arr.length == 2)
							ii = "ii".equals(arr[1]);
					}
				}
			}
			
			
		} catch (Exception e) {
			validQuery = false;
		}

		validQuery = validQuery && (!s.isEmpty() && f != null);

		StringBuilder qb = new StringBuilder();

		if (validQuery) {
			qb.append("SELECT " + String.join(",", s) + " FROM " + f);

			// TODO: Look at the order
			if (!j.isEmpty()) {
				qb.append(" JOIN " + String.join(" JOIN ", j));
			}
			if (!lj.isEmpty()) {
				qb.append(" LEFT JOIN " + String.join(" LEFT JOIN ", lj));
			}
			if (!rj.isEmpty()) {
				qb.append(" RIGHT JOIN " + String.join(" RIGHT JOIN ", rj));
			}
			if (w != null) {
				qb.append(" WHERE " + w);
			}
			if (!o.isEmpty()) {
				qb.append(" ORDER BY " + String.join(",", o));
			}
			if (l != null) {
				qb.append(" LIMIT " + l);
			}

			// Creating destination table
			if (destTableName != null && !destFields.isEmpty()) {
				destTable = new DbTable(destTableName, destFields, ii);
			}
		}

		return validQuery ? qb.toString() : null;
	}
}
