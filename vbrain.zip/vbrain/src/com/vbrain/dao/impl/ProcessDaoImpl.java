package com.vbrain.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.vbrain.common.io.Bot;
import com.vbrain.common.io.Constants;
import com.vbrain.common.io.Data;
import com.vbrain.common.io.Group;
import com.vbrain.common.io.Human;
import com.vbrain.common.io.RequestMessage;
import com.vbrain.common.io.Transactions;
import com.vbrain.common.io.User;
import com.vbrain.dao.ProcessDao;
import com.vbrain.dao.TransactionsDao;

public class ProcessDaoImpl extends ConnectionDaoImpl implements  ProcessDao{

	private static final DecimalFormat df = new DecimalFormat("#.##");
	private static final DecimalFormat df1 = new DecimalFormat("#.###");
	private static List<Group> allGroups = null;
	
	
			
	/**
	 * @return the allGroups
	 */
	private static List<Group> getAllGroups() {
		return allGroups;
	}

	/**
	 * @param allGroups the allGroups to set
	 */
	private static void setAllGroups(List<Group> allGroups) {
		ProcessDaoImpl.allGroups = allGroups;
	}

	/**
	 * Get All Process
	 */
	public Data getAllProcess() {
		Connection mysqlConn = null;
		Statement st = null;
		Data data = null;
		ResultSet rs = null;
		try{
			
			String sql = "SELECT distinct name FROM groups where Type = 'Process' order by name";

			System.out.println("getAllProcess(): sql :::: "+sql);

			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);
			data = new Data();
			List<Group> groups = new ArrayList<Group>();
			while(rs.next()){
				String name = rs.getString("name");
				Group group = new Group();
				group.setId(name);
				group.setName(name);
				groups.add(group);
			}
			data.setGroups(groups);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			closeResources(mysqlConn, st, rs);
		} 
		return data;
	}
	
	/**
	 * 
	 * @param startDate
	 * @param endDate
	 * @param workStep
	 * @param groupBy
	 * @return
	 */
	public List<Data> getProcess(String function, String geo, String businessApp){
		Connection mysqlConn = null;
		Statement st = null;
		Data data = null;
		List<Data> dataList = null;
		ResultSet rs = null;
		try{

			
			/*
			String sql = "SELECT vb.bot_key as botKey, vb.bot_provider as provider, vb.status as status, vp.process_name as processName, vg.GEOGRAPHY as geo, vg.REGION as region, "+
					" (select count(*) from vbrain_transaction where bot_id = vb.id) as transactions "+
					"FROM vbrain_bot vb, vbrain_process vp, vbrain_geo vg  "+
					"where vb.type = 'BOT' and vb.PROCESS_ID = vp.ID and vb.GEO_ID = vg.id "+condition+" ;";
					*/
			
			String sql = "SELECT ID, SEQUENCE, PROCESS_NAME, DESCRIPTION FROM vbrain_process "+
						 "  Where FUNCTION = '"+function+"' and BUSINESS_APP_ID = '"+geo+"' and GEO_ID = '"+businessApp+"' "+
					     "  order by sequence";

			System.out.println("sql :::: "+sql);



			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);
			dataList = new ArrayList<Data>();
			int i = 1;
						
			while(rs.next()){
				data = new Data();
				data.setIndex(rs.getInt("SEQUENCE"));
				data.setProcessId(rs.getString("ID") );
				data.setProcessName(rs.getString("PROCESS_NAME") );
				data.setDescription(rs.getString("DESCRIPTION") );

				dataList.add(data);
			}

			
			System.out.println("dataList.size() :::::::: "+dataList.size());

		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			closeResources(mysqlConn, st, rs);
		} 

		return dataList;
	}
	
	public Data getProcess(String processId){
		Connection mysqlConn = null;
		Statement st = null;
		Data data = null;
		
		ResultSet rs = null;
		try{

			
			/*
			String sql = "SELECT vb.bot_key as botKey, vb.bot_provider as provider, vb.status as status, vp.process_name as processName, vg.GEOGRAPHY as geo, vg.REGION as region, "+
					" (select count(*) from vbrain_transaction where bot_id = vb.id) as transactions "+
					"FROM vbrain_bot vb, vbrain_process vp, vbrain_geo vg  "+
					"where vb.type = 'BOT' and vb.PROCESS_ID = vp.ID and vb.GEO_ID = vg.id "+condition+" ;";
					*/
			
			String sql = 	"	SELECT ID, SEQUENCE, PROCESS_NAME, DESCRIPTION, IS_BOT_TYPE, IS_HUMAN_TYPE, "+
							"	IS_STP_TYPE, BOT_EFFORT, HUMAN_EFFORT, STP_EFFORT "+
							"	FROM vbrain_process "+
							"  	Where ID = '"+processId+"'  ";

			System.out.println("sql :::: "+sql);



			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);
			
			while(rs.next()){
				data = new Data();
				data.setIndex(rs.getInt("SEQUENCE"));
				data.setProcessId(rs.getString("ID") );
				data.setProcessName(rs.getString("PROCESS_NAME") );
				data.setDescription(rs.getString("DESCRIPTION") );
				
				data.setIsBotType(rs.getInt("IS_BOT_TYPE") );
				data.setIsHumanType(rs.getInt("IS_HUMAN_TYPE") );
				data.setIsStpType(rs.getInt("IS_STP_TYPE") );
				data.setBotEffortSaved(rs.getInt("BOT_EFFORT") );
				data.setHumanEffortSaved(rs.getInt("HUMAN_EFFORT") );
				data.setStpEffortSaved(rs.getInt("STP_EFFORT") );
			}

			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			closeResources(mysqlConn, st, rs);
		} 

		return data;
	}
	
	/**
	 * 
	 * @param requestMessage
	 * @return
	 */
	public int insertProcess(RequestMessage requestMessage){
		return 0;
	}
	
	/**
	 * 
	 * @param requestMessage
	 * @return
	 */
	public int updateProcess(RequestMessage requestMessage){
		return 0;
	}
	
	
	public Data getHumans(String processId){ 
    	Connection mysqlConn = null;
        Statement st = null;
        //Data data = null;
        Data data = null;
        ResultSet rs = null;
    	try{
    		

    		String sql = "SELECT * from human_worker where process_id = '"+processId+"' and isDisabled = '0'";
    		mysqlConn = getMySqlConnection();
    		st = mysqlConn.createStatement();
    		rs = st.executeQuery(sql);
    		List<Human> users = new ArrayList<Human>();
    		
    		
    		Human user = null;
    		while(rs.next()){
    			user = new Human();
   			
    			user.setId(rs.getString("id"));
    			user.setWorkerId(rs.getString("Worker_Id"));
    			user.setName(rs.getString("Name"));
    			user.setDescription(rs.getString("Description"));
    			user.setProcessId(rs.getString("Process_Id"));
    			user.setAvgEfforts(rs.getString("avgEfforts"));
    			user.setAvgCost(rs.getString("avgCost"));
    			user.setCycleTime(rs.getString("cycleTime"));
    			user.setNoOftransactions(rs.getString("noOftransactions"));
    			
    			users.add(user);
    		}
    		
    		data = new Data();
    		data.setHumans(users);  
    		
    	}
    	catch(Exception e){
    		e.printStackTrace();
    	}
    	finally {
    		closeResources(mysqlConn, st, rs);
        } 

    	return data;
    }
	
	
	public Data getProcesses(){ 
    	Connection mysqlConn = null;
        Statement st = null;
        //Data data = null;
        Data data = null;
        ResultSet rs = null;
    	try{
    		
    		getGroupsInfo();

    		String sql = "SELECT * from groups where type = 'process' and isDisabled = '0'";
    		System.out.println("sql : "+sql);
    		
    		mysqlConn = getMySqlConnection();
    		st = mysqlConn.createStatement();
    		rs = st.executeQuery(sql);
    		List<Group> groups = new ArrayList<Group>();
    		
    		Group group = null;
    		while(rs.next()){
    			group = new Group();
    			
    			group.setId(rs.getString("id"));
    			
    			group.setDescription(rs.getString("Description"));
    			
    			String parentId = rs.getString("parent_id");
    			
    			StringBuffer pathInfo = getPathInfo(parentId);
    			
    			group.setName(rs.getString("Name") + " - ["+ pathInfo.toString() +"]");
    			
    			System.out.println("Parent ["+ rs.getString("Name") + parentId+"] pathInfo --------------->>>>>> "+pathInfo.toString());
    			
    			groups.add(group);
    		}
    		
    		data = new Data();
    		data.setGroups(groups);  
    		
    	}
    	catch(Exception e){
    		e.printStackTrace();
    	}
    	finally {
    		closeResources(mysqlConn, st, rs);
        } 

    	return data;
    }
	
	//author - Lavakumar
	public Data getBusinessProcesses(){ 
    	Connection mysqlConn = null;
        Statement st = null;
        //Data data = null;
        Data data = null;
        ResultSet rs = null;
    	try{
    		
    		String sql = "SELECT * from business_process_view_2 WHERE isDisabled = '0'";
    		System.out.println("sql : "+sql);
    		
    		mysqlConn = getMySqlConnection();
    		st = mysqlConn.createStatement();
    		rs = st.executeQuery(sql);
    		List<Group> groups = new ArrayList<Group>();
    		
    		Group group = null;
    		while(rs.next()){
    			group = new Group();
    			
    			group.setId(rs.getString("business_process_id"));
    			group.setName(rs.getString("campaign_name"));
    			
    			groups.add(group);
    		}
    		
    		data = new Data();
    		data.setGroups(groups);  
    		
    	}
    	catch(Exception e){
    		e.printStackTrace();
    	}
    	finally {
    		closeResources(mysqlConn, st, rs);
        } 

    	return data;
    }
	
	
	
	private StringBuffer getPathInfo(String parentId){
		
		StringBuffer pathIfo = new StringBuffer();
		try{
			List<Group> groups = getAllGroups();
			
			System.out.println("groups.size() :::::::::::::::: "+groups.size());
			
			int isParent = 1;
			
			int count = 0;
			
			while(isParent > 0){
			
				count ++;
				
				for(int i=0; i<groups.size(); i++){
					Group group = groups.get(i);
					
					//System.out.println("parentId -------> "+parentId+" | groupId -------> "+group.getId());
					
					if( parentId.equalsIgnoreCase(group.getId()) ){
						pathIfo.append(group.getName() + " < ");
						
						//System.out.println("-------------------> "+group.getName());
						parentId = group.getParentId();
						
						if(group.getParentId().equalsIgnoreCase("0")){
							isParent = 0;
						}
						
						
						
						break;
					}
				}
				
				//System.out.println("count-------------------> "+count);
				
				if(count == groups.size()){
					isParent = 0;
				}
			}
			
		}
		catch (Exception e){
			e.printStackTrace();
		}
		return pathIfo;
	}
	
	
	
	private void getGroupsInfo(){
    	Connection mysqlConn = null;
        Statement st = null;
        //Data data = null;
        Data data = null;
        ResultSet rs = null;
        List<Group> groups = null;
    	try{
    		

    		//String sql = 	"SELECT * FROM groups where isDisabled = '0' order by parent_id desc";
    		String sql = 	"SELECT * FROM groups order by parent_id desc";
    		System.out.println("sql : "+sql);
    		
    		mysqlConn = getMySqlConnection();
    		st = mysqlConn.createStatement();
    		rs = st.executeQuery(sql);
    		groups = new ArrayList<Group>();
    		Group group = null;
    		
    		while(rs.next()){
    			group = new Group();
    			
    			group.setId(rs.getString("id"));
    			group.setName(rs.getString("name"));
    			group.setDescription(rs.getString("description"));
    			group.setType(rs.getString("type"));
    			group.setParentId(rs.getString("parent_id"));
    			group.setParentGroupId(rs.getString("Parent_Group_Id"));
    			group.setNodes(new ArrayList<Group>());
    			
    			if("0".equals(rs.getString("isDisabled"))){
    				group.setIsDisabled("enabled");
    				group.setIconStyle("remove");
    				
    			}
    			else {
    				group.setIsDisabled("disabled");
    				group.setIconStyle("ok");
    			}
    			
    			
    			//groupIds = groupIds + rs.getString("id") + ",";
    			
    			groups.add(group);
    		}
    		
    		setAllGroups(groups);
    		
    		
    	}
    	catch(Exception e){
    		e.printStackTrace();
    	}
    	finally {
    		closeResources(mysqlConn, st, rs);
        } 

    	
    }
	
	
	
	
	public Data getBots(String processId){ 
    	Connection mysqlConn = null;
        Statement st = null;
        //Data data = null;
        Data data = null;
        ResultSet rs = null;
    	try{
    		

    		String sql = "SELECT * from bot where process_id = '"+processId+"' and isDisabled = '0' ";
    		mysqlConn = getMySqlConnection();
    		st = mysqlConn.createStatement();
    		rs = st.executeQuery(sql);
    		List<Bot> bots = new ArrayList<Bot>();
    		
    		System.out.println("sql ::::::::: "+sql);
    		
    		Bot bot = null;
    		while(rs.next()){
    			bot = new Bot();
    			
    			//System.out.println("processId in get groupUsers method : "+rs.getString("userId"));
    			
    			bot.setId(rs.getString("id"));
    			bot.setBotKey(rs.getString("Bot_Key"));
    			bot.setProvider(rs.getString("Provider"));
    			bot.setHostName(rs.getString("Host_Name"));
    			bot.setDescription(rs.getString("Description"));
    			bot.setProcessId(rs.getString("Process_Id"));
    			
    			bot.setAvgEfforts(rs.getString("avgEfforts"));
    			bot.setAvgCost(rs.getString("avgCost"));
    			bot.setCycleTime(rs.getString("cycleTime"));
    			bot.setNoOftransactions(rs.getString("noOftransactions"));
    			bot.setAvgEffortsSaved(rs.getString("avgEffortsSaved"));
    			
    			
    			bots.add(bot);
    		}
    		
    		data = new Data();
    		data.setBots(bots);  
    		
    	}
    	catch(Exception e){
    		e.printStackTrace();
    	}
    	finally {
    		closeResources(mysqlConn, st, rs);
        } 

    	return data;
    }
	
	
 	public String addBot(Bot bot){

		// Connection oracleConn = null;
		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		//ResultSet rs = null;
		String botKey = "BOT";
		try {

			if(bot != null ){

				String tQuery = "";

				System.out.println("bot    =" + bot);
				//System.out.println("processId   =" + processId);
				
				mysqlConn = getMySqlConnection();
				
				String sql = "SELECT count(*)+1 count from bot ";
	    		st = mysqlConn.createStatement();
	    		ResultSet rs = st.executeQuery(sql);
	    		while(rs.next()){
	    			botKey = "BOT" + rs.getString("count");
	    		}
				
	    		rs = null;
				st.close();
				

				tQuery = "INSERT INTO bot "+
						"(Bot_Key, Provider, Host_Name, Description, Process_Id, avgEfforts, avgCost, cycleTime, noOftransactions, avgEffortsSaved ) "+
						"VALUES (" +
						" '"+botKey+"', "+
						" '"+bot.getProvider()+"', "+
						" '"+bot.getHostName()+"', "+
						" '"+bot.getDescription()+"', "+
						" '"+bot.getProcessId()+"', "+
						" '"+bot.getAvgEfforts()+"', "+
						" '"+bot.getAvgCost()+"', "+
						" '"+bot.getCycleTime()+"', "+
						" '"+bot.getNoOftransactions()+"', "+
						" '"+bot.getAvgEffortsSaved()+"' "+
						" )";
				
				System.out.println("tQuery ::::::: "+tQuery);

				st = mysqlConn.createStatement();

				result = st.executeUpdate(tQuery);

				System.out.println("Add Bot result :::::::::: "+result);
				
				if(result == 0){
					botKey = "0";
				}
			}
		} 
		catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			return "0";
			//System.exit(1);
		} 
		finally {
			// release database resources
			//oracleConn.close();
			boolean closedResources = closeResources(mysqlConn, st, null);
			if(!closedResources) {
        		return "0";
        	}
		}

		return botKey;
	}
 	
 	
 	public int editBot(Bot bot){

		// Connection oracleConn = null;
		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		//ResultSet rs = null;
		try {

			if(bot != null ){

				String tQuery = "";

				System.out.println("bot    =" + bot);
				//System.out.println("processId   =" + processId);
				
				mysqlConn = getMySqlConnection();

				tQuery = "Update bot "+
						" Set Provider = '"+bot.getProvider()+"', Host_Name  = '"+bot.getHostName()+"', Description = '"+bot.getDescription()+"', "+
						" avgEfforts = '"+bot.getAvgEfforts()+"', avgCost = '"+bot.getAvgCost()+"', cycleTime = '"+bot.getCycleTime()+"', noOftransactions = '"+bot.getNoOftransactions()+"' and avgEffortsSaved =   '"+bot.getAvgEffortsSaved()+"' where Id = '"+bot.getId()+"' ";
						
				
				System.out.println("tQuery ::::::: "+tQuery);

				st = mysqlConn.createStatement();

				result = st.executeUpdate(tQuery);

				System.out.println("Update Bot result :::::::::: "+result);
			}
		} 
		catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			result = 0;
			//System.exit(1);
		} 
		finally {
			// release database resources
			//oracleConn.close();
			boolean closedResources = closeResources(mysqlConn, st, null);
			if(!closedResources) {
        		result = 0;
        	}
		}

		return result;
	}
 	
 	
 	public int disableBot(Bot bot){

		// Connection oracleConn = null;
		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		//ResultSet rs = null;
		try {

			if(bot != null ){

				String tQuery = "";

				System.out.println("bot    =" + bot);
				//System.out.println("processId   =" + processId);
				
				mysqlConn = getMySqlConnection();

				tQuery = "Update bot "+
						" Set isDisabled = '1' where ID  = '"+bot.getId()+"' ";
						
				
				System.out.println("tQuery ::::::: "+tQuery);

				st = mysqlConn.createStatement();

				result = st.executeUpdate(tQuery);

				System.out.println("disable Bot result :::::::::: "+result);
			}
		} 
		catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			result = 0;
			//System.exit(1);
		} 
		finally {
			// release database resources
			//oracleConn.close();
			boolean closedResources = closeResources(mysqlConn, st, null);
			if(!closedResources) {
        		result = 0;
        	}
		}

		return result;
	}
 	
 	
 	
 	public int addHuman(Human human){

		// Connection oracleConn = null;
		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		//ResultSet rs = null;
		try {

			if(human != null ){

				String tQuery = "";

				System.out.println("human    =" + human);
				//System.out.println("processId   =" + processId);
				
				int isDuplicateHuman = isDuplicateHuman(human.getWorkerId(), human.getProcessId());
				if(isDuplicateHuman == 0 ){
				
					mysqlConn = getMySqlConnection();
	
					tQuery = "INSERT INTO human_worker "+
							"(Worker_Id, Name, Description, Process_Id, avgEfforts, avgCost, cycleTime, noOftransactions ) "+
							"VALUES (" +
							" '"+human.getWorkerId()+"', "+
							" '"+human.getName()+"', "+
							" '"+human.getDescription()+"', "+
							" '"+human.getProcessId()+"', "+
							" '"+human.getAvgEfforts()+"', "+
							" '"+human.getAvgCost()+"', "+
							" '"+human.getCycleTime()+"', "+
							" '"+human.getNoOftransactions()+"' "+
							" )";
					
					System.out.println("tQuery ::::::: "+tQuery);
	
					st = mysqlConn.createStatement();
	
					result = st.executeUpdate(tQuery);
	
					System.out.println("Add Human result :::::::::: "+result);
				}
				if(isDuplicateHuman == 1 ){
					result = 2;
				} 
				else {
					result = 3;
				}
				
			}
		} 
		catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			result = 0;
			//System.exit(1);
		} 
		finally {
			// release database resources
			//oracleConn.close();
			boolean closedResources = closeResources(mysqlConn, st, null);
			if(!closedResources) {
        		result = 0;
        	}
		}

		return result;
	}
 	
 	
 	public int editHuman(Human human){

		// Connection oracleConn = null;
		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		//ResultSet rs = null;
		try {

			if(human != null ){

				String tQuery = "";

				System.out.println("human    =" + human);
				//System.out.println("processId   =" + processId);
				
				
					mysqlConn = getMySqlConnection();
	
					tQuery = "Update human_worker "+
							" Set Worker_Id = '"+human.getWorkerId()+"', Name = '"+human.getName()+"', Description = '"+human.getDescription()+"', " + 
					" avgEfforts = '"+human.getAvgEfforts()+"', avgCost = '"+human.getAvgCost()+"', cycleTime = '"+human.getCycleTime()+"', noOftransactions = '"+human.getNoOftransactions()+"' where Id  = '"+human.getId()+"' ";
					System.out.println("tQuery ::::::: "+tQuery);
	
					st = mysqlConn.createStatement();
	
					result = st.executeUpdate(tQuery);
	
					System.out.println("Update Human result :::::::::: "+result);
				
			}
		} 
		catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			result = 0;
			//System.exit(1);
		} 
		finally {
			// release database resources
			//oracleConn.close();
			boolean closedResources = closeResources(mysqlConn, st, null);
			if(!closedResources) {
        		result = 0;
        	}
		}

		return result;
	}
 	
 	
 	public int disableHuman(Human human){

		// Connection oracleConn = null;
		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		//ResultSet rs = null;
		try {

			if(human != null ){

				String tQuery = "";

				System.out.println("human    =" + human);
				//System.out.println("processId   =" + processId);
				
				
					mysqlConn = getMySqlConnection();
	
					tQuery = "Update human_worker "+
							" Set isDisabled = '1' where ID  = '"+human.getId()+"' ";
							
					System.out.println("tQuery ::::::: "+tQuery);
	
					st = mysqlConn.createStatement();
	
					result = st.executeUpdate(tQuery);
	
					System.out.println("Disable Human result :::::::::: "+result);
				
			}
		} 
		catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			result = 0;
			//System.exit(1);
		} 
		finally {
			// release database resources
			//oracleConn.close();
			boolean closedResources = closeResources(mysqlConn, st, null);
			if(!closedResources) {
        		result = 0;
        	}
		}

		return result;
	}
 	
 	
 	private int isDuplicateHuman(String userId, String processId){
    	Connection mysqlConn = null;
        Statement st = null;
        ResultSet rs = null;
        
        
    	try{
    		
    		String sql = 	"SELECT * FROM human_worker where worker_id = '"+userId+"'and Process_Id = '"+processId+"' ";
    		mysqlConn = getMySqlConnection();
    		st = mysqlConn.createStatement();
    		rs = st.executeQuery(sql);
    		
    		if(rs.next()){
    			return 1;
    		}
    		else {
    			return 0;
    		}
    		
    	}
    	catch(Exception e){
    		e.printStackTrace();
    		return 2;
    	}
    	finally {
    		boolean closedResources = closeResources(mysqlConn, st, rs);
    		if(!closedResources) {
        		return 2;
        	}
        } 

    	
    }
	
	

}
