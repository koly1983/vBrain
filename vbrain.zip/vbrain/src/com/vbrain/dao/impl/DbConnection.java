package com.vbrain.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.vbrain.dao.impl.ImportImpl.DbConnectionType;
import com.vbrain.db.connection.PostgresDbManager;
import com.vbrain.db.connection.PostgresDbManager82;
import com.vbrain.db.connection.PostgresDbManager84P2;
import com.vbrain.db.connection.VBrainDbManager;
import com.vbrain.db.connection.WfDbManager;
import com.vbrain.db.connection.WfDbManager82;
import com.vbrain.db.connection.WfDbManager84P2;

public class DbConnection {
	
	private Connection _conn = null;
	
	private DbConnectionType type;
	
	public DbConnection(DbConnectionType type) {
		this.type = type;
	}

	private Connection getConnection() {
		if (_conn == null) {
			try {
				switch (type) {
				case VBRAIN:
					_conn = new VBrainDbManager().setUpPool().getConnection();
					break;
				case WFMYSQL:
					_conn = new WfDbManager().setUpPool().getConnection();
					break;
				case WFPOSTGRESQL:
					_conn = new PostgresDbManager().setUpPool().getConnection();
					break;
				case WFMYSQL82:
					_conn = new WfDbManager82().setUpPool().getConnection();
					break;
				case WFPOSTGRESQL82:
					_conn = new PostgresDbManager82().setUpPool().getConnection();
					break;
				case WFMYSQL84P2:
					_conn = new WfDbManager84P2().setUpPool().getConnection();
					break;
				case WFPOSTGRESQL84P2:
					_conn = new PostgresDbManager84P2().setUpPool().getConnection();
					break;
				default:
					break;
				}
			} catch (Exception e) {
				System.out.println("Failed at dataSourceWF ");
				e.printStackTrace();
			}
		}
		return _conn;
	}
	
	public void closePreparedStatement(Statement stmt) {
		try {
			if (stmt != null) {
				stmt.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void closeResultSet(ResultSet rs, boolean closeStatementAsWell) {
		try {
			if (rs != null) {
				Statement stmt = rs.getStatement();
				rs.close();
				if(closeStatementAsWell)
					closePreparedStatement(stmt);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void closeConnection() {
		if (_conn != null) {
			try {
				_conn.close();
			} catch (Exception e) {
				System.out.println("Failed at dataSourceVB ");
			}
		}
	}
	
	public void execute(String query) {
		PreparedStatement pstmt = null;

		try {
			System.out.println("DbConnection : " + type.toString() + " : " + query);
			pstmt = getConnection().prepareStatement(query);

			pstmt.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			System.out.println("Failed at dataSource: "+ type.toString());
		} finally {
			closePreparedStatement(pstmt);
		}
	}
//	
//	public ResultSet executeQuery(String query) {
//		return internalExecuteQuery(query, true);
//	}
	
	public ResultSet executeQuery(String query, boolean expectingResultSet) {
		PreparedStatement pstmt = null;

		try {
			System.out.println("DbConnection : " + type.toString() + " : " + query);
			pstmt = getConnection().prepareStatement(query);

			return pstmt.executeQuery();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			System.out.println("Failed at dataSource: "+ type.toString());
		} finally {
			if(!expectingResultSet)
				closePreparedStatement(pstmt);
		}

		return null;
	}
	

	public DbPreparedStatement prepareStatement(String query) {
		PreparedStatement pstmt = null;

		try {
			System.out.println("DbConnection : " + query);
			pstmt = getConnection().prepareStatement(query);
			return new DbPreparedStatement(pstmt);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			System.out.println("Failed at dataSource: "+ type.toString());
		} 

		return null;
	}
	
	public void insertData(ResultSet source, DbTable destTable) {

		if (destTable == null || source == null) {
			return;
		}

		String insertStatement = destTable.getInsertStatement();
		if (insertStatement == null) {
			return;
		}

		PreparedStatement pstmtObjForinsert = null;

		try {
			pstmtObjForinsert = getConnection().prepareStatement(insertStatement);

			while (source.next()) {
				// Passing values to prepared statement
				int i = 1;
				for (DbTableField dbField : destTable.getFields()) {
					pstmtObjForinsert.setString(i, source.getString(dbField.getName()));
					i++;
				}
				pstmtObjForinsert.addBatch();
			}

			pstmtObjForinsert.executeBatch();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			System.out.println("Failed at dataSource: "+ type.toString());
		} finally {
			closePreparedStatement(pstmtObjForinsert);
		}
	}
}
