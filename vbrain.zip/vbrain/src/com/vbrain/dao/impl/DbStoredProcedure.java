package com.vbrain.dao.impl;

import java.sql.ResultSet;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class DbStoredProcedure {
	private String name;
	private List<String> params;
	protected boolean returnsData;

	public DbStoredProcedure(String name, List<String> params) {
		this.name = name;
		this.params = params;
	}
	
	public DbStoredProcedure(String name, List<String> params, boolean returnsData) {
		this.name = name;
		this.params = params;
		this.returnsData = returnsData;
	}
	
	public DbStoredProcedure(String name, String param) {
		this.name = name;
		if(param != null)
			this.params = Arrays.asList(param);
	}
	
	public DbStoredProcedure(String name, String param, boolean returnsData) {
		this.name = name;
		if(param != null)
			this.params = Arrays.asList(param);
		this.returnsData = returnsData;
	}

	public String getName() {
		return name;
	}

	public String getCallStatement() {
		if (params != null && !params.isEmpty()) {
			String paramsStr = params.stream().map(p -> p!=null?"'" + p + "'":"NULL").collect(Collectors.joining(","));
			return "{Call " + name + "(" + paramsStr + ")}";
		}
		
		return "{Call " + name + "()}";
	}
	
	public void execute(DbConnection conn) {
		
		conn.execute(getCallStatement());
	}
	
	public ResultSet executeQuery(DbConnection conn) {
		
		return executeQuery(conn, true);
	}
	
	protected ResultSet executeQuery(DbConnection conn, boolean expectingResultSet) {
		if(expectingResultSet)
			return conn.executeQuery(getCallStatement(), true);
		
		conn.executeQuery(getCallStatement(), false);
		
			
		return null;
	}
}
