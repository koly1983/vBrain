package com.vbrain.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.tempuri.FNOLBotServiceProxy;

import com.vbrain.common.io.Data;
import com.vbrain.dao.SLATransactionsDao;
import com.vbrain.common.io.Constants;

public class SLATransactionsDaoImpl extends ConnectionDaoImpl implements SLATransactionsDao {

	/**
	 * 
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<Data> getSLAListWorkstepWise(String startDate, String endDate, String function) {
		Connection mysqlConn = null;
		Statement st = null;
		Data data = null;
		// Data data2 = null;
		List<Data> dataList = null;
		// List<Data> dataList2 = null;
		ResultSet rs = null;
		try {

			String sql;
			if (function == null || function.isEmpty()) {
				sql = "select sv.process_name, sv.worker, count(*) total_transactions, sum( case when sv.duration > sv.sla then 1 else 0 end ) as Breached, "
						+ " sum( case when sv.duration <= sv.sla then 1 else 0 end ) as Achieved, st.sequence as sequence "
						+ " from group_sla_view sv, sequence_temp st where sv.worker_status = '0' and  sv.process_id = (select id from groups where isDisabled = '0'  and id = process_id ) and "
						+ " sv.process_name = st.process_name group by sv.process_name order by sequence ";
			} else {
				sql = "select sv.process_name, sv.worker, count(*) total_transactions, sum( case when sv.duration > sv.sla then 1 else 0 end ) as Breached, "
						+ " sum( case when sv.duration <= sv.sla then 1 else 0 end ) as Achieved, st.sequence as sequence "
						+ " from group_sla_view sv, sequence_temp st, groups sg, groups fg "
						+ " where sv.process_id = sg.id and sg.Parent_Id = fg.id and fg.Type = 'function' and fg.Name = '"
						+ function
						+ "' and sv.worker_status = '0' and  sv.process_id = (select id from groups where isDisabled = '0'  and id = process_id ) and "
						+ " sv.process_name = st.process_name group by sv.process_name order by sequence ";
			}

			// System.out.println("Worstep wise Sql::::::::: "+sql);
			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);
			dataList = new ArrayList<Data>();

			while (rs.next()) {
				data = new Data();

				data.setTotalTransactions(Long.parseLong(rs.getString("total_transactions")));
				// System.out.println("Worstep wise total_transactions :
				// "+rs.getString("total_transactions"));

				data.setProcessName(rs.getString("process_name"));
				data.setWorker(rs.getString("worker"));
				data.setSlaAchieved(rs.getLong("Achieved"));
				data.setSlaBreachedActive(rs.getLong("Breached"));

				data.setSlaBreachedFulfilled(Long.parseLong("0000"));

				long totaltrans = Long.parseLong(rs.getString("total_transactions"));
				long achieved = rs.getLong("Achieved");
				long breached = rs.getLong("Breached");

				double PerAchieved = getPercentage(achieved, totaltrans);
				double PerBreached = getPercentage(breached, totaltrans);

				data.setSlaAchievedPer(PerAchieved);
				data.setSlaBreachedActivePer(PerBreached);

				data.setSlaBreachedFulfilledPer(Double.parseDouble("0000"));

				// System.out.println("Worstep wise Process
				// name"+rs.getString("process_name"));
				// System.out.println("Worstep wise
				// Achieved"+rs.getLong("Achieved"));
				// System.out.println("Worstep wise
				// Breached"+rs.getLong("Breached"));
				// System.out.println("Worstep wise Percentage Achieved
				// "+PerAchieved +"%");
				// System.out.println("Worstep wise Percentage Breached
				// "+PerBreached +"%");

				dataList.add(data);
			}

			/*
			 * dataList = new ArrayList<Data>();
			 * 
			 * 
			 * data = new Data();
			 * 
			 * data.setProcessName(Constants.CREATE_FNOL);
			 * data.setWorker("BOT");
			 * data.setTotalTransactions(Long.parseLong("2"));
			 * 
			 * data.setSlaAchieved(Long.parseLong("1"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("1"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * 
			 * data.setSlaAchievedPer(Double.parseDouble("50"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("50"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("0"));
			 * dataList.add(data);
			 * 
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setWorker("BOT");
			 * data.setTotalTransactions(Long.parseLong("4"));
			 * data.setSlaAchieved(Long.parseLong("2"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("1"));
			 * data.setSlaBreachedActive(Long.parseLong("1"));
			 * 
			 * data.setSlaAchievedPer(Double.parseDouble("50"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("25"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("25"));
			 * dataList.add(data);
			 * 
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setWorker("Human");
			 * data.setTotalTransactions(Long.parseLong("0"));
			 * data.setSlaAchieved(Long.parseLong("0"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("0"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * data.setSlaAchievedPer(Double.parseDouble("0"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("0"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("0"));
			 * dataList.add(data);
			 */

			// System.out.println("dataList.size() :::::::: "+dataList.size());

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeResources(mysqlConn, st, rs);

		}

		return dataList;
	}

	public static int getPercentage(long n, long total) {
		float proportion = ((float) n) / ((float) total);
		return Math.round(proportion * 100);
	}

	/**
	 * 
	 * @param startDate
	 * @param endDate
	 * @param processName
	 * @return
	 */
	public List<Data> getSLAListRegionWise(String startDate, String endDate, String processName) {
		Connection mysqlConn = null;
		Statement st = null;
		Data data = null;
		List<Data> dataList = null;
		ResultSet rs = null;

		// System.out.println("getSLAListRegionWise(String startDate, String
		// endDate, String processName) function");

		// System.out.println("processName ::::: "+processName);

		try {

			String sql = "";

			if (processName != null) {

				sql = " select country,process_name,sum( case when duration > sla then 1 else 0 end ) as Breached, "
						+ " sum( case when duration<=sla then 1 else 0 end ) as Achieved from group_sla_view  where worker_status = '0' and process_name = '"
						+ processName + "' group by country, process_name";
				/*
				 * sql =
				 * " select geography,process_name,region,sum( case when duration > sla then 1 else 0 end ) as Breached, "
				 * +
				 * " sum( case when duration<=sla then 1 else 0 end ) as Achieved from group_sla_view where process_id = (select id from vbrain_process where process_name='"
				 * +processName+"') group by geography, process_name";
				 */
			} else {
				sql = "select country,sum( case when duration > sla then 1 else 0 end ) as Breached,sum( case when duration<=sla then 1 else 0 end ) as Achieved from group_sla_view where worker_status = '0' and  process_id = (select id from groups where isDisabled = '0'  and id = process_id )  group by country";

				/*
				 * sql =
				 * "select geography,region,sum( case when duration > sla then 1 else 0 end ) as Breached,sum( case when duration<=sla then 1 else 0 end ) as Achieved from group_sla_view group by geography"
				 * ;
				 */
			}

			// System.out.println(sql);
			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);
			dataList = new ArrayList<Data>();

			while (rs.next()) {
				data = new Data();

				String region = rs.getString("country");
				data.setRegion(region);
				data.setSlaAchieved(rs.getLong("Achieved"));
				data.setSlaBreachedActive(rs.getLong("Breached"));

				data.setSlaBreachedFulfilled(Long.parseLong("0000"));

				if (processName != null) {
					// System.out.println("Process
					// name::::::"+rs.getString("process_name"));
					data.setProcessId(processName);
				}

				long achieved = rs.getLong("Achieved");
				long breached = rs.getLong("Breached");
				long totaltrans = achieved + breached;
				double PerAchieved = getPercentage(achieved, totaltrans);
				double PerBreached = getPercentage(breached, totaltrans);

				data.setSlaAchievedPer(PerAchieved);
				data.setSlaBreachedActivePer(PerBreached);

				data.setSlaBreachedFulfilledPer(Double.parseDouble("0000"));

				// System.out.println("region ::::::::::: "+region);
				// System.out.println("Achieved ::::::: "+achieved);
				// System.out.println("Breached ::::::: "+breached);
				// System.out.println("Percentage Achieved :::::::::::
				// "+PerAchieved +"%");
				// System.out.println("Percentage Breached :::::::::::
				// "+PerBreached +"%");

				dataList.add(data);

			}

			/*
			 * dataList = new ArrayList<Data>();
			 * 
			 * 
			 * data = new Data();
			 * 
			 * if(processName == null){
			 * 
			 * data.setRegion("US - North East");
			 * 
			 * data.setSlaAchieved(Long.parseLong("1"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("1"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * 
			 * data.setSlaAchievedPer(Double.parseDouble("50"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("40"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("10"));
			 * dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("US - West");
			 * data.setSlaAchieved(Long.parseLong("1"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("1"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * 
			 * data.setSlaAchievedPer(Double.parseDouble("50"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("25"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("25"));
			 * dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("US - South West");
			 * data.setSlaAchieved(Long.parseLong("0"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("0"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * data.setSlaAchievedPer(Double.parseDouble("0"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("0"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("0"));
			 * dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("US - South East");
			 * data.setSlaAchieved(Long.parseLong("0"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("0"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * data.setSlaAchievedPer(Double.parseDouble("0"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("0"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("0"));
			 * dataList.add(data);
			 * 
			 * 
			 * } else if(processName.equalsIgnoreCase(Constants.CREATE_FNOL)){
			 * data.setRegion("US - North East");
			 * 
			 * data.setSlaAchieved(Long.parseLong("1"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("1"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * 
			 * data.setSlaAchievedPer(Double.parseDouble("50"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("40"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("10"));
			 * dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("US - West");
			 * data.setSlaAchieved(Long.parseLong("0"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("0"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * data.setSlaAchievedPer(Double.parseDouble("0"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("0"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("0"));
			 * dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("US - South West");
			 * data.setSlaAchieved(Long.parseLong("0"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("0"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * data.setSlaAchievedPer(Double.parseDouble("0"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("0"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("0"));
			 * dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("US - South East");
			 * data.setSlaAchieved(Long.parseLong("0"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("0"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * data.setSlaAchievedPer(Double.parseDouble("0"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("0"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("0"));
			 * dataList.add(data);
			 * 
			 * } else
			 * if(processName.equalsIgnoreCase(Constants.ADJUDICATE_CLAIM)){
			 * 
			 * data = new Data(); data.setRegion("US - North East");
			 * data.setSlaAchieved(Long.parseLong("0"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("0"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * data.setSlaAchievedPer(Double.parseDouble("0"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("0"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("0"));
			 * dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("US - West");
			 * data.setSlaAchieved(Long.parseLong("1"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("1"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * 
			 * data.setSlaAchievedPer(Double.parseDouble("50"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("25"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("25"));
			 * dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("US - South West");
			 * data.setSlaAchieved(Long.parseLong("0"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("0"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * data.setSlaAchievedPer(Double.parseDouble("0"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("0"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("0"));
			 * dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("US - South East");
			 * data.setSlaAchieved(Long.parseLong("0"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("0"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * data.setSlaAchievedPer(Double.parseDouble("0"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("0"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("0"));
			 * dataList.add(data);
			 * 
			 * } else if(processName.equalsIgnoreCase(Constants.APPROVE_CLAIM)){
			 * data = new Data(); data.setRegion("US - North East");
			 * data.setSlaAchieved(Long.parseLong("0"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("0"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * data.setSlaAchievedPer(Double.parseDouble("0"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("0"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("0"));
			 * dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("US - West");
			 * data.setSlaAchieved(Long.parseLong("0"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("0"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * data.setSlaAchievedPer(Double.parseDouble("0"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("0"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("0"));
			 * dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("US - South West");
			 * data.setSlaAchieved(Long.parseLong("0"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("0"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * data.setSlaAchievedPer(Double.parseDouble("0"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("0"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("0"));
			 * dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("US - South East");
			 * data.setSlaAchieved(Long.parseLong("0"));
			 * data.setSlaBreachedFulfilled(Long.parseLong("0"));
			 * data.setSlaBreachedActive(Long.parseLong("0"));
			 * data.setSlaAchievedPer(Double.parseDouble("0"));
			 * data.setSlaBreachedFulfilledPer(Double.parseDouble("0"));
			 * data.setSlaBreachedActivePer(Double.parseDouble("0"));
			 * dataList.add(data); }
			 */

			// System.out.println("dataList.size() :::::::: "+dataList.size());

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeResources(mysqlConn, st, rs);

		}

		return dataList;
	}

	/**
	 * 
	 * @param botKey
	 * @param statusFlag
	 * @return
	 */
	public boolean invokeTriggerBotService(String botKey, boolean statusFlag) {
		try {
			// FNOLBotService_ServiceLocator botService_ServiceLocator = new
			// FNOLBotService_ServiceLocator();
			// FNOLBotService_Service botService =
			// botService_ServiceLocator.get;
			FNOLBotServiceProxy botServiceProxy = new FNOLBotServiceProxy();
			String status = botServiceProxy.triggerBot_Execute(botKey, statusFlag);

			// System.out.println("Triiger Bot Response ::::::::::: "+status);

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	/**
	 * 
	 * @param startDate
	 * @param endDate
	 * @param status
	 * @return
	 */
	public List<Data> getSLAListByStatusAndFunction(String startDate, String endDate, String status, String function) {
		Connection mysqlConn = null;
		Statement st = null;
		Data data = null;
		List<Data> dataList = null;
		ResultSet rs = null;
		try {

			String sql;
			if (function == null || function.isEmpty()) {
				sql = "select (select count(*)count from group_sla_view ) as totaltransaction, country, "
						+ "count(*)regionwise_count, case when duration > sla then 'Breached' else 'Achieved' end  as Status"
						+ " from group_sla_view where worker_status = '0'  group by status, country";
			} else {
				sql = "select (select count(*)count from group_sla_view ) as totaltransaction, country, "
						+ "count(*)regionwise_count, case when duration > sla then 'Breached' else 'Achieved' end  as Status"
						+ " from group_sla_view v, groups pg, groups fg "
						+ " where v.process_id = pg.id and pg.Parent_Id = fg.id and fg.Type = 'function' and fg.Name = '"
						+ "' and worker_status = '0' and  process_id = (select id from groups where isDisabled = '0'  and id = process_id ) group by status, country";
			}

			/*
			 * String sql=
			 * "select (select count(*)count from sla_view ) as totaltransaction,process_name,worker,region,geography, count(*)regionwise_count"
			 * +
			 * ",case when duration>=sla then 'Breached' else 'Achieved' end  as status "
			 * +
			 * "from sla_view group by process_name,status,geography order by process_name"
			 * ;
			 */

			// System.out.println(sql);
			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);

			dataList = new ArrayList<Data>();
			while (rs.next()) {

				if (status.equalsIgnoreCase(rs.getString("status"))) {

					data = new Data();
					data.setRegion(rs.getString("country"));
					data.setTotalTransactions(rs.getLong("regionwise_count"));
					long rcount = rs.getLong("regionwise_count");
					long tcount = rs.getLong("totaltransaction");
					double totalPer = getPercentage(rcount, tcount);
					data.setTotalPer(totalPer);
					dataList.add(data);
				}

			}

			/*
			 * dataList = new ArrayList<Data>();
			 * 
			 * if(status.equalsIgnoreCase(Constants.STATUS_ACHIEVED)){
			 * 
			 * data = new Data(); data.setRegion("US");
			 * data.setTotalTransactions(Long.parseLong("3100"));
			 * data.setTotalPer(Double.parseDouble("70")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("UK");
			 * data.setTotalTransactions(Long.parseLong("3040"));
			 * data.setTotalPer(Double.parseDouble("68")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Canada");
			 * data.setTotalTransactions(Long.parseLong("3160"));
			 * data.setTotalPer(Double.parseDouble("68")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Singapore");
			 * data.setTotalTransactions(Long.parseLong("3100"));
			 * data.setTotalPer(Double.parseDouble("70")); dataList.add(data);
			 * 
			 * 
			 * 
			 * } else if(status.equalsIgnoreCase(Constants.STATUS_BREACHED)){
			 * 
			 * data = new Data(); data.setRegion("US");
			 * data.setTotalTransactions(Long.parseLong("1330"));
			 * data.setTotalPer(Double.parseDouble("23")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("UK");
			 * data.setTotalTransactions(Long.parseLong("1330"));
			 * data.setTotalPer(Double.parseDouble("25")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Canada");
			 * data.setTotalTransactions(Long.parseLong("1360"));
			 * data.setTotalPer(Double.parseDouble("24")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Singapore");
			 * data.setTotalTransactions(Long.parseLong("1380"));
			 * data.setTotalPer(Double.parseDouble("23")); dataList.add(data);
			 * 
			 * }
			 */
			/*
			 * else if(status.equalsIgnoreCase("breachedA")){ data = new Data();
			 * data.setRegion("US");
			 * data.setTotalTransactions(Long.parseLong("315"));
			 * data.setTotalPer(Double.parseDouble("7")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("UK");
			 * data.setTotalTransactions(Long.parseLong("305"));
			 * data.setTotalPer(Double.parseDouble("7")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Canada");
			 * data.setTotalTransactions(Long.parseLong("355"));
			 * data.setTotalPer(Double.parseDouble("8")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Singapore");
			 * data.setTotalTransactions(Long.parseLong("325"));
			 * data.setTotalPer(Double.parseDouble("7")); dataList.add(data);
			 * 
			 * 
			 * }
			 */

			// System.out.println("dataList.size() :::::::: "+dataList.size());

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeResources(mysqlConn, st, rs);

		}

		return dataList;
	}

	/**
	 * 
	 * @param startDate
	 * @param endDate
	 * @param processName
	 * @param status
	 * @return
	 */
	public List<Data> getSLAListByStatus(String startDate, String endDate, String processName, String status) {
		Connection mysqlConn = null;
		Statement st = null;
		Data data = null;
		List<Data> dataList = null;
		ResultSet rs = null;
		try {

			String sql = " select (select count(*)count from group_sla_view ) as totaltransaction, sv.process_name, sv.worker, sv.country, count(*) regionwise_count, "
					+ " case when sv.duration >= sv.sla then 'Breached' else 'Achieved' end  as status, st.sequence as sequence"
					+ " from group_sla_view sv, sequence_temp st "
					+ " where worker_status = '0' and  process_id = (select id from groups where isDisabled = '0'  and id = process_id ) and "
					+ " sv.process_name = st.process_name "
					+ " group by sv.process_name, sv.worker_status, sv.country order by sequence";

			System.out.println(sql);
			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);

			dataList = new ArrayList<Data>();
			while (rs.next()) {
				if (processName.equalsIgnoreCase(rs.getString("process_name"))) {
					if (status.equalsIgnoreCase(rs.getString("status"))) {

						data = new Data();
						data.setCountry(rs.getString("country"));
						data.setTotalTransactions(rs.getLong("regionwise_count"));
						long rcount = rs.getLong("regionwise_count");
						long tcount = rs.getLong("totaltransaction");
						double totalPer = getPercentage(rcount, tcount);
						data.setTotalPer(totalPer);
						dataList.add(data);
					}

				}
			}
			/*
			 * if(processName.equalsIgnoreCase(Constants.CREATE_FNOL)){
			 * if(status.equalsIgnoreCase(Constants.STATUS_ACHIEVED)){
			 * 
			 * data = new Data(); data.setRegion("US");
			 * data.setTotalTransactions(Long.parseLong("1500"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("UK");
			 * data.setTotalTransactions(Long.parseLong("1400"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Canada");
			 * data.setTotalTransactions(Long.parseLong("1600"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Singapore");
			 * data.setTotalTransactions(Long.parseLong("1500"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * 
			 * } else if(status.equalsIgnoreCase(Constants.STATUS_BREACHEDF)){
			 * 
			 * data = new Data(); data.setRegion("US");
			 * data.setTotalTransactions(Long.parseLong("155"));
			 * data.setTotalPer(Double.parseDouble("9")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("UK");
			 * data.setTotalTransactions(Long.parseLong("145"));
			 * data.setTotalPer(Double.parseDouble("9")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Canada");
			 * data.setTotalTransactions(Long.parseLong("165"));
			 * data.setTotalPer(Double.parseDouble("9")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Singapore");
			 * data.setTotalTransactions(Long.parseLong("155"));
			 * data.setTotalPer(Double.parseDouble("9")); dataList.add(data); }
			 * else if(status.equalsIgnoreCase(Constants.STATUS_BREACHEDA)){
			 * data = new Data(); data.setRegion("US");
			 * data.setTotalTransactions(Long.parseLong("45"));
			 * data.setTotalPer(Double.parseDouble("3")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("UK");
			 * data.setTotalTransactions(Long.parseLong("35"));
			 * data.setTotalPer(Double.parseDouble("2")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Canada");
			 * data.setTotalTransactions(Long.parseLong("55"));
			 * data.setTotalPer(Double.parseDouble("3")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Singapore");
			 * data.setTotalTransactions(Long.parseLong("45"));
			 * data.setTotalPer(Double.parseDouble("3")); dataList.add(data);
			 * 
			 * }
			 * 
			 * } else
			 * if(processName.equalsIgnoreCase(Constants.ADJUDICATE_CLAIM)){
			 * if(status.equalsIgnoreCase(Constants.STATUS_ACHIEVED)){
			 * 
			 * data = new Data(); data.setRegion("US");
			 * data.setTotalTransactions(Long.parseLong("1350"));
			 * data.setTotalPer(Double.parseDouble("89")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("UK");
			 * data.setTotalTransactions(Long.parseLong("1400"));
			 * data.setTotalPer(Double.parseDouble("91")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Canada");
			 * data.setTotalTransactions(Long.parseLong("1300"));
			 * data.setTotalPer(Double.parseDouble("90")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Singapore");
			 * data.setTotalTransactions(Long.parseLong("1350"));
			 * data.setTotalPer(Double.parseDouble("90")); dataList.add(data);
			 * 
			 * } else if(status.equalsIgnoreCase(Constants.STATUS_BREACHEDF)){
			 * 
			 * data = new Data(); data.setRegion("US");
			 * data.setTotalTransactions(Long.parseLong("120"));
			 * data.setTotalPer(Double.parseDouble("9")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("UK");
			 * data.setTotalTransactions(Long.parseLong("110"));
			 * data.setTotalPer(Double.parseDouble("8")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Canada");
			 * data.setTotalTransactions(Long.parseLong("130"));
			 * data.setTotalPer(Double.parseDouble("9")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Singapore");
			 * data.setTotalTransactions(Long.parseLong("120"));
			 * data.setTotalPer(Double.parseDouble("8")); dataList.add(data); }
			 * else if(status.equalsIgnoreCase(Constants.STATUS_BREACHEDA)){
			 * data = new Data(); data.setRegion("US");
			 * data.setTotalTransactions(Long.parseLong("30"));
			 * data.setTotalPer(Double.parseDouble("2")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("UK");
			 * data.setTotalTransactions(Long.parseLong("20"));
			 * data.setTotalPer(Double.parseDouble("1")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Canada");
			 * data.setTotalTransactions(Long.parseLong("20"));
			 * data.setTotalPer(Double.parseDouble("1")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Singapore");
			 * data.setTotalTransactions(Long.parseLong("30"));
			 * data.setTotalPer(Double.parseDouble("2")); dataList.add(data);
			 * 
			 * }
			 * 
			 * 
			 * 
			 * } else if(processName.equalsIgnoreCase(Constants.APPROVE_CLAIM)){
			 * if(status.equalsIgnoreCase(Constants.STATUS_ACHIEVED)){
			 * 
			 * data = new Data(); data.setRegion("US");
			 * data.setTotalTransactions(Long.parseLong("250"));
			 * data.setTotalPer(Double.parseDouble("19")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("UK");
			 * data.setTotalTransactions(Long.parseLong("240"));
			 * data.setTotalPer(Double.parseDouble("24")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Canada");
			 * data.setTotalTransactions(Long.parseLong("260"));
			 * data.setTotalPer(Double.parseDouble("20")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Singapore");
			 * data.setTotalTransactions(Long.parseLong("260"));
			 * data.setTotalPer(Double.parseDouble("19")); dataList.add(data);
			 * 
			 * } else if(status.equalsIgnoreCase(Constants.STATUS_BREACHEDF)){
			 * 
			 * data = new Data(); data.setRegion("US");
			 * data.setTotalTransactions(Long.parseLong("780"));
			 * data.setTotalPer(Double.parseDouble("58")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("UK");
			 * data.setTotalTransactions(Long.parseLong("770"));
			 * data.setTotalPer(Double.parseDouble("57")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Canada");
			 * data.setTotalTransactions(Long.parseLong("790"));
			 * data.setTotalPer(Double.parseDouble("51")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Singapore");
			 * data.setTotalTransactions(Long.parseLong("780"));
			 * data.setTotalPer(Double.parseDouble("58")); dataList.add(data); }
			 * else if(status.equalsIgnoreCase(Constants.STATUS_BREACHEDA)){
			 * data = new Data(); data.setRegion("US");
			 * data.setTotalTransactions(Long.parseLong("240"));
			 * data.setTotalPer(Double.parseDouble("33")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("UK");
			 * data.setTotalTransactions(Long.parseLong("250"));
			 * data.setTotalPer(Double.parseDouble("29")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Canada");
			 * data.setTotalTransactions(Long.parseLong("260"));
			 * data.setTotalPer(Double.parseDouble("29")); dataList.add(data);
			 * 
			 * data = new Data(); data.setRegion("Singapore");
			 * data.setTotalTransactions(Long.parseLong("250"));
			 * data.setTotalPer(Double.parseDouble("33")); dataList.add(data);
			 * 
			 * } }
			 */

			// System.out.println("dataList.size() :::::::: "+dataList.size());

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeResources(mysqlConn, st, rs);

		}

		return dataList;
	}

	/**
	 * 
	 * @param startDate
	 * @param endDate
	 * @param region
	 * @param status
	 * @param groupBy
	 * @return
	 */
	public List<Data> getSLAListByRegion(String startDate, String endDate, String region, String status, String groupBy,
			String function) {
		Connection mysqlConn = null;
		Statement st = null;
		Data data = null;
		List<Data> dataList = null;
		ResultSet rs = null;
		try {
			String mode = "";
			if (groupBy.equalsIgnoreCase("Daily")) {
				mode = "%m/%d/%Y";
			} else if (groupBy.equalsIgnoreCase("Monthly")) {
				mode = "%M/%Y";
			} else if (groupBy.equalsIgnoreCase("Yearly")) {
				mode = "%Y";
			}

			String sql;
			if (function == null || function.isEmpty()) {
				sql = "select  count(*) Statuscount, DATE_FORMAT(START_TIME, '" + mode
						+ "') as transactiondate,(select count(*)count from group_sla_view ) as totalcount, process_name,country,case when duration>=sla then 'Breached' else 'Achieved' end  as Status from group_sla_view where worker_status = '0' and process_id = (select id from groups where isDisabled = '0'  and id = process_id ) group by transactiondate,process_name,country,Status";
			} else {
				sql = "select  count(*) Statuscount, DATE_FORMAT(START_TIME, '" + mode
						+ "') as transactiondate,(select count(*)count from group_sla_view ) as totalcount, process_name,country,case when duration>=sla then 'Breached' else 'Achieved' end  as Status from group_sla_view v, "
						+ "groups pg, groups fg where v.process_id = pg.id and pg.Parent_Id = fg.id and fg.Type= 'function' and fg.Name = '"
						+ function
						+ "' and worker_status = '0' and process_id = (select id from groups where isDisabled = '0'  and id = process_id ) group by transactiondate,process_name,country,Status";
			}

			// System.out.println(sql);
			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);

			dataList = new ArrayList<Data>();
			while (rs.next()) {

				if (status.equalsIgnoreCase(rs.getString("status"))) {
					if (region.equalsIgnoreCase(rs.getString("country"))) {

						data = new Data();
						data.setProcessName(rs.getString("process_name"));
						data.setTransactionDate(rs.getString("transactiondate"));
						data.setTotalTransactions(rs.getLong("Statuscount"));
						long rcount = rs.getLong("Statuscount");
						long tcount = rs.getLong("totalcount");
						double totalPer = getPercentage(rcount, tcount);
						data.setTotalPer(totalPer);
						dataList.add(data);
						// System.out.println(" PN "+data.getProcessName()+" TD
						// "+data.getTransactionDate()+" TT
						// "+data.getTotalTransactions()+" TP
						// "+data.getTotalPer());
					}
				}

			}
			// select DATE_FORMAT(START_TIME, '%m/%d/%Y') as
			// transactiondate,(select count(*)count from sla_view ) as
			// totaltrans, process_name,geography,case when duration>=sla then
			// 'Breached' else 'Achieved' end as Status from sla_view group by
			// transactiondate;
			/*
			 * dataList = new ArrayList<Data>();
			 * 
			 * if(status.equalsIgnoreCase(Constants.STATUS_ACHIEVED)){
			 * 
			 * if(region.equalsIgnoreCase("US")){
			 * 
			 * if(groupBy.equalsIgnoreCase(Constants.DAILY)){
			 * 
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/01/2017");
			 * data.setTotalTransactions(Long.parseLong("150"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/02/2017");
			 * data.setTotalTransactions(Long.parseLong("140"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/03/2017");
			 * data.setTotalTransactions(Long.parseLong("160"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/04/2017");
			 * data.setTotalTransactions(Long.parseLong("150"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/05/2017");
			 * data.setTotalTransactions(Long.parseLong("170"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/06/2017");
			 * data.setTotalTransactions(Long.parseLong("130"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/07/2017");
			 * data.setTotalTransactions(Long.parseLong("140"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/08/2017");
			 * data.setTotalTransactions(Long.parseLong("150"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/09/2017");
			 * data.setTotalTransactions(Long.parseLong("160"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/10/2017");
			 * data.setTotalTransactions(Long.parseLong("150"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * 
			 * 
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/01/2017");
			 * data.setTotalTransactions(Long.parseLong("25"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/02/2017");
			 * data.setTotalTransactions(Long.parseLong("20"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/03/2017");
			 * data.setTotalTransactions(Long.parseLong("30"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/04/2017");
			 * data.setTotalTransactions(Long.parseLong("35"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/05/2017");
			 * data.setTotalTransactions(Long.parseLong("15"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/06/2017");
			 * data.setTotalTransactions(Long.parseLong("20"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/07/2017");
			 * data.setTotalTransactions(Long.parseLong("30"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/08/2017");
			 * data.setTotalTransactions(Long.parseLong("25"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/09/2017");
			 * data.setTotalTransactions(Long.parseLong("30"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/10/2017");
			 * data.setTotalTransactions(Long.parseLong("20"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * 
			 * 
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/01/2017");
			 * data.setTotalTransactions(Long.parseLong("135"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/02/2017");
			 * data.setTotalTransactions(Long.parseLong("120"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/03/2017");
			 * data.setTotalTransactions(Long.parseLong("150"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/04/2017");
			 * data.setTotalTransactions(Long.parseLong("125"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/05/2017");
			 * data.setTotalTransactions(Long.parseLong("145"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/06/2017");
			 * data.setTotalTransactions(Long.parseLong("135"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/07/2017");
			 * data.setTotalTransactions(Long.parseLong("145"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/08/2017");
			 * data.setTotalTransactions(Long.parseLong("125"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/09/2017");
			 * data.setTotalTransactions(Long.parseLong("130"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/10/2017");
			 * data.setTotalTransactions(Long.parseLong("140"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data); }
			 * else if(groupBy.equalsIgnoreCase(Constants.MONTHLY)){ data = new
			 * Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("April");
			 * data.setTotalTransactions(Long.parseLong("1500"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("April");
			 * data.setTotalTransactions(Long.parseLong("1350"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("April");
			 * data.setTotalTransactions(Long.parseLong("250"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * 
			 * } else if(groupBy.equalsIgnoreCase(Constants.YEARLY)){ data = new
			 * Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("2017");
			 * data.setTotalTransactions(Long.parseLong("1500"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("2017");
			 * data.setTotalTransactions(Long.parseLong("1350"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("2017");
			 * data.setTotalTransactions(Long.parseLong("250"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data); }
			 * 
			 * }
			 * 
			 * 
			 * 
			 * 
			 * } else if(status.equalsIgnoreCase(Constants.STATUS_BREACHED)){
			 * 
			 * if(region.equalsIgnoreCase("US")){
			 * 
			 * if(groupBy.equalsIgnoreCase(Constants.DAILY)){
			 * 
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/01/2017");
			 * data.setTotalTransactions(Long.parseLong("20"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/02/2017");
			 * data.setTotalTransactions(Long.parseLong("15"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/03/2017");
			 * data.setTotalTransactions(Long.parseLong("25"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/04/2017");
			 * data.setTotalTransactions(Long.parseLong("18"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/05/2017");
			 * data.setTotalTransactions(Long.parseLong("22"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/06/2017");
			 * data.setTotalTransactions(Long.parseLong("19"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/07/2017");
			 * data.setTotalTransactions(Long.parseLong("21"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/08/2017");
			 * data.setTotalTransactions(Long.parseLong("20"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/09/2017");
			 * data.setTotalTransactions(Long.parseLong("16"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("04/10/2017");
			 * data.setTotalTransactions(Long.parseLong("24"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * 
			 * 
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/01/2017");
			 * data.setTotalTransactions(Long.parseLong("102"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/02/2017");
			 * data.setTotalTransactions(Long.parseLong("100"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/03/2017");
			 * data.setTotalTransactions(Long.parseLong("103"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/04/2017");
			 * data.setTotalTransactions(Long.parseLong("101"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/05/2017");
			 * data.setTotalTransactions(Long.parseLong("92"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/06/2017");
			 * data.setTotalTransactions(Long.parseLong("114"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/07/2017");
			 * data.setTotalTransactions(Long.parseLong("102"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/08/2017");
			 * data.setTotalTransactions(Long.parseLong("100"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/09/2017");
			 * data.setTotalTransactions(Long.parseLong("104"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("04/10/2017");
			 * data.setTotalTransactions(Long.parseLong("102"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * 
			 * 
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/01/2017");
			 * data.setTotalTransactions(Long.parseLong("15"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/02/2017");
			 * data.setTotalTransactions(Long.parseLong("12"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/03/2017");
			 * data.setTotalTransactions(Long.parseLong("18"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/04/2017");
			 * data.setTotalTransactions(Long.parseLong("15"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/05/2017");
			 * data.setTotalTransactions(Long.parseLong("14"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/06/2017");
			 * data.setTotalTransactions(Long.parseLong("16"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/07/2017");
			 * data.setTotalTransactions(Long.parseLong("14"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/08/2017");
			 * data.setTotalTransactions(Long.parseLong("15"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/09/2017");
			 * data.setTotalTransactions(Long.parseLong("16"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("04/10/2017");
			 * data.setTotalTransactions(Long.parseLong("15"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data); }
			 * else if(groupBy.equalsIgnoreCase(Constants.MONTHLY)){ data = new
			 * Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("April");
			 * data.setTotalTransactions(Long.parseLong("200"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("April");
			 * data.setTotalTransactions(Long.parseLong("150"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("April");
			 * data.setTotalTransactions(Long.parseLong("1020"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * 
			 * } else if(groupBy.equalsIgnoreCase(Constants.YEARLY)){ data = new
			 * Data(); data.setProcessName(Constants.CREATE_FNOL);
			 * data.setTransactionDate("2017");
			 * data.setTotalTransactions(Long.parseLong("200"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data();
			 * data.setProcessName(Constants.ADJUDICATE_CLAIM);
			 * data.setTransactionDate("2017");
			 * data.setTotalTransactions(Long.parseLong("150"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data);
			 * data = new Data(); data.setProcessName(Constants.APPROVE_CLAIM);
			 * data.setTransactionDate("2017");
			 * data.setTotalTransactions(Long.parseLong("1020"));
			 * data.setTotalPer(Double.parseDouble("88")); dataList.add(data); }
			 * 
			 * 
			 * 
			 * 
			 * 
			 * }}
			 */

			// System.out.println("dataList.size() :::::::: "+dataList.size());

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeResources(mysqlConn, st, rs);

		}

		return dataList;
	}
}
