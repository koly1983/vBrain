/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vbrain.dao.impl;

import com.vbrain.adapter.CommonDbAdapter;
import com.vbrain.adapter.impl.CommonDbAdapterImpl;
import com.vbrain.common.api.ApiManager;
import com.vbrain.common.util.Converters;
import com.vbrain.common.util.EmailManager;
import com.vbrain.common.util.WFEmail;
import com.vbrain.dao.OcrJobTracker;
import com.vbrain.hibernate.model.Email;
import com.vbrain.hibernate.model.EmailStatus;
import com.vbrain.hibernate.model.OcrData;
import com.vbrain.hibernate.model.OcrProperties;
import com.vbrain.nodemonitor.OcrSummaryApiReader;
import com.vbrain.nodemonitor.model.OcrStatuses;
import com.vbrain.nodemonitor.model.OcrSummary;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.apache.wink.json4j.JSONArray;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author llihind
 */
public class OcrJobTrackerImpl implements OcrJobTracker {

    private CommonDbAdapter dbAdapter;

	public OcrJobTrackerImpl() {
        dbAdapter = new CommonDbAdapterImpl();
    }

    @Override
    public OcrSummary readOcrSummary(String url) throws Exception {
        OcrSummary ocrSummary = new OcrSummary();

        ApiManager apiManager = new ApiManager(new OcrSummaryApiReader());

        try {
            String output = apiManager.executeCall(url);

            Document doc = Jsoup.parse(output);

            Elements eles = doc.getElementsByTag("message");

            for (Element ele : eles) {
                if (ele.text().contains(OcrStatuses.QUEUED.toString())) {
                    String queuedStr = ele.parent().getElementsByTag("tasksCount").text();
                    ocrSummary.setQueued(Integer.parseInt(queuedStr));
                } else if (ele.text().contains(OcrStatuses.INPROGRESS.toString())) {
                    String inprogressStr = ele.parent().getElementsByTag("tasksCount").text();
                    ocrSummary.setInprogress(Integer.parseInt(inprogressStr));
                } else if (ele.text().contains(OcrStatuses.COMPLETED.toString())) {
                    String completedStr = ele.parent().getElementsByTag("tasksCount").text();
                    ocrSummary.setCompleted(Integer.parseInt(completedStr));
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return ocrSummary;
    }

    @Override
    public void handleOcrStatus(OcrSummary ocrSummary) throws Exception {
        OcrProperties jobLimit = (OcrProperties) dbAdapter.readDataObjfromTable(OcrProperties.class, Collections.emptyMap());
        int maxJobs = jobLimit.getMaxJobs();

        if (ocrSummary.getInprogress() > maxJobs || ocrSummary.getQueued() > maxJobs) {
            //Preparing and sending email out
            EmailStatus emailStatus = (EmailStatus) dbAdapter.readDataObjfromTable(EmailStatus.class, Collections.emptyMap());
            if (emailStatus.isStatus()) {
                Logger log = LoggerFactory.getLogger(OcrJobTrackerImpl.class);
                List<Email> emailClients = dbAdapter.readDataListfromTable(Email.class, Collections.emptyMap());
                String[] to = Converters.converterEmailList("to", emailClients);
                String[] cc = Converters.converterEmailList("cc", emailClients);

                WFEmail email = new WFEmail(log, to, cc, "WARNING : OCR Queue Detected", EmailManager.getOcrEmailBody(ocrSummary.getQueued(), ocrSummary.getInprogress()), WFEmail.HIGH_IMPORTANCE);
                email.sendHTML();
            }
        }

        //Adding data to OCR Data table
        OcrData ocrData = new OcrData();
        ocrData.setCompleted(ocrSummary.getCompleted());
        ocrData.setQueued(ocrSummary.getQueued());
        ocrData.setInProgress(ocrSummary.getInprogress());
        ocrData.setTimestamp(new Date());
        dbAdapter.insertDataToTable(ocrData);
    }

    @Override
    public void handleOcrLicenseStatus(String url, int threshold) throws Exception {
        ApiManager apiManager = new ApiManager(new OcrSummaryApiReader());

        try {
            String output = apiManager.executeCall(url);
            JSONArray jsnAry = new JSONArray(output);

            int volume = Integer.parseInt(jsnAry.getJSONObject(0).getString("volume"));
            int volumeRemaining = Integer.parseInt(jsnAry.getJSONObject(0).getString("volumeRemaining"));

            if (volume - volumeRemaining < threshold) {
                //Preparing and sending email out
                EmailStatus emailStatus = (EmailStatus) dbAdapter.readDataObjfromTable(EmailStatus.class, Collections.emptyMap());
                if (emailStatus.isStatus()) {
                    Logger log = LoggerFactory.getLogger(OcrJobTrackerImpl.class);
                    List<Email> emailClients = dbAdapter.readDataListfromTable(Email.class, Collections.emptyMap());
                    String[] to = Converters.converterEmailList("to", emailClients);
                    String[] cc = Converters.converterEmailList("cc", emailClients);

                    WFEmail email = new WFEmail(log, to, cc, "WARNING : OCR Lisence Running Low", EmailManager.getOcrLicenseEmailBody(volume, volumeRemaining), WFEmail.HIGH_IMPORTANCE);
                    email.sendHTML();
                }
            }

        } catch (Exception ex) {
            throw new Exception("OCR License status request failed with : " + ex);
        }
    }

    @Override
    public void cleanUpOcrData() throws Exception {
        try {
            dbAdapter.clearTable(OcrData.class);
        } catch (Exception e) {
            throw new Exception("OCR data cleanup failed with : "+e);
        }
    }

	@Override
	public void finalizeSynchronizer() {
		dbAdapter.getSession().clear();
        dbAdapter.getSession().close();
		
	}

}
