package com.vbrain.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.vbrain.common.io.Constants;
import com.vbrain.common.io.Data;
import com.vbrain.common.io.Privilage;
import com.vbrain.common.io.Role;
import com.vbrain.common.io.User;
import com.vbrain.dao.UserDao;

public class UserDaoImpl extends ConnectionDaoImpl implements  UserDao{

	/**
	 * 
	 * @param startDate
	 * @param endDate
	 * @param workStep
	 * @param groupBy
	 * @return
	 */
	public List<User> getUsers(){
		Connection mysqlConn = null;
		Statement st = null;
		User user = null;
		List<User> userList = null;
		ResultSet rs = null;
		try{

			String sql = "SELECT u.ID ID, u.User_Id User_Id, u.First_Name First_Name, u.Last_Name Last_Name, u.Role_Id Role_Id, r.Name Role_Name  FROM users u, role r "+
						 "  Where u.role_id = r.id and u.isDisabled = '0' and r.isDisabled = '0' ";

			System.out.println("sql :::: "+sql);

			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);
			userList = new ArrayList<User>();
			
			while(rs.next()){
				user = new User();
				user.setId(rs.getString("ID"));
				user.setUserId(rs.getString("User_Id"));
				user.setFirstName(rs.getString("First_Name"));
				//user.setSurName(rs.getString("Sur_Name"));
				user.setLastName(rs.getString("Last_Name"));
				user.setRoleId(rs.getString("Role_Id"));
				user.setRole(rs.getString("Role_Name"));

				userList.add(user);
			}

			
			System.out.println("dataList.size() :::::::: "+userList.size());

		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			closeResources(mysqlConn, st, rs);
		} 

		return userList;
	}
	
	public User getUser(String userId){
		Connection mysqlConn = null;
		Statement st = null;
		User user = null;
		
		ResultSet rs = null;
		try{

			
			String sql = "SELECT u.ID ID, u.User_Id User_Id, u.First_Name First_Name, u.Last_Name Last_Name, u.Role_Id Role_Id, u.password password, r.Name Role_Name  FROM users u, role r "+
					 "  Where u.id = '"+userId+"' u.role_id = r.id and isDisabled = '0' ";

			System.out.println("sql :::: "+sql);
	
			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);
			
			
			while(rs.next()){
				user = new User();
				user.setId(rs.getString("ID"));
				user.setUserId(rs.getString("User_Id"));
				user.setFirstName(rs.getString("First_Name"));
				user.setLastName(rs.getString("Last_Name"));
				user.setRoleId(rs.getString("Role_Id"));
				user.setRole(rs.getString("Role_Name"));
				user.setPassword(rs.getString("password"));
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			closeResources(mysqlConn, st, rs);
		} 

		return user;
	}
	
	
	public User getUserPrivilage(String userId, String password){
		Connection mysqlConn = null;
		Statement st = null;
		User user = null;
		
		ResultSet rs = null;
		try{

			
			String sql = "SELECT u.ID ID, u.User_Id User_Id, u.First_Name First_Name, u.Last_Name Last_Name, u.Role_Id Role_Id, u.password password, r.Name Role_Name  FROM users u, role r "+
					 "  Where BINARY u.user_id = '"+userId+"' and BINARY password = '"+password+"' and u.isDisabled = '0' and r.isDisabled = '0' and u.role_id = r.id";

			System.out.println("sql :::: "+sql);
	
			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);
			
			
			while(rs.next()){
				user = new User();
				user.setId(rs.getString("ID"));
				user.setUserId(rs.getString("User_Id"));
				user.setFirstName(rs.getString("First_Name"));
				user.setLastName(rs.getString("Last_Name"));
				user.setRoleId(rs.getString("Role_Id"));
				user.setRole(rs.getString("Role_Name"));
				
				user.setPassword(rs.getString("password"));
				
				user.setPrivilages( getPrivilages(rs.getString("Role_Id")) );
				
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			closeResources(mysqlConn, st, rs);
		} 

		return user;
	}
	
	
	private List<Privilage> getPrivilages(String roleId){
		Connection mysqlConn = null;
		Statement st = null;
		Privilage privilage = null;
		List<Privilage> privilages = null;
		ResultSet rs = null;
		try{

			
			String sql = 	" SELECT p.access access, f.category category, f.name functionName, r.Name roleName"+
							" FROM privilage p, functions f, role r "+
							" Where r.id = '"+roleId+"' and p.role_id = r.id and f.id = p.function_id  ";

			System.out.println("sql :::: "+sql);
	
			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);
			privilages = new ArrayList<Privilage>();
			
			while(rs.next()){
				privilage = new Privilage();
				
				privilage.setAccess(rs.getString("access"));
				privilage.setCategory(rs.getString("category"));
				privilage.setFunctionName(rs.getString("functionName"));
				privilage.setRoleName(rs.getString("roleName"));
				
				privilages.add(privilage);
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			closeResources(mysqlConn, st, rs);
		} 

		return privilages;
	}
	
	
	public List<Role> getUserRoles(){
		Connection mysqlConn = null;
		Statement st = null;
		Role role = null;
		List<Role> roleList = null;
		ResultSet rs = null;
		try{

			String sql = "Select * from role order by Name ";

			System.out.println("sql :::: "+sql);

			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);
			roleList = new ArrayList<Role>();
			
			while(rs.next()){
				role = new Role();
				role.setId(rs.getString("ID"));
				role.setName(rs.getString("Name"));
				role.setDescription(rs.getString("Description"));
				role.setIsDisabled(rs.getString("isDisabled"));

				roleList.add(role);
			}

			
			System.out.println("roleList.size() :::::::: "+roleList.size());

		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			closeResources(mysqlConn, st, rs);
		} 

		return roleList;
	}
	
	private int isDuplicateUser(String userId, String mode, String id){
    	Connection mysqlConn = null;
        Statement st = null;
        ResultSet rs = null;
        
        
    	try{
    		
    		String sql = 	"SELECT * FROM users where user_Id = '"+userId+"' ";
    		if("edit".equalsIgnoreCase(mode)){
    			sql = 	"SELECT * FROM users where user_Id = '"+userId+"' and id != '"+id+"' ";
    		}
    		mysqlConn = getMySqlConnection();
    		st = mysqlConn.createStatement();
    		rs = st.executeQuery(sql);
    		
    		if(rs.next()){
    			return 1;
    		}
    		else {
    			return 0;
    		}
    		
    	}
    	catch(Exception e){
    		e.printStackTrace();
    		return 2;
    	}
    	finally {
    		boolean closedResources = closeResources(mysqlConn, st, rs);
    		if(!closedResources) {
        		return 2;
        	}
        } 

    	
    }
	
 	public int addUser(User user){

		// Connection oracleConn = null;
		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		//ResultSet rs = null;
		try {

			if(user != null ){

				String tQuery = "";

				System.out.println("user    =" + user);
				//System.out.println("processId   =" + processId);
				
				int isDuplicateUser = isDuplicateUser(user.getUserId(), "add", "");
				
				if(isDuplicateUser == 0){
					
					mysqlConn = getMySqlConnection();
					tQuery = "INSERT INTO users "+
							"(User_Id, First_Name, Last_Name, Role_Id, Password) "+
							"VALUES (" +
							" '"+user.getUserId()+"', "+
							" '"+user.getFirstName()+"', "+
							" '"+user.getLastName()+"', "+
							" '"+user.getRoleId()+"', 'welcome01' )";
					
					System.out.println("tQuery ::::::: "+tQuery);
	
					st = mysqlConn.createStatement();
	
					result = st.executeUpdate(tQuery);
	
					System.out.println("Add User result :::::::::: "+result);
				}
				else {
					result = 2;
				}
			}
		} 
		catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			result = 0;
			//System.exit(1);
		} 
		finally {
			// release database resources
			//oracleConn.close();
			boolean closedResources = closeResources(mysqlConn, st, null);
			if(!closedResources) {
        		result = 0;
        	}
		}

		return result;
	}
 	
 	
 	public int editUser(User user){

		// Connection oracleConn = null;
		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		//ResultSet rs = null;
		try {

			if(user != null ){

				String tQuery = "";

				System.out.println("user    =" + user.getId());
				//System.out.println("processId   =" + processId);
				
				int isDuplicateUser = isDuplicateUser(user.getUserId(), "edit", user.getId());
				
				if(isDuplicateUser == 0){
				
					mysqlConn = getMySqlConnection();
	
					tQuery = "Update users "+
							" Set User_Id = '"+user.getUserId()+"', First_Name  = '"+user.getFirstName()+"', Last_Name  = '"+user.getLastName()+"',  "+
							" Role_Id = '"+user.getRoleId()+"' where id = '"+user.getId()+"' ";
					
					System.out.println("tQuery ::::::: "+tQuery);
	
					st = mysqlConn.createStatement();
	
					result = st.executeUpdate(tQuery);
	
					System.out.println("Update User result :::::::::: "+result);
				}
				else {
					result = 2;
				}
			}
		} 
		catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			result = 0;
			//System.exit(1);
		} 
		finally {
			// release database resources
			//oracleConn.close();
			boolean closedResources = closeResources(mysqlConn, st, null);
			if(!closedResources) {
        		result = 0;
        	}
		}

		return result;
	}
 	
 	
 	public int disableUser(String userId){

		// Connection oracleConn = null;
		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		//ResultSet rs = null;
		try {

			if(userId != null && userId.trim().length() > 0 ){

				String tQuery = "";

				System.out.println("userId    =" + userId);
				//System.out.println("processId   =" + processId);
				
				mysqlConn = getMySqlConnection();

				tQuery = "Update users "+
						" Set isDisabled = '1' where ID  = '"+userId+"' ";
						
				
				System.out.println("tQuery ::::::: "+tQuery);

				st = mysqlConn.createStatement();

				result = st.executeUpdate(tQuery);

				System.out.println("disable User result :::::::::: "+result);
			}
		} 
		catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			result = 0;
			//System.exit(1);
		} 
		finally {
			// release database resources
			//oracleConn.close();
			boolean closedResources = closeResources(mysqlConn, st, null);
			if(!closedResources) {
        		result = 0;
        	}
		}

		return result;
	}
 	
 	
 	
 
	

}
