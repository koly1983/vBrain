package com.vbrain.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.vbrain.common.exception.AdapterException;
import com.vbrain.dao.VbrainDBAdapter;
import com.vbrain.db.connection.VBrainDbManager;

public class VbrainDBAdapterImpl implements VbrainDBAdapter {
	
    /**
     * Used to Retrieve Data from database and load the data to String array and return as list.
     * @query query retrieved from Properties file and passed as parameter
     * @parameters Array of parameters used to set for prepared statement
     * @parameters Vbrain Database connection
     * @return List with the data fetch from resultSet
     */
    public List<String[]> getDataFromTable(String query, String[] parameters, Connection connObjVb) {
        List<String[]> result = new ArrayList<String[]>();        
        PreparedStatement readData = null;
        ResultSet resultSet = null;
        try{
            if(connObjVb == null) {
                throw new AdapterException("MYSQL DB Connection Not found");
            }
            
            if(query == null || query.isEmpty()) {
                throw new AdapterException("Invalid Query: " + query);
            }
            System.out.println("VbrainDBAdapterImpl : getDataFromTable : Select Query: " + query);
            readData = connObjVb.prepareStatement(query);
            int parameterIndex = 1;
            if( parameters != null && parameters.length > 0) {
                for(String parameter : parameters) {
                    readData.setString(parameterIndex++, parameter);
                }
            }
            resultSet = readData.executeQuery();
            resultSet.last();
            //int resultSetLength = resultSet.getRow();
            resultSet.beforeFirst();
            String rows[] = null;
            int rowIndex = 0 , resultSetIndex = 1;
            while(resultSet.next()){
                int columnCount = resultSet.getMetaData().getColumnCount();
                rows = new String[columnCount];
                for(int count = 0 ; count < columnCount ; count++) {
                    rows[rowIndex++] = resultSet.getString(resultSetIndex++);
                }
                result.add(rows);
                rows = null;resultSetIndex = 1;rowIndex = 0;
            }
        } catch(Exception ex){
            ex.printStackTrace();
        } finally {
            try{
                if (readData != null) {
                    readData.close();
                }
                if (resultSet != null) {
                    resultSet.close();
                }
            }
            catch(Exception e){
                e.printStackTrace();
                return null;
            }
        }
        return result;
    }
    
    /**
     * Method to insert data in to the Vbrain Table
     * 
     * @data List of String array to insert
     * @query insert query
     */
    public void insertData(List<String[]> data, String query, Connection connObjVb) {
        PreparedStatement readData = null;
        
        try{
            if(connObjVb == null) {
                throw new AdapterException("MYSQL DB Connection Not found");
            }
            
            if(data == null || data.isEmpty()) {
                throw new AdapterException("Invalid Data: " + data);
            }
            
            if(query == null || query.isEmpty()) {
                throw new AdapterException("Invalid Query: " + query);
            }
            System.out.println("VbrainDBAdapterImpl : Insert Query: " + query);
            readData = connObjVb.prepareStatement(query);
            readData = executePrepareStatement(readData, data, null);
            readData.executeUpdate();
        } catch(Exception ex){
            ex.printStackTrace();
        } finally {
            try{
                if (readData != null) {
                    readData.close();
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Method to insert data in to the Vbrain Table
     * 
     * @data List of String array to insert
     * @query insert query
     * @qParameter condition parameters
     */
    public void insertData(List<String[]> data, String query, List<String[]> qParameter, Connection connObjVb) {
        PreparedStatement readData = null;
        
        try{
            if(connObjVb == null) {
                throw new AdapterException("MYSQL DB Connection Not found");
            }
            
            if(data == null || data.isEmpty()) {
                throw new AdapterException("Invalid Data: " + data);
            }
            
            if(query == null || query.isEmpty()) {
                throw new AdapterException("Invalid Query: " + query);
            }
            System.out.println("VbrainDBAdapterImpl : Insert Query: " + query);
            readData = connObjVb.prepareStatement(query);
            
            readData = executePrepareStatement(readData, data, qParameter);
            //readData.executeUpdate();
        } catch(Exception ex){
            ex.printStackTrace();
        } finally {
            try{
                if (readData != null) {
                    readData.close();
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Method to update the query based on data and condition parameters
     * @pStatement prepared statement
     * @qParameter condition parameters
     */
    public PreparedStatement executePrepareStatement(PreparedStatement pStatement, List<String[]> data, List<String[]> qParameter) {
        try{
            if(data == null || data.isEmpty()) {
                throw new AdapterException("Invalid Data: " + data);
            }
            
            int conditionSize = data.size();
            if(qParameter != null && data.size() != qParameter.size()) {
               // throw new AdapterException("Invalid Data: " + data);
            	System.out.println("Different record sizes: "+ data.size() + " and " + qParameter.size());
            	conditionSize = Math.min(data.size(),qParameter.size());
            }
            
            int parameterIndex = 1, conditionIndex = 0;
            for(int i=0; i < conditionSize; i++) {
            	String[] dataArray = data.get(conditionIndex);
                for(String insertData : dataArray){
                    pStatement.setString(parameterIndex++, insertData);
                }
                if(qParameter != null && !qParameter.isEmpty()) {
                    String[] conditionArray = qParameter.get(conditionIndex);
                    for(String condition : conditionArray){
                        pStatement.setString(parameterIndex++, condition);
                    }
                }
                conditionIndex++;
                parameterIndex = 1;
                pStatement.executeUpdate();
            }
        } catch(Exception ex){
            ex.printStackTrace();
        }
        return pStatement;
    }
}
