package com.vbrain.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.vbrain.common.io.Constants;
import com.vbrain.common.io.Data;
import com.vbrain.common.io.Group;
import com.vbrain.common.io.RequestMessage;
import com.vbrain.common.io.Transactions;
import com.vbrain.dao.TransactionsDao;
import com.vbrain.dao.impl.ImportImpl.DbConnectionType;

public class TransactionDaoImpl extends ConnectionDaoImpl implements  TransactionsDao{

    private static final DecimalFormat df = new DecimalFormat("#.##");
    private static final DecimalFormat df1 = new DecimalFormat("#.###");
    private static List<Group> allGroups = null;
    
    
    
    /**
     * @return the allGroups
     */
    private static List<Group> getAllGroups() {
        return allGroups;
    }

    /**
     * @param allGroups the allGroups to set
     */
    private static void setAllGroups(List<Group> allGroups) {
        TransactionDaoImpl.allGroups = allGroups;
    }
    
    /**
     * 
     * @param startDate
     * @param endDate
     * @param workStep
     * @param groupBy
     * @return
     */
    public List<Data> getTransactionsWorkstepWise(String startDate, String endDate, String workStep, String groupBy, String function){
        Connection mysqlConn = null;
        Statement st = null;
        Data data = null;
        List<Data> dataList = null;
        ResultSet rs = null;
        try{

            String mode = "";
            if(groupBy.equalsIgnoreCase(Constants.DAILY)){
                mode = "%m/%d/%Y";
            }
            else if(groupBy.equalsIgnoreCase(Constants.MONTHLY)){
                mode = "%M/%Y";
            }
            else if(groupBy.equalsIgnoreCase(Constants.YEARLY)){
                mode = "%Y";
            }


            String sql = "select DATE_FORMAT(start_time, '"+mode+"') AS transactionDate, count(*) totalTransaction, process_id, process_name, sum(duration) totalDuration, sum(efforts_saved) effort_saved "+
                    " from group_transaction_view where tracking_id IS NOT NULL and status = '0' and worker_status = '0' and start_time >= STR_TO_DATE('"+startDate+"', '%m/%d/%Y') and end_time <=  DATE_ADD( STR_TO_DATE('"+endDate+"', '%m/%d/%Y'), INTERVAL 1 DAY) "+
                    " and function = '"+function+"' and process_name = '"+ workStep +"' "+
                    " group by transactionDate order by transactionDate";

            System.out.println("sql :::: "+sql);



            mysqlConn = getMySqlConnection();
            st = mysqlConn.createStatement();
            rs = st.executeQuery(sql);
            dataList = new ArrayList<Data>();
            int i = 1;
            double totalProcessionTime = 0.00;

            //if("Approve Claim".equalsIgnoreCase(workStep) ){
            //avgTT = 0.0;
            //}

            //int effortSavedVal = 0;
            while(rs.next()){
                data = new Data();
                data.setIndex(i++);
                data.setTransactionDate( rs.getString("transactionDate") );
                data.setTotalTransactions( rs.getLong("totalTransaction") );
                data.setProcessName(rs.getString("process_name"));
                totalProcessionTime = rs.getDouble("totalDuration")/60;

                data.setTotalTimeTaken(totalProcessionTime);

                //effortSavedVal = rs.getInt("effort_saved");

                double effortSaved = rs.getDouble("effort_saved")/60;

                data.setEffortSaved( Double.parseDouble(df.format(effortSaved)) );
                
                data.setAverageTimeTaken(totalProcessionTime/ rs.getLong("totalTransaction"));



                dataList.add(data);
            }

            System.out.println("dataList.size() :::::::: "+dataList.size());

        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            closeResources(mysqlConn, st, rs);
        } 

        return dataList;
    }
    
    /**
     * 
     * @param startDate
     * @param endDate
     * @param workStep
     * @param groupBy
     * @param function
     * @return
     */
    public List<Data> getTransactionsListWorkstepWise(String startDate, String endDate, String workStep, String groupBy, String function,String bp_uuid){
        Connection mysqlConn = null;
        Statement st = null;
        Data data = null;
        List<Data> dataList = null;
        ResultSet rs = null;
        try{

            String mode = "";
            if(groupBy.equalsIgnoreCase(Constants.DAILY)){
                mode = "%m/%d/%Y %h:%i:%s";
            }
            else if(groupBy.equalsIgnoreCase(Constants.MONTHLY)){
                mode = "%M/%Y";
            }
            else if(groupBy.equalsIgnoreCase(Constants.YEARLY)){
                mode = "%Y";
            }
            
            String sql = null;
            String transactionCountSql = null;
            
            sql = "select DATE_FORMAT(start_time, '"+mode+"') AS transactionDate, tracking_id, status, process_id, process_name, duration, efforts_saved, error_type, error_cat "+
                    " from group_transaction_view where tracking_id IS NOT NULL and status = '0' and worker_status = '0' and start_time >= STR_TO_DATE('"+startDate+"', '%m/%d/%Y') and end_time <=  DATE_ADD( STR_TO_DATE('"+endDate+"', '%m/%d/%Y'), INTERVAL 1 DAY) "+
                    " and function = '"+function+"'";
            
            transactionCountSql = "select count(*) totalTransaction from group_transaction_view where tracking_id IS NOT NULL and status = '0' "
                    + "and worker_status = '0' and start_time >= STR_TO_DATE('"+startDate+"', '%m/%d/%Y') and "
                            + "end_time <=  DATE_ADD( STR_TO_DATE('"+endDate+"', '%m/%d/%Y'), INTERVAL 1 DAY) and function = '"+function+"'";
            
	            if(workStep !=null){
		            sql = sql + " and process_name = '"+ workStep +"' ";
		            
		            transactionCountSql = transactionCountSql + " and process_name = '"+ workStep +"'";
	            }
	            if(bp_uuid != null) {
	            	sql = sql + " and bp_uuid='"+ bp_uuid +"'";
	            	transactionCountSql = transactionCountSql+ " and bp_uuid='"+ bp_uuid +"'";
	            }
	            	
        
            System.out.println("sql ::: "+sql);
            System.out.println("transactionCountSql :::: "+transactionCountSql);


            mysqlConn = getMySqlConnection();
            st = mysqlConn.createStatement();
            rs = st.executeQuery(transactionCountSql);
            Long totalTransaction = null; 
            while(rs.next()){
                totalTransaction = rs.getLong("totalTransaction");
            }
            rs = st.executeQuery(sql);
            
            dataList = new ArrayList<Data>();
            int i = 1;
            double totalProcessionTime = 0.00;

            //if("Approve Claim".equalsIgnoreCase(workStep) ){
            //avgTT = 0.0;
            //}

            //int effortSavedVal = 0;
            while(rs.next()){
                data = new Data();
                data.setIndex(i++);
                data.setTransactionDate( rs.getString("transactionDate") );
                data.setTotalTransactions(totalTransaction);
                data.setProcessName(rs.getString("process_name"));
                data.setTransactionID(rs.getString("tracking_id"));
                data.setTransactionStatus(rs.getString("status"));
                totalProcessionTime = rs.getDouble("duration")/60;

                data.setTotalTimeTaken(totalProcessionTime);

                //effortSavedVal = rs.getInt("effort_saved");

                double effortSaved = rs.getDouble("efforts_saved")/60;

                data.setEffortSaved( Double.parseDouble(df.format(effortSaved)) );
                
                data.setAverageTimeTaken(totalProcessionTime/ totalTransaction);

                data.setExceptionType(rs.getString("error_cat"));
                data.setExceptionDesc(rs.getString("error_type"));

                dataList.add(data);
            }

            System.out.println("dataList.size() :::::::: "+dataList.size());

        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            closeResources(mysqlConn, st, rs);
        } 

        return dataList;
    }

	public List<Data> getTransactionsListWorkstepWise_2(String startDate, String endDate, String workStep,String groupBy, String function, String bp_uuid) {
		Data data = null;
		List<Data> dataList = null;

		VBrainStoredProcedure tListSP = null;
		try {
			tListSP = new VBrainStoredProcedure("get_transactions_for_run_sp_3", Arrays.asList(bp_uuid, groupBy), true);
			ResultSet rs = tListSP.getResultSet();

			dataList = new ArrayList<Data>();
			int i = 1;
			double totalProcessionTime = 0.00;

			while (rs.next()) {
				data = new Data();
				data.setIndex(i++);
				data.setTransactionDate(rs.getString("transactionDate"));
				data.setProcessName(rs.getString("process_name"));
				data.setTransactionID(rs.getString("tracking_id"));
				data.setTransactionStatus(rs.getString("status"));
				totalProcessionTime = rs.getDouble("duration");

				data.setTotalTimeTaken(totalProcessionTime);

				double effortSaved = rs.getDouble("efforts_saved") / 60;

				data.setEffortSaved(Double.parseDouble(df.format(effortSaved)));

				data.setExceptionType(rs.getString("error_cat"));
				data.setExceptionDesc(rs.getString("error_type"));

				dataList.add(data);
			}

			System.out.println("dataList.size() :::::::: " + dataList.size());

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			tListSP.close();
		}

		return dataList;
	}
    
    public List<Data> getTransactionsWorkstepWise_2(String startDate, String endDate, String function){
        Data data = null;
        List<Data> dataList = null;
        
        VBrainStoredProcedure tListSP = null;
        try{
        	System.out.println("Function Is"+function);
        	if(function.trim().toLowerCase().contains("hana")) {
        		System.out.println("INSIDE HANA");
        		tListSP = new VBrainStoredProcedure("get_runs_for_hana_function_sp_3", Arrays.asList(function, startDate, endDate), true);
        	}
        	else {
        		System.out.println("INSIDE"+function);
        		tListSP = new VBrainStoredProcedure("get_runs_for_function_sp_3", Arrays.asList(function, startDate, endDate), true);
        	}
        	ResultSet rs = tListSP.getResultSet();
        	
            dataList = new ArrayList<Data>();
            int i = 0;
            double effortSaved = 0;
            //int effortSavedVal = 0;
            String processName = "";
            Data transactionData = null;
            List<Data> transactionList = new ArrayList<Data>();
            while(rs.next()){

                String sqlProcessName = rs.getString("processName");
                String sqlWorker = rs.getString("worker");
                String bp_uuid = rs.getString("bp_uuid");
                
                if(! processName.equalsIgnoreCase(sqlProcessName)){
                    if(i > 0){
                        data = new Data();
                        data.setProcessName(processName);
                        data.setTransactionList(transactionList);
                        dataList.add(data);
                        transactionList = new ArrayList<Data>();
                    }
                }

                transactionData = new Data();

                processName = sqlProcessName;

                transactionData.setTotalTransactions( rs.getLong("totalTransaction") );
                transactionData.setTotalTimeTaken( Double.parseDouble(df.format(rs.getDouble("Duration"))) );
                transactionData.setTotalWorker(rs.getLong("totalWorker"));
                transactionData.setFirstTransStartDateTime(rs.getString("first_trans_start_date_time"));
                transactionData.setWorker(sqlWorker);
                transactionData.setBp_uuid(bp_uuid);
                transactionData.setBusinessExceptionCount(rs.getLong("business_error"));
                transactionData.setTechnicalExceptionCount(rs.getLong("technical_error"));
                transactionData.setSuccesstransactionCount(rs.getLong("success"));
                
                if("BOT".equalsIgnoreCase(sqlWorker)){
                    effortSaved = rs.getDouble("Efforts_Saved") /60; 
                    transactionData.setEffortSaved( Double.parseDouble(df.format(effortSaved)) );
                }
                else {
                    transactionData.setEffortSaved(0.0);
                }
                transactionList.add(transactionData);

                System.out.println("processName :::::::: "+processName);
                System.out.println("rs.isLast() :::::::: "+rs.isLast());

                if(rs.isLast()){
                    data = new Data();
                    data.setProcessName(processName);
                    data.setTransactionList(transactionList);
                    dataList.add(data);
                }

                i++;

            }

            System.out.println("dataList For Transaction List.size() :::::::: "+dataList.size());

        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
        	tListSP.close();
        } 

        return dataList;
    }
    
    
    
    
    /**
     * 
     * @param startDate
     * @param endDate
     * @return
     */
    public List<Data> getTransactionsWorkstepWise(String startDate, String endDate, String function){
        Connection mysqlConn = null;
        Statement st = null;
        Data data = null;
        List<Data> dataList = null;
        ResultSet rs = null;
        try{

            String sql = "SELECT count(*) totalTransaction, vt.bp_uuid bp_uuid,count(distinct(vt.worker_id)) totalWorker, "+

                        "  vt.process_name processName, MIN(CAST(vt.start_time AS CHAR)) first_trans_start_date_time,"+
                        "  sum(vt.efforts_saved) Efforts_Saved, "+
                        "  sum(vt.duration) AS Duration, "+
                        "  vt.worker_type AS worker, "+
                        // TODO: check if we need to get this from config
                        "  COALESCE(sum(vt.error_cat = 1), 0) business_error, " +
                        "  COALESCE(sum(vt.error_cat = 2), 0) technical_error, " +
                        "  COALESCE(sum(vt.error_cat is null), 0) success, " +
                        "  (select sequence from sequence_temp st where process_name = vt.process_name) as sequence " + 
                        "  from group_transaction_view vt " +
                        "  where vt.status = 0 and vt.worker_status = '0' and "+
                        "  vt.tracking_id IS NOT NULL and "+
                        "  vt.function = '"+function+"' and "+
                        "  vt.START_TIME >= STR_TO_DATE('"+startDate+"', '%m/%d/%Y') and "+ 
                        "  vt.END_TIME <=  DATE_ADD( STR_TO_DATE('"+endDate+"', '%m/%d/%Y'), INTERVAL 1 DAY) and "+
                        //"  vt.process_name = st.process_name and "+
                        "  vt.process_id = (select id from groups where isDisabled = '0'  and id = vt.process_id ) "+
                        "  group by bp_uuid, worker_type "+
                        "  order by sequence, worker_type, first_trans_start_date_time DESC ";
        
            
            System.out.println("sql ::::::: "+sql);
            
            mysqlConn = getMySqlConnection();
            st = mysqlConn.createStatement();
            rs = st.executeQuery(sql);
            dataList = new ArrayList<Data>();
            int i = 0;
            double effortSaved = 0;
            //int effortSavedVal = 0;
            String processName = "";
            Data transactionData = null;
            List<Data> transactionList = new ArrayList<Data>();
            while(rs.next()){

                String sqlProcessName = rs.getString("processName");
                String sqlWorker = rs.getString("worker");
                String bp_uuid = rs.getString("bp_uuid");
                
                if(! processName.equalsIgnoreCase(sqlProcessName)){
                    if(i > 0){
                        data = new Data();
                        data.setProcessName(processName);
                        data.setTransactionList(transactionList);
                        dataList.add(data);
                        transactionList = new ArrayList<Data>();
                    }
                }

                transactionData = new Data();

                processName = sqlProcessName;

                transactionData.setTotalTransactions( rs.getLong("totalTransaction") );
                transactionData.setTotalTimeTaken( Double.parseDouble(df.format(rs.getDouble("Duration")/60)) );
                transactionData.setTotalWorker(rs.getLong("totalWorker"));
                transactionData.setFirstTransStartDateTime(rs.getString("first_trans_start_date_time"));
                transactionData.setWorker(sqlWorker);
                transactionData.setBp_uuid(bp_uuid);
                transactionData.setBusinessExceptionCount(rs.getLong("business_error"));
                transactionData.setTechnicalExceptionCount(rs.getLong("technical_error"));
                transactionData.setSuccesstransactionCount(rs.getLong("success"));
                
                if("BOT".equalsIgnoreCase(sqlWorker)){
                    effortSaved = rs.getDouble("Efforts_Saved") /60; 
                    transactionData.setEffortSaved( Double.parseDouble(df.format(effortSaved)) );
                }
                else {
                    transactionData.setEffortSaved(0.0);
                }
                transactionList.add(transactionData);

                System.out.println("processName :::::::: "+processName);
                System.out.println("rs.isLast() :::::::: "+rs.isLast());

                if(rs.isLast()){
                    data = new Data();
                    data.setProcessName(processName);
                    data.setTransactionList(transactionList);
                    dataList.add(data);
                }

                i++;

            }

            System.out.println("dataList For Transaction List.size() :::::::: "+dataList.size());

        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            closeResources(mysqlConn, st, rs);
        } 

        return dataList;
    }

    /**
     *  
     * @param startDate
     * @param endDate
     * @return
     */
    public List<Data> getTransactionData(String startDate, String endDate, String function){
        Connection mysqlConn = null;
        Statement st = null;
        Data data = null;
        List<Data> dataList = null;
        ResultSet rs = null;
        try{


            String sql = "select worker_id, process_name, country, start_time, end_time, status, worker_type, description, out_come "+
                    "from group_transaction_view where tracking_id IS NOT NULL and process_id = (select id from groups where isDisabled = '0'  and id = process_id ) and function = '"+function+"' and START_TIME >= STR_TO_DATE('"+startDate+"', '%m/%d/%Y') and END_TIME <=  DATE_ADD( STR_TO_DATE('"+endDate+"', '%m/%d/%Y'), INTERVAL 1 DAY) "+
                    "order by start_time";

            mysqlConn = getMySqlConnection();
            st = mysqlConn.createStatement();
            rs = st.executeQuery(sql);
            dataList = new ArrayList<Data>();
            int i = 1;
            while(rs.next()){


                data = new Data();
                data.setIndex(i++);
                data.setBotKey( rs.getString("worker_id") );
                data.setProcessName(rs.getString("process_name"));
                data.setRegion(rs.getString("country"));
                data.setStartTime(rs.getString("start_time"));
                data.setEndTime(rs.getString("end_time"));
                data.setStatus(rs.getString("status"));
                data.setWorker(rs.getString("worker_type"));
                data.setDescription(rs.getString("description"));

                dataList.add(data);


            }

            System.out.println("dataList.size() :::::::: "+dataList.size());

        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            closeResources(mysqlConn, st, rs);
        } 

        return dataList;
    }
    
    
    
    /**
     * 
     * @param requestMessage
     * @return
     */
    public int insertHumanTransaction(RequestMessage requestMessage){

        // Connection oracleConn = null;
        Connection mysqlConn = null;
        Statement st = null;
        int result = 0;
        //ResultSet rs = null;
        try {

            if(requestMessage.getRequestData().getTransactions().size() > 0){
                List<Transactions> transactionList =  requestMessage.getRequestData().getTransactions();
                String tQuery = "";

                mysqlConn = getMySqlConnection();

                //System.out.println("oracleConn=" + oracleConn);
                System.out.println("transactionList.size() =" + transactionList.size());
                

                for(int i=0; i<transactionList.size(); i++){

                    Transactions transactions = transactionList.get(i);
                    
                    System.out.println("transactions.getTrackingId()  =" + transactions.getTrackingId());
                    System.out.println("transactions.getProcessName() =" + transactions.getProcessName());
                    System.out.println("transactions.getStatus() =" + transactions.getStatus());
                    System.out.println("transactions.getStartDateTime() =" + transactions.getStartDateTime());
                    System.out.println("transactions.getEndDateTime() =" + transactions.getEndDateTime());
                    System.out.println("transactions.getExceptionType() =" + transactions.getExceptionType());
                    System.out.println("transactions.getDescription() =" + transactions.getDescription());
                    
                    

                    tQuery = "INSERT INTO vbrain_transaction "+
                            "(BOT_ID, BUSINESS_APP_NAME, WORKER, STATUS, START_TIME, END_TIME, EXCEPTION_TYPE, DESCRIPTION, CREATED_BY, TRACKING_ID ) "+
                            "VALUES (" +
                            " (select id from vbrain_bot where bot_key='"+transactions.getUserId()+"'), " +
                            " '"+requestMessage.getRequestHeader().getBusinessAppId()+"', "+
                            " 'HUMAN',"+
                            " '"+transactions.getStatus()+"', "+
                            " '"+Timestamp.valueOf(transactions.getStartDateTime())+"', "+
                            " '"+Timestamp.valueOf(transactions.getEndDateTime())+"', "+
                            " '"+transactions.getExceptionType()+"', "+
                            " '"+transactions.getDescription()+"', "+
                            " '"+transactions.getUserId()+"', "+
                            " '"+transactions.getTrackingId()+"' )";
                    
                    System.out.println("tQuery ::::::: "+tQuery);

                    st = mysqlConn.createStatement();

                    result = result + st.executeUpdate(tQuery);

                    System.out.println("result :::::::::: "+result);
                }
            }

        } 
        catch (Exception e) {
            // handle the exception
            e.printStackTrace();
            result = 0;
            //System.exit(1);
        } 
        finally {
            // release database resources
        	boolean closedResources = closeResources(mysqlConn, st, null);
        	if(!closedResources) {
        		result = 0;
        	}
        }

        return result;
    }
    
    /**
     * 
     * @param requestMessage
     * @return
     */
    public int insertTransaction(RequestMessage requestMessage){

        // Connection oracleConn = null;
        Connection mysqlConn = null;
        Statement st = null;
        //ResultSet rs = null;
        try {

            //String dateString = "2011-09-09"; //12-09-2016 22:01:32
            DateFormat formatter = new SimpleDateFormat(Constants.DATE_FORMAT);
            //Date myDate = ;

            // String timestamp = "2011-10-02-18.48.05.123";
            // DateFormat df = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
            // Date parsedDate = df.parse(timestamp);


            getGroups();
            
            String botKey = requestMessage.getRequestHeader().getBotKey();
            
            String parentId = getGroupId(botKey, "BOT");
            
            String country = getGroupName(parentId, "country");
            
            System.out.println("Process Id ["+parentId+"] | Country ["+country+"] ");
            
            mysqlConn = getMySqlConnection();

            if(requestMessage.getRequestData().getTransactions().size() > 0){
                List<Transactions> transactionList =  requestMessage.getRequestData().getTransactions();
                String tQuery = "";
                
                //System.out.println("oracleConn=" + oracleConn);
                System.out.println("transactionList.size() =" + transactionList.size());

                for(int i=0; i<transactionList.size(); i++){

                    Transactions transactions = transactionList.get(i);

                    tQuery = "INSERT INTO transactions "+
                            "(WORKER_ID, WORKER_TYPE, STATUS, START_TIME, END_TIME, OUT_COME, EXCEPTION_TYPE, DESCRIPTION, CREATED_BY, TRACKING_ID, COUNTRY, B_FUNCTION ) "+
                            "VALUES (" +
                            " (select id from bot where bot_key='"+botKey+"'), " +
                            " 'BOT','0', '"+Timestamp.valueOf(transactions.getStartDateTime())+"','"+Timestamp.valueOf(transactions.getEndDateTime())+"', "+
                            " '"+transactions.getOutcome()+"', '"+transactions.getExceptionType()+"', "+
                            " '"+transactions.getDescription()+"', '"+transactions.getCreatedBy()+"', '"+transactions.getTrackingId()+"', '"+country+"', "+
                            " (select Name from groups where id = (select parent_id from groups where id = (select process_id from bot where bot_key='"+botKey+"') ) ) )";


                    st = mysqlConn.createStatement();

                    int result = st.executeUpdate(tQuery);

                    System.out.println("result :::::::::: "+result);


                }
            }

        } 
        catch (Exception e) {
            // handle the exception
            e.printStackTrace();
        } 
        finally {
            // release database resources
        	closeResources(mysqlConn, st, null);
        }

        return 1;
    }

    
    /**
     * 
     * @param trackingId
     * @return
     */
    public List<Integer> getTransactionIds(String trackingId) {
        Connection mysqlConn = null;
        Statement st = null;
        List<Integer> result = null;
        ResultSet rs = null;
        try{
            String sql = "select id from transactions where TRACKING_ID = '" + trackingId + "'";
            System.out.println("sql ::::::::::: "+sql);

            mysqlConn = getMySqlConnection();
            st = mysqlConn.createStatement();
            rs = st.executeQuery(sql);
            result = new ArrayList<Integer>();
            while(rs.next()){
                int id = rs.getInt(1);
                if (id >= 0) {
                    result.add(id);
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            closeResources(mysqlConn, st, rs);
        } 
        return result;
    }
    
    /**
     * 
     * @param trackingId
     * @return
     */
    public List<Integer> getWorkerIds(String trackingId) {
        Connection mysqlConn = null;
        Statement st = null;
        List<Integer> result = null;
        ResultSet rs = null;
        try{
            String sql = "select worker_id from transactions where TRACKING_ID = '" + trackingId + "'";
            System.out.println("sql ::::::::::: "+sql);

            mysqlConn = getMySqlConnection();
            st = mysqlConn.createStatement();
            rs = st.executeQuery(sql);
            result = new ArrayList<Integer>();
            while(rs.next()){
                int id = rs.getInt(1);
                if (id >= 0) {
                    result.add(id);
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            closeResources(mysqlConn, st, rs);
        } 
        return result;
    }
    
    public List<Data> getTransactionsRegionWise_2(String startDate, String endDate, String function){
        Data data = null;
        List<Data> dataList = null;
        
        VBrainStoredProcedure tListSP = null;
        try{
        	tListSP = new VBrainStoredProcedure("get_runs_region_wise_sp_3", Arrays.asList(function, startDate, endDate), true);
        	ResultSet rs = tListSP.getResultSet();

        	dataList = new ArrayList<Data>();
            int i = 0;

            String processName = "";
            Data transData = null;
            List<Data> transList = new ArrayList<Data>();
            while(rs.next()){
                transData = new Data();

                if(i > 0 && !processName.equalsIgnoreCase(rs.getString("process_Name"))){
                    data = new Data();
                    data.setProcessName(processName);
                    data.setTransactionList(transList);
                    dataList.add(data);
                    transList = new ArrayList<Data>();

                }

                processName = rs.getString("process_Name");
                i++;

                transData.setTotalTransactions( rs.getLong("totalTransaction") );
                transData.setRegion(rs.getString("country"));
                transData.setWorker(rs.getString("worker_type"));
                transData.setFirstTransStartDateTime(String.valueOf(rs.getLong("first_trans_start_date_time")));
                
                transList.add(transData);

                if(rs.isLast()){
                    data = new Data();
                    data.setProcessName(processName);
                    data.setTransactionList(transList);
                    dataList.add(data);
                    //transactionList = new ArrayList<Data>();
                }

            }
            System.out.println("dataList.size() *************** "+dataList.size());

        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
        	tListSP.close();
        } 

        return dataList;
    }
    /**
     * 
     * @param startDate
     * @param endDate
     * @return
     */
    public List<Data> getTransactionsRegionWise(String startDate, String endDate, String function){
        Connection mysqlConn = null;
        Statement st = null;
        Data data = null;
        List<Data> dataList = null;
        ResultSet rs = null;
        try{
            String sql = "select count(*) totalTransaction,bp_uuid, process_Name, MIN(CAST(vt.start_time AS CHAR)) first_trans_start_date_time, country, worker_type, (select sequence from sequence_temp where process_name = vt.process_name) as sequence from group_transaction_view vt "+
                    " where vt.tracking_id IS NOT NULL and vt.status = '0' and vt.worker_status = '0' and vt.process_id = (select id from groups where isDisabled = '0'  and id = vt.process_id ) and vt.function = '"+function+"' and vt.START_TIME >= STR_TO_DATE('"+startDate+"', '%m/%d/%Y') and vt.END_TIME <=  DATE_ADD( STR_TO_DATE('"+endDate+"', '%m/%d/%Y'), INTERVAL 1 DAY) "+
                    " group by bp_uuid, country, worker_type order by sequence, country, worker_type";
            
            System.out.println("sql ::::::::::: "+sql);

            mysqlConn = getMySqlConnection();
            st = mysqlConn.createStatement();
            rs = st.executeQuery(sql);
            dataList = new ArrayList<Data>();
            int i = 0;

            String processName = "";
            Data transData = null;
            List<Data> transList = new ArrayList<Data>();
            while(rs.next()){
                transData = new Data();

                if(i > 0 && !processName.equalsIgnoreCase(rs.getString("process_Name"))){
                    data = new Data();
                    data.setProcessName(processName);
                    data.setTransactionList(transList);
                    dataList.add(data);
                    transList = new ArrayList<Data>();

                }

                processName = rs.getString("process_Name");
                i++;

                transData.setTotalTransactions( rs.getLong("totalTransaction") );
                transData.setRegion(rs.getString("country"));
                transData.setWorker(rs.getString("worker_type"));
                transData.setFirstTransStartDateTime(String.valueOf(rs.getLong("first_trans_start_date_time")));
                
                
                System.out.println(" Worker Type :::::::: ----- > "+rs.getString("worker_type"));
                
                transList.add(transData);

                if(rs.isLast()){
                    data = new Data();
                    data.setProcessName(processName);
                    data.setTransactionList(transList);
                    dataList.add(data);
                    //transactionList = new ArrayList<Data>();
                }

            }
            System.out.println("dataList.size() *************** "+dataList.size());

        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            closeResources(mysqlConn, st, rs);
        } 

        return dataList;
    }

    /**
     * @param botKey
     * @param startDate
     * @param endDate
     * @param function
     * @return
     */
    public List<Data> getBotWiseTransactions(String botKey, String function, String startDate, String endDate){
        Connection mysqlConn = null;
        Statement st = null;
        Data data = null;
        List<Data> dataList = null;
        ResultSet rs = null;
        try{
            getGroups();

            String sql = "select * from group_transaction_view "+
                    " where worker_id = '"+botKey+"' and function like '%"+function+"%' "+
                    " and process_id = (select id from groups where isDisabled = '0'  and id = process_id ) " +
                    " and START_TIME >= STR_TO_DATE('"+startDate+"', '%m/%d/%Y') and "+
                    " END_TIME <=  DATE_ADD( STR_TO_DATE('"+endDate+"', '%m/%d/%Y'), INTERVAL 1 DAY) and status = '0' and worker_status = '0' "+
                    " order by start_time desc ";

            System.out.println("sql :::::::::: "+sql);
            
            mysqlConn = getMySqlConnection();
            st = mysqlConn.createStatement();
            rs = st.executeQuery(sql);
            dataList = new ArrayList<Data>();
            int i = 1;

            while(rs.next()){

                data = new Data();
                data.setIndex(i++);
                data.setStartTime(rs.getString("start_time") );
                data.setEndTime(rs.getString("end_time") );
                data.setTotalTimeTaken(rs.getDouble("duration") );
                data.setEffortSaved(rs.getDouble("efforts_saved") );
                
                int status = rs.getInt("status");
                if(status == 0){
                    data.setStatus("Success");
                }
                else {
                    data.setStatus("Failure");
                }
                
                data.setDescription(rs.getString("description") );

                dataList.add(data);
            }

            System.out.println("dataList.size() :::::::: "+dataList.size());

        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            closeResources(mysqlConn, st, rs);
        } 

        return dataList;
    }
    
    /**
     * 
     */
    public List<Data> getTransactionsRegionAndWorkStepWise(String startDate, String endDate, String workStep, String function){
        Connection mysqlConn = null;
        Statement st = null;
        Data data = null;
        List<Data> dataList = null;
        ResultSet rs = null;
        try{
            
            getGroups();

            String sql = "select count(*) totalTransaction, country  "+
                    "from group_transaction_view where tracking_id IS NOT NULL and status = '0' and worker_status = '0' and function = '"+function+"' and process_name = '"+workStep+"' and START_TIME >= STR_TO_DATE('"+startDate+"', '%m/%d/%Y') and END_TIME <=  DATE_ADD( STR_TO_DATE('"+endDate+"', '%m/%d/%Y'), INTERVAL 1 DAY) "+
                    "group by country ";

            mysqlConn = getMySqlConnection();
            st = mysqlConn.createStatement();
            rs = st.executeQuery(sql);
            dataList = new ArrayList<Data>();
            int i = 1;

            while(rs.next()){

                data = new Data();
                data.setIndex(i++);
                data.setTotalTransactions( rs.getLong("totalTransaction") );
                data.setRegion(rs.getString("country"));

                dataList.add(data);
            }

            System.out.println("dataList.size() :::::::: "+dataList.size());

        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            closeResources(mysqlConn, st, rs);
        } 

        return dataList;
    }
    
    
    /**
     * 
     * @param startDate
     * @param endDate
     * @param workStep
     * @return
     */
    public String getGroupId(String workerId, String type){
        Connection mysqlConn = null;
        Statement st = null;
        String processId = "";
        ResultSet rs = null;
        try{
            
            String sql = "";
            if(type.equalsIgnoreCase("BOT")){
                sql = "select process_id  "+
                        "from bot where bot_key = '"+workerId+"' ";
            }
            else if(type.equalsIgnoreCase("HUMAN")){
                sql = "select process_id  "+
                        "from human_worker where worker_id = '"+workerId+"' ";
                
            }
            
            System.out.println("sql ::::::: "+sql);
            
            mysqlConn = getMySqlConnection();
            st = mysqlConn.createStatement();
            rs = st.executeQuery(sql);
            
            int i = 1;

            while(rs.next()){

                processId = rs.getString("process_id");

            }

            System.out.println("process_id :::::::: "+processId);

        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            closeResources(mysqlConn, st, rs);
        } 

        return processId;
    }
    
    
    private String getGroupName(String parentId, String type){
        
        String groupName = "";
        try{
            List<Group> groups = getAllGroups();
            
            System.out.println("groups.size() ::::::::::::: "+groups.size());
            
            int isParent = 1;
            
            int count = 0;
            
            while(isParent > 0){
            
                count ++;
                
                for(int i=0; i<groups.size(); i++){
                    Group group = groups.get(i);
                    
                    //System.out.println("parentId -------> "+parentId+" | groupId -------> "+group.getId());
                    
                    if( parentId.equalsIgnoreCase(group.getId()) ){
                        
                        System.out.println("-------------------> "+group.getName());
                        parentId = group.getParentId();
                        
                        if(type.equalsIgnoreCase(group.getType())){
                            isParent = 0;
                            groupName = group.getName().toUpperCase();
                        }
                        
                        break;
                    }
                }
                
                if(count == groups.size()){
                    isParent = 0;
                }
            }
            
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return groupName;
    }
    
    
    private void getGroups(){
        Connection mysqlConn = null;
        Statement st = null;
        //Data data = null;
        Data data = null;
        ResultSet rs = null;
        List<Group> groups = null;
        try{
            

            //String sql =  "SELECT * FROM groups where isDisabled = '0' order by parent_id desc";
            String sql =    "SELECT * FROM groups order by parent_id desc";
            System.out.println("sql : "+sql);
            
            mysqlConn = getMySqlConnection();
            st = mysqlConn.createStatement();
            rs = st.executeQuery(sql);
            groups = new ArrayList<Group>();
            Group group = null;
            
            while(rs.next()){
                group = new Group();
                
                group.setId(rs.getString("id"));
                group.setName(rs.getString("name"));
                group.setDescription(rs.getString("description"));
                group.setType(rs.getString("type"));
                group.setParentId(rs.getString("parent_id"));
                group.setParentGroupId(rs.getString("Parent_Group_Id"));
                
                groups.add(group);
            }
            
            setAllGroups(groups);
            
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            closeResources(mysqlConn, st, rs);
        } 

        
    }

    @Override
	public String getLastUpdatedDate() {
    	Connection mysqlConn = null;
        Statement st = null;
        String lastUpdatedDate = "";
        ResultSet rs = null;
        try{
            
            String sql = "SELECT DATE_FORMAT(LASTRECORD_TIMESTAMP, '%m/%d/%Y') last_updated_date FROM vbrain.wf_configuration";
            
            System.out.println("sql ::::::: "+sql);
            
            mysqlConn = getMySqlConnection();
            st = mysqlConn.createStatement();
            rs = st.executeQuery(sql);
            

            while(rs.next()){

                lastUpdatedDate = rs.getString("last_updated_date");

            }

            System.out.println("process_id :::::::: "+lastUpdatedDate);

        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            closeResources(mysqlConn, st, rs);
        } 

        return lastUpdatedDate;
	}

    @Override
	public int deleteTransactionsAfterDate(String lastTransactionDate) {
    	Connection mysqlConn = null;
		Statement st = null;
		ResultSet rs = null;
		int result = 0;
		try {
			mysqlConn = getMySqlConnection();
			StringBuffer deleteQuery = new StringBuffer();
			deleteQuery.append("DELETE FROM transactions WHERE ");
			deleteQuery.append("START_TIME >= STR_TO_DATE('").append(lastTransactionDate).append("', '%m/%d/%Y')");
			st = mysqlConn.createStatement();
			result = st.executeUpdate(deleteQuery.toString());
			
			StringBuffer updateSql = new StringBuffer();
			updateSql.append("UPDATE vbrain.wf_configuration ");
			updateSql.append("SET LASTRECORD_TIMESTAMP = '").append(convertToStandartFormat(lastTransactionDate)).append("'");
			result = st.executeUpdate(updateSql.toString());
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeResources(mysqlConn, st, rs);
		} 
		return result;
	}
    
    private String convertToStandartFormat(String datetime) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		Date coverteddatewithseconds = formatter.parse(datetime);
		String converttosimpledateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(coverteddatewithseconds);
		return converttosimpledateformat;
	}
    

}
