package com.vbrain.dao.impl;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.axis.utils.StringUtils;

public class DbTable {
	private String name;
	private List<DbTableField> fields;
	private boolean insertIgnore;

	public DbTable(String name, List<DbTableField> fields, boolean insertIgnore) {
		this.name = name;
		this.fields = fields;
		this.insertIgnore = insertIgnore;
	}

	public boolean isValid() {
		if (StringUtils.isEmpty(name) || fields == null || fields.isEmpty()) {
			return false;
		}
		return true;
	}

	public String getName() {
		return name;
	}

	public List<DbTableField> getFields() {
		return fields;
	}

	public String getInsertStatement() {
		if (!isValid()) {
			return null;
		}

		String placeholderStr = Collections.nCopies(fields.size(), "?").stream().collect(Collectors.joining(","));

		String fieldsStr = fields.stream().map(p -> String.valueOf(p.getName())).collect(Collectors.joining(","));

		StringBuilder qb = new StringBuilder();
		qb.append("INSERT" + (insertIgnore ? " IGNORE" : "") + " INTO " + name);
		qb.append(" (" + fieldsStr + ")");
		qb.append(" VALUES(" + placeholderStr + ")");

		return qb.toString();
	}
}
