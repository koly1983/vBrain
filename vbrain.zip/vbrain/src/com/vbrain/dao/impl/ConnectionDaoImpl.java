package com.vbrain.dao.impl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author
 *
 */
public class ConnectionDaoImpl {

	private static final Logger logger = LoggerFactory.getLogger(ConnectionDaoImpl.class);

	private static Properties prop;

	private static String connectionurl = null;
	private static String username = null;
	private static String password = null;

	static {

		InputStream is = null;

		try {
			prop = new Properties();
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			is = classLoader.getResourceAsStream("vbrainconfig.properties");
			prop.load(is);

			connectionurl = getPropertyValue("db.connectionurl");
			username = getPropertyValue("db.username");
			password = getPropertyValue("db.password");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String getPropertyValue(String key) {
		return prop.getProperty(key);
	}

	protected static Connection getMySqlConnection() {
		Connection con = null;

		try {
			String driver = "com.mysql.jdbc.Driver";
			// String url = "jdbc:mysql://"+dbhost+":3306/vbrain";
			// String url =
			// "jdbc:mysql://mysqldbinstance.cm2uppkzblot.ap-south-1.rds.amazonaws.com:3306/vbrain";
			// String username = "vbrain";
			// String password = "password";
			Class.forName(driver); // load MySQL driver
			con = DriverManager.getConnection(connectionurl, username, password);

		} catch (Exception e) {
			logger.error("Exception: " + e.getMessage());
		}
		return con;
	}

	protected void closeConnection(Connection connection) throws SQLException {
		if (connection != null) {
			connection.close();
		}
	}

	protected void closeStatement(Statement statement) throws SQLException {
		if (statement != null) {
			statement.close();
		}
	}

	protected void closeResultSet(ResultSet resultSet) throws SQLException {
		if (resultSet != null) {
			resultSet.close();
		}
	}

	protected boolean closeResources(Connection connection, Statement statement, ResultSet resultSet) {
		boolean closed = true;
		try {
			closeConnection(connection);
			closeStatement(statement);
			closeResultSet(resultSet);
		} catch (SQLException e) {
			e.printStackTrace();
			closed = false;
		}
		return closed;
	}

	public static void main(String a[]) {
		System.out.println("db.connectionurl: " + connectionurl);
		System.out.println("db.user: " + username);
		System.out.println("db.password: " + password);

	}
}
