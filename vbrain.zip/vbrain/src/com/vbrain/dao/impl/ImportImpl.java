package com.vbrain.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ImportImpl {
//	private DynamicQueryProcedure importProcedure;
//	private DbStoredProcedure postProcedure;
	private List<ProceduresSet> proceduresSetList = new ArrayList<ImportImpl.ProceduresSet>();

	private DbConnection vBrainConnection = null;
	private DbConnection wfConnection = null;

	public ImportImpl(ImportEntity entity) {
		this(entity, WfVersion.WF84);
	}
	
	public ImportImpl(ImportEntity entity, WfVersion wfVersion) {
		
		vBrainConnection = new DbConnection(DbConnectionType.VBRAIN);
		
		switch (entity) {
			case TRANSACTION:
			case CAMPAIGN:
			case RUN:
			case SNAPSHOT:
				if(WfVersion.WF82.equals(wfVersion))
					wfConnection = new DbConnection(DbConnectionType.WFMYSQL82);
				else if (WfVersion.WF84P2.equals(wfVersion))
					wfConnection = new DbConnection(DbConnectionType.WFMYSQL84P2);
				else
					wfConnection = new DbConnection(DbConnectionType.WFMYSQL);
				break;
			case DATASTORE:
				if(WfVersion.WF82.equals(wfVersion))
					wfConnection = new DbConnection(DbConnectionType.WFPOSTGRESQL82);
				else if (WfVersion.WF84P2.equals(wfVersion))
					wfConnection = new DbConnection(DbConnectionType.WFPOSTGRESQL84P2);
				else
					wfConnection = new DbConnection(DbConnectionType.WFPOSTGRESQL);
				break;
			default:
				break;
		}
		
		getProcedureNames(entity.toString(), wfVersion);
	}

	public void execute() {

		try {
			for (ProceduresSet proceduresSet : proceduresSetList) {
				executeProceduresSet(proceduresSet);
			}
		} finally {
			closeConnections();
		}
	}
	
	private void executeProceduresSet(ProceduresSet proceduresSet) {
		ResultSet source = null;

		try {
			proceduresSet.getImportProcedure().execute(vBrainConnection);
			
			source = wfConnection.executeQuery(proceduresSet.getImportProcedure().getQueryString(), true);
			
			// TODO: Any checks required
			vBrainConnection.insertData(source, proceduresSet.getImportProcedure().getDestTable());

			// TODO: Check if import succeeded, only then proceed with
			// postProcedure
			// Call post dump procedures
			if(proceduresSet.getPostProcedure() != null)
				proceduresSet.getPostProcedure().execute(vBrainConnection);
		} finally {
			wfConnection.closeResultSet(source, true);
		}
	}

	private void closeConnections() {
		wfConnection.closeConnection();
		vBrainConnection.closeConnection();
	}
	
	private void getProcedureNames(String entity, WfVersion wfVersion) {
		ResultSet rs = null;

		try {
			if(WfVersion.WF82.equals(wfVersion))
				rs = new DbStoredProcedure("82_import_details_sp", (String) null).executeQuery(vBrainConnection);
			else if(WfVersion.WF84P2.equals(wfVersion))
				rs = new DbStoredProcedure("84P2_import_details_sp", (String) null).executeQuery(vBrainConnection);
			else
				rs = new DbStoredProcedure("import_details_sp", (String) null).executeQuery(vBrainConnection);
			
			while (rs.next()) {
				if (entity.equals(rs.getString("entity"))) {
					ProceduresSet proceduresSet = new ProceduresSet();
					String importProcName = rs.getString("import");
					String importProcParamValues = rs.getString("importParamValues");
					String postProcName = rs.getString("post");
					String postProcParamValues = rs.getString("postParamValues");

					List<String> importParams = null;
					if (importProcParamValues != null) {
						importParams = Arrays.asList(importProcParamValues.split(","));
					}
					proceduresSet.setImportProcedure(new DynamicQueryProcedure(importProcName, importParams));

					if (postProcName != null) {
						List<String> postParams = null;
						if (postProcParamValues != null) {
							postParams = Arrays.asList(postProcParamValues.split(","));
						}
						proceduresSet.setPostProcedure(new DbStoredProcedure(postProcName, postParams));
					}
					//break;
					proceduresSetList.add(proceduresSet);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			vBrainConnection.closeResultSet(rs, true);
		}
	}


	public enum ImportEntity {
		TRANSACTION("T"), CAMPAIGN("C"), RUN("R"), SNAPSHOT("S"), DATASTORE("D");

		private String entity;

		private ImportEntity(String entity) {
			this.entity = entity;
		}

		@Override
		public String toString() {
			return entity;
		}
	}
	public enum DbConnectionType {
		VBRAIN, WFMYSQL, WFPOSTGRESQL, WFMYSQL82, WFPOSTGRESQL82,WFMYSQL84P2, WFPOSTGRESQL84P2
	}
	
	public enum WfVersion {
		WF82("8.2"),WF84("8.4"),WF84P2("8.4P2");
		
		private String version;

		private WfVersion(String version) {
			this.version = version;
		}

		@Override
		public String toString() {
			return version;
		}
	}
	
	public class ProceduresSet {
		private DynamicQueryProcedure importProcedure;
		private DbStoredProcedure postProcedure;
		public DynamicQueryProcedure getImportProcedure() {
			return importProcedure;
		}
		public DbStoredProcedure getPostProcedure() {
			return postProcedure;
		}
		public void setImportProcedure(DynamicQueryProcedure importProcedure) {
			this.importProcedure = importProcedure;
		}
		public void setPostProcedure(DbStoredProcedure postProcedure) {
			this.postProcedure = postProcedure;
		}
		
	}
}
