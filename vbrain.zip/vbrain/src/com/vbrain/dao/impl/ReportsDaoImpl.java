package com.vbrain.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.vbrain.common.io.Data;
import com.vbrain.common.io.RequestMessage;
import com.vbrain.dao.ReportDao;

public class ReportsDaoImpl extends ConnectionDaoImpl implements ReportDao {

	private static enum WorkerType {
		BOT,
		Human
	}
	
	private static class SLAConfig {
		public int avgEfforts;
		public int avgEffortsSaved;
		
		
		public SLAConfig(int avgEfforts, int avgEffortsSaved) {
			this.avgEfforts = avgEfforts;
			this.avgEffortsSaved = avgEffortsSaved;
		}
	}
	
	/**
	 * @param reportType
	 * @param processName
	 */
	public Data getReport(String reportType, String processName) {
        Data data = null;
		Connection mysqlConn = null;
		Statement st = null;
		try {
			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			Map<String, Integer> map = new LinkedHashMap<String, Integer>();
			
			int result = 0;
			int totalBotCount=0;
			//result = this.getBotCount(mysqlConn, st, processName);
			
			
			result = this.getCompletedTxnCount(mysqlConn, st, reportType, processName);
			map.put("completed_txn", result);
			totalBotCount+=result;
			result = this.getExceptionTxnCount(mysqlConn, st, reportType, processName);
			map.put("exception_txn", result);
			totalBotCount+=result;
			result = this.getPendingTxnCount(mysqlConn, st, reportType, processName);
			map.put("pending_txn", result);
			totalBotCount+=result;
			
			map.put("rpa_count", totalBotCount);
			result = this.getTechExceptionTxnCount(mysqlConn, st, reportType, processName);
			map.put("technical_exp_txn", result);
			result = this.getBusinessExceptionTxnCount(mysqlConn, st, reportType, processName);
			map.put("business_exp_txn", result);
			result = this.getOtherExceptionTxnCount(mysqlConn, st, reportType, processName);
			map.put("other_exp_txn", result);

			result = this.getTotalTransactionTime(mysqlConn, st, reportType, processName, WorkerType.BOT);
			map.put("total_bot_txn_minutes", result);
			
			result = this.getTotalTransactionTime(mysqlConn, st, reportType, processName, WorkerType.Human);
			map.put("total_human_txn_minutes", result);
			
			Map<Integer, SLAConfig> botConfig = this.getSLAConfig(mysqlConn, st, processName, WorkerType.BOT);
			Map<Integer, SLAConfig> humanConfig = this.getSLAConfig(mysqlConn, st, processName, WorkerType.Human);
			
			Map<Integer, Integer> botTxnTime = this.getAvgTransactionTime(mysqlConn, st, reportType, processName, WorkerType.BOT);
			Map<Integer, Integer> humanTxnTime = this.getAvgTransactionTime(mysqlConn, st, reportType, processName, WorkerType.Human);
			
			this.computeResult(botTxnTime, botConfig, map, WorkerType.BOT);
			this.computeResult(humanTxnTime, botConfig, map, WorkerType.Human);
			
			if (data == null) {
				data = new Data();
			}
			data.setProcessMetrics(map);
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			closeResources(mysqlConn, st, null);
		} 

        return data;
	}
	
	/**
	 * Get Bot count
	 * @param mysqlConn
	 * @param st
	 * @param processName
	 * @return
	 * @throws SQLException
	 */
	protected int getBotCount(Connection mysqlConn, Statement st, String processName) throws SQLException {
		ResultSet rs = null;
		try {
			String sql = "select count(*) rpa from bot b join groups g on g.id = b.Process_Id where g.Type = 'process' and g.Name = '" +
					processName + "'";
			rs = st.executeQuery(sql);
			while (rs.next()) {
				int rpa_count = rs.getInt("rpa");
				return rpa_count;
			}
			return 0;
		} finally {
			if (rs != null) {
				rs.close();
			}
		}
	}
	
	protected String getCompleteCondition(String reportType) {
		return getCondition(reportType, true);
	}
	
	protected String getPendingCondition(String reportType) {
		return getCondition(reportType, false);
	}

	/**
	 * Get date range SQL condition
	 * @param reportType
	 * @param hasEndDate
	 * @return
	 */
	protected String getCondition(String reportType, boolean hasEndDate) {
		if (reportType == null || reportType.trim().isEmpty() || reportType.equalsIgnoreCase("Today")) {
		    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
		    Date date = new Date();  
		    String endDate = formatter.format(date);
		    String startDate = endDate.substring(0,  10) + " 00:00:00";
		    String cond = "START_TIME >= STR_TO_DATE('" + startDate + "', '%d/%m/%Y %H:%i:%s') ";
		    if (hasEndDate) {
		    	cond += "and END_TIME <= " +
		                          "STR_TO_DATE('" + endDate + "', '%d/%m/%Y %H:%i:%s')";
		    }
		    return cond;
		} else if (reportType.equalsIgnoreCase("Previous Day")) {
		    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");  
		    Date date = new Date();  
		    String endDate = formatter.format(date);
			String cond = "START_TIME > DATE_SUB('" + endDate + "', INTERVAL 1 DAY) ";
			if (hasEndDate) {
				cond += "and END_TIME <= STR_TO_DATE('" + endDate + "', '%Y-%m-%d')";
			}
			return cond;
		} else if (reportType.equalsIgnoreCase("MTD")) {
		    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
		    Date date = new Date();  
		    String endDate = formatter.format(date);
		    String startDate = "01" + endDate.substring(2, 10) + " 00:00:00";
		    String cond = "START_TIME >= STR_TO_DATE('" + startDate + "', '%d/%m/%Y %H:%i:%s') ";
		    if (hasEndDate) {
		    	cond +="and END_TIME <= " +
		    			"STR_TO_DATE('" + endDate + "', '%d/%m/%Y %H:%i:%s')";
		    }
		    return cond;
		} else if (reportType.equalsIgnoreCase("YTD")) {
		    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
		    Date date = new Date();  
		    String endDate = formatter.format(date);
		    String startDate = "01/01" + endDate.substring(5, 10) + " 00:00:00";
		    String cond = "START_TIME >= STR_TO_DATE('" + startDate + "', '%d/%m/%Y %H:%i:%s') ";
		    if (hasEndDate) {
		    	cond += "and END_TIME <= " +
		    			"STR_TO_DATE('" + endDate + "', '%d/%m/%Y %H:%i:%s')";
		    }
		    return cond;
		}
		return "";
	}
	
	/**
	 * Get completed transaction count
	 * @param mysqlConn
	 * @param st
	 * @param reportType
	 * @param processName
	 * @return
	 * @throws SQLException
	 */
	protected int getCompletedTxnCount(Connection mysqlConn, Statement st, String reportType, String processName) throws SQLException {
		ResultSet rs = null;
		try {
			//String condition = this.getCompleteCondition(reportType);
			String condition=" START_TIME >= STR_TO_DATE('01/11/2019 00:00:00', '%d/%m/%Y %H:%i:%s') and END_TIME <= STR_TO_DATE('13/11/2019 18:15:08', '%d/%m/%Y %H:%i:%s')";
			String sql = "select count(*) completed from transactions t, groups g, bot b where g.id = b.Process_Id and b.id = t.WORKER_ID and g.Type = 'process' and g.Name = '" +
					processName + "'  and (t.EXCEPTION_TYPE is NULL or t.EXCEPTION_TYPE = '')";
			if (condition != null && !condition.isEmpty()) {
				sql += " and " + condition;
			}
			System.out.println("sql :::: "+sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				int result = rs.getInt("completed");
				return result;
			}
			return 0;
		} finally {
			if (rs != null) {
				rs.close();
			}
		}
		
	}

	/**
	 * Get pending transaction count
	 * @param mysqlConn
	 * @param st
	 * @param reportType
	 * @param processName
	 * @return
	 * @throws SQLException
	 */
	protected int getPendingTxnCount(Connection mysqlConn, Statement st, String reportType, String processName) throws SQLException {
		ResultSet rs = null;
		try {
			String condition = this.getPendingCondition(reportType);
			
			String sql = "select count(*) completed from transactions t, groups g, bot b where b.id = t.WORKER_ID and g.id = b.Process_Id and g.Type = 'process' and g.Name = '" +
					processName + "' and t.END_TIME is NULL and (t.EXCEPTION_TYPE is NULL  or t.EXCEPTION_TYPE = '')";
			if (condition != null && !condition.isEmpty()) {
				sql += " and " + condition;
			}
			System.out.println("sql :::: "+sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				int result = rs.getInt("completed");
				return result;
			}
			return 0;
		} finally {
			if (rs != null) {
				rs.close();
			}
		}
		
	}

	/**
	 * Get exception transaction count
	 * @param mysqlConn
	 * @param st
	 * @param reportType
	 * @param processName
	 * @return
	 * @throws SQLException
	 */
	protected int getExceptionTxnCount(Connection mysqlConn, Statement st, String reportType, String processName) throws SQLException {
		ResultSet rs = null;
		try {
			String condition = this.getCompleteCondition(reportType);
			
			String sql = "select count(*) txncount from transactions t, groups g, bot b where b.id = t.WORKER_ID and g.id = b.Process_Id and g.Type = 'process' and g.Name = '" +
					processName + "' and (t.EXCEPTION_TYPE is not NULL and t.EXCEPTION_TYPE != '')";
			if (condition != null && !condition.isEmpty()) {
				sql += " and " + condition;
			}
			System.out.println("sql :::: "+sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				int result = rs.getInt("txncount");
				return result;
			}
			return 0;
		} finally {
			if (rs != null) {
				rs.close();
			}
		}
		
	}

	/**
	 * Get tech exception transaction count
	 * @param mysqlConn
	 * @param st
	 * @param reportType
	 * @param processName
	 * @return
	 * @throws SQLException
	 */
	protected int getTechExceptionTxnCount(Connection mysqlConn, Statement st, String reportType, String processName) throws SQLException {
		ResultSet rs = null;
		try {
			String condition = this.getCompleteCondition(reportType);
			
			String sql = "select count(*) txncount from transactions t, groups g, bot b where b.id = t.WORKER_ID and g.id = b.Process_Id and g.Type = 'process' and g.Name = '" +
					processName + "' and t.EXCEPTION_TYPE <>'1'";
			if (condition != null && !condition.isEmpty()) {
				sql += " and " + condition;
			}
			System.out.println("getTechExceptionTxnCount(): sql :::: "+sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				int result = rs.getInt("txncount");
				return result;
			}
			return 0;
		} finally {
			if (rs != null) {
				rs.close();
			}
		}
		
	}

	/**
	 * Get business exception transaction count
	 * @param mysqlConn
	 * @param st
	 * @param reportType
	 * @param processName
	 * @return
	 * @throws SQLException
	 */
	protected int getBusinessExceptionTxnCount(Connection mysqlConn, Statement st, String reportType, String processName) throws SQLException {
		ResultSet rs = null;
		try {
			String condition = this.getCompleteCondition(reportType);
			
			String sql = "select count(*) txncount from transactions t, groups g, bot b where b.id = t.WORKER_ID and g.id = b.Process_Id and g.Type = 'process' and g.Name = '" +
					processName + "' and t.EXCEPTION_TYPE <>'2'";
			if (condition != null && !condition.isEmpty()) {
				sql += " and " + condition;
			}
			System.out.println("getBusinessExceptionTxnCount(): sql :::: "+sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				int result = rs.getInt("txncount");
				return result;
			}
			return 0;
		} finally {
			if (rs != null) {
				rs.close();
			}
		}
		
	}

	/**
	 * Get other exception transaction count
	 * @param mysqlConn
	 * @param st
	 * @param reportType
	 * @param processName
	 * @return
	 * @throws SQLException
	 */
	protected int getOtherExceptionTxnCount(Connection mysqlConn, Statement st, String reportType, String processName) throws SQLException {
		ResultSet rs = null;
		try {
			String condition = this.getCompleteCondition(reportType);
			
			String sql = "select count(*) txncount from transactions t, groups g, bot b where b.id = t.WORKER_ID and g.id = b.Process_Id and g.Type = 'process' and g.Name = '" +
					processName + "' and t.EXCEPTION_TYPE != '' and t.EXCEPTION_TYPE is not NULL and t.EXCEPTION_TYPE !='1' and t.EXCEPTION_TYPE !='2'";
			if (condition != null && !condition.isEmpty()) {
				sql += " and " + condition;
			}
			System.out.println("getOtherExceptionTxnCount(): sql :::: "+sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				int result = rs.getInt("txncount");
				return result;
			}
			return 0;
		} finally {
			if (rs != null) {
				rs.close();
			}
		}
		
	}

	/**
	 * Return SLA config
	 * @param mysqlConn
	 * @param st
	 * @param processName
	 * @param workType
	 * @return
	 */
	Map<Integer, SLAConfig> getSLAConfig(Connection mysqlConn, Statement st, String processName, WorkerType workType) throws SQLException {
		ResultSet rs = null;
		try {
			String table = null;
			String sql = "";
			if (workType == WorkerType.BOT) {
				table = "bot";
				sql = "select b.ID, avgEfforts, avgEffortsSaved from " + table + " b join groups g on g.id = b.Process_Id where g.Type = 'process' and g.Name = '" +
						processName +"'";
			} else {
				table = "human_worker";
				sql = "select b.ID, avgEfforts, 0 as avgEffortsSaved from " + table + " b join groups g on g.id = b.Process_Id where g.Type = 'process' and g.Name = '" +
						processName +"'";
			}
			Map<Integer, SLAConfig> map = new HashMap<Integer, SLAConfig>();
			System.out.println("getSLAConfig(): sql :::: "+sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				int id = rs.getInt("ID");
				int avgEfforts = rs.getInt("avgEfforts");
				int avgEffortsSaved = rs.getInt("avgEffortsSaved");
				map.put(id, new SLAConfig(avgEfforts, avgEffortsSaved));
			}
			return map;
		} finally {
			if (rs != null) {
				rs.close();
			}
		}
	}

	/**
	 * Compute result
	 * @param botTxnTime
	 * @param botConfig
	 * @param map
	 * @param workerType
	 */
	void computeResult(Map<Integer, Integer> botTxnTime, Map<Integer, SLAConfig> botConfig, Map<String, Integer>map, WorkerType workerType) {
		Iterator<Map.Entry<Integer, Integer>> entries = botTxnTime.entrySet().iterator();
		int e_count = 0;
		int s_count = 0;
		int avg_count = 0;
		int avg_txn_time = 0;
		double efficiency = 0;
		int minutes_saved = 0;
		while (entries.hasNext()) {
		    Map.Entry<Integer, Integer> entry = entries.next();
		    int worker_id = entry.getKey();
		    int txn_time = entry.getValue();
		    SLAConfig config = botConfig.get(worker_id);
		    if (config != null) {
		    	if (config.avgEfforts > 0 && txn_time > 0) {
		    		efficiency += ((100 * config.avgEfforts) / txn_time);
		    		e_count++;
		    	}
		    	if (config.avgEfforts > 0 && txn_time > 0 && config.avgEffortsSaved >= 0) {
		    		minutes_saved += config.avgEffortsSaved + (config.avgEfforts - txn_time);
		    		s_count++;
		    	}
		    }
		    avg_txn_time += txn_time;
		    avg_count++;
		}
		String worker = workerType.name().toLowerCase();
		if (avg_count > 0) {
			map.put("avg_" + worker + "_txn_minutes", (int)(avg_txn_time/avg_count));
		} else {
			map.put("avg_" + worker + "_txn_minutes", 0);
		}
		if (e_count > 0) {
			map.put(worker + "_efficiency", (int)(efficiency/e_count));
		} else {
			map.put(worker + "_efficiency", (int)0);
		}
		if (s_count > 0) {
			map.put(worker + "_minutes_saved", (int)(minutes_saved/s_count));
		} else {
			map.put(worker + "_minutes_saved", (int)0);
		}
	}

	/**
	 * Retrieve average transaction time in minutes at per work id basis
	 * @param mysqlConn
	 * @param st
	 * @param reportType
	 * @param processName
	 * @param workType
	 * @return
	 */
	Map<Integer, Integer> getAvgTransactionTime(Connection mysqlConn, Statement st, 
			String reportType, String processName, WorkerType workType) throws SQLException {
		ResultSet rs = null;
		try {
			String condition = this.getCompleteCondition(reportType);
			
			String type = null;
			String sql = "";
			if (workType == WorkerType.BOT) {
				type = "BOT";
			} else {
				type = "human_worker";
			}
			sql = "select WORKER_ID, AVG(TIMESTAMPDIFF(MINUTE, START_TIME, END_TIME)) as delta from transactions t " +
			      ", groups g, bot b where b.id = t.WORKER_ID and g.id = b.Process_Id and g.Type = 'process' and g.Name = '" + processName + "' and t.END_TIME is not NULL and " +
				  "(t.EXCEPTION_TYPE is NULL or t.EXCEPTION_TYPE = '') and t.WORKER_TYPE = '" + type.toUpperCase() + "'";
			if (condition != null && !condition.isEmpty()) {
				sql += " and " + condition;
			}
			sql += " group by t.WORKER_ID";
			System.out.println("getAvgTransactionTime(): sql :::: "+sql);
			rs = st.executeQuery(sql);
			Map<Integer, Integer> map = new HashMap<Integer, Integer>();
			while (rs.next()) {
				int worker_id = rs.getInt("WORKER_ID");
				int delta = rs.getInt("delta");
				map.put(worker_id, delta);
			}
			return map;
		} finally {
			if (rs != null) {
				rs.close();
			}
		}
	}

	/**
	 * Retrieve total transaction time in minutes
	 * @param mysqlConn
	 * @param st
	 * @param reportType
	 * @param processName
	 * @param workType
	 * @return
	 */
	int getTotalTransactionTime(Connection mysqlConn, Statement st, 
			String reportType, String processName, WorkerType workType) throws SQLException {
		ResultSet rs = null;
		try {
			String condition = this.getCompleteCondition(reportType);
			
			String type = null;
			String sql = "";
			if (workType == WorkerType.BOT) {
				type = "bot";
			} else {
				type = "human_worker";
			}
			sql = "select SUM(TIMESTAMPDIFF(MINUTE, START_TIME, END_TIME)) as delta from transactions t " +
			      ", groups g, bot b where b.id = t.WORKER_ID and g.id = b.Process_Id and g.Type = 'process' and g.Name = '" + processName + "' and t.END_TIME is not NULL and " +
				  "(t.EXCEPTION_TYPE is NULL or t.EXCEPTION_TYPE = '') and t.WORKER_TYPE = '" + type.toUpperCase() + "'";
			if (condition != null && !condition.isEmpty()) {
				sql += " and " + condition;
			}
			System.out.println("getTotalTransactionTime(): sql :::: "+sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				int delta = rs.getInt("delta");
				return delta;
			}
			return 0;
		} finally {
			if (rs != null) {
				rs.close();
			}
		}
	}
}
