package com.vbrain.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.vbrain.common.io.Constants;
import com.vbrain.common.io.Data;
import com.vbrain.common.io.Group;
import com.vbrain.dao.BotsDao;

public class BotsDaoImpl extends ConnectionDaoImpl implements BotsDao{

	private static List<Group> allGroups = null;
	
	
	
	/**
	 * @return the allGroups
	 */
	private static List<Group> getAllGroups() {
		return allGroups;
	}

	/**
	 * @param allGroups the allGroups to set
	 */
	private static void setAllGroups(List<Group> allGroups) {
		BotsDaoImpl.allGroups = allGroups;
	}
	
	
	/**
	 * 
	 * @param workStep
	 * @param status
	 * @param function
	 * @return
	 */
	public List<Data> getBotListByStatus(String workStep, String status, String function){
		Connection mysqlConn = null;
		Statement st = null;
		Data data = null;
		List<Data> dataList = null;
		ResultSet rs = null;
		try{
			
			getGroups();

			String condition = "";

			if(workStep.equalsIgnoreCase(Constants.WORKSTEP) && status.equalsIgnoreCase(Constants.WORKSTEP)){
				condition = "";
			}
			else if(workStep.equalsIgnoreCase(Constants.WORKSTEP) && !status.equalsIgnoreCase(Constants.WORKSTEP)){
				condition = " and b.status = '"+status+"'";
			}
			else if(!workStep.equalsIgnoreCase(Constants.WORKSTEP) && !status.equalsIgnoreCase(Constants.WORKSTEP)){
				condition = " and b.status = '"+status+"' and g.name = '"+workStep+"'";
			}
			else if(!workStep.equalsIgnoreCase(Constants.WORKSTEP) && status.equalsIgnoreCase(Constants.WORKSTEP)){ 
				condition = " and g.name = '"+workStep+"'";
			}

			String sql;
			if(function == null || function.isEmpty()) {
				sql = 	" SELECT b.bot_key as botKey, b.provider as provider, b.status as status, b.process_id as processId, g.name as processName, "+
							" (select count(*) from transactions where status='0' and worker_id = b.id and worker_type='BOT') as transactions "+
							" FROM bot b, groups g "+
							" where b.isDisabled = '0'  and b.process_id = (select id from groups where isDisabled = '0'  and id = b.process_id )  and g.id = b.process_id " + condition ;
			} else {
				sql = 	" SELECT b.bot_key as botKey, b.provider as provider, b.status as status, b.process_id as processId, g.name as processName, "+
						" (select count(*) from transactions where status='0' and worker_id = b.id and worker_type='BOT') as transactions "+
						" FROM bot b, groups g, groups fg "+
						" where b.isDisabled = '0'  and b.process_id = (select id from groups where isDisabled = '0'  and id = b.process_id )  and g.id = b.process_id and "+
						" g.Parent_Id= fg.id and fg.Type = 'function' and fg.Name = '" + function + "' "
						+ condition ;
			}
			
			System.out.println("sql ::::::"+sql);
			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);
			dataList = new ArrayList<Data>();
			int i = 1;
			String statusId = "";

			while(rs.next()){


				data = new Data();
				data.setIndex(i++);
				data.setBotKey( rs.getString("botkey") );
				data.setBotProvider( rs.getString("provider") );
				statusId = rs.getString("status");

				if("1".equalsIgnoreCase(statusId)){
					data.setBotStatus(Constants.BOT_STATUS_ACTIVE);
				}
				else if("0".equalsIgnoreCase(statusId)){
					data.setBotStatus(Constants.BOT_STATUS_INACTIVE);
				}
				else if("2".equalsIgnoreCase(statusId)){
					data.setBotStatus(Constants.BOT_STATUS_WAITING);
				}
				data.setProcessName(rs.getString("processName"));
				data.setTotalTransactions(rs.getLong("transactions"));
				
				String country = getCountry(rs.getString("processId"));
				data.setRegion(country);
				dataList.add(data);


			}

			System.out.println("dataList.size() :::::::: "+dataList.size());

		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			try{
				mysqlConn.close();
				st.close();
				rs.close();

			}
			catch(Exception e){
				e.printStackTrace();
			}
		} 

		return dataList;
	}

	/**
	 * @return
	 */
	public List<Data> getBotList(String function){
		Connection mysqlConn = null;
		Statement st = null;
		Data data = null;
		List<Data> dataList = null;
		ResultSet rs = null;
		try{
			String sql;
			if (function == null || function.isEmpty()) {
				sql = 	" SELECT  distinct(processName) processName, "+
						" (select count(*) from group_bot_view where status='1' and processName = b.processName  ) active, "+
						" (select count(*) from group_bot_view where status='0' and processName = b.processName  ) inactive, "+
						" (select count(*) from group_bot_view where status='2' and processName = b.processName  ) waiting "+
						" FROM group_bot_view b "+
						" where  b.processId = (select id from groups where isDisabled = '0'  and id = b.processId ) "+
						" group by b.status, b.processName "+ 
						" order by b.processId";
			} else {
				sql = 	" SELECT  distinct(processName) processName, "+
						" (select count(*) from group_bot_view where status='1' and processName = b.processName  ) active, "+
						" (select count(*) from group_bot_view where status='0' and processName = b.processName  ) inactive, "+
						" (select count(*) from group_bot_view where status='2' and processName = b.processName  ) waiting "+
						" FROM group_bot_view b, groups pg, groups fg"+
						" where b.processId = pg.id and pg.Parent_id = fg.id and fg.Type = 'function' and fg.Name = '" + function + 
						"' and b.processId = (select id from groups where isDisabled = '0'  and id = b.processId ) "+
						" group by b.status, b.processName "+ 
						" order by b.processId";
			}
			
			System.out.println("sql ::::::"+sql);

			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);
			dataList = new ArrayList<Data>();
			while(rs.next()){
				data = new Data();
				data.setProcessName(rs.getString("processName"));
				data.setBotActiveCount( rs.getInt(Constants.BOT_STATUS_ACTIVE) );
				data.setBotInactiveCount( rs.getInt(Constants.BOT_STATUS_INACTIVE) );
				data.setBotWaitingCount( rs.getInt(Constants.BOT_STATUS_WAITING) );
				dataList.add(data);
			}
			System.out.println("dataList.size() :::::::: "+dataList.size());

		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			try{
				mysqlConn.close();
				st.close();
				rs.close();

			}
			catch(Exception e){
				e.printStackTrace();
			}
		} 

		return dataList;
	}
	/**
	 * 
	 * @param botKey
	 * @param statusId
	 * @return
	 */
	public int changeBotStatus(String botKey, String statusId){

		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		try {

			System.out.println("status ["+statusId+"] | bot_key ="+botKey+" ");
			
			String sql = "UPDATE bot SET STATUS ='"+statusId+"' WHERE bot_key ='"+botKey+"' ";
			
			System.out.println("sql ::::::::::::::: "+sql);

			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();

			result = st.executeUpdate(sql);

			System.out.println("result :::::::::: "+result);
		} 
		catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			System.exit(1);
		} 
		finally {
			try {
				mysqlConn.close();
				st.close();
			} 
			catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return result;

	}


	private String getCountry(String parentId){
		
		String country = "";
		try{
			List<Group> groups = getAllGroups();
			
			System.out.println("groups.size() :::::::::::::::: "+groups.size());
			
			int isParent = 1;
			
			
			int count = 0;
			
			
				
			for(int i=0; i<groups.size(); i++){
				Group group = groups.get(i);
				
				//System.out.println("parentId -------> "+parentId+" | groupId -------> "+group.getId());
				
				if( parentId.equalsIgnoreCase(group.getId()) ){
					
					
					System.out.println("-------------------> "+group.getType() +" Name --------> "+group.getName());
					parentId = group.getParentId();
					
					if(group.getType().equalsIgnoreCase("country")){
						country = group.getName();
						isParent = 0;
						break;
					}
				}
			}
			
			
		}
		catch (Exception e){
			e.printStackTrace();
		}
		return country;
	}
	
	
	private void getGroups(){
    	Connection mysqlConn = null;
        Statement st = null;
        //Data data = null;
        Data data = null;
        ResultSet rs = null;
        List<Group> groups = null;
    	try{
    		

    		//String sql = 	"SELECT * FROM groups where isDisabled = '0' order by parent_id desc";
    		String sql = 	"SELECT * FROM groups order by parent_id desc";
    		System.out.println("sql : "+sql);
    		
    		mysqlConn = getMySqlConnection();
    		st = mysqlConn.createStatement();
    		rs = st.executeQuery(sql);
    		groups = new ArrayList<Group>();
    		Group group = null;
    		
    		while(rs.next()){
    			group = new Group();
    			
    			group.setId(rs.getString("id"));
    			group.setName(rs.getString("name"));
    			group.setDescription(rs.getString("description"));
    			group.setType(rs.getString("type"));
    			group.setParentId(rs.getString("parent_id"));
    			group.setParentGroupId(rs.getString("Parent_Group_Id"));
    			group.setNodes(new ArrayList<Group>());
    			
    			if("0".equals(rs.getString("isDisabled"))){
    				group.setIsDisabled("enabled");
    				group.setIconStyle("remove");
    				
    			}
    			else {
    				group.setIsDisabled("disabled");
    				group.setIconStyle("ok");
    			}
    			
    			
    			//groupIds = groupIds + rs.getString("id") + ",";
    			
    			groups.add(group);
    		}
    		
    		setAllGroups(groups);
    		
    		
    	}
    	catch(Exception e){
    		e.printStackTrace();
    	}
    	finally {
    		try{
	           mysqlConn.close();
	           st.close();
	           rs.close();

    		}
    		catch(Exception e){
    			e.printStackTrace();
    		}
        } 

    	
    }

}
