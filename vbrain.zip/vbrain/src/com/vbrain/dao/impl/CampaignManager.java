package com.vbrain.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.sql.DataSource;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.vbrain.dao.impl.ImportImpl.ImportEntity;
import com.vbrain.dao.impl.ImportImpl.WfVersion;
import com.vbrain.db.connection.VBrainDbManager;
import com.vbrain.db.connection.WfDbManager;


public class CampaignManager implements Job{

	public void updateDataBase() {

		ResultSet rsObj = null;
		ResultSet rsObjForDate = null;
		
		Connection connObjVb = null;
		Connection connObjWf = null;
		
		PreparedStatement pstmtObjFordatetime = null;
		PreparedStatement pstmtObjForCampaignData = null;
		PreparedStatement pstmtObjForinsert = null;
		
		PreparedStatement updateobj = null;

		DateTime lastrecordtime = null;

		WfDbManager wfmgr = new WfDbManager();
		VBrainDbManager vbrainmgr = new VBrainDbManager();

		try {

			DataSource dataSourceVB = vbrainmgr.setUpPool();
			DataSource dataSourceWF = wfmgr.setUpPool();

			// Performing Database Operation!
			System.out.println("\n=====Making A New Connection Object For Db Transaction=====\n");
			try {
			    connObjVb = dataSourceVB.getConnection();
			} catch(Exception e) {
			    System.out.println("Failed at dataSourceVB ");
			}
			
			pstmtObjFordatetime = selectLastRecordDatetime(connObjVb);
			rsObjForDate = pstmtObjFordatetime.executeQuery();
			
			if (rsObjForDate.next()) {
				lastrecordtime = convertToStandardTime(rsObjForDate.getObject("LASTRECORD_TIMESTAMP").toString());
			} else if (lastrecordtime == null) {
				lastrecordtime = DateTime.now();
			}
			
			try {
			    connObjWf = dataSourceWF.getConnection();
            } catch(Exception e) {
                System.out.println("Failed at dataSourceWF ");
            }
			// Select Bp Related data from vbrain tables
			pstmtObjForCampaignData = selectCampaignData(connObjWf, lastrecordtime);
			rsObj = pstmtObjForCampaignData.executeQuery();
			pstmtObjForinsert = insertWfCampaign(connObjVb);

			while (rsObj.next()) {
				pstmtObjForinsert = convertCompaignData(pstmtObjForinsert, rsObj);
				pstmtObjForinsert.addBatch();
			}

			pstmtObjForinsert.executeBatch();
			
	
			String updatesql = "{CALL update_lastrecord_campaign_sp()}";
			System.out.println("CampaignManager : " + updatesql);
			updateobj = connObjVb.prepareStatement(updatesql);
			updateobj.executeUpdate();
			
			System.out.println("\n=====Releasing Connection Object To Pool=====\n");

		} catch (Exception sqlException) {
			sqlException.printStackTrace();
		} finally {
			try {		       
				// Closing ResultSet Object
				if (rsObj != null) {
					rsObj.close();
				}
				
				// Closing PreparedStatement Object
				if (pstmtObjForCampaignData != null) {
					pstmtObjForCampaignData.close();
				}
				if (pstmtObjForinsert != null) {
					pstmtObjForinsert.close();
				}
				if (updateobj != null) {
					updateobj.close();
				}
				// Closing Connection Object
				if (connObjWf != null) {
					connObjWf.close();
				}
				if (connObjVb != null) {
					connObjVb.close();
				}
			} catch (Exception sqlException) {
				sqlException.printStackTrace();
			}
		}
		
	}

	private DateTime convertToStandardTime(String datetime) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		Date coverteddatewithseconds = formatter.parse(datetime);
		String converttosimpledateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(coverteddatewithseconds);
		DateTimeFormatter formatters = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
		DateTime converteddatetimeobj = formatters.parseDateTime(converttosimpledateformat);
		return converteddatetimeobj;
	}
	
	private PreparedStatement selectLastRecordDatetime(Connection con) throws SQLException {
		String selecttimestamp = "SELECT IFNULL(LASTRECORD_TIMESTAMP_CAMPAIGN, from_unixtime(0)) as LASTRECORD_TIMESTAMP FROM vbrain.wf_configuration";
		System.out.println("CampaignManager : " + selecttimestamp);
		PreparedStatement insertObj = con.prepareStatement(selecttimestamp);
		return insertObj;
	}
	
	private PreparedStatement convertCompaignData(PreparedStatement insertObjforCampaign, ResultSet rsObjforCampaign)
			throws SQLException, ParseException {
		insertObjforCampaign.setString(1, rsObjforCampaign.getString("mappingId"));
		insertObjforCampaign.setString(2, rsObjforCampaign.getString("campaingId"));
		insertObjforCampaign.setString(3, rsObjforCampaign.getString("stepId"));
		insertObjforCampaign.setString(4, rsObjforCampaign.getString("bpName"));
		insertObjforCampaign.setString(5, rsObjforCampaign.getString("stepTitle"));
		insertObjforCampaign.setString(6, rsObjforCampaign.getString("deleted"));
		insertObjforCampaign.setString(7, rsObjforCampaign.getString("stepIndex"));
		insertObjforCampaign.setString(8, rsObjforCampaign.getString("bpLastModified"));
		insertObjforCampaign.setString(9, rsObjforCampaign.getString("stepLastModified"));

		return insertObjforCampaign;
	}
	
	
	private PreparedStatement insertWfCampaign(Connection con) throws SQLException {
		StringBuilder insertQuery = new StringBuilder("INSERT INTO vbrain.wf_campaign ");
		insertQuery.append("(MAPPING_ID, CAMPAIGN_ID, STEP_ID, BP_NAME, STEP_TITLE, DELETED, STEP_INDEX, BP_LASTMODIFIED, STEP_LASTMODIFIED) ");
		insertQuery.append("VALUES (?,?,?,?,?,?,?,?,?)");
		System.out.println("CampaignManager : " + insertQuery.toString());
		PreparedStatement inserttempObj = con.prepareStatement(insertQuery.toString());
		return inserttempObj;
	}


	private PreparedStatement selectCampaignData(Connection con, DateTime lastrecordtime) throws SQLException {
		StringBuilder selectCampaignQuery = new StringBuilder("SELECT title, id, lastModified FROM Campaign");
		selectCampaignQuery.append(" WHERE lastModified > '").append(lastrecordtime).append("'");
		
		StringBuilder getMappingQuery = new StringBuilder();
		getMappingQuery.append("SELECT ");
		getMappingQuery.append("cm.id as mappingId, bp.id as campaingId, s.id as stepId, ");
		getMappingQuery.append("bp.title as bpName, s.title as stepTitle, ");
		getMappingQuery.append("cm.deleted as deleted, cm.stepIndex as stepIndex, ");
		getMappingQuery.append("bp.lastModified as bpLastModified, s.lastModified as stepLastModified ");
		getMappingQuery.append("FROM wfdb.CampaignMap cm ");
		getMappingQuery.append("JOIN (").append(selectCampaignQuery).append(") s ON cm.campaign = s.id ");
		getMappingQuery.append("JOIN (").append(selectCampaignQuery).append(") bp ON cm.parent = bp.id ");
		
		System.out.println("CampaignManager : " + getMappingQuery.toString());
		PreparedStatement insertObj = con.prepareStatement(getMappingQuery.toString());
		return insertObj;
	}



	
	/**
     * Method triggered with scheduler.
     * 
     */
    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        CampaignManager connectionManager = new CampaignManager();
        //connectionManager.updateDataBase();
        connectionManager.updateDataBase2();
    }
    
    public void updateDataBase2() {
    	ImportImpl wfTrans = new ImportImpl(ImportEntity.CAMPAIGN);
		wfTrans.execute();
		
		ImportImpl wf82Trans = new ImportImpl(ImportEntity.CAMPAIGN, WfVersion.WF82);
		wf82Trans.execute();
    }
}