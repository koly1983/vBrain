package com.vbrain.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.vbrain.common.io.Constants;
import com.vbrain.common.io.Data;
import com.vbrain.common.io.Privilage;
import com.vbrain.common.io.Role;
import com.vbrain.common.io.User;
import com.vbrain.dao.PrivilageDao;
import com.vbrain.dao.UserDao;

public class PrivilageDaoImpl extends ConnectionDaoImpl implements  PrivilageDao{

	/**
	 * 
	 * @param startDate
	 * @param endDate
	 * @param workStep
	 * @param groupBy
	 * @return
	 */
	public List<Privilage> getPrivilages(String roleId){
		Connection mysqlConn = null;
		Statement st = null;
		Privilage privilage = null;
		List<Privilage> privilageList = null;
		ResultSet rs = null;
		try{

			String sql = "SELECT f.Id Category_Id, f.Category Category, f.Name Function_Name,  p.id Privilage_Id, p.function_id Function_Id, p.Role_Id Role_Id, p.access Access, r.Name Role_Name "+
						 " FROM functions f, privilage p, role r "+
						 " where p.role_id = '"+roleId+"' and f.id = p.Function_Id and p.Role_Id = r.id order by Category_Id;";

			System.out.println("sql :::: "+sql);

			mysqlConn = getMySqlConnection();
			st = mysqlConn.createStatement();
			rs = st.executeQuery(sql);
			privilageList = new ArrayList<Privilage>();
			
			while(rs.next()){
				privilage = new Privilage();
				privilage.setId(rs.getString("Privilage_Id"));
				privilage.setCategory(rs.getString("Category"));
				privilage.setFunctionName(rs.getString("Function_Name"));
				privilage.setFunctionId(rs.getString("Function_Id"));
				privilage.setRoleId(rs.getString("Role_Id"));
				privilage.setRoleName(rs.getString("Role_Name"));
				privilage.setAccess(rs.getString("Access"));

				privilageList.add(privilage);
			}

			
			System.out.println("dataList.size() :::::::: "+privilageList.size());

		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			closeResources(mysqlConn, st, rs);
		} 

		return privilageList;
	}
	
	
 	
 	
 	public int editPrivilage(String privilageId, String access){

		// Connection oracleConn = null;
		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		//ResultSet rs = null;
		try {

			if(privilageId != null && access != null  ){

				String tQuery = "";

				mysqlConn = getMySqlConnection();

				tQuery = "Update privilage "+
						" Set access = '"+access+"' where Id = '"+privilageId+"' ";
				
				System.out.println("tQuery ::::::: "+tQuery);

				st = mysqlConn.createStatement();

				result = st.executeUpdate(tQuery);

				System.out.println("Update Privilage result :::::::::: "+result);
			}
		} 
		catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			result = 0;
			//System.exit(1);
		} 
		finally {
			// release database resources
			//oracleConn.close();
			boolean closedResources = closeResources(mysqlConn, st, null);
			if(!closedResources) {
        		result = 0;
        	}
		}

		return result;
	}
 	
 	
 	public int addRole(Role role){
 		
 		int result = insertRole(role);
 		
 		if(result == 1){
 		
 			insertDefaultPrivilege(role.getName());
 		}
 		
 		return result;
 		
 	}
 	
 	private int insertRole(Role role){

		// Connection oracleConn = null;
		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		//ResultSet rs = null;
		try {

			if(role != null ){

				String tQuery = "";

				System.out.println("role    =" + role);
				//System.out.println("processId   =" + processId);
				
				int isDuplicate = isDuplicateRole(role.getName(), "add", "");
				
				if(isDuplicate == 0){
					
					mysqlConn = getMySqlConnection();
					tQuery = "INSERT INTO role "+
							"(Name) "+
							"VALUES ( '"+role.getName()+"' )";
					
					System.out.println("tQuery ::::::: "+tQuery);
	
					st = mysqlConn.createStatement();
	
					result = st.executeUpdate(tQuery);
	
					System.out.println("Add Role result :::::::::: "+result);
					
					
				}
				else {
					result = 2;
				}
			}
		} 
		catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			result = 0;
			//System.exit(1);
		} 
		finally {
			// release database resources
			//oracleConn.close();
			boolean closedResources = closeResources(mysqlConn, st, null);
			if(!closedResources) {
        		result = 0;
        	}
		}

		return result;
	}
 	
 	
 	private int insertDefaultPrivilege(String roleName){

		// Connection oracleConn = null;
		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		//ResultSet rs = null;
		try {

			if(roleName != null ){

				String tQuery = "";

				System.out.println("roleName    =" + roleName);
				
					
				mysqlConn = getMySqlConnection();
				tQuery = " INSERT INTO privilage (function_id, role_id, access)  SELECT id, (select id from role where name = '"+roleName+"'), '0' FROM functions";
				
				System.out.println("tQuery ::::::: "+tQuery);

				st = mysqlConn.createStatement();

				result = st.executeUpdate(tQuery);

				System.out.println("Add insertDefaultPrivilege result :::::::::: "+result);
				
			}
		} 
		catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			result = 0;
			//System.exit(1);
		} 
		finally {
			// release database resources
			//oracleConn.close();
			boolean closedResources = closeResources(mysqlConn, st, null);
			if(!closedResources) {
        		result = 0;
        	}
		}

		return result;
	}
 	
 	
 	public int editRole(Role role){

		// Connection oracleConn = null;
		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		//ResultSet rs = null;
		try {

			if(role != null ){

				String tQuery = "";

				System.out.println("role    =" + role.getId());
				//System.out.println("processId   =" + processId);
				
				int isDuplicateUser = isDuplicateRole(role.getName(), "edit", role.getId());
				
				if(isDuplicateUser == 0){
				
					mysqlConn = getMySqlConnection();
	
					tQuery = "Update role "+
							" Set name = '"+role.getName()+"' where id = '"+role.getId()+"' ";
					
					System.out.println("tQuery ::::::: "+tQuery);
	
					st = mysqlConn.createStatement();
	
					result = st.executeUpdate(tQuery);
	
					System.out.println("Update Role result :::::::::: "+result);
				}
				else {
					result = 2;
				}
			}
		} 
		catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			result = 0;
			//System.exit(1);
		} 
		finally {
			// release database resources
			//oracleConn.close();
			boolean closedResources = closeResources(mysqlConn, st, null);
			if(!closedResources) {
        		result = 0;
        	}
		}

		return result;
	}
 	
 	
 	public int changeRole(String roleId, String mode){

		// Connection oracleConn = null;
		Connection mysqlConn = null;
		Statement st = null;
		int result = 0;
		//ResultSet rs = null;
		try {

			if(roleId != null && roleId.trim().length() > 0 ){

				String tQuery = "";

				System.out.println("roleId    =" + roleId);
				//System.out.println("processId   =" + processId);
				
				mysqlConn = getMySqlConnection();

				tQuery = "Update role "+
						" Set isDisabled = '"+mode+"' where id  = '"+roleId+"' ";
						
				
				System.out.println("tQuery ::::::: "+tQuery);

				st = mysqlConn.createStatement();

				result = st.executeUpdate(tQuery);

				System.out.println("Change role result :::::::::: "+result);
			}
		} 
		catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			result = 0;
			//System.exit(1);
		} 
		finally {
			// release database resources
			//oracleConn.close();
			boolean closedResources = closeResources(mysqlConn, st, null);
			if(!closedResources) {
        		result = 0;
        	}
		}

		return result;
	}
 	
 		
 	private int isDuplicateRole(String name, String mode, String id){
    	Connection mysqlConn = null;
        Statement st = null;
        ResultSet rs = null;
        
        
    	try{
    		
    		String sql = 	"SELECT * FROM role where name = '"+name+"' ";
    		if("edit".equalsIgnoreCase(mode)){
    			sql = 	"SELECT * FROM role where name = '"+name+"' and id != '"+id+"' ";
    		}
    		mysqlConn = getMySqlConnection();
    		st = mysqlConn.createStatement();
    		rs = st.executeQuery(sql);
    		
    		if(rs.next()){
    			return 1;
    		}
    		else {
    			return 0;
    		}
    		
    	}
    	catch(Exception e){
    		e.printStackTrace();
    		return 2;
    	}
    	finally {
    		boolean closedResources = closeResources(mysqlConn, st, rs);
    		if(!closedResources) {
        		return 2;
        	}
        } 

    	
    }
	

}
