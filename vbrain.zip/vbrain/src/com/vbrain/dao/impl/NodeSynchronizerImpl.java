/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vbrain.dao.impl;

import com.vbrain.common.util.ConfigNameExtractor;
import com.vbrain.dao.NodeSynchronizer;
import com.vbrain.hibernate.model.Hubs;
import com.vbrain.hibernate.model.Nodes;
import com.vbrain.hibernate.model.Servers;
import com.vbrain.hibernate.model.Status;
import com.vbrain.nodemonitor.model.Statuses;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 *
 * @author llihind
 */
public class NodeSynchronizerImpl implements NodeSynchronizer {

    NodeStatusHandlerImpl statusHandler;

    public NodeSynchronizerImpl() {
        statusHandler = new NodeStatusHandlerImpl();
    }

    @Override
    public void syncNodes(String hubName, String url) throws Exception {
        try {
            //Retreave node and hub status object
            HashMap subFilters = new HashMap();
            subFilters.put("status", Statuses.ACTIVE.toString());
            Status nodeStatus = (Status) statusHandler.getDbAdapter().readDataObjfromTable(Status.class, subFilters);
            subFilters = new HashMap();
            subFilters.put("status", Statuses.HEALTHY.toString());
            Status hubStatus = (Status) statusHandler.getDbAdapter().readDataObjfromTable(Status.class, subFilters);
            
            Map filters = new HashMap();
            filters.put("serverName", ConfigNameExtractor.compileServerName(url));
            Servers server = (Servers) statusHandler.getDbAdapter().readDataObjfromTable(Servers.class, filters);
            Hubs hub = statusHandler.getHub(hubName);

            if (server == null) {
                server = new Servers();
                server.setServerName(ConfigNameExtractor.compileServerName(url));
                server.setUrl(ConfigNameExtractor.compileServerUrl(url));
                statusHandler.getDbAdapter().insertDataToTable(server);
            }

            if (hub == null) {
                hub = new Hubs();
                hub.setHubName(hubName);
                hub.setUrl(url);
                hub.setServers(server);
                hub.setStatus(hubStatus);
                hub.setEmailState(true);
                statusHandler.getDbAdapter().insertDataToTable(hub);
            }
            
            List<com.vbrain.nodemonitor.model.Nodes> nodeList = statusHandler.readNodeObjects(url);
            if(nodeList != null) {
                for (com.vbrain.nodemonitor.model.Nodes nodes : nodeList) {
                    Nodes node = new Nodes();
                    node.setNodeName(nodes.getNodeName());
                    node.setUrl(nodes.getUrl());
                    node.setHubs(hub);
                    node.setStatus(nodeStatus);
                    statusHandler.getDbAdapter().insertDataToTable(node);
                }
                
                //clearing up all connections
                statusHandler.getDbAdapter().getSession().clear();
                statusHandler.getDbAdapter().getSession().close();
            }else {
                throw new Exception("Could not read nodes from given url");
            }
            
        } catch (Exception e) {
            throw new Exception("Synchronizing nodes failed with : "+e);
        }
    }
    
    @Override
    public void deSyncNodes(String hubName) throws Exception {
        try {
            List<Nodes> nodes = statusHandler.getNodesList(hubName);

            for (Nodes node : nodes) {
               statusHandler.getDbAdapter().deleteDataOnTable(node);
            }
            statusHandler.getDbAdapter().deleteDataOnTable(statusHandler.getHub(hubName));
            
            //Clearing up all connections
            statusHandler.getDbAdapter().getSession().clear();
            statusHandler.getDbAdapter().getSession().close();
        } catch (Exception e) {
            throw new Exception("DeSynchronizing nodes failed with : "+e);
        } 
    }

}
