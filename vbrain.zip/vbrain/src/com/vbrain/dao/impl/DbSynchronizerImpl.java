/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vbrain.dao.impl;

import com.vbrain.adapter.CommonDbAdapter;
import com.vbrain.adapter.impl.CommonDbAdapterImpl;
import com.vbrain.bpsynchronizer.DbTypes;
import com.vbrain.dao.DbSynchronizer;
import com.vbrain.hibernate.access.model.BusinessProcess;
import com.vbrain.hibernate.access.model.TempBps;
import com.vbrain.hibernate.sql.model.Campaign;
import com.vbrain.hibernate.sql.model.Run;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 *
 * @author llihind
 */
public class DbSynchronizerImpl implements DbSynchronizer {

    private final CommonDbAdapter sqlDBAdapter;
    private final CommonDbAdapter accessDBAdapter;

    public DbSynchronizerImpl() {
        sqlDBAdapter = new CommonDbAdapterImpl(DbTypes.SQL.toString());
        accessDBAdapter = new CommonDbAdapterImpl(DbTypes.ACCESS.toString());
    }

    @Override
    public List<Campaign> getFilteredBpList(List<Run> runInstanceList) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Run> getFilteredRunListByDateRange() throws Exception {
        try {
            //Setting up date formats
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            Date today = new Date();
            long DAY_IN_MS = 1000 * 60 * 60 * 24;
            Date lastWeek = new Date(System.currentTimeMillis() - (7 * DAY_IN_MS));

            String formattedToday = dateFormat.format(today);
            String formattedLastweek = dateFormat.format(lastWeek);
            System.out.println("Last Week : " + formattedLastweek);
            System.out.println("Today : " + formattedToday);

            List<Run> runDataList = new ArrayList<>();

            String query = "select DISTINCT c.title as title from Campaign c INNER JOIN Run r ON (c.id = r.campaign_id) WHERE r.startDate > '" + formattedLastweek + "' AND r.startDate < '" + formattedToday + "'";
            List<Object> rows = sqlDBAdapter.getDataObjsUsingQuery(query);

            for (Object row : rows) {
                Campaign campaign = new Campaign();
                Run run = new Run();

                if (row != null) {
                    campaign.setTitle(row.toString());
                    run.setCampaign(campaign);
                }
                

                runDataList.add(run);

            }

            return runDataList;
        } catch (Exception e) {
            throw new Exception("Getting Filtered Run List Failed With : " + e);
        }

    }

    @Override
    public void syncDatabases(List<Run> runInstanceList) throws Exception {
        List<BusinessProcess> mainBpList = accessDBAdapter.readDataListfromTable(BusinessProcess.class, Collections.emptyMap());
        accessDBAdapter.clearTable(TempBps.class);
        System.out.println("Run Bp List Size : " + runInstanceList.size());
        System.out.println("Process Bp List Size : " + mainBpList.size());
        for (Run runInstance : runInstanceList) {
            boolean isBpFound = false;
            String bpName = runInstance.getCampaign().getTitle();
            for (BusinessProcess businessProcess : mainBpList) {
                if (businessProcess.getProcessName().equals(bpName)) {
                    isBpFound = true;
                    break;
                }
            }

            if (!isBpFound) {
                TempBps bp = new TempBps();
                bp.setBpName(bpName);
                accessDBAdapter.insertDataToTable(bp);
            }
        }
    }

    @Override
    public void reverseSyncDatabases(List<Run> runInstanceList) throws Exception {
        List<BusinessProcess> mainBpList = accessDBAdapter.readDataListfromTable(BusinessProcess.class, Collections.emptyMap());
        System.out.println("Run Bp List Size : " + runInstanceList.size());
        System.out.println("Process Bp List Size : " + mainBpList.size());
        int count = 0;
        for (BusinessProcess businessProcess : mainBpList) {
            boolean isBpFound = false;
            String bpName = businessProcess.getProcessName();
            for (Run runInstance : runInstanceList) {
                if (runInstance.getCampaign().getTitle().equals(bpName)) {
                    isBpFound = true;
                    break;
                }
            }

            if (!isBpFound) {
                List<TempBps> tempBps=accessDBAdapter.readDataListfromTable(TempBps.class, Collections.emptyMap());
                TempBps bp = new TempBps();
                if(count+1<=tempBps.size()){
                    bp = tempBps.get(count);
                }
                bp.setReverseBpName(bpName);
                accessDBAdapter.insertDataToTable(bp);
            }
            count++;
        }
    }

	@Override
	public void finalizeSynchronizer() {
		sqlDBAdapter.getSession().clear();
		sqlDBAdapter.getSession().close();
		
		accessDBAdapter.getSession().clear();
		accessDBAdapter.getSession().close();
		
	}

}
