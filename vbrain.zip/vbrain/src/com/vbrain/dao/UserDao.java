package com.vbrain.dao;

import java.util.List;

import com.vbrain.common.io.Bot;
import com.vbrain.common.io.Data;
import com.vbrain.common.io.Human;
import com.vbrain.common.io.RequestMessage;
import com.vbrain.common.io.Role;
import com.vbrain.common.io.User;

public interface UserDao {
	
	/**
	 * 
	 * @return
	 */
	public List<User> getUsers();
	
	
	/**
	 * 
	 * @param userId
	 * @return
	 */
	public User getUser(String userId);
	
	/**
	 * 
	 * @param requestMessage
	 * @return
	 */
	public int addUser(User user);
	
	/**
	 * 
	 * @param requestMessage
	 * @return
	 */
	public int editUser(User user);
			
	public int disableUser(String userId);
	
	public List<Role> getUserRoles();
	
	public User getUserPrivilage(String userId, String password);
	
}
