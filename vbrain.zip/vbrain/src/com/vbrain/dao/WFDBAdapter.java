package com.vbrain.dao;

import java.sql.Connection;
import java.util.List;

public interface WFDBAdapter {
	public List<String[]> getDataFromTable(String query, String[] parameter, Connection connObjPostgres);
}
