package com.vbrain.dao;

import java.sql.Connection;
import java.util.List;

public interface VbrainDBAdapter {
    public void insertData(List<String[]> data, String query, Connection connObjVb);
    public void insertData(List<String[]> data, String query, List<String[]> qParameter, Connection connObjVb);
    public List<String[]> getDataFromTable(String query, String[] parameters, Connection connObjVb);
}
