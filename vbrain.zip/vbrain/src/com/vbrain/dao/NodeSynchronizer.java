/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vbrain.dao;

/**
 *
 * @author llihind
 */
public interface NodeSynchronizer {
    public void syncNodes(String hubName,String url) throws Exception;
    public void deSyncNodes(String hubName) throws Exception;
}
