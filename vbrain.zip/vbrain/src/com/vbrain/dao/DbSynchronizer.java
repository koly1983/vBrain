/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vbrain.dao;

import com.vbrain.hibernate.access.model.TempBps;
import com.vbrain.hibernate.sql.model.Campaign;
import com.vbrain.hibernate.sql.model.Run;
import java.util.List;

/**
 *
 * @author llihind
 */
public interface DbSynchronizer {
    public List<Campaign> getFilteredBpList (List<Run> runInstanceList) throws Exception;
    public List<Run> getFilteredRunListByDateRange () throws Exception;
    public void syncDatabases(List<Run> runInstanceList) throws Exception;
    public void reverseSyncDatabases(List<Run> runInstanceList) throws Exception;
    public void finalizeSynchronizer();
    
}
