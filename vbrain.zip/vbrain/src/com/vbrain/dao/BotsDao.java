package com.vbrain.dao;

import java.util.List;

import com.vbrain.common.io.Data;

public interface BotsDao {
	 List<Data> getBotListByStatus(String workStep, String status, String function);
	 List<Data> getBotList(String function);
	 int changeBotStatus(String botKey, String statusId);

}
