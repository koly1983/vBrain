package com.vbrain.dao;

import java.util.List;

import com.vbrain.common.io.Data;
import com.vbrain.common.io.RequestMessage;

public interface TransactionsDao {
	public List<Data> getTransactionsWorkstepWise(String startDate, String endDate, String workStep, String groupBy, String function);
	public List<Data> getTransactionsWorkstepWise(String startDate, String endDate, String function);
	public List<Data> getTransactionData(String startDate, String endDate, String function);
	public int insertTransaction(RequestMessage requestMessage);
	public List<Data> getTransactionsRegionWise(String startDate, String endDate, String function);
	public List<Data> getTransactionsRegionAndWorkStepWise(String startDate, String endDate, String workStep, String function);
	public List<Data> getBotWiseTransactions(String botKey, String function, String startDate, String endDate);
	public String getLastUpdatedDate();
	public int deleteTransactionsAfterDate(String lastTransactionDate);

}
