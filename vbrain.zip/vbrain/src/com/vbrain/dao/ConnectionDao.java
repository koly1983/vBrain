package com.vbrain.dao;

import java.sql.Connection;

public interface ConnectionDao {
	
	Connection getMySqlConnection();

}
