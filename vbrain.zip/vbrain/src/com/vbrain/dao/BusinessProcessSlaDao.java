package com.vbrain.dao;

import com.vbrain.common.io.BusinessProcessSla;

public interface BusinessProcessSlaDao {

	public int configureSla(BusinessProcessSla sla);
	int deleteSlaConfiguration(String businessProcessId);
}
