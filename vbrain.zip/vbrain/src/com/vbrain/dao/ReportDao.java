package com.vbrain.dao;

import com.vbrain.common.io.Data;

public interface ReportDao {

	public Data getReport(String reportType, String processName);
}

