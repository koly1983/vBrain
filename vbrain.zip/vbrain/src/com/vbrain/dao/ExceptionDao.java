package com.vbrain.dao;


import java.util.List;

import com.vbrain.common.io.Exception;

public interface ExceptionDao {

	public int addException(Exception exception);
	
	public List<Exception> getExceptions();
	
	public List<Exception> getExceptionsByLob(String lobId);
	
	public int deleteException(String exceptionId);

	int updateException(Exception exception);
	
}
