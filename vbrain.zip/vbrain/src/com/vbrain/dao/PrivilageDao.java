package com.vbrain.dao;

import java.util.List;

import com.vbrain.common.io.Bot;
import com.vbrain.common.io.Data;
import com.vbrain.common.io.Human;
import com.vbrain.common.io.Privilage;
import com.vbrain.common.io.RequestMessage;
import com.vbrain.common.io.Role;
import com.vbrain.common.io.User;

public interface PrivilageDao {
	
	/**
	 * 
	 * @return
	 */
	public List<Privilage> getPrivilages(String roleId);
	
	public int editPrivilage(String privilageId, String access);
	
	public int addRole(Role role);
	
	public int editRole(Role role);
	
	public int changeRole(String roleId, String mode);
	
	
}
