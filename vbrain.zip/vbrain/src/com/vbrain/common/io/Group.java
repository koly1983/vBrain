
package com.vbrain.common.io;


import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;


@JsonSerialize(include = Inclusion.NON_NULL)
public class Group {

    
    private String                 id;
    private String                 name;
    private String                 description;
    private String                 type;
    private String                 parentId;
    private String                 datastoreName;
    private String                 parentGroupId;
    private String                 isDisabled;
    private String                 iconStyle;
    private CampaignMapping        campaignMapping;
    private List<Group>			   nodes;
    private List<User>			   users;
    private String				   bpId;
    private String				   mappingId;
    private String				   wfVersion;
	/**
	 * @return the bpId
	 */
	public String getBpId() {
		return bpId;
	}
	/**
	 * @param bpId the bpId to set
	 */
	public void setBpId(String bpId) {
		this.bpId = bpId;
	}
	/**
	 * @return the mappingId
	 */
	public String getMappingId() {
		return mappingId;
	}
	/**
	 * @param mappingId the mappingId to set
	 */
	public void setMappingId(String mappingId) {
		this.mappingId = mappingId;
	}
	/**
	 * @return the campaignMapping
	 */
	public CampaignMapping getCampaignMapping() {
		return campaignMapping;
	}
	/**
	 * @param campaignMapping the campaignMapping to set
	 */
	public void setCampaignMapping(CampaignMapping campaignMapping) {
		this.campaignMapping = campaignMapping;
	}
	/**
	 * @return the iconStyle
	 */
	public String getIconStyle() {
		return iconStyle;
	}
	/**
	 * @param iconStyle the iconStyle to set
	 */
	public void setIconStyle(String iconStyle) {
		this.iconStyle = iconStyle;
	}
	/**
	 * @return the isDisabled
	 */
	public String getIsDisabled() {
		return isDisabled;
	}
	/**
	 * @param isDisabled the isDisabled to set
	 */
	public void setIsDisabled(String isDisabled) {
		this.isDisabled = isDisabled;
	}
	/**
	 * @return the users
	 */
	public List<User> getUsers() {
		return users;
	} 
	/**
	 * @param users the users to set
	 */
	public void setUsers(List<User> users) {
		this.users = users;
	}
	/**
	 * @return the nodes
	 */
	public List<Group> getNodes() {
		return nodes;
	}
	/**
	 * @param nodes the nodes to set
	 */
	public void setNodes(List<Group> nodes) {
		this.nodes = nodes;
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the parentId
	 */
	public String getParentId() {
		return parentId;
	}
	/**
	 * @param parentId the parentId to set
	 */
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public String getDatastoreName() {
		return datastoreName;
	}
	public void setDatastoreName(String datastoreName) {
		this.datastoreName = datastoreName;
	}
	/**
	 * @return the parentGroupId
	 */
	public String getParentGroupId() {
		return parentGroupId;
	}
	/**
	 * @param parentGroupId the parentGroupId to set
	 */
	public void setParentGroupId(String parentGroupId) {
		this.parentGroupId = parentGroupId;
	}
	public String getWfVersion() {
		return wfVersion;
	}
	public void setWfVersion(String wfVersion) {
		this.wfVersion = wfVersion;
	}
    
    
    
}
