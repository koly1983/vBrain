package com.vbrain.common.io;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

//import com.rem.common.enums.ManagedEntityType;
//import com.rem.common.enums.WorkflowType;

@JsonSerialize(include = Inclusion.NON_NULL)
public class RequestHeader {

    private String            transactionId;
   //private WorkflowType      workflowType;
    private ManagedEntityType requestType;
    private String            cmdType;
    private String            cmdMode;
    private String            echoBack;
    
    //vBrain attributs
    private String            botKey = "";
    private String            processName = "";
    
    private String 			  authKey;
    private String 			  businessAppId;
    
    private String 			  workerType;
    private String 			  workerId;
    
    
    
    
    
    /**
	 * @return the workerType
	 */
	public String getWorkerType() {
		return workerType;
	}

	/**
	 * @param workerType the workerType to set
	 */
	public void setWorkerType(String workerType) {
		this.workerType = workerType;
	}

	/**
	 * @return the workerId
	 */
	public String getWorkerId() {
		return workerId;
	}

	/**
	 * @param workerId the workerId to set
	 */
	public void setWorkerId(String workerId) {
		this.workerId = workerId;
	}

	/**
	 * @return the authKey
	 */
	public String getAuthKey() {
		return authKey;
	}

	/**
	 * @param authKey the authKey to set
	 */
	public void setAuthKey(String authKey) {
		this.authKey = authKey;
	}

	/**
	 * @return the businessAppId
	 */
	public String getBusinessAppId() {
		return businessAppId;
	}

	/**
	 * @param businessAppId the businessAppId to set
	 */
	public void setBusinessAppId(String businessAppId) {
		this.businessAppId = businessAppId;
	}

	/**
     * @return the botKey
     */
    public String getBotKey() {
        return botKey;
    }

    /**
     * @param botKey the botKey to set
     */
    public void setBotKey(String botKey) {
        this.botKey = botKey;
    }

    /**
     * @return the processName
     */
    public String getProcessName() {
        return processName;
    }

    /**
     * @param processName the processName to set
     */
    public void setProcessName(String processName) {
        this.processName = processName;
    }



    /**
     * @return the transactionID
     */
    public String getTransactionId() {
        return transactionId;
    }

    /**
     * @param transactionID
     *            the transactionID to set
     */
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }



    /**
     * @return the requestType
     */
    public ManagedEntityType getRequestType() {
        return requestType;
    }

    /**
     * @param requestType
     *            the requestType to set
     */
    public void setRequestType(ManagedEntityType requestType) {
        this.requestType = requestType;
    }

    /**
     * @return the cmdType
     */
    public String getCmdType() {
        return cmdType;
    }

    /**
     * @param cmdType
     *            the cmdType to set
     */
    public void setCmdType(String cmdType) {
        this.cmdType = cmdType;
    }

    /**
     * @return the cmdMode
     */
    public String getCmdMode() {
        return cmdMode;
    }

    /**
     * @param cmdMode
     *            the cmdMode to set
     */
    public void setCmdMode(String cmdMode) {
        this.cmdMode = cmdMode;
    }

    /**
     * @return the echoBack
     */
    public String getEchoBack() {
        return echoBack;
    }

    /**
     * @param echoBack
     *            the echoBack to set
     */
    public void setEchoBack(String echoBack) {
        this.echoBack = echoBack;
    }

}
