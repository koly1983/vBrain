package com.vbrain.common.io;

public enum ManagedEntityType {
    WORKFLOW, SERVICE, ROBOT, TRANSACTION, NULL;
}
