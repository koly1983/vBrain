
package com.vbrain.common.io;


import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;


@JsonSerialize(include = Inclusion.NON_NULL)
public class Bot {

    
    private String                 id;
    private String                 botKey;
    private String                 provider;
    private String                 hostName;
    private String                 description;
    private String 				   processId;
    
    private String 				   avgEfforts;
    private String 				   avgCost;
    private String 				   cycleTime;
    private String 				   noOftransactions;
    private String 				   avgEffortsSaved;
    
    
	/**
	 * @return the avgEffortsSaved
	 */
	public String getAvgEffortsSaved() {
		return avgEffortsSaved;
	}
	/**
	 * @param avgEffortsSaved the avgEffortsSaved to set
	 */
	public void setAvgEffortsSaved(String avgEffortsSaved) {
		this.avgEffortsSaved = avgEffortsSaved;
	}
	/**
	 * @return the avgEfforts
	 */
	public String getAvgEfforts() {
		return avgEfforts;
	}
	/**
	 * @param avgEfforts the avgEfforts to set
	 */
	public void setAvgEfforts(String avgEfforts) {
		this.avgEfforts = avgEfforts;
	}
	/**
	 * @return the avgCost
	 */
	public String getAvgCost() {
		return avgCost;
	}
	/**
	 * @param avgCost the avgCost to set
	 */
	public void setAvgCost(String avgCost) {
		this.avgCost = avgCost;
	}
	/**
	 * @return the cycleTime
	 */
	public String getCycleTime() {
		return cycleTime;
	}
	/**
	 * @param cycleTime the cycleTime to set
	 */
	public void setCycleTime(String cycleTime) {
		this.cycleTime = cycleTime;
	}
	/**
	 * @return the noOftransactions
	 */
	public String getNoOftransactions() {
		return noOftransactions;
	}
	/**
	 * @param noOftransactions the noOftransactions to set
	 */
	public void setNoOftransactions(String noOftransactions) {
		this.noOftransactions = noOftransactions;
	}
	/**
	 * @return the processId
	 */
	public String getProcessId() {
		return processId;
	}
	/**
	 * @param processId the processId to set
	 */
	public void setProcessId(String processId) {
		this.processId = processId;
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the botKey
	 */
	public String getBotKey() {
		return botKey;
	}
	/**
	 * @param botKey the botKey to set
	 */
	public void setBotKey(String botKey) {
		this.botKey = botKey;
	}
	/**
	 * @return the provider
	 */
	public String getProvider() {
		return provider;
	}
	/**
	 * @param provider the provider to set
	 */
	public void setProvider(String provider) {
		this.provider = provider;
	}
	/**
	 * @return the hostName
	 */
	public String getHostName() {
		return hostName;
	}
	/**
	 * @param hostName the hostName to set
	 */
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
    
    
    
    
}
