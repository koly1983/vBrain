package com.vbrain.common.io;

import java.util.Date;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include = Inclusion.NON_NULL)
public class ApplicationContext {

    private String requestType;
    private Date   systemDate;
    private String systemIP;
    private String timeZone;
    private String userId;
    private double requestProviderVersion;
    private String language;

    private String region;
    private String country;
    private String lineOfBusiness;
    private String subLineOfBusiness;
    private String sourceSystemName;
    private String targetSystemName;
    private String businessSegment;
    private String hostName;
    private String hostIP;

    // Optional Fields
    private String optionalField1;
    private String optionalField2;
    private String optionalField3;
    private String optionalField4;
    private String optionalField5;
    private String optionalField6;
    private String optionalField7;
    private String optionalField8;
    private String optionalField9;
    private String optionalField10;

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    public String getSubLineOfBusiness() {
        return subLineOfBusiness;
    }

    public void setSubLineOfBusiness(String subLineOfBusiness) {
        this.subLineOfBusiness = subLineOfBusiness;
    }

    public String getSourceSystemName() {
        return sourceSystemName;
    }

    public void setSourceSystemName(String sourceSystemName) {
        this.sourceSystemName = sourceSystemName;
    }

    public String getTargetSystemName() {
        return targetSystemName;
    }

    public void setTargetSystemName(String targetSystemName) {
        this.targetSystemName = targetSystemName;
    }

    public String getBusinessSegment() {
        return businessSegment;
    }

    public void setBusinessSegment(String businessSegment) {
        this.businessSegment = businessSegment;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public String getHostIP() {
        return hostIP;
    }

    public void setHostIP(String hostIP) {
        this.hostIP = hostIP;
    }

    /**
     * @return the requestType
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * @param requestType
     *            the requestType to set
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    /**
     * @return the systemDate
     */
    public Date getSystemDate() {
        return systemDate;
    }

    /**
     * @param systemDate
     *            the systemDate to set
     */
    public void setSystemDate(Date systemDate) {
        this.systemDate = systemDate;
    }

    /**
     * @return the systemIP
     */
    public String getSystemIP() {
        return systemIP;
    }

    /**
     * @param systemIP
     *            the systemIP to set
     */
    public void setSystemIP(String systemIP) {
        this.systemIP = systemIP;
    }

    /**
     * @return the timeZone
     */
    public String getTimeZone() {
        return timeZone;
    }

    /**
     * @param timeZone
     *            the timeZone to set
     */
    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * @return the requestProviderVersion
     */
    public double getRequestProviderVersion() {
        return requestProviderVersion;
    }

    /**
     * @param requestProviderVersion
     *            the requestProviderVersion to set
     */
    public void setRequestProviderVersion(double requestProviderVersion) {
        this.requestProviderVersion = requestProviderVersion;
    }

    /**
     * @return the language
     */
    public String getLanguage() {
        return language;
    }

    /**
     * @param language
     *            the language to set
     */
    public void setLanguage(String language) {
        this.language = language;
    }

    /**
     * @return the optionalField1
     */
    public String getOptionalField1() {
        return optionalField1;
    }

    /**
     * @param optionalField1
     *            the optionalField1 to set
     */
    public void setOptionalField1(String optionalField1) {
        this.optionalField1 = optionalField1;
    }

    /**
     * @return the optionalField2
     */
    public String getOptionalField2() {
        return optionalField2;
    }

    /**
     * @param optionalField2
     *            the optionalField2 to set
     */
    public void setOptionalField2(String optionalField2) {
        this.optionalField2 = optionalField2;
    }

    /**
     * @return the optionalField3
     */
    public String getOptionalField3() {
        return optionalField3;
    }

    /**
     * @param optionalField3
     *            the optionalField3 to set
     */
    public void setOptionalField3(String optionalField3) {
        this.optionalField3 = optionalField3;
    }

    /**
     * @return the optionalField4
     */
    public String getOptionalField4() {
        return optionalField4;
    }

    /**
     * @param optionalField4
     *            the optionalField4 to set
     */
    public void setOptionalField4(String optionalField4) {
        this.optionalField4 = optionalField4;
    }

    /**
     * @return the optionalField5
     */
    public String getOptionalField5() {
        return optionalField5;
    }

    /**
     * @param optionalField5
     *            the optionalField5 to set
     */
    public void setOptionalField5(String optionalField5) {
        this.optionalField5 = optionalField5;
    }

    /**
     * @return the optionalField6
     */
    public String getOptionalField6() {
        return optionalField6;
    }

    /**
     * @param optionalField6
     *            the optionalField6 to set
     */
    public void setOptionalField6(String optionalField6) {
        this.optionalField6 = optionalField6;
    }

    /**
     * @return the optionalField7
     */
    public String getOptionalField7() {
        return optionalField7;
    }

    /**
     * @param optionalField7
     *            the optionalField7 to set
     */
    public void setOptionalField7(String optionalField7) {
        this.optionalField7 = optionalField7;
    }

    /**
     * @return the optionalField8
     */
    public String getOptionalField8() {
        return optionalField8;
    }

    /**
     * @param optionalField8
     *            the optionalField8 to set
     */
    public void setOptionalField8(String optionalField8) {
        this.optionalField8 = optionalField8;
    }

    /**
     * @return the optionalField9
     */
    public String getOptionalField9() {
        return optionalField9;
    }

    /**
     * @param optionalField9
     *            the optionalField9 to set
     */
    public void setOptionalField9(String optionalField9) {
        this.optionalField9 = optionalField9;
    }

    /**
     * @return the optionalField10
     */
    public String getOptionalField10() {
        return optionalField10;
    }

    /**
     * @param optionalField10
     *            the optionalField10 to set
     */
    public void setOptionalField10(String optionalField10) {
        this.optionalField10 = optionalField10;
    }

}
