package com.vbrain.common.io;

public class RequestMessage {

    private RequestHeader      requestHeader;
    private ApplicationContext applicationContext;
    private RequestParameter   requestParameter;
    private RequestAction      requestAction;
    private RequestData        requestData;
    private String             action;
    

   // private ObjectData         objectData;

    /**
     * @return the requestHeader
     */
    public RequestHeader getRequestHeader() {
        return requestHeader;
    }

    /**
     * @param requestHeader
     *            the requestHeader to set
     */
    public void setRequestHeader(RequestHeader requestHeader) {
        this.requestHeader = requestHeader;
    }

    /**
     * @return the applicationContext
     */
    public ApplicationContext getApplicationContext() {
        return applicationContext;
    }

    /**
     * @param applicationContext
     *            the applicationContext to set
     */
    public void setApplicationContext(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    /**
     * @return the requestParameter
     */
    public RequestParameter getRequestParameter() {
        return requestParameter;
    }

    /**
     * @param requestParameter
     *            the requestParameter to set
     */
    public void setRequestParameter(RequestParameter requestParameter) {
        this.requestParameter = requestParameter;
    }

    /**
     * @return the requestAction
     */
    public RequestAction getRequestAction() {
        return requestAction;
    }

    /**
     * @param requestAction
     *            the requestAction to set
     */
    public void setRequestAction(RequestAction requestAction) {
        this.requestAction = requestAction;
    }

    public RequestData getRequestData() {
        return requestData;
    }

    public void setRequestData(RequestData requestData) {
        this.requestData = requestData;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

 
}
