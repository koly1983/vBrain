
package com.vbrain.common.io;


import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;


@JsonSerialize(include = Inclusion.NON_NULL)
public class Exception {

    
    private String                 id;
    private String                 lob;
    private String                 lobName;
    private String                 exceptionType;
    private String                 exceptionValue;
    private String                 fullMatchValue; 				   
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the lob
	 */
	public String getLob() {
		return lob;
	}
	/**
	 * @param lob the lob to set
	 */
	public void setLob(String lob) {
		this.lob = lob;
	}
	/**
	 * @return the lobName
	 */
	public String getLobName() {
		return lobName;
	}
	/**
	 * @param lobName the lobName to set
	 */
	public void setLobName(String lobName) {
		this.lobName = lobName;
	}
	/**
	 * @return the exceptionType
	 */
	public String getExceptionType() {
		return exceptionType;
	}
	/**
	 * @param exceptionType the exceptionType to set
	 */
	public void setExceptionType(String exceptionType) {
		this.exceptionType = exceptionType;
	}
	/**
	 * @return the exceptionValue
	 */
	public String getExceptionValue() {
		return exceptionValue;
	}
	/**
	 * @param exceptionValue the exceptionValue to set
	 */
	public void setExceptionValue(String exceptionValue) {
		this.exceptionValue = exceptionValue;
	}
	/**
	 * @return the fullMatchValue
	 */
	public String getFullMatchValue() {
		return fullMatchValue;
	}
	/**
	 * @param fullMatchValue the fullMatchValue to set
	 */
	public void setFullMatchValue(String fullMatchValue) {
		this.fullMatchValue = fullMatchValue;
	}
}
