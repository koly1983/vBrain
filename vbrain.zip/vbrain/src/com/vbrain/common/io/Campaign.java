package com.vbrain.common.io;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include = Inclusion.NON_NULL)
public class Campaign {

	private String 					id;
	private String 					title;
	private String					wfVersion;
	private List<CampaignMapping> 	mappings;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWfVersion() {
		return wfVersion;
	}
	public void setWfVersion(String wfVersion) {
		this.wfVersion = wfVersion;
	}
	public List<CampaignMapping> getMappings() {
		if(mappings == null) {
			mappings = new ArrayList<>();
		}
		return mappings;
	}
	public void setMappings(List<CampaignMapping> mappings) {
		this.mappings = mappings;
	}
	
}
