package com.vbrain.common.io;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

//import com.rem.common.enums.ConfigChangeType;
//import com.rem.common.enums.ManagedEntityType;
//import com.rem.common.io.EventDetails;

@JsonSerialize(include = Inclusion.NON_NULL)
public class RequestData {
    private int               index;
    private String            businessSegment;
    private String            region;
    private String            country;
    private String            lineOfBusiness;
    private String            subLineOfBusiness;

   // private EventDetails      event;

  //  private ManagedEntityType objectType;
    private String            objectId;
    private String            objectName;
  //  private ConfigChangeType  changeType;
    private String            cmdType;
    private String            cmdMode;
    private String            echoBack;
    private String            botStatusId;
    
    private List<Transactions> 	transactions;
    private List<Incident> 		incidents;
    private Group				group;
    
    
    
    
    /**
	 * @return the group
	 */
	public Group getGroup() {
		return group;
	}

	/**
	 * @param group the group to set
	 */
	public void setGroup(Group group) {
		this.group = group;
	}
    
    
    
    /**
	 * @return the incidents
	 */
	public List<Incident> getIncidents() {
		return incidents;
	}

	/**
	 * @param incidents the incidents to set
	 */
	public void setIncidents(List<Incident> incidents) {
		this.incidents = incidents;
	}

	/**
	 * @return the botStatusId
	 */
	public String getBotStatusId() {
		return botStatusId;
	}

	/**
	 * @param botStatusId the botStatusId to set
	 */
	public void setBotStatusId(String botStatusId) {
		this.botStatusId = botStatusId;
	}

    /**
     * @return the transactions
     */
    public List<Transactions> getTransactions() {
        return transactions;
    }

    /**
     * @param transactions the transactions to set
     */
    public void setTransactions(List<Transactions> transactions) {
        this.transactions = transactions;
    }
    

    /**
     * @return the index
     */
    public int getIndex() {
        return index;
    }

    /**
     * @param index
     *            the index to set
     */
    public void setIndex(int index) {
        this.index = index;
    }

    /**
     * @return the businessSegment
     */
    public String getBusinessSegment() {
        return businessSegment;
    }

    /**
     * @param businessSegment
     *            the businessSegment to set
     */
    public void setBusinessSegment(String businessSegment) {
        this.businessSegment = businessSegment;
    }

    /**
     * @return the region
     */
    public String getRegion() {
        return region;
    }

    /**
     * @param region
     *            the region to set
     */
    public void setRegion(String region) {
        this.region = region;
    }

    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * @param country
     *            the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * @return the lineOfBusiness
     */
    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    /**
     * @param lineOfBusiness
     *            the lineOfBusiness to set
     */
    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    /**
     * @return the subLineOfBusiness
     */
    public String getSubLineOfBusiness() {
        return subLineOfBusiness;
    }

    /**
     * @param subLineOfBusiness
     *            the subLineOfBusiness to set
     */
    public void setSubLineOfBusiness(String subLineOfBusiness) {
        this.subLineOfBusiness = subLineOfBusiness;
    }


    /**
     * @return the objectId
     */
    public String getObjectId() {
        return objectId;
    }

    /**
     * @param objectId
     *            the objectId to set
     */
    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    /**
     * @return the objectName
     */
    public String getObjectName() {
        return objectName;
    }

    /**
     * @param objectName
     *            the objectName to set
     */
    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

 

    /**
     * @return the cmdType
     */
    public String getCmdType() {
        return cmdType;
    }

    /**
     * @param cmdType
     *            the cmdType to set
     */
    public void setCmdType(String cmdType) {
        this.cmdType = cmdType;
    }

    /**
     * @return the cmdMode
     */
    public String getCmdMode() {
        return cmdMode;
    }

    /**
     * @param cmdMode
     *            the cmdMode to set
     */
    public void setCmdMode(String cmdMode) {
        this.cmdMode = cmdMode;
    }

    /**
     * @return the echoBack
     */
    public String getEchoBack() {
        return echoBack;
    }

    /**
     * @param echoBack
     *            the echoBack to set
     */
    public void setEchoBack(String echoBack) {
        this.echoBack = echoBack;
    }

}
