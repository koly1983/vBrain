
package com.vbrain.common.io;

import com.vbrain.nodemonitor.model.Hubs;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

//import com.rem.common.enums.WFTransactionType;

@JsonSerialize(include = Inclusion.NON_NULL)
public class RequestParameter {

    private String                    startDate;
    private String                    endDate;

    private String                    workStep;
    private String                    region;
    private String                    workflowType;
    private String                    function;

    private String                    serviceID;

    private String                    groupBy;
    private int                       itemsPerPage;
    private int                       requestedPageNumber;

    private String                    isDRAFT;

   // private List<WorkflowTypeDetails> workFlowTypes;
  //  private List<WorkflowIDDetails>   workFlowNames;
    private List<RequestData>         requestData;
  //  private WFTransactionType         transactionType;
    private String                    transactionId;

    private String                    reportType;

    private String                    reportRange;

    private boolean                   allTypes;

    // Attributes for userProfile service
    private String                    employeeID;
    private String                    applicationName;
    private String                    cbdCode;
    private String                    botKey;
    private String                    botStatusId;
    
    private String                    groupId;
    private String                    userId;
    private String                    processId;
    private String[]                  userIds;
    private String                    roleId;
    private String                    exceptionId;
    
    private Group                     group;
    private Bot                       bot;
    private Human                     human;
    private User                      user;
    private Privilage                 privilage;
    private Role                      role; 
    private Exception                 exception;
    private Hubs                      hub;

    private String                    processName;
    
    private String                    type;
    private Long                      transGroupId;
    private String bp_uuid;
    
    private String                    hubName;
    
    private BusinessProcessSla        businessProcessSla;
    private String					  businessProcessId;
    
    /**
     * @return the role
     */
    public Role getRole() {
        return role;
    }

    /**
     * @param role the role to set
     */
    public void setRole(Role role) {
        this.role = role;
    }

    /**
     * @return the privilage
     */
    public Privilage getPrivilage() {
        return privilage;
    }

    /**
     * @param privilage the privilage to set
     */
    public void setPrivilage(Privilage privilage) {
        this.privilage = privilage;
    }

    /**
     * @return the roleId
     */
    public String getRoleId() {
        return roleId;
    }

    /**
     * @param roleId the roleId to set
     */
    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    /**
	 * @return the exceptionId
	 */
	public String getExceptionId() {
		return exceptionId;
	}

	/**
	 * @param exceptionId the exceptionId to set
	 */
	public void setExceptionId(String exceptionId) {
		this.exceptionId = exceptionId;
	}

	/**
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * @return the userIds
     */
    public String[] getUserIds() {
        return userIds;
    }

    /**
     * @param userIds the userIds to set
     */
    public void setUserIds(String[] userIds) {
        this.userIds = userIds;
    }

    /**
     * @return the processId
     */
    public String getProcessId() {
        return processId;
    }

    /**
     * @param processId the processId to set
     */
    public void setProcessId(String processId) {
        this.processId = processId;
    }

    /**
     * @return the bot
     */
    public Bot getBot() {
        return bot;
    }

    /**
     * @param bot the bot to set
     */
    public void setBot(Bot bot) {
        this.bot = bot;
    }

    /**
     * @return the human
     */
    public Human getHuman() {
        return human;
    }

    /**
     * @param human the human to set
     */
    public void setHuman(Human human) {
        this.human = human;
    }

    /**
     * @return the groupId
     */
    public String getGroupId() {
        return groupId;
    }

    /**
     * @param groupId the groupId to set
     */
    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * @return the group
     */
    public Group getGroup() {
        return group;
    }

    /**
     * @param group the group to set
     */
    public void setGroup(Group group) {
        this.group = group;
    }
    
    /**
     * @return the exception
     */
    public Exception getException() {
        return exception;
    }

    /**
     * @param exception the exception to set
     */
    public void setException(Exception exception) {
        this.exception = exception;
    }

    // Attributes for heartBeat - reportStatus service
    
   
    
    /**
     * @return the botKey
     */
    public String getBotKey() {
        return botKey;
    }

    /**
     * @return the function
     */
    public String getFunction() {
        return function;
    }

    /**
     * @param function the function to set
     */
    public void setFunction(String function) {
        this.function = function;
    }

    /**
     * @param botKey the botKey to set
     */
    public void setBotKey(String botKey) {
        this.botKey = botKey;
    }

    /**
     * @return the botStatusId
     */
    public String getBotStatusId() {
        return botStatusId;
    }

    /**
     * @param botStatusId the botStatusId to set
     */
    public void setBotStatusId(String botStatusId) {
        this.botStatusId = botStatusId;
    }

    private String                    status;
    /**
     * @return the region
     */
    public String getRegion() {
        return region;
    }

    /**
     * @param region the region to set
     */
    public void setRegion(String region) {
        this.region = region;
    }

    private String                    mode;

    
    /**
     * @return the mode
     */
    public String getMode() {
        return mode;
    }

    /**
     * @param mode the mode to set
     */
    public void setMode(String mode) {
        this.mode = mode;
    }

    /**
     * @return the workStep
     */
    public String getWorkStep() {
        return workStep;
    }

    /**
     * @param workStep the workStep to set
     */
    public void setWorkStep(String workStep) {
        this.workStep = workStep;
    }

    /**
     * @return the groupBy
     */
    public String getGroupBy() {
        return groupBy;
    }

    /**
     * @param groupBy the groupBy to set
     */
    public void setGroupBy(String groupBy) {
        this.groupBy = groupBy;
    }

    /**
     * @return the startDate
     */
    public String getStartDate() {
        return startDate;
    }

    /**
     * @param startDate
     *            the startDate to set
     */
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    /**
     * @return the endDate
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * @param endDate
     *            the endDate to set
     */
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    
    /**
     * @return the serviceID
     */
    public String getServiceID() {
        return serviceID;
    }

    /**
     * @param serviceID
     *            the serviceID to set
     */
    public void setServiceID(String serviceID) {
        this.serviceID = serviceID;
    }

    
    /**
     * @return the itemsPerPage
     */
    public int getItemsPerPage() {
        return itemsPerPage;
    }

    /**
     * @param itemsPerPage
     *            the itemsPerPage to set
     */
    public void setItemsPerPage(int itemsPerPage) {
        this.itemsPerPage = itemsPerPage;
    }

    /**
     * @return the requestedPageNumber
     */
    public int getRequestedPageNumber() {
        return requestedPageNumber;
    }

    /**
     * @param requestedPageNumber
     *            the requestedPageNumber to set
     */
    public void setRequestedPageNumber(int requestedPageNumber) {
        this.requestedPageNumber = requestedPageNumber;
    }

    /**
     * @return the isDRAFT
     */
    public String getIsDRAFT() {
        return isDRAFT;
    }

    /**
     * @param isDRAFT
     *            the isDRAFT to set
     */
    public void setIsDRAFT(String isDRAFT) {
        this.isDRAFT = isDRAFT;
    }

 
    /**
     * @return the requestData
     */
    public List<RequestData> getRequestData() {
        return requestData;
    }

    /**
     * @param requestData
     *            the requestData to set
     */
    public void setRequestData(List<RequestData> requestData) {
        this.requestData = requestData;
    }

  
    /**
     * @return the transactionId
     */
    public String getTransactionId() {
        return transactionId;
    }

    /**
     * @param transactionId
     *            the transactionId to set
     */
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    /**
     * @return the reportType
     */
    public String getReportType() {
        return this.reportType;
    }

    /**
     * @param reportType
     *            the reportType to set
     */
    public void setReportType(final String reportType) {
        this.reportType = reportType;
    }

    /**
     * @return the allTypes
     */
    public boolean isAllTypes() {
        return allTypes;
    }

    /**
     * @param allTypes
     *            the allTypes to set
     */
    public void setAllTypes(boolean allTypes) {
        this.allTypes = allTypes;
    }

    /**
     * @return the workflowType
     */
    public String getWorkflowType() {
        return workflowType;
    }

    /**
     * @param workflowType
     *            the workflowType to set
     */
    public void setWorkflowType(String workflowType) {
        this.workflowType = workflowType;
    }

    /*********** Attributes for userProfile service ***********/

    /**
     * @return the employeeID
     */
    public String getEmployeeID() {
        return employeeID;
    }

    /**
     * @param employeeID
     *            the employeeID to set
     */
    public void setEmployeeID(String employeeID) {
        this.employeeID = employeeID;
    }

    /**
     * @return the applicationName
     */
    public String getApplicationName() {
        return applicationName;
    }

    /**
     * @param applicationName
     *            the applicationName to set
     */
    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    /**
     * @return the cbdCode
     */
    public String getCbdCode() {
        return cbdCode;
    }

    /**
     * @param cbdCode
     *            the cbdCode to set
     */
    public void setCbdCode(String cbdCode) {
        this.cbdCode = cbdCode;
    }

    

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    
    public String getProcessName() {
        return processName;
    }

    public void setProcessName(String processName) {
        this.processName = processName;
    }

    
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getReportRange() {
        return reportRange;
    }

    public void setReportRange(String reportRange) {
        this.reportRange = reportRange;
    }

    public Long getTransGroupId() {
        return transGroupId;
    }

    public void setTransGroupId(Long transGroupId) {
        this.transGroupId = transGroupId;
    }

	public String getBp_uuid() {
		return bp_uuid;
	}

	public void setBp_uuid(String bp_uuid) {
		this.bp_uuid = bp_uuid;
	}

    /**
     * @return the hub
     */
    public Hubs getHub() {
        return hub;
    }

    /**
     * @param hub the hub to set
     */
    public void setHub(Hubs hub) {
        this.hub = hub;
    }

    /**
     * @return the hubName
     */
    public String getHubName() {
        return hubName;
    }

    /**
     * @param hubName the hubName to set
     */
    public void setHubName(String hubName) {
        this.hubName = hubName;
    }

	public BusinessProcessSla getBusinessProcessSla() {
		return businessProcessSla;
	}

	public void setBusinessProcessSla(BusinessProcessSla businessProcessSla) {
		this.businessProcessSla = businessProcessSla;
	}

	public String getBusinessProcessId() {
		return businessProcessId;
	}

	public void setBusinessProcessId(String businessProcessId) {
		this.businessProcessId = businessProcessId;
	}
    
}
