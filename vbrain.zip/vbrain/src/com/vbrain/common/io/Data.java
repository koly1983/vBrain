
package com.vbrain.common.io;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.vbrain.nodemonitor.model.Hubs;
import com.vbrain.nodemonitor.model.Nodes;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;


@JsonSerialize(include = Inclusion.NON_NULL)
public class Data {

    private int                    index;

    private String                 transactionID;
    private String                 transactionDate;

    private String                 ticketID;

	private String                 ticketDesc;
    private String                 transactionDesc;
    private String                 groupName;
    private Long				   groupID;
    
	private Long                   totalTransactions;
    private Double                 totalPer;
    private Double                 totalTimeTaken;
    private Long                   successtransactionCount;

    private String                 exceptionTxt;
    private String                 exceptionType;
    private String                 exceptionDesc;

    private Long                   businessExceptionCount;
    private Long                   technicalExceptionCount;
    private Double                 effortSaved;

    private String                 endState;
    private String                 endStateDesc;
    private String                 region;
    private String                 country;
    private String                 lineOfBusiness;
    private String                 subLineOfBusiness;
    
    private String                 transactionStatus;

    private Long                   totalCompletedTransactions;
    private Long                   totalBacklogTransactions;
    private Long                   totalWorker;
    private String                 worker;
    private String                 transactionType;

    private Double                 averageTimeTaken;

    // for transaction report
    private String                 firstTransStartDateTime;
    private String                 startTime;

    private String                 endTime;

    private String                 errorCode;

    private String                 errorMessage;
    
    private String				   processId;
    private String                 processName;
    
    private String 				   botKey;
    private int 				   botCount;
    private int 				   botActiveCount;
    private int 				   botWaitingCount;
    private int 				   botInactiveCount;
    
    
    private String 				   botProvider;
    private String 				   botStatus;
    private String 				   workStep;
    private String 				   status;
    private String 				   description;
    private String 				   outCome;
    
    private Long                   slaAchieved;
    private Long                   slaBreachedFulfilled;
    private Long                   slaBreachedActive;
    private Double                 slaAchievedPer;
	private Double                 slaBreachedFulfilledPer;
    private Double                 slaBreachedActivePer;
    
    
    private Long                   totalIncidents;
    private Long                   ticketsClosed;
    private Long                   ticketsOpen;
    private String 				   displayClass;
    private List<Data>			   transactionList;
    
    private int 				   isBotType;
    private int 				   isHumanType;
    private int 				   isStpType;
    private int 				   botEffortSaved;
    private int 				   humanEffortSaved;
    private int 				   stpEffortSaved;
    
    private List<Group>		       groups;
    private Group 		   		   group;
   
    private List<Bot> 		   	   bots;
    private Bot 		   		   bot;
    
    private List<Human> 		   humans;
    private Human 		   		   human;
   
    private List<User> 		   	   users;
    private User 		   		   user;
    
    private List<Hubs>                     hubs;
    private Hubs                                   hub;
    
    private List<Nodes>                     nodes;
    private Nodes                                   node;

    private List<Role> 		   	   roles;
    private List<Privilage> 	   privilages;
    private List<Exception> 	   exceptions;
    
    private List<BusinessProcessSla> businessProcessSlas;
    
    public List<BusinessProcessSla> getBusinessProcessSlas() {
		return businessProcessSlas;
	}

	private Map<String, Integer>   processMetrics;
    
    private String 				   bp_uuid;
    
    private List<Campaign> 		   campaigns;
    private CampaignMapping		   campaignMapping;
    
    private Long				   mappingId;
    private Long				   campaignId;
    private Long				   bpId;
    
    private String 				   wfVersion;
    
	public String getWfVersion() {
		return wfVersion;
	}

	public void setWfVersion(String wfVersion) {
		this.wfVersion = wfVersion;
	}

	/**
	 * @return the mappingId
	 */
	public Long getMappingId() {
		return mappingId;
	}

	/**
	 * @param mappingId the mappingId to set
	 */
	public void setMappingId(Long mappingId) {
		this.mappingId = mappingId;
	}

	/**
	 * @return the campaignId
	 */
	public Long getCampaignId() {
		return campaignId;
	}

	/**
	 * @param campaignId the campaignId to set
	 */
	public void setCampaignId(Long campaignId) {
		this.campaignId = campaignId;
	}

	/**
	 * @return the bpId
	 */
	public Long getBpId() {
		return bpId;
	}

	/**
	 * @param bpId the bpId to set
	 */
	public void setBpId(Long bpId) {
		this.bpId = bpId;
	}

	/**
	 * @return the privilages
	 */
	public List<Privilage> getPrivilages() {
		return privilages;
	}

	/**
	 * @param privilages the privilages to set
	 */
	public void setPrivilages(List<Privilage> privilages) {
		this.privilages = privilages;
	}

	/**
	 * @return the exceptions
	 */
	public List<Exception> getExceptions() {
		return exceptions;
	}

	/**
	 * @param exceptions the exceptions to set
	 */
	public void setExceptions(List<Exception> exceptions) {
		this.exceptions = exceptions;
	}
	
	/**
	 * @param slaConfigurations the slaConfigurations to set
	 */
	
	public void setBusinessProcessSlas(List<BusinessProcessSla> businessProcessSlas) {
		this.businessProcessSlas = businessProcessSlas;
	}

	/**
	 * @return the roles
	 */
	public List<Role> getRoles() {
		return roles;
	}

	/**
	 * @param roles the roles to set
	 */
	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	/**
	 * @return the users
	 */
	public List<User> getUsers() {
		return users;
	}

	/**
	 * @param users the users to set
	 */
	public void setUsers(List<User> users) {
		this.users = users;
	}

	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * @return the bots
	 */
	public List<Bot> getBots() {
		return bots;
	}

	/**
	 * @param bots the bots to set
	 */
	public void setBots(List<Bot> bots) {
		this.bots = bots;
	}

	/**
	 * @return the bot
	 */
	public Bot getBot() {
		return bot;
	}

	/**
	 * @param bot the bot to set
	 */
	public void setBot(Bot bot) {
		this.bot = bot;
	}

	/**
	 * @return the humans
	 */
	public List<Human> getHumans() {
		return humans;
	}

	/**
	 * @param humans the humans to set
	 */
	public void setHumans(List<Human> humans) {
		this.humans = humans;
	}

	/**
	 * @return the human
	 */
	public Human getHuman() {
		return human;
	}

	/**
	 * @param human the human to set
	 */
	public void setHuman(Human human) {
		this.human = human;
	}

	/**
	 * @return the group
	 */
	public Group getGroup() {
		return group;
	}

	/**
	 * @param group the group to set
	 */
	public void setGroup(Group group) {
		this.group = group;
	}

	/**
	 * @return the groups
	 */
	public List<Group> getGroups() {
		return groups;
	}

	/**
	 * @param groups the groups to set
	 */
	public void setGroups(List<Group> groups) {
		this.groups = groups;
	}

	/**
	 * @return the isBotType
	 */
	public int getIsBotType() {
		return isBotType;
	}

	/**
	 * @param isBotType the isBotType to set
	 */
	public void setIsBotType(int isBotType) {
		this.isBotType = isBotType;
	}

	/**
	 * @return the isHumanType
	 */
	public int getIsHumanType() {
		return isHumanType;
	}

	/**
	 * @param isHumanType the isHumanType to set
	 */
	public void setIsHumanType(int isHumanType) {
		this.isHumanType = isHumanType;
	}

	/**
	 * @return the isStpType
	 */
	public int getIsStpType() {
		return isStpType;
	}

	/**
	 * @param isStpType the isStpType to set
	 */
	public void setIsStpType(int isStpType) {
		this.isStpType = isStpType;
	}

	/**
	 * @return the botEffortSaved
	 */
	public int getBotEffortSaved() {
		return botEffortSaved;
	}

	/**
	 * @param botEffortSaved the botEffortSaved to set
	 */
	public void setBotEffortSaved(int botEffortSaved) {
		this.botEffortSaved = botEffortSaved;
	}

	/**
	 * @return the humanEffortSaved
	 */
	public int getHumanEffortSaved() {
		return humanEffortSaved;
	}

	/**
	 * @param humanEffortSaved the humanEffortSaved to set
	 */
	public void setHumanEffortSaved(int humanEffortSaved) {
		this.humanEffortSaved = humanEffortSaved;
	}

	/**
	 * @return the stpEffortSaved
	 */
	public int getStpEffortSaved() {
		return stpEffortSaved;
	}

	/**
	 * @param stpEffortSaved the stpEffortSaved to set
	 */
	public void setStpEffortSaved(int stpEffortSaved) {
		this.stpEffortSaved = stpEffortSaved;
	}

	/**
	 * @return the processId
	 */
	public String getProcessId() {
		return processId;
	}

	/**
	 * @param processId the processId to set
	 */
	public void setProcessId(String processId) {
		this.processId = processId;
	}

	/**
	 * @return the transactionList
	 */
	public List<Data> getTransactionList() {
		return transactionList;
	}

	/**
	 * @param transactionList the transactionList to set
	 */
	public void setTransactionList(List<Data> transactionList) {
		this.transactionList = transactionList;
	}

	/**
	 * @return the displayClass
	 */
	public String getDisplayClass() {
		return displayClass;
	}

	/**
	 * @param displayClass the displayClass to set
	 */
	public void setDisplayClass(String displayClass) {
		this.displayClass = displayClass;
	}

	/**
	 * @return the totalPer
	 */
	public Double getTotalPer() {
		return totalPer;
	}

	/**
	 * @param totalPer the totalPer to set
	 */
	public void setTotalPer(Double totalPer) {
		this.totalPer = totalPer;
	}

	/**
	 * @return the totalIncidents
	 */
	public Long getTotalIncidents() {
		return totalIncidents;
	}

	/**
	 * @param totalIncidents the totalIncidents to set
	 */
	public void setTotalIncidents(Long totalIncidents) {
		this.totalIncidents = totalIncidents;
	}

	/**
	 * @return the ticketsClosed
	 */
	public Long getTicketsClosed() {
		return ticketsClosed;
	}

	/**
	 * @param ticketsClosed the ticketsClosed to set
	 */
	public void setTicketsClosed(Long ticketsClosed) {
		this.ticketsClosed = ticketsClosed;
	}

	/**
	 * @return the ticketsOpen
	 */
	public Long getTicketsOpen() {
		return ticketsOpen;
	}

	/**
	 * @param ticketsOpen the ticketsOpen to set
	 */
	public void setTicketsOpen(Long ticketsOpen) {
		this.ticketsOpen = ticketsOpen;
	}

	/**
	 * @return the botActiveCount
	 */
	public int getBotActiveCount() {
		return botActiveCount;
	}

	/**
	 * @param botActiveCount the botActiveCount to set
	 */
	public void setBotActiveCount(int botActiveCount) {
		this.botActiveCount = botActiveCount;
	}

	/**
	 * @return the botWaitingCount
	 */
	public int getBotWaitingCount() {
		return botWaitingCount;
	}

	/**
	 * @param botWaitingCount the botWaitingCount to set
	 */
	public void setBotWaitingCount(int botWaitingCount) {
		this.botWaitingCount = botWaitingCount;
	}

	/**
	 * @return the botInactiveCount
	 */
	public int getBotInactiveCount() {
		return botInactiveCount;
	}

	/**
	 * @param botInactiveCount the botInactiveCount to set
	 */
	public void setBotInactiveCount(int botInactiveCount) {
		this.botInactiveCount = botInactiveCount;
	}

	/**
	 * @return the botCount
	 */
	public int getBotCount() {
		return botCount;
	}

	/**
	 * @param botCount the botCount to set
	 */
	public void setBotCount(int botCount) {
		this.botCount = botCount;
	}

	/**
	 * @return the botProvider
	 */
	public String getBotProvider() {
		return botProvider;
	}

	/**
	 * @param botProvider the botProvider to set
	 */
	public void setBotProvider(String botProvider) {
		this.botProvider = botProvider;
	}

	/**
	 * @return the botStatus
	 */
	public String getBotStatus() {
		return botStatus;
	}

	/**
	 * @param botStatus the botStatus to set
	 */
	public void setBotStatus(String botStatus) {
		this.botStatus = botStatus;
	}

	/**
	 * @return the slaAchievedPer
	 */
	public Double getSlaAchievedPer() {
		return slaAchievedPer;
	}

	/**
	 * @param slaAchievedPer the slaAchievedPer to set
	 */
	public void setSlaAchievedPer(Double slaAchievedPer) {
		this.slaAchievedPer = slaAchievedPer;
	}

	/**
	 * @return the slaBreachedFulfilledPer
	 */
	public Double getSlaBreachedFulfilledPer() {
		return slaBreachedFulfilledPer;
	}

	/**
	 * @param slaBreachedFulfilledPer the slaBreachedFulfilledPer to set
	 */
	public void setSlaBreachedFulfilledPer(Double slaBreachedFulfilledPer) {
		this.slaBreachedFulfilledPer = slaBreachedFulfilledPer;
	}

	/**
	 * @return the slaBreachedActivePer
	 */
	public Double getSlaBreachedActivePer() {
		return slaBreachedActivePer;
	}

	/**
	 * @param slaBreachedActivePer the slaBreachedActivePer to set
	 */
	public void setSlaBreachedActivePer(Double slaBreachedActivePer) {
		this.slaBreachedActivePer = slaBreachedActivePer;
	}

    
    
    /**
	 * @return the slaAchieved
	 */
	public Long getSlaAchieved() {
		return slaAchieved;
	}

	/**
	 * @param slaAchieved the slaAchieved to set
	 */
	public void setSlaAchieved(Long slaAchieved) {
		this.slaAchieved = slaAchieved;
	}

	/**
	 * @return the slaBreachedFulfilled
	 */
	public Long getSlaBreachedFulfilled() {
		return slaBreachedFulfilled;
	}

	/**
	 * @param slaBreachedFulfilled the slaBreachedFulfilled to set
	 */
	public void setSlaBreachedFulfilled(Long slaBreachedFulfilled) {
		this.slaBreachedFulfilled = slaBreachedFulfilled;
	}

	/**
	 * @return the slaBreachedActive
	 */
	public Long getSlaBreachedActive() {
		return slaBreachedActive;
	}

	/**
	 * @param slaBreachedActive the slaBreachedActive to set
	 */
	public void setSlaBreachedActive(Long slaBreachedActive) {
		this.slaBreachedActive = slaBreachedActive;
	}

	/**
	 * @return the botKey
	 */
	public String getBotKey() {
		return botKey;
	}

	/**
	 * @param botKey the botKey to set
	 */
	public void setBotKey(String botKey) {
		this.botKey = botKey;
	}

	/**
	 * @return the workStep
	 */
	public String getWorkStep() {
		return workStep;
	}

	/**
	 * @param workStep the workStep to set
	 */
	public void setWorkStep(String workStep) {
		this.workStep = workStep;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the outCome
	 */
	public String getOutCome() {
		return outCome;
	}

	/**
	 * @param outCome the outCome to set
	 */
	public void setOutCome(String outCome) {
		this.outCome = outCome;
	}

	/**
	 * @return the effortSaved
	 */
	public Double getEffortSaved() {
		return effortSaved;
	}

	/**
	 * @param effortSaved the effortSaved to set
	 */
	public void setEffortSaved(Double effortSaved) {
		this.effortSaved = effortSaved;
	}

	/**
	 * @return the totalWorker
	 */
	public Long getTotalWorker() {
		return totalWorker;
	}

	/**
	 * @param totalWorker the totalWorker to set
	 */
	public void setTotalWorker(Long totalWorker) {
		this.totalWorker = totalWorker;
	}

	/**
	 * @return the worker
	 */
	public String getWorker() {
		return worker;
	}

	/**
	 * @param worker the worker to set
	 */
	public void setWorker(String worker) {
		this.worker = worker;
	}

	/**
     * @return the processName
     */
    public String getProcessName() {
        return processName;
    }

    /**
     * @param processName the processName to set
     */
    public void setProcessName(String processName) {
        this.processName = processName;
    }

        /**
     * @return the index
     */
    public int getIndex() {
        return this.index;
    }

    /**
     * @param index
     *            the index to set
     */
    public void setIndex(final int index) {
        this.index = index;
    }

    /**
     * @return the transactionID
     */
    public String getTransactionID() {
        return this.transactionID;
    }

    /**
     * @param transactionID
     *            the transactionID to set
     */
    public void setTransactionID(final String transactionID) {
        this.transactionID = transactionID;
    }

    /**
     * @return the transactionDate
     */
    public String getTransactionDate() {
        return this.transactionDate;
    }

    /**
     * @param transactionDate
     *            the transactionDate to set
     */
    public void setTransactionDate(final String transactionDate) {
        this.transactionDate = transactionDate;
    }

    
    /**
     * @return the totalTransactions
     */
    public Long getTotalTransactions() {
        return this.totalTransactions;
    }

    /**
     * @param totalTransactions
     *            the totalTransactions to set
     */
    public void setTotalTransactions(final Long totalTransactions) {
        this.totalTransactions = totalTransactions;
    }

    /**
     * @return the totalTimeTaken
     */
    public Double getTotalTimeTaken() {
        return this.totalTimeTaken;
    }

    /**
     * @param totalTimeTaken
     *            the totalTimeTaken to set
     */
    public void setTotalTimeTaken(final Double totalTimeTaken) {
        this.totalTimeTaken = totalTimeTaken;
    }

    /**
     * @return the successtransactionCount
     */
    public Long getSuccesstransactionCount() {
        return this.successtransactionCount;
    }

    /**
     * @param successtransactionCount
     *            the successtransactionCount to set
     */
    public void setSuccesstransactionCount(final Long successtransactionCount) {
        this.successtransactionCount = successtransactionCount;
    }

    /**
     * @return the exceptionTxt
     */
    public String getExceptionTxt() {
        return this.exceptionTxt;
    }

    /**
     * @param exceptionTxt
     *            the exceptionTxt to set
     */
    public void setExceptionTxt(final String exceptionTxt) {
        this.exceptionTxt = exceptionTxt;
    }

    /**
     * @return the exceptionType
     */
    public String getExceptionType() {
        return this.exceptionType;
    }

    /**
     * @param exceptionType
     *            the exceptionType to set
     */
    public void setExceptionType(final String exceptionType) {
        this.exceptionType = exceptionType;
    }

    /**
     * @return the exceptionDesc
     */
    public String getExceptionDesc() {
        return this.exceptionDesc;
    }

    /**
     * @param exceptionDesc
     *            the exceptionDesc to set
     */
    public void setExceptionDesc(final String exceptionDesc) {
        this.exceptionDesc = exceptionDesc;
    }

    /**
     * @return the businessExceptionCount
     */
    public Long getBusinessExceptionCount() {
        return this.businessExceptionCount;
    }

    /**
     * @param businessExceptionCount
     *            the businessExceptionCount to set
     */
    public void setBusinessExceptionCount(final Long businessExceptionCount) {
        this.businessExceptionCount = businessExceptionCount;
    }

    /**
     * @return the technicalExceptionCount
     */
    public Long getTechnicalExceptionCount() {
        return this.technicalExceptionCount;
    }

    /**
     * @param technicalExceptionCount
     *            the technicalExceptionCount to set
     */
    public void setTechnicalExceptionCount(final Long technicalExceptionCount) {
        this.technicalExceptionCount = technicalExceptionCount;
    }

  
    /**
     * @return the endState
     */
    public String getEndState() {
        return this.endState;
    }

    /**
     * @param endState
     *            the endState to set
     */
    public void setEndState(final String endState) {
        this.endState = endState;
    }

    /**
     * @return the endStateDesc
     */
    public String getEndStateDesc() {
        return this.endStateDesc;
    }

    /**
     * @param endStateDesc
     *            the endStateDesc to set
     */
    public void setEndStateDesc(final String endStateDesc) {
        this.endStateDesc = endStateDesc;
    }

        /**
     * @return the region
     */
    public String getRegion() {
        return this.region;
    }

    /**
     * @param region
     *            the region to set
     */
    public void setRegion(final String region) {
        this.region = region;
    }

    /**
     * @return the country
     */
    public String getCountry() {
        return this.country;
    }

    /**
     * @param country
     *            the country to set
     */
    public void setCountry(final String country) {
        this.country = country;
    }

    /**
     * @return the lineOfBusiness
     */
    public String getLineOfBusiness() {
        return this.lineOfBusiness;
    }

    /**
     * @param lineOfBusiness
     *            the lineOfBusiness to set
     */
    public void setLineOfBusiness(final String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    /**
     * @return the subLineOfBusiness
     */
    public String getSubLineOfBusiness() {
        return this.subLineOfBusiness;
    }

    /**
     * @param subLineOfBusiness
     *            the subLineOfBusiness to set
     */
    public void setSubLineOfBusiness(final String subLineOfBusiness) {
        this.subLineOfBusiness = subLineOfBusiness;
    }

    /**
     * @return the transactionType
     */
    public String getTransactionType() {
        return this.transactionType;
    }

    /**
     * @param transactionType
     *            the transactionType to set
     */
    public void setTransactionType(final String transactionType) {
        this.transactionType = transactionType;
    }

    /**
     * @return the totalCompletedTransactions
     */
    public Long getTotalCompletedTransactions() {
        return this.totalCompletedTransactions;
    }

    /**
     * @param totalCompletedTransactions
     *            the totalCompletedTransactions to set
     */
    public void setTotalCompletedTransactions(
            final Long totalCompletedTransactions) {
        this.totalCompletedTransactions = totalCompletedTransactions;
    }

    /**
     * @return the averageTimeTaken
     */
    public Double getAverageTimeTaken() {
        return this.averageTimeTaken;
    }

    /**
     * @param averageTimeTaken
     *            the averageTimeTaken to set
     */
    public void setAverageTimeTaken(final Double averageTimeTaken) {
        this.averageTimeTaken = averageTimeTaken;
    }

    
    /**
     * @return the transactionStatus
     */
    public String getTransactionStatus() {
        return this.transactionStatus;
    }

    /**
     * @param transactionStatus
     *            the transactionStatus to set
     */
    public void setTransactionStatus(final String transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

        /**
     * @return the startTime
     */
    public String getStartTime() {
        return this.startTime;
    }

    /**
     * @param startTime
     *            the startTime to set
     */
    public void setStartTime(final String startTime) {
        this.startTime = startTime;
    }

    /**
     * @return the endDate
     */
    public String getEndTime() {
        return this.endTime;
    }

    /**
     * @param endDate
     *            the endDate to set
     */
    public void setEndTime(final String endTime) {
        this.endTime = endTime;
    }

    /**
     * @return the errorCode
     */
    public String getErrorCode() {
        return this.errorCode;
    }

    /**
     * @param errorCode
     *            the errorCode to set
     */
    public void setErrorCode(final String errorCode) {
        this.errorCode = errorCode;
    }

    /**
     * @return the errorMessage
     */
    public String getErrorMessage() {
        return this.errorMessage;
    }

    /**
     * @param description
     *            the description to set
     */
    public void setErrorMessage(final String newVal) {
        this.errorMessage = newVal;
    }

    
    public String getTicketID() {
		return ticketID;
	}

    /**
     * @param ticketID
     *            the ticketID to set
     */
	public void setTicketID(String ticketID) {
		this.ticketID = ticketID;
	}

    public String getTicketDesc() {
		return ticketDesc;
	}

    /**
     * @param ticketDesc
     *            the ticketDesc to set
     */
	public void setTicketDesc(String ticketDesc) {
		this.ticketDesc = ticketDesc;
	}

	public String getTransactionDesc() {
		return transactionDesc;
	}

    /**
     * @param transactionDesc
     *            the transactionDesc to set
     */
	public void setTransactionDesc(String transactionDesc) {
		this.transactionDesc = transactionDesc;
	}

	public String getGroupName() {
		return groupName;
	}

    /**
     * @param groupName
     *            the groupName to set
     */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * 
	 * @return
	 */
	public Map<String, Integer> getProcessMetrics() {
		return processMetrics;
	}

	/**
	 * 
	 * @param processMetrics
	 */
	public void setProcessMetrics(Map<String, Integer> processMetrics) {
		this.processMetrics = processMetrics;
	}

	public Long getGroupID() {
		return groupID;
	}

	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}

	public String getFirstTransStartDateTime() {
		return firstTransStartDateTime;
	}

	public void setFirstTransStartDateTime(String firstTransStartDateTime) {
		this.firstTransStartDateTime = firstTransStartDateTime;
	}

	public String getBp_uuid() {
		return bp_uuid;
	}

	public void setBp_uuid(String bp_uuid) {
		this.bp_uuid = bp_uuid;
	}

	public List<Campaign> getCampaigns() {
		return campaigns;
	}

	public void setCampaigns(List<Campaign> campaigns) {
		this.campaigns = campaigns;
	}

	/**
	 * @return the campaignMapping
	 */
	public CampaignMapping getCampaignMapping() {
		return campaignMapping;
	}

	/**
	 * @param campaignMapping the campaignMapping to set
	 */
	public void setCampaignMapping(CampaignMapping campaignMapping) {
		this.campaignMapping = campaignMapping;
	}
	
	/**
     * @return the hubs
     */
    public List<Hubs> getHubs() {
        return hubs;
    }

    /**
     * @param hubs the hubs to set
     */
    public void setHubs(List<Hubs> hubs) {
        this.hubs = hubs;
    }

    /**
     * @return the hub
     */
    public Hubs getHub() {
        return hub;
    }

    /**
     * @param hub the hub to set
     */
    public void setHub(Hubs hub) {
        this.hub = hub;
    }

    /**
     * @return the nodes
     */
    public List<Nodes> getNodes() {
        return nodes;
    }

    /**
     * @param nodes the nodes to set
     */
    public void setNodes(List<Nodes> nodes) {
        this.nodes = nodes;
    }

    /**
     * @return the node
     */
    public Nodes getNode() {
        return node;
    }

    /**
     * @param node the node to set
     */
    public void setNode(Nodes node) {
        this.node = node;
    }
	
}
