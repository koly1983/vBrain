/**
 * 
 */
package com.vbrain.common.io;

import java.util.List;


public class RequestType {

    private String             requestTypeCode;
    private String             requestTypeValue;
   // private List<RequestValue> requestValues;

    /**
     * @return the requestTypeCode
     */
    public String getRequestTypeCode() {
        return requestTypeCode;
    }

    /**
     * @param requestTypeCode
     *            the requestTypeCode to set
     */
    public void setRequestTypeCode(String requestTypeCode) {
        this.requestTypeCode = requestTypeCode;
    }

    /**
     * @return the requestTypeValue
     */
    public String getRequestTypeValue() {
        return requestTypeValue;
    }

    /**
     * @param requestTypeValue
     *            the requestTypeValue to set
     */
    public void setRequestTypeValue(String requestTypeValue) {
        this.requestTypeValue = requestTypeValue;
    }

  
}
