package com.vbrain.common.io;


import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;


@JsonSerialize(include = Inclusion.NON_NULL)
public class BusinessProcessSla {
	
	private String id;
	private String bpId;
	private String bpName;
	private String slaTime;
	private String emailAddress;
	
	public String getbpId() {
		return bpId;
	}
	public void setbpId(String bpId) {
		this.bpId = bpId;
	}
	public String getSlaTime() {
		return slaTime;
	}
	public void setSlaTime(String slaTime) {
		this.slaTime = slaTime;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getBpName() {
		return bpName;
	}
	public void setBpName(String bpName) {
		this.bpName = bpName;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

}
