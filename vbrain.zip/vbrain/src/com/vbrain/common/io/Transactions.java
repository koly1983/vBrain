package com.vbrain.common.io;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include = Inclusion.NON_NULL)
public class Transactions {

    // Attributes for vBrain
    private String businessAppId = "";
    private String startDateTime = "";
    private String endDateTime = "";
    private String createdBy = "";
    private String duration = "";
    private String outcome = "";
    private String exceptionType = "";
	private String description = "";
    private String processName = "";
    private String processId = "";
    
    private String status = "";
    
    private String createdDate = "";
    
    private String businessException = "";
    private String operationalException = "";
    private String trackingId = "";
    private String userId = "";
    
    /**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the trackingId
	 */
	public String getTrackingId() {
		return trackingId;
	}

	/**
	 * @param trackingId the trackingId to set
	 */
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}

	/**
	 * @return the businessException
	 */
	public String getBusinessException() {
		return businessException;
	}

	/**
	 * @param businessException the businessException to set
	 */
	public void setBusinessException(String businessException) {
		this.businessException = businessException;
	}

	/**
	 * @return the operationalException
	 */
	public String getOperationalException() {
		return operationalException;
	}

	/**
	 * @param operationalException the operationalException to set
	 */
	public void setOperationalException(String operationalException) {
		this.operationalException = operationalException;
	}

	/**
   	 * @return the exceptionType
   	 */
   	public String getExceptionType() {
   		return exceptionType;
   	}

   	/**
   	 * @param exceptionType the exceptionType to set
   	 */
   	public void setExceptionType(String exceptionType) {
   		this.exceptionType = exceptionType;
   	}
    /**
	 * @return the processId
	 */
	public String getProcessId() {
		return processId;
	}

	/**
	 * @param processId the processId to set
	 */
	public void setProcessId(String processId) {
		this.processId = processId;
	}


    /**
     * @return the createdDate
     */
    public String getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate the createdDate to set
     */
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the processName
     */
    public String getProcessName() {
        return processName;
    }

    /**
     * @param processName the processName to set
     */
    public void setProcessName(String processName) {
        this.processName = processName;
    }

    /**
     * @return the businessAppId
     */
    public String getBusinessAppId() {
        return businessAppId;
    }

    /**
     * @param businessAppId the businessAppId to set
     */
    public void setBusinessAppId(String businessAppId) {
        this.businessAppId = businessAppId;
    }

    /**
     * @return the startDateTime
     */
    public String getStartDateTime() {
        return startDateTime;
    }

    /**
     * @param startDateTime the startDateTime to set
     */
    public void setStartDateTime(String startDateTime) {
        this.startDateTime = startDateTime;
    }

    /**
     * @return the endDateTime
     */
    public String getEndDateTime() {
        return endDateTime;
    }

    /**
     * @param endDateTime the endDateTime to set
     */
    public void setEndDateTime(String endDateTime) {
        this.endDateTime = endDateTime;
    }

    /**
     * @return the createdBy
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * @param createdBy the createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @return the duration
     */
    public String getDuration() {
        return duration;
    }

    /**
     * @param duration the duration to set
     */
    public void setDuration(String duration) {
        this.duration = duration;
    }

    /**
     * @return the outcome
     */
    public String getOutcome() {
        return outcome;
    }

    /**
     * @param outcome the outcome to set
     */
    public void setOutcome(String outcome) {
        this.outcome = outcome;
    }

 
    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

}
