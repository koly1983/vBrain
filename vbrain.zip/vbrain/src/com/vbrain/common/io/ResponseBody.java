package com.vbrain.common.io;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include = Inclusion.NON_NULL)
public class ResponseBody {
    private Long                 totalTimeSaved;
    private Long                 totalActiveWorkFlows;

    private Long                 totalActiveTransactions;
    private Long                 totalCount;

    private Long                 totalMaxPotential;
    //private List<Data>           data;
    //private List<EnumCollection> enumCollection;

    private String               errorCode;
    private String               errorMessage;


    private List<RequestType>    requestTypes;


    /**
     * @return the totalTimeSaved
     */
    public Long getTotalTimeSaved() {
        return totalTimeSaved;
    }

    /**
     * @param totalTimeSaved
     *            the totalTimeSaved to set
     */
    public void setTotalTimeSaved(Long totalTimeSaved) {
        this.totalTimeSaved = totalTimeSaved;
    }

    /**
     * @return the totalActiveWorkFlows
     */
    public Long getTotalActiveWorkFlows() {
        return totalActiveWorkFlows;
    }

    /**
     * @param totalActiveWorkFlows
     *            the totalActiveWorkFlows to set
     */
    public void setTotalActiveWorkFlows(Long totalActiveWorkFlows) {
        this.totalActiveWorkFlows = totalActiveWorkFlows;
    }

    /**
     * @return the totalActiveTransactions
     */
    public Long getTotalActiveTransactions() {
        return totalActiveTransactions;
    }

    /**
     * @param totalActiveTransactions
     *            the totalActiveTransactions to set
     */
    public void setTotalActiveTransactions(Long totalActiveTransactions) {
        this.totalActiveTransactions = totalActiveTransactions;
    }

    /**
     * @return the totalCount
     */
    public Long getTotalCount() {
        return totalCount;
    }

    /**
     * @param totalCount
     *            the totalCount to set
     */
    public void setTotalCount(Long totalCount) {
        this.totalCount = totalCount;
    }

    /**
     * @return the totalMaxPotential
     */
    public Long getTotalMaxPotential() {
        return totalMaxPotential;
    }

    /**
     * @param totalMaxPotential
     *            the totalMaxPotential to set
     */
    public void setTotalMaxPotential(Long totalMaxPotential) {
        this.totalMaxPotential = totalMaxPotential;
    }

    /**
     * @return the data
     */


    /**
     * @return the errorCode
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * @param errorCode
     *            the errorCode to set
     */
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    /**
     * @return the errorMessage
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * @param errorMessage
     *            the errorMessage to set
     */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }


    /**
     * @return the requestTypes
     */
    public List<RequestType> getRequestTypes() {
        return requestTypes;
    }

    /**
     * @param requestTypes
     *            the requestTypes to set
     */
    public void setRequestTypes(List<RequestType> requestTypes) {
        this.requestTypes = requestTypes;
    }

  
}
