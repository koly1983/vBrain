package com.vbrain.common.io;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include = Inclusion.NON_NULL)
public class CampaignMapping {

	private String mappingId;
	private String campaignId;
	private String stepId;
	private String stepTitle;
	private String stepIndex;
	private String datastoreName;
	/**
	 * @return the mappingId
	 */
	public String getMappingId() {
		return mappingId;
	}
	/**
	 * @param mappingId the mappingId to set
	 */
	public void setMappingId(String mappingId) {
		this.mappingId = mappingId;
	}
	/**
	 * @return the campaignId
	 */
	public String getCampaignId() {
		return campaignId;
	}
	/**
	 * @param campaignId the campaignId to set
	 */
	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}
	/**
	 * @return the stepId
	 */
	public String getStepId() {
		return stepId;
	}
	/**
	 * @param stepId the stepId to set
	 */
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	/**
	 * @return the stepTitle
	 */
	public String getStepTitle() {
		return stepTitle;
	}
	/**
	 * @param stepTitle the stepTitle to set
	 */
	public void setStepTitle(String stepTitle) {
		this.stepTitle = stepTitle;
	}
	/**
	 * @return the stepIndex
	 */
	public String getStepIndex() {
		return stepIndex;
	}
	/**
	 * @param stepIndex the stepIndex to set
	 */
	public void setStepIndex(String stepIndex) {
		this.stepIndex = stepIndex;
	}
	/**
	 * @return the datastoreName
	 */
	public String getDatastoreName() {
		return datastoreName;
	}
	/**
	 * @param datastoreName the datastoreName to set
	 */
	public void setDatastoreName(String datastoreName) {
		this.datastoreName = datastoreName;
	}
	
	
}
