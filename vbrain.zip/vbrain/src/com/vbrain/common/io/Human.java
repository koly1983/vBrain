
package com.vbrain.common.io;


import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;


@JsonSerialize(include = Inclusion.NON_NULL)
public class Human {

    
    private String                 id;
    private String                 workerId;
    private String                 name;
    private String                 description;
    private String 				   processId;
    
    private String 				   avgEfforts;
    private String 				   avgCost;
    private String 				   cycleTime;
    private String 				   noOftransactions;
    
    
    
	/**
	 * @return the avgEfforts
	 */
	public String getAvgEfforts() {
		return avgEfforts;
	}
	/**
	 * @param avgEfforts the avgEfforts to set
	 */
	public void setAvgEfforts(String avgEfforts) {
		this.avgEfforts = avgEfforts;
	}
	/**
	 * @return the avgCost
	 */
	public String getAvgCost() {
		return avgCost;
	}
	/**
	 * @param avgCost the avgCost to set
	 */
	public void setAvgCost(String avgCost) {
		this.avgCost = avgCost;
	}
	/**
	 * @return the cycleTime
	 */
	public String getCycleTime() {
		return cycleTime;
	}
	/**
	 * @param cycleTime the cycleTime to set
	 */
	public void setCycleTime(String cycleTime) {
		this.cycleTime = cycleTime;
	}
	/**
	 * @return the noOftransactions
	 */
	public String getNoOftransactions() {
		return noOftransactions;
	}
	/**
	 * @param noOftransactions the noOftransactions to set
	 */
	public void setNoOftransactions(String noOftransactions) {
		this.noOftransactions = noOftransactions;
	}
	/**
	 * @return the processId
	 */
	public String getProcessId() {
		return processId;
	}
	/**
	 * @param processId the processId to set
	 */
	public void setProcessId(String processId) {
		this.processId = processId;
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the workerId
	 */
	public String getWorkerId() {
		return workerId;
	}
	/**
	 * @param workerId the workerId to set
	 */
	public void setWorkerId(String workerId) {
		this.workerId = workerId;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
    
    
}
