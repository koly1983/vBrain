package com.vbrain.common.io;

public class Constants {

	  public static final String STATUS_WISE = "statusWise";
	  public static final String STATUS_REGION_WISE = "statusAndRegionWise";
	  public static final String REGION_WISE = "regionWise";
	  public static final String REGION_WORKSTEP_WISE = "regionAndWorkstepWise";
	  public static final String WORKSTEP = "all";
	 // public static final String PROCESS_NAME = "process_Name";
	 // public static final String PROCESSNAME = "processName";
	 // public static final String REGION = "region";
	 // public static final String GEO = "geo";
	 // public static final String GEOGRAPHY = "geography";
	 // public static final String TRANSACTIONS = "transactions";
	  public static final String BOT_STATUS_ACTIVE = "Active";
	  public static final String BOT_STATUS_INACTIVE = "Inactive";
	  public static final String BOT_STATUS_WAITING = "Waiting";
	 // public static final String BOTKEY = "botkey";
	 // public static final String BOT_KEY = "bot_key";
	 // public static final String PROVIDER = "provider";
	 // public static final String STATUS = "status";
	  public static final String DRIVER_NAME = "com.mysql.jdbc.Driver";
	  public static final String JDBC_URL = "jdbc:mysql://localhost:3306/vbrainApp";
	  public static final String USERNAME = "root";
	  public static final String PASSWORD = "root";
	  public static final String CREATE_FNOL = "Read email and OCR";
	  public static final String ADJUDICATE_CLAIM = "Underwrite";
	  public static final String APPROVE_CLAIM = "Issue Quote";
	  public static final String STATUS_ACHIEVED = "achieved";
	  public static final String STATUS_BREACHED = "breached";
	  public static final String STATUS_BREACHEDF = "breachedF";
	  public static final String STATUS_BREACHEDA= "breachedA";
	  public static final String DAILY = "daily";
	  public static final String MONTHLY = "monthly";
	  public static final String YEARLY = "yearly";
	 // public static final String TRANSACTION_DATE = "transactionDate";
	 // public static final String TOTAL_TRANSACTION = "totalTransaction";
	 // public static final String TOTAL_DURATION = "totalDuration";
	  //public static final String EFFORT_SAVED = "effort_saved";
	  //public static final String TOTAL_WORKER = "totalWorker";
	 // public static final String WORKER = "Worker";
	 // public static final String START_TIME = "start_time";
	 // public static final String END_TIME = "end_time";
	 // public static final String DESCRIPTION = "description";
	  public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";


	  

}
