package com.vbrain.common.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Utility class to read the properties file from resources
 * @author VISWANATHV
 * @since 12/26/2018
 */
public class ReadProperties {
    Properties prop;
    
    /**
     * Constructor initialized the Properties variable.
     */
    public ReadProperties() {
        // TODO Auto-generated constructor stub
        this.prop = new Properties();
    }
    
    /**
     * Method to load properties from the given file
     * @param fileName name of the resource file
     * @return Properties initialized from file
     */
    public Properties loadProperties(String fileName){
        InputStream inputStream = null;
        try{
            inputStream = getClass().getClassLoader().getResourceAsStream(fileName);
            if(inputStream != null) {
                prop.load(inputStream);
                System.out.println("Property file successfully loaded!");
                inputStream.close();

            } else {
                throw new FileNotFoundException(" Properties File: " + fileName + " Not found !");
            }
        } catch(Exception e){
            e.printStackTrace();
        } finally {
            if(inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return this.prop;
    }
    
    public String getProperty(String key){
        String value = null;
        if(this.prop != null) {
            value = prop.getProperty(key);
        }
        return value;
    }
}
