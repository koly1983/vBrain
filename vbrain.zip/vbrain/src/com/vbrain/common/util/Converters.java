/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vbrain.common.util;

import com.vbrain.hibernate.model.Email;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author llihind
 */
public class Converters {

    public static String[] converterEmailList(String type, List<Email> emailList) {
        String[] emailAry = new String[emailList.size()];
        int index = 0;
        for (Email email : emailList) {
            switch (type) {
                case "to":
                    emailAry[index] = email.getTo();
                    break;
                case "cc":
                    emailAry[index] = email.getCc();
                    break;

            }
            index++;
        }
        
        //Removing all null values from array
        List<String> filteredList = new ArrayList<>();
        for (String s : emailAry) {
            if (s != null && s.length() > 0) {
                filteredList.add(s);
            }
        }
        
        return filteredList.toArray(new String[filteredList.size()]);
    }

}
