/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vbrain.common.util;

import com.vbrain.hibernate.model.Nodes;
import java.util.Date;
import java.util.List;

/**
 *
 * @author llihind
 */
public class EmailManager {

    public static String getStatusEmailBody(List<Nodes> nodeList, String hubName,String serverName) {
        Date d = new Date();
        String html = "Node Monitor has detected a weak hub.<br><br> Hub Name : "+hubName+"<br> Server Name : "+serverName+" <br><br><p><table border='1' style='border-collapse:collapse;border-color: black;' cellpadding='5'>\n"
                + "            <tbody style='white-space: nowrap;'>\n"
                + "            <tr align='left'>\n"
                + "                 <td><b>Node Name</td>\n"
                + "                 <td><b>Node Status</td>\n"
                + "				 <td><b>Current Timestamp</td>\n"
                + "            </tr>\n";
        for (Nodes nodes : nodeList) {
            html += "            <tr align='left'>\n"
                    + "                 <td>" + nodes.getNodeName() + "</td>\n"
                    + "                 <td>" + nodes.getStatus().getStatus() + "</td>\n"
                    + "		  <td>" + d.toString() + "</td>\n"
                    + "            </tr>\n";

        }

        html += "            </tbody>\n"
                + "        </table></p>";

        return html;
    }
    
    public static String getStatusEmailBody(List<Nodes> nodeList, String hubName,String serverName,String updatedMsg,String type) {
        Date d = new Date();
        String html = "Node Monitor has detected a hub "+type+".<br><br>IMPORTANT : "+updatedMsg+"<br><br><b>Currently Synced Hub Data in Database :</b><br><br> Hub Name : "+hubName+"<br> Server Name : "+serverName+" <br><br><p><table border='1' style='border-collapse:collapse;border-color: black;' cellpadding='5'>\n"
                + "            <tbody style='white-space: nowrap;'>\n"
                + "            <tr align='left'>\n"
                + "                 <td><b>Node Name</td>\n"
                + "                 <td><b>Node Status</td>\n"
                + "				 <td><b>Current Timestamp</td>\n"
                + "            </tr>\n";
        for (Nodes nodes : nodeList) {
            html += "            <tr align='left'>\n"
                    + "                 <td>" + nodes.getNodeName() + "</td>\n"
                    + "                 <td>" + nodes.getStatus().getStatus() + "</td>\n"
                    + "		  <td>" + d.toString() + "</td>\n"
                    + "            </tr>\n";

        }

        html += "            </tbody>\n"
                + "        </table></p>";

        return html;
    }
    
    public static String getOcrEmailBody(int queued, int inprogress) {
        Date d = new Date();
        String html = "Node Monitor has detected a OCR health check failure.<br><br><p><table border='1' style='border-collapse:collapse;border-color: black;' cellpadding='5'>\n"
                + "            <tbody style='white-space: nowrap;'>\n"
                + "            <tr align='left'>\n"
                + "                 <td><b>Task Info</td>\n"
                + "                 <td><b>Task Count</td>\n"
                + "            </tr>\n"
      
                + "            <tr align='left'>\n"
                    + "                 <td>Queued</td>\n"
                    + "                 <td>" + String.valueOf(queued)+ "</td>\n"
                    + "            </tr>\n"
                    + "            <tr align='left'>\n"
                    + "                 <td>In Progress</td>\n"
                    + "                 <td>" + String.valueOf(inprogress)+ "</td>\n"
                    + "            </tr>\n"
                    + "            </tbody>\n"
                    + "        </table></p>";

        return html;
    }
    
    public static String getOcrLicenseEmailBody(int volume, int volumeRemaining) {
        Date d = new Date();
        String html = "It appears to be OCR license document limit is running out. Please check the volumes and take appropriate action.<br><br><p><table border='1' style='border-collapse:collapse;border-color: black;' cellpadding='5'>\n"
                + "            <tbody style='white-space: nowrap;'>\n"
                + "            <tr align='left'>\n"
                + "                 <td><b>Volume</td>\n"
                + "                 <td><b>Volume Remaining</td>\n"
                + "            </tr>\n"
      
                + "            <tr align='left'>\n"
                    + "                 <td>Queued</td>\n"
                    + "                 <td>" + String.valueOf(volume)+ "</td>\n"
                    + "            </tr>\n"
                    + "            <tr align='left'>\n"
                    + "                 <td>In Progress</td>\n"
                    + "                 <td>" + String.valueOf(volumeRemaining)+ "</td>\n"
                    + "            </tr>\n"
                    + "            </tbody>\n"
                    + "        </table></p>";

        return html;
    }
}
