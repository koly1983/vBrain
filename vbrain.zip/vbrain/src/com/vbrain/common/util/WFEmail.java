/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vbrain.common.util;

/**
 *
 * @author llihind
 */
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;

public class WFEmail {

    /**
     * High-importance Setting for the email
     */
    public static final String HIGH_IMPORTANCE = "1";
    /**
     * Normal-importance Setting for the email
     */
    public static final String NORMAL_IMPORTANCE = "3";
    /**
     * Low-importance Setting for the email
     */
    public static final String LOW_IMPORTANCE = "5";

    /**
     * The SMTP server from which emails will be sent
     */
    private static final String host = "mailhost.tor.treasury.bmo.com";
    /**
     * The email address from which emails will be sent
     */
    private static final String user = "Work.Fusion@bmo.com";

    /**
     * Pre-configured Log4j logger
     */
    private Logger log;
    /**
     * List of recipients
     */
    private String[] to;
    /**
     * List of cc recipients
     */
    private String[] cc;
    /**
     * Title of the email
     */
    private String title;
    /**
     * Context, body of the email
     */
    private String content;
    /**
     * Importance of the email
     *
     * @see HIGH_IMPORTANCE
     * @see NORMAL_IMPORTANCE
     * @see LOW_IMPORTANCE
     */
    private String importance = NORMAL_IMPORTANCE;

    /**
     * An array of File objects to be sent
     */
    private File[] attachments;

    /**
     * Base constructor for the class, more constructors to be added later Sends
     * email to one recipient and multiple cc recipients with an importance of
     * "NORMAL" with an HTML-formatted signature. No attachments.
     *
     * @param log A pre-configured Log4j logger.
     * @param to Takes in one email address as the main recipient of the email.
     * @param cc Takes in an array of Strings, containing the email address of
     * cc recipients.
     * @param title The title of the email.
     * @param content The content of the email.
     * @param importance Importance of the email, it can be High(1), Normal(3)
     * or Low(5).
     */
    public WFEmail(Logger log, String[] to, String[] cc, String title, String content, String importance) {
        this.log = log;
        this.to = to;
        this.cc = cc;
        this.title = title;
        this.content = content;
        this.importance = importance;

        attachments = new File[0];
    }

    public WFEmail(Logger log, String[] to, String[] cc, String title, String content) {
        this.log = log;
        this.to = to;
        this.cc = cc;
        this.title = title;
        this.content = content;

        attachments = new File[0];

    }

    public WFEmail(Logger log, String[] to, String title, String content) {
        this.log = log;
        this.to = to;
        this.title = title;
        this.content = content;

        attachments = new File[0];

    }

    /**
     * Adds one file into the variable "attachments" via file path
     *
     * @param path a string that contains the path to the attachment, path
     * starts in /opt/samba/ in the linux server
     * @return the boolean value of whether or not the file is successfully
     * added as an attachment
     */
    public boolean attachFile(String path) {
        File file = new File("/opt/samba/" + path);
        if (file != null) {
            addToArrayHelper(file);
            return true;
        }
        return false;
    }

    /**
     * Adds one file into the variable "attachments" from a File object
     *
     * @param file a File object that contains the path to the attachment
     * @return the boolean value of whether or not the file is successfully
     * added as an attachment
     */
    public boolean attachFile(File file) {
        if (file != null) {
            addToArrayHelper(file);
            return true;
        }
        return false;
    }

    /**
     * Adds one file into the variable "attachments" from an s3 bucket
     *
     * @param path a string that contains the path to the attachment, path
     * starts in /opt/samba/ in the linux server. WE HIGHLY RECOMMEND TEMP if
     * you do not intend to reuse this file.
     * @param content the content in byteArray
     * @return the boolean value of whether or not the file is successfully
     * added as an attachment
     */
    public boolean attachFile(String path,byte[] content) throws IOException {
        File file = new File("/opt/samba/" + path);
        FileUtils.writeByteArrayToFile(file, content);
        if (file != null) {
            addToArrayHelper(file);
            return  true;
        }
        return false;
    }

    

    /**
     * Filter out null and empty emailId Adresses
     */
    public Set<String> filterEmailAddressList(String[] email) {
        Set<String> emailList = new HashSet<String>();
        if (email == null || email.length < 1) {
            return emailList;
        }

        for (int i = 0; i < email.length; i++) {
            if (email[i] != null) {
                if (!email[i].trim().isEmpty()) {
                    emailList.add(email[i]);
                }
            }
        }
        return emailList;
    }

    /**
     * Sends a plain text-based email based on the properties in this class
     */
    public boolean sendPlain() {
        String ToList = "";
        String CCList = "";
        String AttList = "";
        Set<String> emailToList = new HashSet<String>();
        Set<String> emailCcList = new HashSet<String>();

        String LogImportance = "ERROR";
        if (importance.equals("1")) {
            LogImportance = "HIGH";
        } else if (importance.equals("3")) {
            LogImportance = "NORMAL";
        } else if (importance.equals("5")) {
            LogImportance = "LOW";
        }

        Properties props = new Properties();
        props.put("mail.smtp.host", host);

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(user, ""); //second param is for passwords, but we do not have any
            }
        });

        try {

            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(user));
            message.setHeader("X-Priority", importance);

            emailToList = filterEmailAddressList(to);
            emailCcList = filterEmailAddressList(cc);

            if (emailToList.size() == 0 && emailCcList.size() == 0) {
                log.warn("No emailId to To and Cc recipients");
                        return false;
            } else if (emailToList.size() == 0) {
                log.warn("No emailId to To recipients");
                        return false;
            }
            // TO

            int toCounter = 0;
            for (String emailAddress : emailToList) {

                message.addRecipient(Message.RecipientType.TO, new InternetAddress(emailAddress));
                if (toCounter != 0) {
                    ToList = ToList + "; " + emailAddress;
                } else {
                    ToList = ToList + emailAddress;
                }
                toCounter++;
            }

            // CC
            int ccCounter = 0;
            for (String emailAddress : emailCcList) {

                message.addRecipient(Message.RecipientType.CC, new InternetAddress(emailAddress));
                if (ccCounter != 0) {
                    CCList = CCList + "; " + emailAddress;
                } else {
                    CCList = CCList + emailAddress;
                }
                ccCounter++;
            }
            message.setSubject(title);

            Multipart multipart = new MimeMultipart();

            //set text
            BodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setText(content + "\n\n\n -- WorkFusion Server");
            multipart.addBodyPart(messageBodyPart);

            //jav.io.file attachments
            for (int i = 0; i < attachments.length; i++) {

                //for Logging
                if (i != 0) {
                    AttList = AttList + "; " + attachments[i].getName();
                } else {
                    AttList = AttList + attachments[i].getName();
                }

                //set attachment
                messageBodyPart = new MimeBodyPart();
                DataSource source = new FileDataSource(attachments[i]);
                messageBodyPart.setDataHandler(new DataHandler(source));
                messageBodyPart.setFileName(attachments[i].getName());
                multipart.addBodyPart(messageBodyPart);

            }

            message.setContent(multipart);

            //send the message
            Transport.send(message);
            log.warn("Title: '" + title + "'" + " TO: " + ToList + " CC: " + CCList + " with attachment " + AttList + " was sent successfully with " + LogImportance + " importance.");
            return true;

        } catch (MessagingException e) {
            e.printStackTrace();
            log.warn("failed to send '" + title + "' TO: " + ToList + " CC: " + CCList + " with attachment " + AttList + " of " + LogImportance + " importance. ERROR: " + e);
            return false;
        }
    }

    /**
     * Sends an HTML-formatted email with the properties in this class
     */
    public boolean sendHTML() {
        String ToList = "";
        String CCList = "";
        String AttList = "";
        Set<String> emailToList = new HashSet<String>();
        Set<String> emailCcList = new HashSet<String>();

        String LogImportance = "ERROR";
        if (importance.equals("1")) {
            LogImportance = "HIGH";
        } else if (importance.equals("3")) {
            LogImportance = "NORMAL";
        } else if (importance.equals("5")) {
            LogImportance = "LOW";
        }

        Properties props = new Properties();
        props.put("mail.smtp.host", host);

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(user, "");
            }
        });

        //Compose the message
        try {

            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(user));

            message.setHeader("X-Priority", importance);
            //message.setHeader("Content-Type", "text/html");

            emailToList = filterEmailAddressList(to);
            emailCcList = filterEmailAddressList(cc);

            if (emailToList.size() == 0 && emailCcList.size() == 0) {
                log.warn("No emailId to To recipients");
                        return false;
            } else if (emailToList.size() == 0) {
                log.warn("No emailId to To recipients");
                        return false;
            }

            // TO
            int toCounter = 0;
            for (String emailAddress : emailToList) {

                message.addRecipient(Message.RecipientType.TO, new InternetAddress(emailAddress));
                if (toCounter != 0) {
                    ToList = ToList + "; " + emailAddress;
                } else {
                    ToList = ToList + emailAddress;
                }
                toCounter++;
            }

            // CC
            int ccCounter = 0;
            for (String emailAddress : emailCcList) {

                message.addRecipient(Message.RecipientType.CC, new InternetAddress(emailAddress));
                if (ccCounter != 0) {
                    CCList = CCList + "; " + emailAddress;
                } else {
                    CCList = CCList + emailAddress;
                }
                ccCounter++;
            }

            message.setSubject(title);

            Multipart multipart = new MimeMultipart();

            //set text ----- cannot do it if you want inline for some reason
            BodyPart messageBodyPart = new MimeBodyPart();

            //test inline image, html part
            //messageBodyPart = new MimeBodyPart();
            String htmlText = content + "<br><br>"
                    + "<br><span style=\"font-family: Arial !important; font-style:normal; font-size: 10px; color: gray; \">This email and its attachments are confidential. Any unauthorized use or disclosure is prohibited. If you receive this email in error, please notify me by reply email and permanently delete the original without making any copies or disclosing its contents.</span>";
            messageBodyPart.setContent(htmlText, "text/html");
            multipart.addBodyPart(messageBodyPart);

            //jav.io.file attachments
            for (int i = 0; i < attachments.length; i++) {

                //for Logging
                if (i != 0) {
                    AttList = AttList + "; " + attachments[i].getName();
                } else {
                    AttList = AttList + attachments[i].getName();
                }

                //set attachment
                messageBodyPart = new MimeBodyPart();
                DataSource source = new FileDataSource(attachments[i]);
                messageBodyPart.setDataHandler(new DataHandler(source));
                messageBodyPart.setFileName(attachments[i].getName());
                multipart.addBodyPart(messageBodyPart);

            }

            message.setContent(multipart);

            //send the message
            Transport.send(message);
            log.warn("Title: '" + title + "'" + " TO: " + ToList + " CC: " + CCList + " with attachment " + AttList + " was sent successfully with " + LogImportance + " importance.");
            System.out.println("Email Sent Sucessfully : "+"Title: '" + title + "'" + " TO: " + ToList + " CC: " + CCList + " with attachment " + AttList + " was sent successfully with " + LogImportance + " importance.");
            return true;

        } catch (Exception e) {
            log.warn("failed to send '" + title + "' TO: " + ToList + " CC: " + CCList + " with attachment " + AttList + " of " + LogImportance + " importance. ERROR: " + e);
            e.printStackTrace();
            log.warn("Exception stacktrace::"+e.getStackTrace());
            return false;
        }
    }

    /**
     * Adds a File object into the attachment variable
     *
     * @param file the File object to be attached
     */
    private void addToArrayHelper(File file) {
        File[] tempArr = new File[attachments.length + 1];

        System.arraycopy(attachments, 0, tempArr, 0, attachments.length);
        tempArr[tempArr.length - 1] = file;

        attachments = tempArr;

        log.warn("new ATT[" + tempArr.length + "]:: " + attachments[tempArr.length - 1]);
    }
}
