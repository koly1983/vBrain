/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vbrain.common.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author llihind
 */
public class ConfigNameExtractor {
    public static String compileNodeName (String nodeConfigPath) {
        Pattern pattern = Pattern.compile("\\\\(.*?)\\.json");
        Matcher matcher = pattern.matcher(nodeConfigPath);
        
        String match = "";
        while(matcher.find()) {
           match = matcher.group(1);
        }
        return match;
    }
    
    public static String compileServerName (String url) {
        Pattern pattern = Pattern.compile("(http|https):\\/\\/(.*?)(\\:|\\/)");
        Matcher matcher = pattern.matcher(url);
        
        String match = "";
        while(matcher.find()) {
           match = matcher.group(2);
        }
        return match;
    }
    
    public static String compileServerUrl (String url) {
        Pattern pattern = Pattern.compile("(http|https):\\/\\/(.*?)(\\:|\\/)");
        Matcher matcher = pattern.matcher(url);
        
        String match = "";
        while(matcher.find()) {
           match = matcher.group(1)+"://"+matcher.group(2);
           
        }
        return match;
    }
    
    
    public static String compileLastPort (String url) {
        Pattern pattern = Pattern.compile(":(?:.(?!:))+($)");
        Matcher matcher = pattern.matcher(url);
        
        String match = "";
        while(matcher.find()) {
           match = matcher.group();
           
        }
        return match;
    }
}
