package com.vbrain.common.util;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vbrain.adapter.CommonDbAdapter;
import com.vbrain.adapter.impl.CommonDbAdapterImpl;
import com.vbrain.hibernate.model.Email;

public class SlaBreachNotifier {
	ResultSet rs;

	public SlaBreachNotifier(ResultSet rs) {
		this.rs = rs;	
	}

	public void notifyToSupportTeam(String emailAddress) {
		Logger log = LoggerFactory.getLogger(SlaBreachNotifier.class);
		String htmlContent = generateNotificationContent();
		System.out.println("Generated html content is"+htmlContent);
		try {
			if(htmlContent != null) {
			WFEmail email = new WFEmail(log, new String[] {emailAddress}, new String[1], "***IMP-SLA Breached Records***", htmlContent);
			email.sendHTML();
			System.out.println("Completed Sending SLA Breach Email");
			}
		} 
		catch (Exception e) {
			e.printStackTrace();
		}

	}

	private String generateNotificationContent() {
		StringBuffer content = new StringBuffer();
		try {
			boolean hasResults = false;
			if(rs == null) {
				return null;
			}
			content.append("<html><head><style>table,th,td{border: 1px solid black}</style></thead><body>");
			content.append("<P>Hi Team, </br> Below Records Breached the Configured SLA </p>");
			content.append("<table>");
			content.append("<thead><tr>");
			content.append("<td>Business Process Name</td><td>Start Time</td><td>End Time</td><td>Total Processing Time(In Seconds)</td><td>Tracking ID</td><td>Description</td>");
			content.append("</tr></thead>");
			content.append("<tbody>");	
			while(rs.next()) {
				hasResults = true;
				content.append("<tr><td>");
				content.append(rs.getString("CAMPAIGN_NAME") != null ? rs.getString("CAMPAIGN_NAME").toString() : "NA" );
				content.append("</td><td>");
				content.append(rs.getString("START_TIME") != null ? rs.getString("START_TIME") : "NA" );
				content.append("</td><td>");
				content.append(rs.getString("END_TIME") != null ? rs.getString("END_TIME") : "NA" );
				content.append("</td><td>");
				content.append(rs.getString("DURATION") != null ? rs.getString("DURATION") : "NA");
				content.append("</td><td>");
				content.append(rs.getString("TRACKING_ID") != null ? rs.getString("TRACKING_ID") : "NA");
				content.append("</td><td>");
				content.append(rs.getString("DESCRIPTION") != "null" ? rs.getString("DESCRIPTION") : "NA");
				content.append("</td></tr>");
			}
			content.append("</tbody>");
			content.append("</table>");
			content.append("</body></html>");
			if(!hasResults) {
				return null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return content.toString();
	}
}
