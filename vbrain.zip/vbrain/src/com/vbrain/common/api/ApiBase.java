package  com.vbrain.common.api;

import java.io.IOException;
import java.net.ProxySelector;
import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.protocol.HTTP;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.ProxyAuthenticationStrategy;
import org.apache.http.impl.conn.SystemDefaultRoutePlanner;
import org.apache.http.impl.client.HttpClients;

public class ApiBase{
	
	/**
	 * create api connection with proxy credentials
	 *
	 * @param 				String proxyurl**
	 *						*String proxyport
	 *						**String proxyusername
	 *						***String proxypassword 
	 *
	 * @return              CloseableHttpClient client
	 */
    public CloseableHttpClient createConnection(String PROXY_URL, int PROXY_PORT, String PROXY_USERNAME, String PROXY_PASSWORD){

        BasicCredentialsProvider credentialProvider = new BasicCredentialsProvider();
        credentialProvider.setCredentials(new AuthScope(PROXY_URL, PROXY_PORT),
                new UsernamePasswordCredentials(PROXY_USERNAME, PROXY_PASSWORD));
        HttpHost proxyConfig = new HttpHost(PROXY_URL, PROXY_PORT);


        HttpClientBuilder clientBuilder = HttpClientBuilder.create();
        clientBuilder
                .setProxy(proxyConfig)
                .setProxyAuthenticationStrategy(new ProxyAuthenticationStrategy())
                .setDefaultCredentialsProvider(credentialProvider)
                .disableCookieManagement();

        CloseableHttpClient client = clientBuilder.build();
        return client;

    }

	/**
	 * create api connection without proxy credentials
	 *
	 *
	 * @return              CloseableHttpClient client
	 */
    public CloseableHttpClient createConnection(){
        CloseableHttpClient client = HttpClients.custom()
                .setRoutePlanner(new
                SystemDefaultRoutePlanner(ProxySelector.getDefault()))
                .build();

        return client;
    }

	/* Creates get request */
    public HttpPost createPostMethod(String API_URL){
        HttpPost httpPost = new HttpPost(API_URL);
        return httpPost;
    }

	/* Creates post request */
    public HttpGet createGetMethod(String API_URL){
        HttpGet httpGet = new HttpGet(API_URL);
        return httpGet;
    }

	/**
	 * execute post request
	 *
	 * @param 				org.apache.http.client.methods.HttpPost**
	 *						*org.apache.http.impl.client.CloseableHttpClient
	 *						**org.apache.http.entity.StringEntity
	 *						***String content_type
	 *						****String api_username
	 *						*****String api_password
	 *
	 * @return              CloseableHttpResponse response
	 */
    public CloseableHttpResponse executeRequest(HttpPost method, CloseableHttpClient client,StringEntity BODY_CONTENT, String content_Type, String API_USERNAME, String API_PASSWORD) throws IOException{
        final UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(API_USERNAME, API_PASSWORD);

        Header authorization = BasicScheme.authenticate(credentials, HTTP.UTF_8, false);

        method.addHeader(authorization);
        BODY_CONTENT.setContentType(content_Type);
        method.setEntity(BODY_CONTENT);

        final CloseableHttpResponse response = client.execute(method);
		
		return response;
    }
	
	/**
	 * execute get request
	 *
	 * @param 				org.apache.http.client.methods.HttpPost**
	 *						*org.apache.http.impl.client.CloseableHttpClient
	 *						**String api_username
	 *						***String api_password
	 *
	 * @return              CloseableHttpResponse response
	 */
	public CloseableHttpResponse executeRequest(HttpGet method, CloseableHttpClient client, String API_USERNAME, String API_PASSWORD) throws IOException{
		final UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(API_USERNAME, API_PASSWORD);

		Header authorization = BasicScheme.authenticate(credentials, HTTP.UTF_8, false);

		method.addHeader(authorization);

		final CloseableHttpResponse response = client.execute(method);
		
		return response;
	}
        
        public CloseableHttpResponse executeRequest(HttpGet method, CloseableHttpClient client) throws IOException{
		final CloseableHttpResponse response = client.execute(method);
		
		return response;
	}
}