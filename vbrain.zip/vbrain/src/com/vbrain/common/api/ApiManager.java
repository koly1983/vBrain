package  com.vbrain.common.api;

//import com.bmo.cdnaml.fiu.webir.common.*

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.entity.StringEntity;

public class ApiManager{
    IApiCallManager apiManager;

    public ApiManager(IApiCallManager apiManager) {
        this.apiManager=apiManager;
    }

	/*Start executing api calls*/
    public String executeCall(String url) throws Exception{
		StringEntity entity = apiManager.compileInput();
		CloseableHttpResponse response = apiManager.executeApiCall(entity,url);
		String finalOutput  = apiManager.compileOutput(response);
                
                return finalOutput;
    }

}
