package  com.vbrain.common.api;

//import com.bmo.cdnaml.fiu.webir.model.IContainData;


import java.io.IOException;
import java.io.UnsupportedEncodingException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.entity.StringEntity;

        
public interface IApiCallManager {
    
    public StringEntity compileInput() throws UnsupportedEncodingException;

    public CloseableHttpResponse executeApiCall(StringEntity BODY_CONTENT, String url) throws IOException;

    public String compileOutput(CloseableHttpResponse ApiResponse) throws Exception;
}