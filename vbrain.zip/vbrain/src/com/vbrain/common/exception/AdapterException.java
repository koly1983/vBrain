package com.vbrain.common.exception;

public class AdapterException extends Exception{
    
    private static final long serialVersionUID = -6298857319441954087L;

    public AdapterException(Exception exception) {
        super(exception);
    }
    
    public AdapterException(String message) {
        super(message);
    }
}
