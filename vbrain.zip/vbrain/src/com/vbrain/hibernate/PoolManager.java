/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vbrain.hibernate;

import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;

/**
 * Hibernate Utility class with a convenient method to get Session Factory
 * object.
 *
 * @author llihind
 */
public class PoolManager {

    private static final SessionFactory sessionFactory;
    
    private static final SessionFactory sqlSessionFactory;
    private static final SessionFactory accessSessionFactory;
    
    static {
        try {
            // Create the SessionFactory from standard (hibernate.cfg.xml) 
            // config file.
        	sqlSessionFactory = new Configuration().configure("hibernate_sql.cfg.xml").buildSessionFactory();
        } catch (Throwable ex) {
            // Log the exception. 
            System.err.println("Initial SqlSessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }
    
    static {
        try {
            // Create the SessionFactory from standard (hibernate_access.cfg) 
            // config file.
            accessSessionFactory = new Configuration().configure("hibernate_access.cfg.xml").buildSessionFactory();
        } catch (Throwable ex) {
            // Log the exception. 
            System.err.println("Initial AccessSessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }
    
    public static SessionFactory getSqlSessionFactory() {
        return sqlSessionFactory;
    }
    
    public static SessionFactory getAccessSessionFactory() {
        return accessSessionFactory;
    }
    
    static {
        try {
            // Create the SessionFactory from standard (hibernate.cfg.xml) 
            // config file.
            sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();
        } catch (Throwable ex) {
            // Log the exception. 
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }
    
    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}
